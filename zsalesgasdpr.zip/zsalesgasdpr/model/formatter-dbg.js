
sap.ui.define([], function () {
    "use strict";
    return {
        addValues: function (Pstation1, Pstation2, Pstation3, Pstation4){
            return parseInt(Pstation1)+parseInt(Pstation2)+parseInt(Pstation3)+parseInt(Pstation4);
            }
}
});