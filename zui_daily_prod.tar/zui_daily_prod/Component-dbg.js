sap.ui.define(["sap/suite/ui/generic/template/lib/AppComponent"],function(e){"use strict";return e.extend("com.ui.crescent.zuidailyprodreport.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component-dbg.js.map
