sap.ui.define([
    "sap/m/PDFViewer",
    "sap/m/BusyDialog",
    "sap/m/MessageBox",
    "sap/ui/core/format/DateFormat",
], function (PDFViewer, BusyDialog, MessageBox,DateFormat) {
    'use strict';

    return {
        /**
         * Action triggered on print preview
         * @param {object} oEvent sap.ui.base.Event
         */
        onPrint: async function (oEvent) {
            try {
                const oModel = oEvent.getSource().getModel();
                const oData = oEvent.getSource().getBindingContext().getObject();
                if (oData) {
                    var opdfViewer = new PDFViewer();
                    this.getView().addDependent(opdfViewer);
                    var oBusyDialog = new BusyDialog({
                        title: 'Generating Form...'
                    });
                    oBusyDialog.open()
                    var vPDF = await this.getPDFData(oData, oModel);
                    if (vPDF?.results[0]?.stream_data) {
                        let base64EncodedPDF = vPDF.results[0].stream_data;
                        let decodedPdfContent = atob(base64EncodedPDF);
                        let byteArray = new Uint8Array(decodedPdfContent.length);
                        for (var i = 0; i < decodedPdfContent.length; i++) {
                            byteArray[i] = decodedPdfContent.charCodeAt(i);
                        }
                        var blob = new Blob([byteArray.buffer], {
                            type: 'application/pdf'
                        });
                        var pdfurl = URL.createObjectURL(blob);
                        jQuery.sap.addUrlWhitelist("blob"); // register blob url as whitelist
                        opdfViewer.setSource(pdfurl);
                        opdfViewer.setVisible(true);
                        var title = this.getView().getModel("i18n").getResourceBundle().getText("pdfTitle");
                        opdfViewer.setTitle(title);
                        opdfViewer.open();
                    }
                    oBusyDialog.close();
                }
            }
            catch (e) {
                oBusyDialog.close();
            }
        },

        /**
         * Returns the response of printPreview oData call
         * @param {string} sId Table ID
         * @returns {object}  oData response
         */
        getPDFData: async function (oData, oModel) {
            var sPath = oModel.createKey("/Print", { "p_contract": oData.Vbeln, "p_yearmonth": oData.zyearmonth }) + "/Set";

            return new Promise((resolve, reject) => {
                // Perform Read operation and pass billingdoc as parameter to URL
                oModel.read(sPath,
                    {
                        success: function (oData, oResponse) {
                            resolve(oData);
                        },
                        error: function (oError) {
                            reject(oError);
                        }
                    });
            })
        },

        /**
         * Returns the date in Odata format
         * @param {date} date Date()
         * @returns {string}  odata date format
         */
        getOdataDate: function (date) {
            const year = date.getFullYear();
            const month = String(date.getMonth() + 1).padStart(2, '0');
            const day = String(date.getDate()).padStart(2, '0');

            return `datetime'${year}-${month}-${day}T00:00:00'`;
        },

        /**
         * Action triggered on Generate
         * @param {object} oEvent sap.ui.base.Event
         */
        onGenerate: function (oEvent) {
            this.onGenerate(oEvent, "Generate");
        },

        /**
         * Action triggered on Revise
         * @param {object} oEvent sap.ui.base.Event
         */
        onRevise: function (oEvent) {
            this.onRevise(oEvent, "revise");
        },

        /**
         * Function for generate/revise
         * @param {object} oEvent sap.ui.base.Event
         * @param {string} sId action Id
         */
        onGenerate: async function (oEvent, sId) {
            try {
                const oModel = oEvent?.getSource()?.getModel();
                const oData = oEvent?.getSource()?.getBindingContext()?.getObject();
                if (oData) {
                    var oBusyDialog = new BusyDialog();
                    oBusyDialog.open()
                    const aResponse = await this.getGenerateData(oData, oModel, sId);
                    const oResponse = aResponse?.results[0];
                    oBusyDialog.close();
                    oModel.refresh();
                    if (oResponse?.msgty === 'S') {
                        MessageBox.success(oResponse?.msg, {
                            title: "Success",
                            onClose: function () {
                            }
                        });
                    }
                    else {
                        MessageBox.error(oResponse?.msg, {
                            title: "Error",
                            onClose: function () {
                            }
                        });
                    }
                }
            }
            catch (e) {
                oBusyDialog.close();
            }
        },


            /**
                     * Function for generate/revise
                     * @param {object} oEvent sap.ui.base.Event
                     * @param {string} sId action Id
                     */
            onGenerateSales: async function (oEvent, sId) {
                try {
                    const oModel = oEvent?.getSource()?.getModel();
                    const oData = oEvent?.getSource()?.getBindingContext()?.getObject();
                    if (oData) {
                        var oBusyDialog = new BusyDialog();
                        oBusyDialog.open()
                        const aResponse = await this.getGenerateSales(oData, oModel, sId);
                        const oResponse = aResponse?.results[0];
                        oBusyDialog.close();
                        oModel.refresh();
                        if (oResponse?.msgty === 'S') {
                            MessageBox.success(oResponse?.msg, {
                                title: "Success",
                                onClose: function () {
                                }
                            });
                        }
                        else {
                            MessageBox.error(oResponse?.msg, {
                                title: "Error",
                                onClose: function () {
                                }
                            });
                        }
                    }
                }
                catch (e) {
                    oBusyDialog.close();
                }
            },

        /**
                * Function for revise
                * @param {object} oEvent sap.ui.base.Event
                * @param {string} sId action Id
                */
        onRevise: async function (oEvent, sId) {
            try {
                const oModel = oEvent?.getSource()?.getModel();
                const oData = oEvent?.getSource()?.getBindingContext()?.getObject();
                if (oData) {
                    var oBusyDialog = new BusyDialog();
                    oBusyDialog.open()
                    const aResponse = await this.getReviseData(oData, oModel, sId);
                    const oResponse = aResponse?.results[0];
                    oBusyDialog.close();
                    oModel.refresh();
                    if (oResponse?.msgty === 'S') {
                        MessageBox.success(oResponse?.msg, {
                            title: "Success",
                            onClose: function () {
                            }
                        });
                    }
                    else {
                        MessageBox.error(oResponse?.msg, {
                            title: "Error",
                            onClose: function () {
                            }
                        });
                    }
                }
            }
            catch (e) {
                oBusyDialog.close();
            }
        },


        /**
         * Returns the response of Generate/Response oData call
         * @param {object}  oData response
         * @param {object}  oModel data model
         * @param  {string} sId action Id
         */
        getGenerateData: async function (oData, oModel, sId) {
            var sPath = oModel.createKey("/Generate", { "p_contract": oData.Vbeln, "p_yearmonth": oData.zyearmonth }) + "/Set";
            return new Promise((resolve, reject) => {
                // Perform Read operation and pass billingdoc as parameter to URL
                oModel.read(sPath,
                    {
                        success: function (oData, oResponse) {
                            resolve(oData);
                        },
                        error: function (oError) {
                            reject(oError);
                        }
                    });
            })
        },
        /**
                 * Returns the response of Generate/Response oData call
                 * @param {object}  oData response
                 * @param {object}  oModel data model
                 * @param  {string} sId action Id
                 */
        getGenerateSales: async function (oData, oModel, sId) {
            var sPath = oModel.createKey("/CreateSales", { "p_contract": oData.Vbeln, "p_yearmonth": oData.zyearmonth }) + "/Set";
            return new Promise((resolve, reject) => {
                // Perform Read operation and pass billingdoc as parameter to URL
                oModel.read(sPath,
                    {
                        success: function (oData, oResponse) {
                            resolve(oData);
                        },
                        error: function (oError) {
                            reject(oError);
                        }
                    });
            })
        },

        /**
                 * Returns the response of Generate/Response oData call
                 * @param {object}  oData response
                 * @param {object}  oModel data model
                 * @param  {string} sId action Id
                 */
        getReviseData: async function (oData, oModel, sId) {
            var sPath = oModel.createKey("/Revise", { "p_contract": oData.Vbeln, "p_yearmonth": oData.zyearmonth }) + "/Set";
            return new Promise((resolve, reject) => {
                // Perform Read operation and pass billingdoc as parameter to URL
                oModel.read(sPath,
                    {
                        success: function (oData, oResponse) {
                            resolve(oData);
                        },
                        error: function (oError) {
                            reject(oError);
                        }
                    });
            })
        },
         /**
        * Returns the response of Generate/Response oData call
        * @param {object}  oData response
        * @param {object}  oModel data model
        * @param  {string} sId action Id
        */
         onUpload: async function (oData, oModel, sId) {
            if (!this.importDialog) {
                //create instance of fragment
                this.importDialog = sap.ui.xmlfragment("com.crescent.ui.dpr.monthly.zuimonthlyprod.ext.fragment.fileUpload", this);
            }
            this.getView().addDependent(this.importDialog);
            this.importDialog.open();

        },
        /**
        * Returns the response of Generate/Response oData call
        * @param {object}  oData response
        * @param {object}  oModel data model
        * @param  {string} sId action Id
        */
        handleCancelPress: async function (oData, oModel, sId) {
            this.importDialog.close();
            this.importDialog.destroy();
            this.importDialog = null;
        },


        handleUploadPress: async function (oData, oModel, sId) {
            //perform upload
            var oModel = this.getView().getModel();
            var oResourceBundle = this.getView().getModel("i18n").getResourceBundle();
            var oData = oData?.getSource()?.getBindingContext()?.getObject();
            var contractData = oData.Vbeln;
            var date = DateFormat.getDateInstance({ pattern: "MMdd" }).format(oData.zyearmonth);

            var oFileUploader = sap.ui.getCore().byId("fupImportMonthly");
            var sMsg = "";

            //check file has been entered
            var sFile = oFileUploader.getValue();
            if (!sFile) {
                sMsg = "Please select a file first";
                sap.m.MessageToast.show(sMsg);
                return;
            }
            else {
                var that = this;
                that._addTokenToUploader(contractData, date);
                oFileUploader.upload();
                that.importDialog.close();

            }

        },

        _addTokenToUploader: function (contractData, date) {
            //Add header parameters to file uploader.
            var oDataModel = this.getView().getModel('gasAttachment');
            var sTokenForUpload = oDataModel.getSecurityToken();
            var oFileUploader = sap.ui.getCore().byId("fupImportMonthly");
            var oHeaderParameter = new sap.ui.unified.FileUploaderParameter({
                name: "X-CSRF-Token",
                value: sTokenForUpload
            });

            var sFile = oFileUploader.getValue();
            var oHeaderSlug = new sap.ui.unified.FileUploaderParameter({
                name: "SLUG",
                value: sFile
            });

            //Header parameter need to be removed then added.
            oFileUploader.removeAllHeaderParameters();
            oFileUploader.addHeaderParameter(oHeaderParameter);

            oFileUploader.addHeaderParameter(oHeaderSlug);
            //set upload url
            const sPath = `/ATTACHSet(CONTRACT='${contractData}${date}',REPORT='M')/$value`;
            var sUrl = oDataModel.sServiceUrl + sPath;
            oFileUploader.setUploadUrl(sUrl);
        },

        handleUploadComplete: function (oEvent) {
            var oResourceBundle = this.getView().getModel("i18n").getResourceBundle();
            var sMsg = "";
            var sMsgType = "Error";
            var oResponse = oEvent.getParameters("response");
            if (oResponse) {
                if (oResponse.status === 204) {
                    //TODO use i18n
                    sMsg = oResourceBundle.getText("uploadSuccess");
                    sMsgType = "Information";
                } else {
                    sMsg = oResourceBundle.getText("uploadFailure");
                    sMsgType = "Error";
                }
            }
            this.importDialog.destroy();
            this.importDialog = null;
            sap.m.MessageToast.show(sMsg);
        },
        onDownload: async function (oData, oModel, sId) {
            //perform Download
            var opdfViewer = new PDFViewer();
			this.getView().addDependent(opdfViewer);
            var oDataModel = this.getView().getModel('gasAttachment');
            var oModel = this.getView().getModel();
            var oResourceBundle = this.getView().getModel("i18n").getResourceBundle();
            var oData = oData?.getSource()?.getBindingContext()?.getObject();
            var contractData = oData.Vbeln;
            var date = DateFormat.getDateInstance({ pattern: "MMdd" }).format(oData.zyearmonth);
            const sPath = `/ATTACHSet(CONTRACT='${contractData}${date}',REPORT='M')/$value`;
            var sUrl = oDataModel.sServiceUrl + sPath;
            opdfViewer.setSource(sUrl);
            opdfViewer.setShowDownloadButton(false);
			opdfViewer.open();	
        }

    };
});