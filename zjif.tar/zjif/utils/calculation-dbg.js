sap.ui.define([
    "sap/ui/model/json/JSONModel"
   
], 
function (JSONModel) {
    "use strict";

    return {
        // Function to calculate totals for a specific table
        calculateSubTotals: function (tableId) {
            var table = this.byId(tableId);
            var items = table.getItems();
            var totalITDDec = 0;
            var totalYTDLastMonth = 0;
            var totalCurrentMonth = 0;
            var totalYTD = 0;
            var totalInception = 0;

            // Calculate totals for each column
            items.forEach(function (item) {
                var cells = item.getCells();
                totalITDDec += parseInt(cells[1].getText().replace(/[$,]/g, ''));
                totalYTDLastMonth += parseInt(cells[2].getText().replace(/[$,]/g, ''));
                totalCurrentMonth += parseInt(cells[3].getText().replace(/[$,]/g, ''));
                totalYTD += parseInt(cells[4].getText().replace(/[$,]/g, ''));
                totalInception += parseInt(cells[5].getText().replace(/[$,]/g, ''));
            });
            var totals = {
                ITDDec: parseInt(totalITDDec).toString(),
                YearToDateLastMonth: parseInt(totalYTDLastMonth).toString(),
                CurrentMonth: parseInt(totalCurrentMonth).toString(),
                YearToDate: parseInt(totalYTD).toString(),
                InceptionTillDate: parseInt(totalInception).toString()
            };

            // Create a JSON model for totals and set it to the view
            var oModel = new JSONModel({
                totals: totals
            });
            this.getView().setModel(oModel, "totals_" + tableId);
        },

        calculateTotals: function (tableIds) {
            var totalITDDec = 0;
            var totalYTDLastMonth = 0;
            var totalCurrentMonth = 0;
            var totalYTD = 0;
            var totalInception = 0;

            tableIds.forEach(tableId => {
                const model = this.getView().getModel("totals_" + tableId);
                if (model) {
                    const data = model.getData();
                    if (data.totals) {
                        totalITDDec += parseInt(Number(data.totals.ITDDec)) || 0;
                        totalYTDLastMonth += parseInt(Number(data.totals.YearToDateLastMonth)) || 0;
                        totalCurrentMonth += parseInt(Number(data.totals.CurrentMonth)) || 0;
                        totalYTD += parseInt(Number(data.totals.YearToDate)) || 0;
                        totalInception += parseInt(Number(data.totals.InceptionTillDate)) || 0;
                    }
                } else {
                    console.warn("Model not found for tableId:", tableId);
                }
            });

            return {
                ITDDec: parseInt(totalITDDec).toString(),
                YTDLastMonth: parseInt(totalYTDLastMonth).toString(),
                CurrentMonth: parseInt(totalCurrentMonth).toString(),
                YTD: parseInt(totalYTD).toString(),
                Inception: parseInt(totalInception).toString()
            };  // Return the totals as an object
        },

        computeGrandTotal: function () {
            const A = this.calculateTotals(['tblKM250ExProjA1SD', 'tblKM250ExProjA2SD','tblKM250ExProjA3SD']); //A = A1 + A2 +A3
            const B = this.calculateTotals(['tblEPActSD', 'tblProComActSD']); //B = B1 + B2
            const C = { //C = A + B
                ITDDec: (Number(A.ITDDec) + Number(B.ITDDec)).toFixed(2),
                YTDLastMonth: (Number(A.YTDLastMonth) + Number(B.YTDLastMonth)).toFixed(2),
                CurrentMonth: (Number(A.CurrentMonth) + Number(B.CurrentMonth)).toFixed(2),
                YTD: (Number(A.YTD) + Number(B.YTD)).toFixed(2),
                Inception: (Number(A.Inception) + Number(B.Inception)).toFixed(2)
            };
            const D = this.calculateTotals(['tblEPActClsdSD', 'tblProComActClsdSD']); //D = D1 + D2
            const E = D;
            const F = this.calculateTotals(['tblIntCstsSD']); //, 'tblNIntCstsD', 'tblSupCstsD']);
            const G = this.calculateTotals(['tblOvhCstsPDAD', 'tblFinCstsPDAD']);
            let H = { //H = C + E + F + G
                ITDDec: (Number(C.ITDDec) + Number(E.ITDDec) + Number(F.ITDDec) + Number(G.ITDDec)).toFixed(2),
                YTDLastMonth: (Number(C.YTDLastMonth) + Number(E.YTDLastMonth) + Number(F.YTDLastMonth) + Number(G.YTDLastMonth)).toFixed(2),
                CurrentMonth: (Number(C.CurrentMonth) + Number(E.CurrentMonth) + Number(F.CurrentMonth) + Number(G.CurrentMonth)).toFixed(2),
                YTD: (Number(C.YTD) + Number(E.YTD) + Number(F.YTD) + Number(G.YTD)).toFixed(2),
                Inception: (Number(C.Inception) + Number(E.Inception) + Number(F.Inception) + Number(G.Inception)).toFixed(2)
            };

            Object.keys(H).forEach((sKey)=>{
                H[sKey] = parseInt(H[sKey]).toString();
            });
            const K = this.calculateTotals(['tblKMCHSD', 'tblKMOpxSD']); //K = I + J
            let R = { //R = H + K
                ITDDec: (Number(H.ITDDec) + Number(K.ITDDec)).toFixed(2),
                YTDLastMonth: (Number(H.YTDLastMonth) + Number(K.YTDLastMonth)).toFixed(2),
                CurrentMonth: (Number(H.CurrentMonth) + Number(K.CurrentMonth)).toFixed(2),
                YTD: (Number(H.YTD) + Number(K.YTD)).toFixed(2),
                Inception: (Number(H.Inception) + Number(K.Inception)).toFixed(2)
            };
            Object.keys(R).forEach((sKey)=>{
                R[sKey] = parseInt(R[sKey]).toString();
            });


            // Set individual models for each total
            this.getView().setModel(new JSONModel(A), "totalA");
            this.getView().setModel(new JSONModel(B), "totalB");
            this.getView().setModel(new JSONModel(C), "totalC");
            this.getView().setModel(new JSONModel(D), "totalD");
            this.getView().setModel(new JSONModel(E), "totalE");
            this.getView().setModel(new JSONModel(F), "totalF");
            this.getView().setModel(new JSONModel(G), "totalG");
            this.getView().setModel(new JSONModel(H), "totalH");
            this.getView().setModel(new JSONModel(K), "totalK");


            // Set the grand total model
            //const grandTotalModel = new JSONModel({ S: S });
            this.getView().setModel(new JSONModel(R), "grandTotal");
            //this.getView().setModel(grandTotalModel, "grandTotalModel");
        },
    };

});