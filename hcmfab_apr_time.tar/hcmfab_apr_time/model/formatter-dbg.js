/*
 * Copyright (C) 2009-2017 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([], function () {
 "use strict";

 return {

  /**
   * Rounds the number unit value to 2 digits
   * @public
   * @param {string} sValue the number string to be rounded
   * @returns {string} sValue with 2 digits rounded
   */
  numberUnit: function (sValue) {
   if (!sValue) {
    return "";
   }
   return parseFloat(sValue).toFixed(2);
  },
  formatDate: function (oDate) {
   if (oDate === undefined)
    return "";

   var oDateFormat = sap.ui.core.format.DateFormat.getInstance({
    pattern: "YYYY-MM-dd"
   });

   return oDateFormat.format(oDate);
  },
  formatEntries: function (amount, unit) {
   this.oBundle = this.getModel("i18n").getResourceBundle();
   if (unit === "H") {
    var r = parseFloat(amount, 10).toFixed(2);
    r = r + " " + this.oBundle.getText("hours");
    return r;
   } else {
    var ret = parseFloat(amount, 10).toFixed(2);
    ret = ret + " " + unit;
    return ret;
   }
  },
  formatHours: function (amount, unit) {
   this.self.oBundle = this.self.getModel("i18n").getResourceBundle();
   if (unit === "H") {
    var r = parseFloat(amount, 10).toFixed(2);
    r = r + " " + this.self.oBundle.getText("hours");
    return r;
   } else {
    var ret = parseFloat(amount, 10).toFixed(2);
    ret = ret + " " + unit;
    return ret;
   }
  },
  status: function (sValue) {
   this.self.oBundle = this.self.getModel("i18n").getResourceBundle();
   if (sValue === '10') {
    return this.self.oBundle.getText("inprocess");
   } else if (sValue === '20') {
    return this.self.oBundle.getText("releasedforapproval");
   } else if (sValue === '30') {
    return this.self.oBundle.getText("approved");
   } else if (sValue === '40') {
    return this.self.oBundle.getText("approvalrejected");
   } else if (sValue === '50') {
    return this.self.oBundle.getText("changedafterapproval");
   } else if (sValue === '60') {
    return this.self.oBundle.getText("cancelled");
   }

  },
  formatTotalToTarget: function (total, target) {
   this.oBundle = this.getModel("i18n").getResourceBundle();
   var r = parseFloat(total, 10).toFixed(2) + " / " + parseFloat(target, 10).toFixed(2);
   r = r + " " + this.oBundle.getText("hours");
   return r;
  },
  formatState: function (total, target, approved) {
   // No legend yet coloring is generic
   var totalVal = parseFloat(total, 10).toFixed(2);
   //processing total if fractional part exists and if length of the fraction is more than 2 then trailing 
   //numbers are removed to prevent inconsistencies in target total 
   var targetVal = parseFloat(target, 10).toFixed(2);
   var approvedVal = parseFloat(approved, 10).toFixed(2);
   if ((parseFloat(totalVal) + parseFloat(approvedVal)) > parseFloat(targetVal)) {
    return "Error";
   } else if ((parseFloat(totalVal) + parseFloat(approvedVal)) == parseFloat(targetVal)) {
    return "Success";
   } else {
    // return "Warning";
   }
  },
  formatApprovedHours: function (hours) {
   this.oBundle = this.getModel("i18n").getResourceBundle();
   var r = parseFloat(hours, 10).toFixed(2);
   r = r + " " + this.oBundle.getText("hours");
   return r;
  },
  formatTotals: function (units) {
   this.oBundle = this.getModel("i18n").getResourceBundle();
   var r = parseInt(units, 10);
   if (r == 1) {
    r = r + " " + this.oBundle.getText("entry");
   } else {
    r = r + " " + this.oBundle.getText("entries");
   }
   return r;
  },
  formatNumberUnit: function (noOfUnits) {
   if (noOfUnits == "") {
    return noOfUnits;
   }
   this.oBundle = this.getModel("i18n").getResourceBundle();
   var r = parseInt(noOfUnits, 10);
   if (r == 1) {
    r = this.oBundle.getText("entry");
   } else {
    r = this.oBundle.getText("entries");
   }
   return r;
  },
  visibility: function (sValue) {
   if (sValue == 'X') {
    return true;
   } else {
    return false;
   }
  },
  historyVisibility: function (sValue) {
   if (sValue == '') {
    return false;
   } else {
    return true;
   }
  },
  /**
   * extracts the service path from the given absolute URL
   * @public
   * @param {string} sURL absolute URL
   * @returns {string} service path
   */
  formatImageURL: function (sMediaSrc) {
   var sUrl = "";
   if (sMediaSrc && typeof sMediaSrc === "string") {
    var oLink = document.createElement("a");
    oLink.href = sMediaSrc;
    sUrl = (oLink.pathname.charAt(0) === "/") ? oLink.pathname : "/" + oLink.pathname;
   }
   return sUrl;
  },
  getGroupHeader: function (oGroup) {
   return 0;
  },
  dateStringFormat: function (sValue) {
   var adjustedDate = new Date(sValue.getTime() - sValue.getTimezoneOffset() * 60000);
   this.oDateFullFormat = sap.ui.core.format.DateFormat.getDateInstance({
    UTC: true,
    style: "full",
    calendarType: sap.ui.core.CalendarType.Gregorian
   });
   return String(this.oDateFullFormat.format(adjustedDate));
  },

  formatEmployeeID: function (empId) {
   return parseInt(empId, 10);
  }
 };

});
