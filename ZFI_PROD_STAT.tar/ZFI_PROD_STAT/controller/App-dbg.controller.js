sap.ui.define(
    [
        "sap/ui/core/mvc/Controller",
        "sap/ui/model/Filter",
        "sap/ui/model/json/JSONModel",
        "sap/m/MessageBox",
        "sap/m/PDFViewer",
        "sap/m/BusyDialog",
        "sap/base/util/UriParameters"
    ],
    function (BaseController, Filter, JSONModel, MessageBox, PDFViewer, BusyDialog, UriParameters) {
        "use strict";
        var inbox = '',
            monthYear = '',
            monthYearFormatted = '',
            plant = '',
            unit = '';
        return BaseController.extend("com.ui.crescent.zuiproductionstatement.controller.App", {
            onInit() {
                let oProdModel, oView;
                const oData = {
                    items: [

                    ],
                    status: [],
                    header: {
                        Generate: false,
                        Display: true
                    }
                }
                oProdModel = new JSONModel(oData);
                oView = this.getView();
                oView.setModel(oProdModel, "oProdModel");
                this.inbox = '';
                if (window.location.href.split("?").length > 2) {
                    this.monthYear = window.location.href.split("?")[2].split("&")[0].split("=")[1];
                    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                    let part1 = this.monthYear.slice(0, 4);
                    let part2 = this.monthYear.slice(4, 6);
                    let part = part1.concat("-", part2);
                    const d = new Date(part);
                    var monString = months[d.getMonth()];
                    this.monthYearFormatted = monString.concat("-", part1);
                    this.plant = window.location.href.split("?")[2].split("&")[1].split("=")[1];
                    this.unit = window.location.href.split("?")[2].split("&")[2].split("=")[1];
                    this.inbox = 'X';
                }

            },

            onPlantInitialize() {
                if (this.inbox == 'X') {
                    this.byId("Plant").setValue(this.plant);
                    this.byId("year").setValue(this.monthYearFormatted);

                } else {
                    this.byId("Plant").setValue("5021");

                }

            },

            onUnitInitialize() {
                if (this.inbox == 'X') {
                    this.byId("Unit").setValue(this.unit);
                    this.inbox = ''; // This is the last method called.
                } else {
                    this.byId("Unit").setValue("ISP");
                }


            },

            onAfterRendering: function () {
                if (this.inbox == 'X') {
                    this.getData();
                }
            },


            getData: async function () {
                try {
                    let oModel, oView;
                    var sMonYear, sPlant, sUnit;
                    oView = this.getView();
                    oModel = oView.getModel();
                    var oBusyDialog = new BusyDialog();
                    oBusyDialog.open();
                    //Get the Plant Value
                    sPlant = oView?.byId("Plant")?.getValue();

                    //Get the Unit Value
                    sUnit = oView?.byId("Unit")?.getValue();

                    //Get Month and Year
                    let sViewDate = oView.byId("year")?.getDateValue();
                    if (sViewDate) {
                        sMonYear = this.getMonthYear(sViewDate);
                    }


                    if (this.inbox == 'X') {
                        sPlant = this.plant;
                        sUnit = this.unit;
                        sMonYear = this.monthYear;

                    }

                    if (sPlant && sUnit && sMonYear) {
                        const aFilters = [
                            new Filter({
                                path: "Plant",
                                operator: "EQ",
                                value1: sPlant
                            }),
                            new Filter({
                                path: "Unit",
                                operator: "EQ",
                                value1: sUnit
                            }),
                            new Filter({
                                path: "MonthYear",
                                operator: "EQ",
                                value1: sMonYear
                            })
                        ];

                        const aFilterStatus = [
                            new Filter({
                                path: "Plant",
                                operator: "EQ",
                                value1: sPlant
                            }),
                            new Filter({
                                path: "Matnr",
                                operator: "EQ",
                                value1: sUnit
                            }),
                            new Filter({
                                path: "Zyearmonth",
                                operator: "EQ",
                                value1: sMonYear
                            })
                        ];

                        const aFilterStatusDet = [
                            new Filter({
                                path: "Unit",
                                operator: "EQ",
                                value1: sUnit
                            }),
                            new Filter({
                                path: "MonthYear",
                                operator: "EQ",
                                value1: sMonYear
                            }),
                            new Filter({
                                path: "Plant",
                                operator: "EQ",
                                value1: sPlant
                            })
                        ];


                        let oProdModel = oView.getModel("oProdModel");
                        //Fetch the header data
                        this.setProdHeader(oModel, oProdModel, aFilters);
                        //Fetch the Items data
                        this.setProdItems(oModel, oProdModel, aFilters);
                        //Fetch the Status data
                        this.setProdStatus(oModel, oProdModel, aFilterStatus);
                        //Fetch the Status Detail data
                        this.setProdStatusDet(oModel, oProdModel, aFilterStatusDet);


                        oBusyDialog.close();

                    } else {
                        oBusyDialog.close();
                        MessageBox.error("Enter the Mandatory Fields.", {
                            title: "Error",
                            onClose: function () {
                            }
                        });
                    }


                }
                catch (e) {
                    oBusyDialog.close();
                    MessageBox.error("Error..Check console", {
                        title: "Error",
                        onClose: function () {
                        }
                    });
                }
            },

            setProdHeader: async function (oModel, oProdModel, aFilters) {

                const sPath = `/ProdStatmentHeaderSet`;
                const oData = await this.getProductionData(oModel, aFilters, sPath);
                if (oData && oData?.results[0]) {
                    oProdModel.setProperty("/header", oData?.results[0]);
                    if (oData?.results[0].Display) {
                        oProdModel.setProperty("/header/Display", false);
                    } else {
                        oProdModel.setProperty("/header/Display", true);
                    }
                }else{
                    oProdModel.setProperty("/header", {});
                }
            },

            setProdStatus: async function (oModel, oProdModel, aFilters) {
                const sPath = `/ProdStatItmStatusSet`;
                const oData = await this.getProductionData(oModel, aFilters, sPath);
                if (oData && oData?.results[0]) {
                    oProdModel.setProperty("/status", oData?.results);
                }else{
                    oProdModel.setProperty("/status", {});
                }
            },


            setProdStatusDet: async function (oModel, oProdModel, aFilters) {
                const sPath = `/ProdWFStatusDetailsSet`;
                const oData = await this.getProductionData(oModel, aFilters, sPath);
                if (oData && oData?.results[0]) {
                    oProdModel.setProperty("/statusDet", oData?.results[0]);
                    
                    if (oData.results[0].Status == "") {
                        oProdModel.setProperty("/statusDet/FromTime", "");
                        oProdModel.setProperty("/statusDet/ToTime", "");
                    } else {
                        oProdModel.setProperty("/statusDet/FromTime", "6:00:00");
                        oProdModel.setProperty("/statusDet/ToTime", "6:00:00");
                    }
                }else{
                    oProdModel.setProperty("/statusDet", {});
                }
                if(oData && oData.results[0] && parseInt(oData.results[0].Status) === 2 ){
                    oProdModel.setProperty("/saveVisible",false);
                }else{
                    oProdModel.setProperty("/saveVisible",true);
                }
            },

            setProdItems: async function (oModel, oProdModel, aFilters) {
                const sPath = `/ProdStatmentItemSet`;
                let oData = await this.getProductionData(oModel, aFilters, sPath);
                let len = oData.results.length;
                for (var i = 0; i < len; i++) {
                    if (oData.results[i].Sno === '6.1.1') {
                        if (oData.results[i].LpgSg === '0.000') { oData.results[i].LpgSg = 'Null' };
                        if (oData.results[i].LpgRvp === '0.000') { oData.results[i].LpgRvp = '' };
                        if (oData.results[i].LpgBbls === '0.000') { oData.results[i].LpgBbls = 'Null' };
                        if (oData.results[i].LpgMt === '0.000') { oData.results[i].LpgMt = 'Null' };

                        if (oData.results[i].CondBbls === '0.000') { oData.results[i].CondBbls = 'Null' };
                        if (oData.results[i].CondMt === '0.000') { oData.results[i].CondMt = 'Null' };
                        if (oData.results[i].CondRvp === '0.000') { oData.results[i].CondRvp = 'Null' };
                        if (oData.results[i].CondSg === '0.000') { oData.results[i].CondSg = 'Null' };

                        if (oData.results[i].FlaredGasMt === '0.000') { oData.results[i].FlaredGasMt = '' };
                        if (oData.results[i].FlaredGasNm3 === '0.000') { oData.results[i].FlaredGasNm3 = '' };

                        if (oData.results[i].GasBtu === '0.000') { oData.results[i].GasBtu = 'Null' };
                        if (oData.results[i].GasHc === '0.000') { oData.results[i].GasHc = 'Null' };
                        if (oData.results[i].GasMt === '0.000') { oData.results[i].GasMt = 'Null' };
                        if (oData.results[i].GasNm3 === '0.000') { oData.results[i].GasNm3 = 'Null' };
                        if (oData.results[i].GasSg === '0.000') { oData.results[i].GasSg = 'Null' };
                        if (oData.results[i].GasWater === '0.000') { oData.results[i].GasWater = 'Null' };

                    }

                    if (oData.results[i].Sno === '6.1.2') {
                        if (oData.results[i].LpgSg === '0.000') { oData.results[i].LpgSg = '' };
                        if (oData.results[i].LpgRvp === '0.000') { oData.results[i].LpgRvp = '' };
                        if (oData.results[i].LpgBbls === '0.000') { oData.results[i].LpgBbls = '' };
                        if (oData.results[i].LpgMt === '0.000') { oData.results[i].LpgMt = '' };

                        if (oData.results[i].CondBbls === '0.000') { oData.results[i].CondBbls = '' };
                        if (oData.results[i].CondMt === '0.000') { oData.results[i].CondMt = '' };
                        if (oData.results[i].CondRvp === '0.000') { oData.results[i].CondRvp = '' };
                        if (oData.results[i].CondSg === '0.000') { oData.results[i].CondSg = '' };

                        if (oData.results[i].FlaredGasMt === '0.000') { oData.results[i].FlaredGasMt = 'Null' };
                        if (oData.results[i].FlaredGasNm3 === '0.000') { oData.results[i].FlaredGasNm3 = 'Null' };

                        if (oData.results[i].GasBtu === '0.000') { oData.results[i].GasBtu = '' };
                        if (oData.results[i].GasHc === '0.000') { oData.results[i].GasHc = '' };
                        if (oData.results[i].GasMt === '0.000') { oData.results[i].GasMt = 'Null' };
                        if (oData.results[i].GasNm3 === '0.000') { oData.results[i].GasNm3 = 'Null' };
                        if (oData.results[i].GasSg === '0.000') { oData.results[i].GasSg = '' };
                        if (oData.results[i].GasWater === '0.000') { oData.results[i].GasWater = '' };
                    }

                    if (oData.results[i].Sno === '6.1.3') {
                        if (oData.results[i].LpgSg === '0.000') { oData.results[i].LpgSg = '' };
                        if (oData.results[i].LpgRvp === '0.000') { oData.results[i].LpgRvp = '' };
                        if (oData.results[i].LpgBbls === '0.000') { oData.results[i].LpgBbls = 'Null' };
                        if (oData.results[i].LpgMt === '0.000') { oData.results[i].LpgMt = 'Null' };

                        if (oData.results[i].CondBbls === '0.000') { oData.results[i].CondBbls = 'Null' };
                        if (oData.results[i].CondMt === '0.000') { oData.results[i].CondMt = 'Null' };
                        if (oData.results[i].CondRvp === '0.000') { oData.results[i].CondRvp = '' };
                        if (oData.results[i].CondSg === '0.000') { oData.results[i].CondSg = '' };

                        if (oData.results[i].FlaredGasMt === '0.000') { oData.results[i].FlaredGasMt = '' };
                        if (oData.results[i].FlaredGasNm3 === '0.000') { oData.results[i].FlaredGasNm3 = '' };

                        if (oData.results[i].GasBtu === '0.000') { oData.results[i].GasBtu = '' };
                        if (oData.results[i].GasHc === '0.000') { oData.results[i].GasHc = '' };
                        if (oData.results[i].GasMt === '0.000') { oData.results[i].GasMt = '' };
                        if (oData.results[i].GasNm3 === '0.000') { oData.results[i].GasNm3 = '' };
                        if (oData.results[i].GasSg === '0.000') { oData.results[i].GasSg = '' };
                        if (oData.results[i].GasWater === '0.000') { oData.results[i].GasWater = '' };
                    }

                    if (oData.results[i].Sno === '6.1.4') {
                        if (oData.results[i].LpgSg === '0.000') { oData.results[i].LpgSg = '' };
                        if (oData.results[i].LpgRvp === '0.000') { oData.results[i].LpgRvp = '' };
                        if (oData.results[i].LpgBbls === '0.000') { oData.results[i].LpgBbls = 'Null' };
                        if (oData.results[i].LpgMt === '0.000') { oData.results[i].LpgMt = 'Null' };

                        if (oData.results[i].CondBbls === '0.000') { oData.results[i].CondBbls = 'Null' };
                        if (oData.results[i].CondMt === '0.000') { oData.results[i].CondMt = 'Null' };
                        if (oData.results[i].CondRvp === '0.000') { oData.results[i].CondRvp = '' };
                        if (oData.results[i].CondSg === '0.000') { oData.results[i].CondSg = '' };

                        if (oData.results[i].FlaredGasMt === '0.000') { oData.results[i].FlaredGasMt = '' };
                        if (oData.results[i].FlaredGasNm3 === '0.000') { oData.results[i].FlaredGasNm3 = '' };

                        if (oData.results[i].GasBtu === '0.000') { oData.results[i].GasBtu = '' };
                        if (oData.results[i].GasHc === '0.000') { oData.results[i].GasHc = '' };
                        if (oData.results[i].GasMt === '0.000') { oData.results[i].GasMt = '' };
                        if (oData.results[i].GasNm3 === '0.000') { oData.results[i].GasNm3 = '' };
                        if (oData.results[i].GasSg === '0.000') { oData.results[i].GasSg = '' };
                        if (oData.results[i].GasWater === '0.000') { oData.results[i].GasWater = '' };
                    }

                    if (oData.results[i].Sno === '6.1.5') {
                        if (oData.results[i].LpgSg === '0.000') { oData.results[i].LpgSg = '' };
                        if (oData.results[i].LpgRvp === '0.000') { oData.results[i].LpgRvp = '' };
                        if (oData.results[i].CondBbls === '0.000') { oData.results[i].CondBbls = '' };
                        if (oData.results[i].CondMt === '0.000') { oData.results[i].CondMt = '' };
                        if (oData.results[i].CondRvp === '0.000') { oData.results[i].CondRvp = '' };
                        if (oData.results[i].CondSg === '0.000') { oData.results[i].CondSg = '' };
                        if (oData.results[i].FlaredGasMt === '0.000') { oData.results[i].FlaredGasMt = '' };
                        if (oData.results[i].FlaredGasNm3 === '0.000') { oData.results[i].FlaredGasNm3 = '' };
                        if (oData.results[i].GasBtu === '0.000') { oData.results[i].GasBtu = '' };
                        if (oData.results[i].GasHc === '0.000') { oData.results[i].GasHc = '' };
                        if (oData.results[i].GasMt === '0.000') { oData.results[i].GasMt = '' };
                        if (oData.results[i].GasNm3 === '0.000') { oData.results[i].GasNm3 = '' };
                        if (oData.results[i].GasSg === '0.000') { oData.results[i].GasSg = '' };
                        if (oData.results[i].GasWater === '0.000') { oData.results[i].GasWater = '' };
                        if (oData.results[i].LpgBbls === '0.000') { oData.results[i].LpgBbls = '' };
                        if (oData.results[i].LpgMt === '0.000') { oData.results[i].LpgMt = '' };
                    }

                    if (oData.results[i].Sno === '6.1.6') {
                        if (oData.results[i].LpgSg === '0.000') { oData.results[i].LpgSg = '' };
                        if (oData.results[i].LpgRvp === '0.000') { oData.results[i].LpgRvp = '' };
                        if (oData.results[i].LpgBbls === '0.000') { oData.results[i].LpgBbls = 'Null' };
                        if (oData.results[i].LpgMt === '0.000') { oData.results[i].LpgMt = 'Null' };

                        if (oData.results[i].CondBbls === '0.000') { oData.results[i].CondBbls = 'Null' };
                        if (oData.results[i].CondMt === '0.000') { oData.results[i].CondMt = 'Null' };
                        if (oData.results[i].CondRvp === '0.000') { oData.results[i].CondRvp = '' };
                        if (oData.results[i].CondSg === '0.000') { oData.results[i].CondSg = '' };

                        if (oData.results[i].FlaredGasMt === '0.000') { oData.results[i].FlaredGasMt = '' };
                        if (oData.results[i].FlaredGasNm3 === '0.000') { oData.results[i].FlaredGasNm3 = '' };

                        if (oData.results[i].GasBtu === '0.000') { oData.results[i].GasBtu = '' };
                        if (oData.results[i].GasHc === '0.000') { oData.results[i].GasHc = '' };
                        if (oData.results[i].GasMt === '0.000') { oData.results[i].GasMt = 'Null' };
                        if (oData.results[i].GasNm3 === '0.000') { oData.results[i].GasNm3 = 'Null' };
                        if (oData.results[i].GasSg === '0.000') { oData.results[i].GasSg = '' };
                        if (oData.results[i].GasWater === '0.000') { oData.results[i].GasWater = '' };
                    }

                    if (oData.results[i].Sno === '8.2.1') {
                        if (oData.results[i].LpgSg === '0.000') { oData.results[i].LpgSg = '' };
                        if (oData.results[i].LpgRvp === '0.000') { oData.results[i].LpgRvp = '' };
                        if (oData.results[i].LpgBbls === '0.000') { oData.results[i].LpgBbls = 'Null' };
                        if (oData.results[i].LpgMt === '0.000') { oData.results[i].LpgMt = 'Null' };

                        if (oData.results[i].CondBbls === '0.000') { oData.results[i].CondBbls = 'Null' };
                        if (oData.results[i].CondMt === '0.000') { oData.results[i].CondMt = 'Null' };
                        if (oData.results[i].CondRvp === '0.000') { oData.results[i].CondRvp = '' };
                        if (oData.results[i].CondSg === '0.000') { oData.results[i].CondSg = '' };

                        if (oData.results[i].FlaredGasMt === '0.000') { oData.results[i].FlaredGasMt = '' };
                        if (oData.results[i].FlaredGasNm3 === '0.000') { oData.results[i].FlaredGasNm3 = '' };

                        if (oData.results[i].GasBtu === '0.000') { oData.results[i].GasBtu = '' };
                        if (oData.results[i].GasHc === '0.000') { oData.results[i].GasHc = '' };
                        if (oData.results[i].GasMt === '0.000') { oData.results[i].GasMt = 'Null' };
                        if (oData.results[i].GasNm3 === '0.000') { oData.results[i].GasNm3 = 'Null' };
                        if (oData.results[i].GasSg === '0.000') { oData.results[i].GasSg = '' };
                        if (oData.results[i].GasWater === '0.000') { oData.results[i].GasWater = '' };
                    }

                    if (oData.results[i].Sno === '8.2.2') {
                        if (oData.results[i].LpgSg === '0.000') { oData.results[i].LpgSg = '' };
                        if (oData.results[i].LpgRvp === '0.000') { oData.results[i].LpgRvp = '' };
                        if (oData.results[i].LpgBbls === '0.000') { oData.results[i].LpgBbls = 'Null' };
                        if (oData.results[i].LpgMt === '0.000') { oData.results[i].LpgMt = 'Null' };

                        if (oData.results[i].CondBbls === '0.000') { oData.results[i].CondBbls = 'Null' };
                        if (oData.results[i].CondMt === '0.000') { oData.results[i].CondMt = 'Null' };
                        if (oData.results[i].CondRvp === '0.000') { oData.results[i].CondRvp = '' };
                        if (oData.results[i].CondSg === '0.000') { oData.results[i].CondSg = '' };

                        if (oData.results[i].FlaredGasMt === '0.000') { oData.results[i].FlaredGasMt = '' };
                        if (oData.results[i].FlaredGasNm3 === '0.000') { oData.results[i].FlaredGasNm3 = '' };

                        if (oData.results[i].GasBtu === '0.000') { oData.results[i].GasBtu = '' };
                        if (oData.results[i].GasHc === '0.000') { oData.results[i].GasHc = '' };
                        if (oData.results[i].GasMt === '0.000') { oData.results[i].GasMt = 'Null' };
                        if (oData.results[i].GasNm3 === '0.000') { oData.results[i].GasNm3 = 'Null' };
                        if (oData.results[i].GasSg === '0.000') { oData.results[i].GasSg = '' };
                        if (oData.results[i].GasWater === '0.000') { oData.results[i].GasWater = '' };
                    }

                    if (oData.results[i].Sno === '8.2.4') {
                        if (oData.results[i].LpgSg === '0.000') { oData.results[i].LpgSg = '' };
                        if (oData.results[i].LpgRvp === '0.000') { oData.results[i].LpgRvp = '' };
                        if (oData.results[i].LpgBbls === '0.000') { oData.results[i].LpgBbls = 'Null' };
                        if (oData.results[i].LpgMt === '0.000') { oData.results[i].LpgMt = 'Null' };

                        if (oData.results[i].CondBbls === '0.000') { oData.results[i].CondBbls = 'Null' };
                        if (oData.results[i].CondMt === '0.000') { oData.results[i].CondMt = 'Null' };
                        if (oData.results[i].CondRvp === '0.000') { oData.results[i].CondRvp = '' };
                        if (oData.results[i].CondSg === '0.000') { oData.results[i].CondSg = '' };

                        if (oData.results[i].FlaredGasMt === '0.000') { oData.results[i].FlaredGasMt = '' };
                        if (oData.results[i].FlaredGasNm3 === '0.000') { oData.results[i].FlaredGasNm3 = '' };

                        if (oData.results[i].GasBtu === '0.000') { oData.results[i].GasBtu = '' };
                        if (oData.results[i].GasHc === '0.000') { oData.results[i].GasHc = '' };
                        if (oData.results[i].GasMt === '0.000') { oData.results[i].GasMt = 'Null' };
                        if (oData.results[i].GasNm3 === '0.000') { oData.results[i].GasNm3 = 'Null' };
                        if (oData.results[i].GasSg === '0.000') { oData.results[i].GasSg = '' };
                        if (oData.results[i].GasWater === '0.000') { oData.results[i].GasWater = '' };
                    }

                    if (oData.results[i].Sno === '') {
                        if (oData.results[i].LpgSg === '0.000') { oData.results[i].LpgSg = '' };
                        if (oData.results[i].LpgRvp === '0.000') { oData.results[i].LpgRvp = '' };
                        if (oData.results[i].CondRvp === '0.000') { oData.results[i].CondRvp = '' };
                        if (oData.results[i].CondSg === '0.000') { oData.results[i].CondSg = '' };
                        if (oData.results[i].FlaredGasMt === '0.000') { oData.results[i].FlaredGasMt = '' };
                        if (oData.results[i].FlaredGasNm3 === '0.000') { oData.results[i].FlaredGasNm3 = '' };
                        if (oData.results[i].GasBtu === '0.000') { oData.results[i].GasBtu = '' };
                        if (oData.results[i].GasHc === '0.000') { oData.results[i].GasHc = '' };
                        if (oData.results[i].GasMt === '0.000') { oData.results[i].GasMt = '' };
                        if (oData.results[i].GasNm3 === '0.000') { oData.results[i].GasNm3 = '' };
                        if (oData.results[i].GasSg === '0.000') { oData.results[i].GasSg = '' };
                        if (oData.results[i].GasWater === '0.000') { oData.results[i].GasWater = '' };
                    }

                }

                if (oData) {
                    oProdModel.setProperty("/items", oData?.results);
                }else{
                    oProdModel.setProperty("/items", []);
                }
            },

            getProductionData: function (oModel, aFilters, sPath) {
                return new Promise((resolve, reject) => {
                    // Perform Read operation and pass billingdoc as parameter to URL
                    oModel.read(sPath,
                        {
                            filters: aFilters,
                            success: function (oData, oResponse) {
                                resolve(oData);
                            },
                            error: function (oError) {
                                reject(oError);
                            }
                        });
                })
            },
            /**
             * Returns the date in Odata format
             * @param {date} date Date()
             * @returns {string}  odata date format
             */
            getMonthYear: function (date) {
                const year = date.getFullYear();
                const month = String(date.getMonth() + 1).padStart(2, '0');

                return `${year}${month}`;
            },

            /**
             * action triggered on print preview
             * @param {object} oEvent sap.ui.base.Event
             */
            onPrint: async function (oEvent) {
                try {
                    var oResourceBundle = this.getView().getModel("i18n").getResourceBundle();
                    var opdfViewer = new PDFViewer();
                    this.getView().addDependent(opdfViewer);
                    var oBusyDialog = new BusyDialog({
                        title: 'Generating Form...'
                    });
                    oBusyDialog.open();
                    let oModel, oView, sMonYear, oProdModel;
                    oView = this.getView();
                    // get the Model reference
                    oModel = oView.getModel();
                    oProdModel = oView.getModel("oProdModel");

                    //Get the Plant Value
                    const sPlant = oView?.byId("Plant")?.getValue();

                    //Get the Unit Value
                    const sUnit = oView?.byId("Unit")?.getValue();

                    //Get Month and Year
                    const sViewDate = oView.byId("year")?.getDateValue();
                    if (sViewDate) {
                        sMonYear = this.getMonthYear(sViewDate);
                    }
                    if (sPlant && sUnit && sMonYear) {
                        //Get Header Data
                        const oHeader = oProdModel.getProperty("/header");

                        const oData =
                        {
                            Plant: sPlant,
                            Unit: sUnit,
                            MonthYear: sMonYear,
                            Note1: oHeader.Note1,
                            Note2: oHeader.Note2,
                            Note3: oHeader.Note3,
                            Note4: oHeader.Note4
                        };
                        var vPDF = await this.postData(oModel, oData, `/ProdStatprintformSet`);
                        if (vPDF?.FormData) {
                            let base64EncodedPDF = vPDF?.FormData;
                            let decodedPdfContent = atob(base64EncodedPDF);
                            let byteArray = new Uint8Array(decodedPdfContent.length);
                            for (var i = 0; i < decodedPdfContent.length; i++) {
                                byteArray[i] = decodedPdfContent.charCodeAt(i);
                            }
                            var blob = new Blob([byteArray.buffer], {
                                type: 'application/pdf'
                            });
                            var pdfurl = URL.createObjectURL(blob);
                            jQuery.sap.addUrlWhitelist("blob"); // register blob url as whitelist
                            opdfViewer.setSource(pdfurl);
                            opdfViewer.setVisible(true);

                            opdfViewer.setTitle(oResourceBundle.getText("pdfTitle"));
                            opdfViewer.open();
                        }
                        oBusyDialog.close();
                    }
                    else {
                        oBusyDialog.close();
                        MessageBox.error("Enter the Mandatory Fields.", {
                            title: "Error",
                            onClose: function () {
                            }
                        });
                    }

                }
                catch (e) {
                    oBusyDialog.close();
                }
            },

            /**
             * Returns the response of post oData call
             * @param {object} oModel  OData Model
             * @param {object} oProdData  OData 
             * @param {string} sId Table ID
             * @returns {object}  oData response
             */
            postData: async function (oModel, oProdData, sPath) {
                const sToken = oModel.getSecurityToken();
                const oHeaders = {
                    "x-csrf-token": sToken
                };
                return new Promise((resolve, reject) => {
                    // Perform Read operation and pass billingdoc as parameter to URL
                    oModel.create(sPath, oProdData,
                        {
                            headers: oHeaders,
                            success: function (oData, oResponse) {
                                resolve(oData);
                            },
                            error: function (oError) {
                                reject(oError);
                            }
                        });
                })
            },
            onPressSave: function () {
                //Get the Plant Value
                let oView = this.getView();
                const sPlant = oView?.byId("Plant")?.getValue();

                //Get the Unit Value
                const sUnit = oView?.byId("Unit")?.getValue();
          let sMonYear;
                //Get Month and Year
                const sViewDate = oView.byId("year")?.getDateValue();
                if (sViewDate) {
                    sMonYear = this.getMonthYear(sViewDate);
                }
            let oHeader = this.getView().getModel("oProdModel").getProperty("/header");
            let oPayload = {
                "Matnr":sUnit,
                "Plant":sPlant,
                "Zyearmonth":sMonYear,
                "Note1":oHeader.Note1,
                "Note2":oHeader.Note2,
                "Note3":oHeader.Note3,
                "Note4":oHeader.Note4
            };    
            let oModel = this.getView().getModel();
            this.getView().setBusy(true);
            oModel.create("/ProdStatSaveSet",oPayload,{
                
                success:function(data,oResponse){
                    this.getView().setBusy(false);
                    if (data) {
                        if (data?.Msgtype === 'S') {

                            
                            MessageBox.success(data?.Message, {
                                title: "Success",
                                onClose: function () {
                                    this.getData();
                                }.bind(this)
                            });
                        } else {
                           
                            MessageBox.error(data?.Message, {
                                title: "Error",
                                onClose: function () {
                                }
                            });
                        }
                    }
                }.bind(this),
                error:function(oError){
                    this.getView().setBusy(false);
                }.bind(this)
            })
            },
            /**
             * action triggered on Generate action
             * @param {object} oEvent sap.ui.base.Event
             */
            onGenerate: async function (oEvent) {
                try {

                    var opdfViewer = new PDFViewer();
                    this.getView().addDependent(opdfViewer);
                    var oBusyDialog = new BusyDialog();
                    oBusyDialog.open();
                    let oModel, oView, sMonYear, oProdModel;
                    oView = this.getView();
                    // get the Model reference
                    oModel = oView.getModel();
                    oProdModel = oView.getModel("oProdModel");

                    //Get the Plant Value
                    const sPlant = oView?.byId("Plant")?.getValue();

                    //Get the Unit Value
                    const sUnit = oView?.byId("Unit")?.getValue();

                    //Get Month and Year
                    const sViewDate = oView.byId("year")?.getDateValue();
                    if (sViewDate) {
                        sMonYear = this.getMonthYear(sViewDate);
                    }
                    if (sPlant && sUnit && sMonYear) {
                        //Get Header Data
                        const oHeader = oProdModel.getProperty("/header");

                        const oData =
                        {
                            Plant: sPlant,
                            Matnr: sUnit,
                            Zyearmonth: sMonYear,
                            Note1: oHeader.Note1,
                            Note2: oHeader.Note2,
                            Note3: oHeader.Note3,
                            Note4: oHeader.Note4
                        };
                        const data = await this.postData(oModel, oData, `/ProdWFGenerateSet`);
                        if (data) {
                            if (data?.Msgtype === 'S') {

                                oBusyDialog.close();
                                MessageBox.success(data?.Message, {
                                    title: "Success",
                                    onClose: function () {
                                        this.getData();
                                    }.bind(this)
                                });
                            } else {
                                oBusyDialog.close();
                                MessageBox.error(data?.Message, {
                                    title: "Error",
                                    onClose: function () {
                                    }
                                });
                            }
                        }
                        oBusyDialog.close();
                    }
                    else {
                        oBusyDialog.close();
                        MessageBox.error("Enter the Mandatory Fields.", {
                            title: "Error",
                            onClose: function () {
                            }
                        });
                    }

                }
                catch (e) {
                    oBusyDialog.close();
                }
            },
        });
    }
);


