
sap.ui.define([
    "sap/ui/model/json/JSONModel"
],
    function (JSONModel) {
        "use strict";
        const dDate = function () {
            const today = new Date();
            const yesterday = new Date(today);
            yesterday.setDate(new Date().getDate() - 1);
            return today;;
        };
        

        const operationsData = {
            date: dDate(),         
        };
        

        return JSONModel.extend("com.ui.crescent.zdailyprodop.model.salesmodel", {

            /**
             * Constructor for the Invoice Model - initialize the data
             * @param {object} keys for the invoice objects
             */
            constructor: function () {
                JSONModel.prototype.constructor.apply(this, arguments);
                this.init();
            },

            /**
             * Initializes the model's invoice model
             * @param {object} keys for the Invoice objects
             */
            init: function () {
                this.setProperty("/operationsData", Object.create(operationsData));
            }

    });
    }
);