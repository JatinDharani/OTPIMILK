sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox",
    "sap/m/BusyDialog",
    "sap/m/PDFViewer",
    "sap/ui/model/Filter",
    "sap/ui/core/format/DateFormat"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, JSONModel, MessageBox, BusyDialog, PDFViewer,Filter,DateFormat) {
        "use strict";

        return Controller.extend("com.ui.crescent.zdailyprodmgmt.controller.App", {
            onInit: function () {
                let oProdModel, oView;
                const oData = {
                    header: {
                        GenFlag: false
                    },
                    gas: {},
                    gasDelv: {},
                    FLgas: {},
                    avgGasPQ: {},
                    liqProdQual: {},
                    liquid: {},
                    express: {},
                    gasNom: {}
                }
                let oMinDate = {
                    date:new Date("2024","00","01")
                }
                
                this.getView().setModel(new JSONModel(oMinDate), "dateValidator");

                var operationsModel = this.getOwnerComponent().getModel("operations");
                this.getView().setModel(operationsModel, "operations");
               
                oProdModel = new JSONModel(oData);
                oView = this.getView();
                oView.setModel(oProdModel, "oProdModel");
                let oDailyModel = this.getOwnerComponent().getModel("zdaily");
                oDailyModel.setProperty("/data",{"ExeDate":"N","Exced57":"N","NotifiedHop":"N","NomAdj":"N","Remarks":""});
               this._checkStartup();
            },
            _checkStartup:function(){
                let oStartup = this.getOwnerComponent().getComponentData().startupParameters;
                if(Object.keys(oStartup).length > 0){
                    let sProdNet = oStartup.ProdNet[0];
                    let sDPRDate = oStartup.DPRDate[0];
                    if(sDPRDate){
                        let oDate = new Date(sDPRDate.substring(6,10),Number(sDPRDate.substring(3,5)) -1,sDPRDate.substring(0,2));
                        this.getView()?.byId("DPRDate")?.setDateValue(oDate); 
                    }
                    this.getView()?.byId("ProdNet")?.setValue(sProdNet);
                          
                }
            },
            _getAprStatus:function(){
                let sEntity = "/Mgmt_ApStatSet";
                let sProdNet = this.getView()?.byId("ProdNet")?.getValue();
                let sDPRDate = this.resolveTimeDifference(this.getView()?.byId("DPRDate")?.getDateValue());
                let oModel = this.getOwnerComponent().getModel("ZUHAM_DAILY_MGMT");
                let oKey = {
                    ProdNet:sProdNet,
                    ExeDate:sDPRDate
                };
                let oDailyModel = this.getOwnerComponent().getModel("zdaily");
                let sURL = oModel.createKey(sEntity,oKey);
                this.getView().setBusy(true);
                oModel.read(sURL,{
                    success:function(oData,oResponse){
                        //oData.ExeDate = sDPRDate;
                        oDailyModel.setProperty("/overAllStatus",oData);
                        this.getView().setBusy(false);
                    }.bind(this),
                    error:function(oError){
                        this.getView().setBusy(false);
                    }.bind(this)
                });
            },
            _getAprStatusTable:function(){
                let sEntity = "/Mgmt_StatusSet";
                let sProdNet = this.getView()?.byId("ProdNet")?.getValue();
                let sDPRDate = this.resolveTimeDifference(this.getView()?.byId("DPRDate")?.getDateValue());
                let oModel = this.getOwnerComponent().getModel("ZUHAM_DAILY_MGMT");
                let oKey = {
                    ProdNet:sProdNet,
                    ExeDate:sDPRDate
                };
                let aFilters = [
                    new  Filter({
                      path: "ProdNet",
                      operator: "EQ",
                      value1: sProdNet
                    }),
                    new Filter({
                      path: "ExeDate",
                      operator: "EQ",
                      value1: sDPRDate
                    })];
                let oDailyModel = this.getOwnerComponent().getModel("zdaily");
                let sURL = sEntity;//oModel.createKey(sEntity,oKey);
                this.getView().setBusy(true);
                window.setTimeout(() => {
                    oModel.read(sURL,{
                        filters:aFilters,
                        success:function(oData,oResponse){
                            //oData.ExeDate = sDPRDate;
                            oDailyModel.setProperty("/status",oData.results);
                            this.getView().setBusy(false);
                        }.bind(this),
                        error:function(oError){
                            this.getView().setBusy(false);
                        }.bind(this)
                    });  
                }, 7000);
              
            },
            

            onProdNetInit(){
                this.byId("ProdNet").setValue("ISP");  
                // Get yesterday's date 
                var dateObj = new Date(new Date().setDate(new Date().getDate() - 1));
                this.getView().byId("DPRDate").setDateValue( dateObj ); 
                this._checkStartup();  
                this._readUHAMData();   
              this._getAprStatus();
              this._getAprStatusTable();
            },

            resolveTimeDifference: function (dateTime) {

                if (dateTime !== undefined && dateTime !== null && dateTime !== "") {
                    var offSet = dateTime.getTimezoneOffset();
                    var offSetVal = dateTime.getTimezoneOffset() / 60;
                    var h = Math.floor(Math.abs(offSetVal));
                    var m = Math.floor((Math.abs(offSetVal) * 60) % 60);
                    dateTime = new Date(dateTime.setHours(h, m, 0, 0)); return dateTime;
                }
                return null;
            },
            getData: async function () {
                try {
                    let oModel, oView, sPath;
                    oView = this.getView();
                    this._getAprStatus();
                    this._getAprStatusTable();
                    oModel = oView.getModel();
                    var oBusyDialog = new BusyDialog();
                    oBusyDialog.open();
                    //Get the ProdNet Value
                    const sProdNet = oView?.byId("ProdNet")?.getValue();

                    //Get DPRDate
                    const sDPRDate = this.resolveTimeDifference(oView?.byId("DPRDate")?.getDateValue());

                    //const sDPRDate = this.getView().getModel("operations").getData().operationsData.date;

                    if (sProdNet && sDPRDate) {
                        //Fetch the Gas data
                        sPath = oModel.createKey("/GasSet", { "Tplnr": sProdNet, "ExeDate": sDPRDate });
                        this.getProductionData(oModel, sPath, '/gas');

                        //Fetch the Gas Delivered data
                        sPath = oModel.createKey("/GasDelSet", { "Tplnr": sProdNet, "ExeDate": sDPRDate });
                        this.getProductionData(oModel, sPath, '/gasDelv');

                        //Fetch the Flared Gas data
                        sPath = oModel.createKey("/FLgasSet", { "Tplnr": sProdNet, "ExeDate": sDPRDate });
                        this.getProductionData(oModel, sPath, '/FLgas');

                        //Fetch the Average Gas Product Quality data
                        sPath = oModel.createKey("/AvgGasPQSet", { "Tplnr": sProdNet, "ExeDate": sDPRDate });
                        this.getProductionData(oModel, sPath, '/avgGasPQ');

                        //Fetch the Liquid Product Quality data
                        sPath = oModel.createKey("/LiqProdQualSet", { "Tplnr": sProdNet, "ExeDate": sDPRDate });
                        this.getProductionData(oModel, sPath, '/liqProdQual');

                        //Fetch the Liquids data
                        sPath = oModel.createKey("/LiquidsSet", { "Tplnr": sProdNet, "ExeDate": sDPRDate });
                        this.getProductionData(oModel, sPath, '/liquid');
                        oBusyDialog.close();

                        //Fetch the Export Pressure data
                        sPath = oModel.createKey("/ExpPressSet", { "Tplnr": sProdNet, "ExeDate": sDPRDate });
                        this.getProductionData(oModel, sPath, '/express');
                        oBusyDialog.close();

                        //Fetch the Gas Nomination Set data
                        sPath = oModel.createKey("/GasNomSet", { "Tplnr": sProdNet, "ExeDate": sDPRDate });
                        this.getProductionData(oModel, sPath, '/gasNom');
                        oBusyDialog.close();
                        this._readUHAMData();
                this._readEmailData();

                    } else {
                        oBusyDialog.close();
                        MessageBox.error("Enter the Mandatory Fields.", {
                            title: "Error",
                            onClose: function () {
                            }
                        });
                    }

                
                }
                catch (e) {
                    oBusyDialog.close();
                    console.log(e);
                    MessageBox.error("Error..Check console", {
                        title: "Error",
                        onClose: function () {
                        }
                    });
                }
            },
            getProductionData: function (oModel, sPath, sProperty) {
                try {
                    new Promise((resolve, reject) => {
                        let oProdModel = this.getView().getModel("oProdModel");
                        // Perform Read operation and pass billingdoc as parameter to URL
                        oModel.read(sPath,
                            {
                                success: function (oData, oResponse) {
                                    oProdModel.setProperty(sProperty, oData);
                                },
                                error: function (oError) {
                                    reject(oError);
                                }
                            });
                    })
                }
                catch (e) {
                    oBusyDialog.close();
                    console.log(e);
                    MessageBox.error("Error..Check console", {
                        title: "Error",
                        onClose: function () {
                        }
                    });
                }
            },

            /**
             * action triggered on print preview
             * @param {object} oEvent sap.ui.base.Event
             */
            onPrint: async function (oEvent) {
                try {

                    var oBusyDialog = new BusyDialog({
                        title: 'Generating Form...'
                    });
                    var opdfViewer = new PDFViewer();
                    this.getView().addDependent(opdfViewer);

                    oBusyDialog.open();
                    let oModel, oView;
                    oView = this.getView();
                    // get the Model reference
                    oModel = this.getView().getModel('uhamDprMgmt');
                    //Get the ProdNet Value
                    const sProdNet = oView?.byId("ProdNet")?.getValue();

                    //Get DPRDate
                    const sDPRDate = oView.byId("DPRDate")?.getDateValue();

                    if (sProdNet && sDPRDate) {


                        const oData =
                        {
                            "d": {
                                "p_prodnet": sProdNet,
                                "p_date": sDPRDate

                            }
                        }

                        var sPath = oModel.createKey("/Print", { "p_prodnet": sProdNet, "p_date": sDPRDate }) + "/Set";

                        //var vPDF = await this.postData(oModel, oData, sPath);
                        var vPDF = await this.getPDFData(oModel, sPath);
                        //if (vPDF?.FormData) {
                        if (vPDF?.results[0]?.stream_data) {
                            let base64EncodedPDF = vPDF?.results[0].stream_data;
                            let decodedPdfContent = atob(base64EncodedPDF);
                            let byteArray = new Uint8Array(decodedPdfContent.length);
                            for (var i = 0; i < decodedPdfContent.length; i++) {
                                byteArray[i] = decodedPdfContent.charCodeAt(i);
                            }
                            var blob = new Blob([byteArray.buffer], {
                                type: 'application/pdf'
                            });
                            var pdfurl = URL.createObjectURL(blob);
                            jQuery.sap.addUrlWhitelist("blob"); // register blob url as whitelist
                            opdfViewer.setSource(pdfurl);
                            opdfViewer.setVisible(true);

                            opdfViewer.setTitle("Contract Document");
                            opdfViewer.open();
                        }
                        oBusyDialog.close();
                    }
                    else {
                        oBusyDialog.close();
                        MessageBox.error("Enter the Mandatory Fields.", {
                            title: "Error",
                            onClose: function () {
                            }
                        });
                    }

                }
                catch (e) {
                    oBusyDialog.close();
                }
            },
            
            getPDFData: async function (oModel, sPath) {

                return new Promise((resolve, reject) => {
                    // Perform Read operation and pass billingdoc as parameter to URL
                    oModel.read(sPath,
                        {
                            success: function (oData, oResponse) {
                                resolve(oData);
                            },
                            error: function (oError) {
                                reject(oError);
                            }
                        });
                })
            },
            onDateChange:function(oEvent){
                var oDatePicker = oEvent.getSource();
              var oSelectedDate = new Date(oDatePicker.getValue().split("/")[2],Number(oDatePicker.getValue().split("/")[1]) - 1,oDatePicker.getValue().split("/")[0]);
                var oMinDate = new Date(2024, 0, 1); // January 1, 2023
                
                if (oSelectedDate < oMinDate) {
                    sap.m.MessageBox.error("Selected date is before the minimum allowed date (01.01.2024).");
                    oDatePicker.setDateValue(oMinDate); // Reset to minimum date
                }
            },
            _onClickRevise:function(){
                let sEntity = "/Mgmt_ReviseSet";
                let sProdNet = this.getView()?.byId("ProdNet")?.getValue();
                 let sDPRDate = this.resolveTimeDifference(this.getView()?.byId("DPRDate")?.getDateValue());
                // var oFormat = DateFormat.getDateInstance({
                //     pattern: "dd.MM.YYYY"
                // });
                // let osDate = oFormat.format(sDPRDate);

                let oS1Date = this.getView()?.byId("DPRDate")?.getValue();
                let sMessage = "Do you want to revise the Management DPR for "+oS1Date+"?";
                MessageBox.warning(sMessage, {
                    actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                    emphasizedAction: MessageBox.Action.OK,
                    onClose: function (sAction) {
                       if(sAction === "OK"){
                        let oModel = this.getOwnerComponent().getModel("ZUHAM_DAILY_MGMT");
                        let oKey = {
                            ProdNet:sProdNet,
                            ExeDate:sDPRDate
                        };
                       
                        let sURL = oModel.createKey(sEntity,oKey);
                        this.getView().setBusy(true);
                        oModel.read(sURL,{
                            success:function(oData,oResponse){
                                this._getAprStatus();
                                this._getAprStatusTable();
                                let sType = oData.MsgType === "S" ? "success":"error";
                                let sMessage = oData.MsgText;
                                MessageBox[sType].apply(this,[sMessage,{onClose:function(){
                                    this.onInit();
                                    
                                }.bind(this)}]);
                                this.getData();
                                    
                                
                                
                                this.getView().setBusy(false);
                            }.bind(this),
                            error:function(oError){
                                this.getView().setBusy(false);
                            }.bind(this)
                        });
        
                       }
                    }.bind(this)
                });
                

            },
            _readUHAMData:function(){
                let sEntity = "/Mgmt_RemarksSet";
                let sProdNet = this.getView()?.byId("ProdNet")?.getValue();
                let sDPRDate = this.resolveTimeDifference(this.getView()?.byId("DPRDate")?.getDateValue());
                let oModel = this.getOwnerComponent().getModel("ZUHAM_DAILY_MGMT");
                let oKey = {
                    ProdNet:sProdNet,
                    ExeDate:sDPRDate
                };
                let oDailyModel = this.getOwnerComponent().getModel("zdaily");
                let sURL = oModel.createKey(sEntity,oKey);
                this.getView().setBusy(true);
                oModel.read(sURL,{
                    success:function(oData,oResponse){
                        oDailyModel.setProperty("/data",oData);
                        oDailyModel.updateBindings(true);
                        this.getView().setBusy(false);
                    }.bind(this),
                    error:function(oError){
                        this.getView().setBusy(false);
                    }.bind(this)
                });

            },
            onNOMChange:function(oEvent){
                let oDailyModel = this.getOwnerComponent().getModel("zdaily");
                let iSelectedIndex = oEvent.getParameter("selectedIndex");
                let sValue = iSelectedIndex === 1 ? "N" : "Y";
                oDailyModel.setProperty("/data/NomAdj",sValue);
            },
            onBuChange:function(oEvent){
                let oDailyModel = this.getOwnerComponent().getModel("zdaily");
                let iSelectedIndex = oEvent.getParameter("selectedIndex");
                let sValue = iSelectedIndex === 1 ? "N" : "Y";
                oDailyModel.setProperty("/data/NotifiedHop",sValue);
            },
            onEXChange:function(oEvent){
                let oDailyModel = this.getOwnerComponent().getModel("zdaily");
                let iSelectedIndex = oEvent.getParameter("selectedIndex");
                let sValue = iSelectedIndex === 1 ? "N" : "Y";
                oDailyModel.setProperty("/data/Exced57",sValue);
            },
            _createUHAMData:function(){
                let sEntity = "/Mgmt_RemarksSet";
                let sProdNet = this.getView()?.byId("ProdNet")?.getValue();
                let sDPRDate = this.resolveTimeDifference(this.getView()?.byId("DPRDate")?.getDateValue());
                let oModel = this.getOwnerComponent().getModel("ZUHAM_DAILY_MGMT");
                let oKey = {
                    ProdNet:sProdNet,
                    ExeDate:sDPRDate
                };
                let oDailyModel = this.getOwnerComponent().getModel("zdaily");

                let oPayLoad = oDailyModel.getProperty("/data") ;
                //let sURL = oModel.createKey(sEntity,oKey);
                oPayLoad.ProdNet = sProdNet;
                oPayLoad.ExeDate = sDPRDate;
            //    this._validateDate(sDPRDate);
            //    if(!_validateDate){
            //     return;
            //    }
                oModel.create(sEntity,oPayLoad,{
                    success:function(oData,oResponse){
                      MessageBox.success("Data saved successfully!");
                    }.bind(this),
                    error:function(oError){}.bind(this)
                })
            },
            _validateDate:function(sDate){
                let oDate = new Date("2024","0","01");
                if(sDate){
                    if(sDate.getTime() < oDate.getTime()){
                        return false;
                    }
                    else{
                        return true;
                    }
                }else{

                    return true;
                }
            },
            
            _readEmailData:function(){
            //    Mgmt_MailsendSet
            },
            _createEmailData:function(){
                let sEntity = "/Mgmt_MailsendSet";
                let sProdNet = this.getView()?.byId("ProdNet")?.getValue();
                let sDPRDate = this.resolveTimeDifference(this.getView()?.byId("DPRDate")?.getDateValue());
                let oModel = this.getOwnerComponent().getModel("ZUHAM_DAILY_MGMT");
                let oKey = {
                    ProdNet:sProdNet,
                    ExeDate:sDPRDate
                };
                this.getView().setBusy(true);
                let sURL = oModel.createKey(sEntity,oKey);
                oModel.read(sURL,{
                    success:function(oData,oResponse){
                        this._getAprStatus();
                        this._getAprStatusTable();
                        let sType = oData.MsgType === "S" ? "success":"error";
                        let sMessage = oData.MsgText;
                        MessageBox[sType].apply(null,[sMessage]);
                        this.getView().setBusy(false);
                      //  this._onClickRevise();
                    //   if(sType.toUpperCase() === "SUCCESS"){
                    //     this.getData();
                    //     this._getAprStatus();
                    //         this._getAprStatusTable();
                    //   }
                      this.getData();
                       
                            
                    }.bind(this),
                    error:function(oError){
                        this.getView().setBusy(false);
                    }.bind(this)
                });
            }
        });

    });
