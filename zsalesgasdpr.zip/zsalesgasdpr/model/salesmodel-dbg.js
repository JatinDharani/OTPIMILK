
sap.ui.define([
    "sap/ui/model/json/JSONModel"
],
    function (JSONModel) {
        "use strict";
        const dDate = function () {
            const today = new Date();
            const yesterday = new Date(today);
            yesterday.setDate(new Date().getDate() - 1);
            return yesterday;;
        };
        const dMonth = function () {
            const today = new Date();
            const lastMonth = new Date(today.getFullYear(), today.getMonth() - 1, 1);
            return lastMonth;
        };

        const dYear = function () {
            const today = new Date();
            const lastYear = new Date(today.getFullYear() - 1, today.getMonth(), today.getDate());
            return lastYear;
        };

        const production = {
            contract: "",
            bgStartDate: "",
            bgEndDate: "",
            month: dMonth(),
            date: dDate(),
            year: dYear(),
            dateSelect: true,
            monthSelect: false,
            yearSelect: false,
            bgSelect: false
        };
        const nomination = {
            date: dDate(),
            contract: ""
        }

        return JSONModel.extend("com.ui.crescent.zsalesgasdpr.model.salesmodel", {

            /**
             * Constructor for the Invoice Model - initialize the data
             * @param {object} keys for the invoice objects
             */
            constructor: function () {
                JSONModel.prototype.constructor.apply(this, arguments);
                this.init();
            },

            /**
             * Initializes the model's invoice model
             * @param {object} keys for the Invoice objects
             */
            init: function () {
                this.resetProduction();
                this.resetNomination();
            },

            /**
             * Resets the model's Production details
             */
            resetProduction: function () {
                this.setProperty("/production", Object.create(production));
              
            },


            /**
             * Resets the model's Nomination details
             */
            resetNomination: function () {
                this.setProperty("/nomination", Object.create(nomination));
            },

            /**
             * Sets the indicator in model whether Date input is enabled or not.
             *
             * @param {boolean} dateSelect indicating if Date input is enabled or not.
             */
            setDateSelect: function (dateSelect) {
                this.setProperty("/production/dateSelect", dateSelect);
            },
            
            /**
             * Sets the indicator in model whether Month input is enabled or not.
             *
             * @param {boolean} monthSelect indicating if Month input is enabled or not.
             */
            setMonthSelect: function (monthSelect) {
                this.setProperty("/production/monthSelect", monthSelect);
            },

            /**
             * Sets the indicator in model whether Year input is enabled or not.
             *
             * @param {boolean} yearSelect indicating if Year input is enabled or not.
             */
            setYearSelect: function (yearSelect) {
                this.setProperty("/production/yearSelect", yearSelect);
            }, 

            /**
             * Sets the indicator in model whether Background date input is enabled or not.
             *
             * @param {boolean} bgSelect indicating if Background date input is enabled or not.
             */
            setBGSelect: function (bgSelect) {
                this.setProperty("/production/bgSelect", bgSelect);
            }

        });
    }
);
