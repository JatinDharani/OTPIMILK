sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageBox",
    'sap/ui/model/type/String',
    'sap/m/Label',
    'sap/m/SearchField',
    'sap/m/Token',
    'sap/ui/model/Filter',
    'sap/ui/model/FilterOperator',
    "com/ui/crescent/zsalesgasdpr/model/oDataHelper",
    "com/ui/crescent/zsalesgasdpr/model/formatter",
    "sap/ui/model/json/JSONModel"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, MessageBox, TypeString, Label, SearchField, Token, Filter, FilterOperator, oDataHelper, formatter,JSONModel) {
        "use strict";
        var count = 0;
        var _bDialogInitialized;
        var _oVHD;
        var _reportType;
        var _Vbeln;
        var _startDate;
        var _endDate;
        var _dateRange;
        return Controller.extend("com.ui.crescent.zsalesgasdpr.controller.app", {

            formatter: formatter,
            onDateChange:function(oEvent){
                var oDatePicker = oEvent.getSource();
                var oSelectedDate = oDatePicker.getDateValue();
                var oMinDate = new Date(2024, 0, 1); // January 1, 2023
                
                if (oSelectedDate < oMinDate) {
                    sap.m.MessageToast.show("Selected date is before the minimum allowed date.");
                    oDatePicker.setDateValue(oMinDate); // Reset to minimum date
                }
            },
            onInit: function () {

                var osalesModel = this.getOwnerComponent().getModel("sales");
                this.getView().setModel(osalesModel, "sales");

                this.getView().getModel("sales").resetNomination();

                this.getContractF4Data();
 
                var oColModel = new sap.ui.model.json.JSONModel();
                this.getView().setModel(oColModel, "oColModel");
                oColModel.setData({
                    cols: [
                        { label: "Sales Document", template: "Contract" },
                        { label: "Sales Document Type", template: "SDDocumentCategory" }
                    ]
                });
                let oMinDate = {
                    date:new Date("2024","00","01")
                }
                
                this.getView().setModel(new JSONModel(oMinDate), "dateValidator");

                var onomModelModel = this.getOwnerComponent().getModel("nomModel");
                this.getView().setModel(onomModelModel, "nomModel");
                // this.getView().byId("__RBDaily").setSelected(true);

            },

            onBeforeRendering: function () {
                var dailySelected = this.getView().byId("__RBDaily").getSelected();

            },

            onResetProduction: function () {
                if (typeof (this.getView().byId("__RBDaily")) != 'undefined') {
                    this.getView().byId("__RBDaily").setSelected(true);
                }
                this.getView().getModel("sales").resetProduction();
            },
            onResetNomination: function () {
                this.getView().getModel("sales").resetNomination();
            },

            onSubmitProdReport: function () {
                // IF Daily data is selected 
                if (this.getView().byId("__RBDaily").getSelected()) {

                    // Get Contract data 
                    var dailyDate = this.getView().getModel("sales").getData().production.date;

                    // Get Contract data 
                    var contractData = this.getView().getModel("sales").getData().production.contract;

                    if (contractData !== "") {
                        this.getView().byId("prdCtrtText").setValueState(sap.ui.core.ValueState.None);
                        var oDataModel = this.getView().getModel('dailySalesProdRep');
                        var sPath = oDataModel.createKey("/daily", { "Vbeln": contractData, "Zdate": dailyDate });
                        var that = this;
                        oDataHelper.callGetOData(oDataModel, sPath)
                            .then(function (data) {
                                that.callDailyProd(data.Vbeln, data.Zdate)
                            })
                            .catch(function (oError) {
                                MessageBox.error("No records found")
                            });
                    } else {
                        this.getView().byId("prdCtrtText").setValueState(sap.ui.core.ValueState.Error);
                        this.getView().byId("prdCtrtText").setValueStateText("Required");
                    }

                }

                else if (this.getView().byId("__RBMonthly").getSelected()) {
                    // Get Contract data 
                    var inpMonthYear = this.getView().getModel("sales").getData().production.month;

                    var month = ("0" + (inpMonthYear.getMonth() + 1)).slice(-2);
                    var year = inpMonthYear.getFullYear();

                    var monthYear = year + month;

                    // Get Contract data 
                    var contractData = this.getView().getModel("sales").getData().production.contract;
                    

                    if (contractData !== "") {
                        this.getView().byId("prdCtrtText").setValueState(sap.ui.core.ValueState.None);
                        var oDataModel = this.getView().getModel('MonthlySalesGas');
                        var sPath = oDataModel.createKey("/Monthly", { "Vbeln": contractData, "zyearmonth": monthYear });
                        var that = this;
                        oDataHelper.callGetOData(oDataModel, sPath)
                            .then(function (data) {
                                that.callMonthlyProd(data.Vbeln, data.zyearmonth)
                            })
                            .catch(function (oError) {
                                MessageBox.error("No records found")
                            });
                    } else {
                        this.getView().byId("prdCtrtText").setValueState(sap.ui.core.ValueState.Error);
                        this.getView().byId("prdCtrtText").setValueStateText("Required");
                    }


                }
                // If yearly button is selected 
                else if (this.getView().byId("__RBYearly").getSelected()) {
                    // Get Contract data 
                    var inpMonthYear = this.getView().getModel("sales").getData().production.year;
                    var year = inpMonthYear.getFullYear();


                    // Get Contract data 
                    var contractData = this.getView().getModel("sales").getData().production.contract;
                    contractData = contractData.padStart(10, '0');

                    if (contractData !== "") {
                        this.getView().byId("prdCtrtText").setValueState(sap.ui.core.ValueState.None);
                        var oDataModel = this.getView().getModel('YearlySalesGas');
                        var sPath = oDataModel.createKey("/yearly", { "VBELN": contractData, "ZYEAR": year });
                        var that = this;
                        oDataHelper.callGetOData(oDataModel, sPath)
                            .then(function (data) {
                                that.callYearlyProd(data.VBELN, data.ZYEAR)
                            })
                            .catch(function (oError) {
                                MessageBox.error("No records found")
                            });
                    } else {
                        this.getView().byId("prdCtrtText").setValueState(sap.ui.core.ValueState.Error);
                        this.getView().byId("prdCtrtText").setValueStateText("Required");
                    }


                }


                // IF Background data is selected 
                else if (this.getView().byId("__RBBG").getSelected()) {
                    // Get Date 
                    var dateRange = this.getView().byId("DRS3").getValue();

                    // Get Start and End  data 
                    var startDate = this.getView().getModel("sales").getData().production.bgStartDate;
                    var endDate = this.getView().getModel("sales").getData().production.bgEndDate;
                    // Get Contract data 
                    var contractData = this.getView().getModel("sales").getData().production.contract;

                    if (contractData == "") {

                        this.getView().byId("prdCtrtText").setValueState(sap.ui.core.ValueState.Error);
                        this.getView().byId("prdCtrtText").setValueStateText("Required");


                    } else if ((startDate == "") || (endDate == "")) {
                        this.getView().byId("DRS3").setValueState(sap.ui.core.ValueState.Error);
                        this.getView().byId("DRS3").setValueStateText("Required");

                    }
                    else {
                        this.getView().byId("prdCtrtText").setValueState(sap.ui.core.ValueState.None);
                        this.getView().byId("DRS3").setValueState(sap.ui.core.ValueState.None);
                        var oDataModelDailyGas = this.getView().getModel('dailySalesGas');
                        var sPath = "/DailyReport"



                        // Filter for contract 

                        var filter1 = new sap.ui.model.Filter({
                            path: "Vbeln",
                            operator: sap.ui.model.FilterOperator.EQ,
                            value1: contractData
                        });


                        var filter2 = new sap.ui.model.Filter({
                            path: "Zdate",
                            operator: sap.ui.model.FilterOperator.BT,
                            value1: startDate,
                            value2: endDate
                        });

                        var sFilters = [filter1, filter2]
                        this._Vbeln = contractData;
                        this._startDate = startDate;
                        this._endDate = endDate;
                        this._dateRange = dateRange;
                        var that = this;
                        oDataHelper.callGetODataFilter(oDataModelDailyGas, sPath, sFilters)
                            .then(function (data) {
                                if (data.results.length > 0) {
                                    that.callBkgdProd(that._Vbeln, that._startDate, that._endDate, that._dateRange)
                                } else {
                                    MessageBox.error("No records found")
                                }

                            })
                            .catch(function (oError) {
                                MessageBox.error("No records found")
                            });
                    }
                }
            },


            geti18NText: function(code){
               return  this.getView().getModel("i18n").getResourceBundle().getText(code);
            },

            onSubmitNomination: async function (oEvent) {
                // Get Contract data 
                var dailyDate = this.getView().getModel("sales").getData().nomination.date;

                // Get Contract data 
                var contractData = this.getView().getModel("sales").getData().nomination.contract;

                // Get the Production Network
                var sProdNet = this.getView().getModel("sales").getData().nomination.Tplnr;
                
                if(!sProdNet){
                       
                    this.getView().byId("ProdNet").setValueState(sap.ui.core.ValueState.Error);
                    this.getView().byId("ProdNet").setValueStateText("Required");
                }

                if (contractData !== "" && sProdNet) {
                    this.getView().byId("nomCtrtText").setValueState(sap.ui.core.ValueState.None);

                    this.getView().byId("ProdNet").setValueState(sap.ui.core.ValueState.None);
                    this.getView().byId("ProdNet").setValueStateText("");

                    contractData = contractData.padStart(10, '0');
                    const oNomData = await this.getNominationData(contractData, dailyDate ,sProdNet);

                    // Check the Authorization is blank, if yes show error 
                    if ((oNomData.Auth == "") && (oNomData.DisplayAuth == "")){
                        MessageBox.error(this.geti18NText("AuthError"));
                    }else if (oNomData.DisplayAuth == "X"){
                        this.getOwnerComponent().getModel("oNomModel").setData(oNomData);
                        this.getOwnerComponent().getRouter().navTo("Nomination");
                    }
                    else if (oNomData.Changepastrec == ""){
                        MessageBox.error(this.geti18NText("Changepastrec"));
                    } else {
                        this.getOwnerComponent().getModel("oNomModel").setData(oNomData);
                        this.getOwnerComponent().getRouter().navTo("Nomination");
                    }


                    

                } else {
                    
                    this.getView().byId("nomCtrtText").setValueState(sap.ui.core.ValueState.Error);
                    this.getView().byId("nomCtrtText").setValueStateText("Required");
                }


            },




            getNominationData: async function (sContract, sDate, sTplnr) {
                const oModel = this.getOwnerComponent().getModel("nomModel");
                //Get the data
                var sPath = oModel.createKey("/NominationSet", { "Vbeln": sContract, "Zdate": sDate,"Tplnr": sTplnr });

                return new Promise((resolve, reject) => {
                    // Perform Read operation and pass billingdoc as parameter to URL
                    oModel.read(sPath,
                        {
                            success: function (oData, oResponse) {
                                resolve(oData);
                            },
                            error: function (oError) {
                                reject(oError);
                            }
                        });
                })
            },
            callDailyProd: function (contractData, dailyDate) {
                // Get the CrossApplicationNavigation service      
                var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
                // Define the target application
                var oTarget = {
                    semanticObject: "ZUI_DAILY_PROD",
                    action: "display"
                };
                // Additional parameters for navigation
                var oParams = {
                    "Vbeln": contractData,
                    "Zdate": dailyDate
                };
                // Trigger the navigation
                oCrossAppNavigator.toExternal({
                    target: oTarget,
                    params: oParams
                });
            },

            callMonthlyProd: function (contractData, monthYear) {
                // Get the CrossApplicationNavigation service      
                var oCrossAppNavigator =  sap.ushell.Container.getService("CrossApplicationNavigation");
                // Define the target application
                var oTarget = {
                    semanticObject: "ZUI_MNTHLY_PROD",
                    action: "display"
                };
                // Additional parameters for navigation
                var oParams = {
                    "Vbeln": contractData,
                    "zyearmonth": monthYear
                };
                // Trigger the navigation
                oCrossAppNavigator.toExternal({
                    target: oTarget,
                    params: oParams
                });
            },
            

            callYearlyProd: function (contractData, year) {
                // Get the CrossApplicationNavigation service      
                var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
                // Define the target application
                var oTarget = {
                    semanticObject: "ZUI_YEARLY_PROD",
                    action: "displayReport"
                };
                // Additional parameters for navigation
                var oParams = {
                    "VBELN": contractData,
                    "ZYEAR": year
                };
                // Trigger the navigation
                oCrossAppNavigator.toExternal({
                    target: oTarget,
                    params: oParams
                });
            },

            callBkgdProd: function (contractData, startDate, endDate, dateRange) {
                // Get the CrossApplicationNavigation service      
                var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
                // Define the target application
                var oTarget = {
                    semanticObject: "ZUI_SALES_BKGD",
                    action: "display"

                };
                 // Trigger the navigation
                 oCrossAppNavigator.toExternal({
                    target: oTarget,
                    params : {
                        "sap-xapp-state-data": JSON.stringify({
                            "selectionVariant": {
                            "SelectOptions":[{"PropertyName":"Vbeln",
                                            "Ranges":[{"Sign":"I","Low":contractData,"Option":"EQ"}]},
                                            {"PropertyName":"Zdate",
                                            "Ranges":[{"Sign":"I","Low":startDate,"Option":"BT","High":endDate}]}]}})
                      }
                });

                // // Trigger the navigation
                // oCrossAppNavigator.toExternal({      
                //     target: {
                //         shellHash: "ZUI_SALES_BKGD-display?Vbeln=4000010&Zdate='2023-01-10-2023-07-10'"
                //     }
                // });
            },


            onCtrtText: function (oEvent) {

                var newValue = oEvent.getParameter('newValue');
                var inputId = oEvent.getParameter('id');
                var regex = /^[a-zA-Z0-9]+$/;
                if (!newValue.match(regex)) {
                    this.byId(inputId).setValueState(sap.ui.core.ValueState.Error);
                    this.byId(inputId).setValueStateText("Only Alphanumeric allowed");
                    this.getView().byId("subPrdCtrt").setEnabled(false);
                } else {
                    this.byId(inputId).setValueState(sap.ui.core.ValueState.None);
                    this.getView().byId("subPrdCtrt").setEnabled(true)
                }
            },



            onProdRBSelect: function (oEvent) {
                if (typeof (this.getView().byId("__RBDaily")) != 'undefined') {
                    const dateSelect = this.getView().byId("__RBDaily").getSelected();
                    if (this.getView().getModel("sales") !== undefined) {


                        this.getView().getModel("sales").setProperty("/production/dateSelect", dateSelect);
                    }
                }

                if (typeof (this.getView().byId("__RBMonthly")) != 'undefined') {
                    const monthSelect = this.getView().byId("__RBMonthly").getSelected();
                    this.getView().getModel("sales").setProperty("/production/monthSelect", monthSelect);
                }

                if (typeof (this.getView().byId("__RBYearly")) != 'undefined') {
                    const yearSelect = this.getView().byId("__RBYearly").getSelected();
                    this.getView().getModel("sales").setProperty("/production/yearSelect", yearSelect);
                }

                if (typeof (this.getView().byId("__RBBG")) != 'undefined') {
                    const bgSelect = this.getView().byId("__RBBG").getSelected();
                    this.getView().getModel("sales").setProperty("/production/bgSelect", bgSelect);
                }

            },

            onContractF4: function () {

                this._reportType = "Contract";
                this._oBasicSearchField = new SearchField();
                var oContractModel = this.getView().getModel('contractData');
                var oColModel = this.getView().getModel('oColModel');
                var that = this;
                if (!this._oValueHelpDialog) {
                    this._oValueHelpDialog = this.loadFragment({
                        name: "com.ui.crescent.zsalesgasdpr.fragment.valueContractHelpDialog"
                    });

                }


                this._oValueHelpDialog.then(function (oDialog) {
                    var oFilterBar = oDialog.getFilterBar();
                    that._oVHD = oDialog;
                    // Initialise the dialog with model only the first time. Then only open it
                    if (that._bDialogInitialized) {
                        // Re-set the tokens from the input and update the table
                        oDialog.setTokens([]);
                        var oToken = new Token();
                        oToken.setKey(that.getView().byId("prdCtrtText").getValue());
                        oToken.setText(that.getView().byId("prdCtrtText").getValue());
                        oDialog.setTokens(oToken);
                        oDialog.update();

                        oDialog.open();
                        return;
                    }
                    that.getView().addDependent(oDialog);

                    // Set key fields for filtering in the Define Conditions Tab
                    oDialog.setRangeKeyFields([{
                        label: "Product",
                        key: "ProductCode",
                        type: "string",
                        typeInstance: new TypeString({}, {
                            maxLength: 7
                        })
                    }]);

                    // Set Basic Search for FilterBar
                    oFilterBar.setFilterBarExpanded(false);
                    oFilterBar.setBasicSearch(that._oBasicSearchField);

                    // Trigger filter bar search when the basic search is fired
                    that._oBasicSearchField.attachSearch(function () {
                        oFilterBar.search();
                    });

                    var oTable = oDialog.getTable();
                    oTable.setModel(oColModel, "columns");
                    oTable.setModel(oContractModel)
                    oTable.bindRows("/contractModelData");
                    oDialog.setTitle("Contract Number");
                    // set flag that the dialog is initialized
                    that._bDialogInitialized = true;
                    oDialog.open();
                });
            },

            onValueHelpOkPress: function (oEvent) {
                var aToken = oEvent.getParameter("tokens")[0];
                var inputVal = aToken.getKey();
                if (this._reportType == "Nomination") {
                    this.getView().byId("nomCtrtText").setValue(inputVal);
                    this.getView().byId("nomCtrtText").setValueState(sap.ui.core.ValueState.None);
                    this.getView().byId("subNomCtrt").setEnabled(true)
                } else if (this._reportType == "Contract") {
                    this.getView().byId("prdCtrtText").setValue(inputVal);
                    this.getView().byId("prdCtrtText").setValueState(sap.ui.core.ValueState.None);
                    this.byId("prdCtrtText").setValueState(sap.ui.core.ValueState.None);
                    this.getView().byId("subPrdCtrt").setEnabled(true)
                }

                this._oVHD.close();

            },

            onValueHelpCancelPress: function (oEvent) {
                this._oVHD.close();

            },

            onFilterBarSearch: function (oEvent) {
                var sSearchQuery = this._oBasicSearchField.getValue(),
                    aSelectionSet = oEvent.getParameter("selectionSet");

                var aFilters = aSelectionSet.reduce(function (aResult, oControl) {
                    if (oControl.getValue()) {
                        aResult.push(new Filter({
                            path: oControl.getName(),
                            operator: FilterOperator.Contains,
                            value1: oControl.getValue()
                        }));
                    }

                    return aResult;
                }, []);
                aFilters.push(new Filter({
                    filters: [
                        new Filter({ path: "SalesDocument", operator: FilterOperator.Contains, value1: sSearchQuery }),
                        new Filter({ path: "SalesDocumentType", operator: FilterOperator.Contains, value1: sSearchQuery }),
                        new Filter({ path: "SalesOrganization", operator: FilterOperator.Contains, value1: sSearchQuery })
                    ],
                    and: false
                }));

                this._filterTable(new Filter({
                    filters: aFilters,
                    and: true
                }));
            },

            _filterTable: function (oFilter) {
                var oVHD = this._oVHD;

                oVHD.getTableAsync().then(function (oTable) {
                    if (oTable.bindRows) {
                        oTable.getBinding("rows").filter(oFilter);
                    }
                    if (oTable.bindItems) {
                        oTable.getBinding("items").filter(oFilter);
                    }

                    // This method must be called after binding update of the table.
                    oVHD.update();
                });
            },

            onNomF4: function () {
                this._reportType = "Nomination";
                this._oBasicSearchField = new SearchField();
                var oContractModel = this.getView().getModel('contractData');
                var oColModel = this.getView().getModel('oColModel');
                var that = this;
                if (!this._oValueHelpDialog) {
                    this._oValueHelpDialog = this.loadFragment({
                        name: "com.ui.crescent.zsalesgasdpr.fragment.valueContractHelpDialog"
                    });

                }


                this._oValueHelpDialog.then(function (oDialog) {
                    var oFilterBar = oDialog.getFilterBar();
                    that._oVHD = oDialog;
                    // Initialise the dialog with model only the first time. Then only open it
                    if (that._bDialogInitialized) {
                        // Re-set the tokens from the input and update the table
                        oDialog.setTokens([]);
                        var oToken = new Token();
                        oToken.setKey(that.getView().byId("nomCtrtText").getValue());
                        oToken.setText(that.getView().byId("nomCtrtText").getValue());
                        oDialog.setTokens(oToken);
                        oDialog.update();

                        oDialog.open();
                        return;
                    }
                    that.getView().addDependent(oDialog);

                    // Set Basic Search for FilterBar
                    oFilterBar.setFilterBarExpanded(false);
                    oFilterBar.setBasicSearch(that._oBasicSearchField);

                    // Trigger filter bar search when the basic search is fired
                    that._oBasicSearchField.attachSearch(function () {
                        oFilterBar.search();
                    });

                    var oTable = oDialog.getTable();
                    oTable.setModel(oColModel, "columns");
                    oTable.setModel(oContractModel)
                    oTable.bindRows("/contractModelData");
                    oDialog.setTitle("Contract Number");
                    // set flag that the dialog is initialized
                    that._bDialogInitialized = true;
                    oDialog.open();
                });


            },

            getContractF4Data: function () {
                var that = this;
                var sPath = "/Contract"
                var sFilters = [];
                var filter1 = new sap.ui.model.Filter({
                    path: "SDDocumentCategory",
                    operator: sap.ui.model.FilterOperator.EQ,
                    value1: "G"
                });
                sFilters.push(filter1);
                var oDataModelDailyGas = this.getView().getModel('dailySalesGas');
                if (oDataModelDailyGas !== undefined) {
                    var oContractModel = new sap.ui.model.json.JSONModel();

                    this.getView().setModel(oContractModel, "contractData");

                    //oDataHelper.callGetODataFilter(oDataModelDailyGas, sPath, sFilters)
                    oDataHelper.callGetOData(oDataModelDailyGas, sPath)
                        .then(function (data) {
                            debugger;
                            that.getView().getModel("contractData").setData({ contractModelData: data.results });
                            if (data.results.length > 0 ){
                                that.getView().byId("prdCtrtText").setValue(data.results[0].Contract);
                                that.getView().byId("nomCtrtText").setValue(data.results[0].Contract);
                            }

                        })
                        .catch(function (oError) {
                            MessageBox.error("No contract records found")
                        });
                }
            },

            onNomCtrctLiveChange: function (oEvent) {

                var newValue = oEvent.getParameter('newValue');
                var inputId = oEvent.getParameter('id');
                var regex = /^[a-zA-Z0-9]+$/;
                if (!newValue.match(regex)) {
                    this.byId(inputId).setValueState(sap.ui.core.ValueState.Error);
                    this.byId(inputId).setValueStateText("Only Alphanumeric allowed");
                    this.getView().byId("subNomCtrt").setEnabled(false);
                } else {
                    this.byId(inputId).setValueState(sap.ui.core.ValueState.None);
                    this.getView().byId("subNomCtrt").setEnabled(true)
                }
            }

        });
    });
