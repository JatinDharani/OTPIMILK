sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "jib/utils/calculation"
], function (Controller, JSONModel, MessageToast, calculation) {
    "use strict";
    var oView;
    var oCommonTotal = {
        "Particulars": "",
        "Gjahr": "0000",
        "ITDDec": 0,
        "YearToDateLastMonth": 0,
        "CurrentMonth": 0,
        "YearToDate": 0,
        "InceptionTillDate": 0,
        "Waers": "USD",
        "isHeading": "",
        "isTotal": "",
        "isSubTotal": ""
    }

    var oCommonPDF = {
        "FIELD1": "",
        "FIELD2": "",
        "FIELD3": "",
        "FIELD4": "",
        "FIELD5": "",
        "FIELD6": "",
        "FIELD7": "",
        "FIELD8": "",
        "FIELD9": "",
        "FIELD10": "",
        "FIELD11": "",
        "FIELD12": "",
        "isHeading": "",
        "isSubTotal": "",
        "isTotal": "",
        "TabId": "",
        "SectionID": ""
    }

    let oCommonPDFMapping = {
        "FIELD1": "Particulars",
        "FIELD2": "ITDDec",
        "FIELD3": "YearToDateLastMonth",
        "FIELD4": "CurrentMonth",
        "FIELD5": "YearToDate",
        "FIELD6": "InceptionTillDate",
        "FIELD7": "",
        "FIELD8": "",
        "FIELD9": "",
        "FIELD10": "",
        "FIELD11": "",
        "FIELD12": "",
        "isHeading": "isHeading",
        "isSubTotal": "isSubTotal",
        "isTotal": "isTotal",
        "TabId": "",
        "SectionID": ""

    }
    var aNumericColumns = ["YearToDateLastMonth", "ITDDec", "CurrentMonth", "YearToDate", "InceptionTillDate"]
    return Controller.extend("jib.controller.Main", {
        calculation: calculation,
        // Define the formatter function
        formatClass: function (condition) {
            return condition ? 'total' : 'grandTotal';
        },
        onInit: function () {
            oView = this.getView()
            // Initialize the JSON Model
            var sModelPath = sap.ui.require.toUrl("jib/model/data.json");
            // Get Image Path
            var sLoadingURL = new JSONModel({
                sImagePath: sap.ui.require.toUrl("jib/images/clock_load.png")
            });
            this.getView().setModel(sLoadingURL, 'dataLoadLogo')
            //var oModel3 = new JSONModel(sPath);
            var oInputModel = new JSONModel();
            oInputModel.loadData(sModelPath);
            oInputModel.attachRequestCompleted(function () {
                this.getView().setModel(oInputModel, "data");
                var itemsData = oInputModel.getProperty("/itemsData");
                // Loop through item data and create models for each group
                for (var i = 0; i < itemsData.length; i++) {
                    var modelName = "costObjectGrp" + (i + 1);
                    // Initialize the groups
                    var itemsModel = new JSONModel(itemsData[i]);
                    this.getView().setModel(itemsModel, modelName);
                }
            }.bind(this));
            //Appendix 2 - Schedule of Shareholder Loans due
            this.initAppx2Tables();

            this.getView().setModel(new JSONModel({}), "schBAdvDue")
            this.getView().setModel(new JSONModel({}), "appx4RevRec")
            this.getView().setModel(new JSONModel({}), "schDThirdPartyLoans")
            this.getView().setModel(new JSONModel({}), "schCAggrRevCRR")
        },
        openDatePicker: function (oEvent) {
            this.getView().byId("htbInputMonthYear").openBy(oEvent.getSource().getDomRef());
        },
        /*
         * Formatter function to dynamically generate column header text based on period and year.
         * @param {string} sPeriod Selected period value
         * @param {string} sYear Selected year value */
        formatYTDMinus1Header: function (sPeriod, sYear) {
            var oPeriods = this.getView().getModel('data').getProperty("/Periods");
            if (sPeriod && sPeriod > 1) {
                return "YTD " + oPeriods[sPeriod - 2].value + " " + sYear;
            }
            return "YTD " + oPeriods[11].value + " " + (sYear - 1);
        },
        formatColumnHeader: function (sPeriod) {
            var oPeriods = this.getView().getModel('data').getProperty("/Periods");
            if (sPeriod && sPeriod > 1) {
                return oPeriods[sPeriod - 1].value;
            }
            return oPeriods[0].value;
        },
        formatStyleText(sText, sStyle, isHeading) {
            if (sStyle?.toUpperCase() == "BOLD" && sText == "0" && isHeading == 'X') {
                return ''
            } else if (sStyle?.toUpperCase() == "BOLD") {
                return "<strong>" + sText + "</strong>"
            } else if (sText) {
                return sText;
            } else {
                return '';
            }
        },
        formatITDTillLastYearHeader: function (sYear) {
            return sYear - 1;
        },
        parseData: function (oData) {
            let aProperties = ["YearToDateLastMonth",
                "YearToDate",
                "InceptionTillDate",
                "CurrentMonth",
                "ITDDec"];

            if (oData.results) {
                oData.results.forEach((oItem) => {
                    aProperties.forEach((sProperty) => {
                        oItem[sProperty] = oItem[sProperty] ? parseInt(oItem[sProperty]).toString() : undefined;
                    });

                });
            }
            return oData;
        },
        onSearch: function () {



            var that = this;
            // Make a single backend call to fetch data for Billing Schedule
            var oFilterGjahr = [new sap.ui.model.Filter("Gjahr", sap.ui.model.FilterOperator.EQ, that.getView().getModel("data").getProperty("/Year")),
            new sap.ui.model.Filter("CurrentMonth", sap.ui.model.FilterOperator.EQ, that.getView().getModel("data").getProperty("/SelectedPeriod"))
            ];
            this.getView().getModel().read("/BillingSchAppx1Set", {
                filters: [oFilterGjahr],
                success: function (oData) {
                    // Store the data in a JSON model for filtering 
                    oData = this.parseData(oData);
                    var oModel = new sap.ui.model.json.JSONModel();
                    oModel.setData(oData);
                    that.getView().setModel(oModel, "billingSchedule");

                    // Call function to filter and bind data to tables
                    that.bindDataToTables();
                }.bind(this),
                error: function () {
                    // Handle error
                    sap.m.MessageToast.show("Error fetching data");
                }
            });

            //Call for other entitysets
            // Define the entity sets you want to fetch
            var aEntitySets = [
                { name: "OverheadPayableAppx3A", path: "/OverheadPayableAppx3ASet", sIconTab: "OhdDivPay" },
                { name: "DividendPayableAppx3A", path: "/DividendPayableAppx3ASet", sIconTab: "OhdDivPay" },
                { name: "SchBAdvRevSet", path: "/SchBAdvRevSet", sIconTab: "schBAdvDue" },
                { name: "Appex4Set", path: "/Appex4Set", sIconTab: "Appx4" },
                { name: "SchDLoansSet", path: "/SchDLoansSet", sIconTab: "SchDThirdPartyLoans" },
                { name: "SchCStateSet", path: "/SchCStateSet", sIconTab: "SchCAggrRevCRR" },

            ];

            // Create an array of promises
            var aPromises = aEntitySets.map(function (oEntitySet) {
                return new Promise(function (resolve, reject) {
                    that.getView().getModel().read(oEntitySet.path, {
                        filters: [oFilterGjahr],
                        success: function (oData) {
                            oData = this.parseData(oData);
                            resolve({ name: oEntitySet.name, data: oData, sIconTab: oEntitySet.sIconTab });
                        }.bind(this),
                        error: function () {
                            reject("Error fetching data from " + oEntitySet.name);
                        }
                    });
                }.bind(this));
            }.bind(this));

            // Execute all promises in parallel
            Promise.all(aPromises)
                .then(function (aResults) {
                   let aHeads = ["ITDDec","InceptionTillDate","CurrentMonth","YearToDate","YearToDateLastMonth"];
let bRes=[];
aResults[0].data.results.forEach((oItem)=>{bRes.push(Object.assign({},oItem))});
aResults[0].data.results.forEach(function(oItem){
    if(oItem.OverheadExpenses === "Overheads due but not Paid"){
      let aPaid = bRes.find((oPaid)=>{
          return oPaid.OverheadExpenses === "Overheads Paid" && oPaid.Particulars === oItem.Particulars ;
      });
      let aAccured = bRes.find((oAcc)=>{
          return oAcc.OverheadExpenses === "Overheads Accrued" && oAcc.Particulars === oItem.Particulars ;
      });
      if(aAccured && aPaid){
          aHeads.forEach((sHead)=>{
              oItem[sHead] = (aAccured[sHead]) - (aPaid[sHead]); 
oItem[sHead] = oItem[sHead].toString();
          }); console.log(oItem)
      }
    }
 }.bind(this));

 bRes=[];
aResults[1].data.results.forEach((oItem)=>{bRes.push(Object.assign({},oItem))});

aResults[1].data.results.forEach(function(oItem){
                              if(oItem.DividendExpenses === "Dividend due but not Paid"){
                                let aPaid = bRes.find((oPaid)=>{
                                    return oPaid.DividendExpenses === "Dividend Paid" && oPaid.Particulars === oItem.Particulars ;
                                });
                                let aAccured = bRes.find((oAcc)=>{
                                    return oAcc.DividendExpenses === "Dividend Accrued" && oAcc.Particulars === oItem.Particulars ;
                                });
                                if(aAccured && aPaid){
                                    aHeads.forEach((sHead)=>{
                                        oItem[sHead] = (aAccured[sHead]) - (aPaid[sHead]); 
oItem[sHead] = oItem[sHead].toString();
                                    }); 
                                }
                              }
                           }.bind(this));
                    let oSchBAdvDueModel = oView.getModel("schBAdvDue");

                    let oSchCAggrRevCRRModel = oView.getModel("schCAggrRevCRR");
                    // Process each result
                    aResults.forEach(function (oResult) {
                        if (oResult.sIconTab == "OhdDivPay") {
                            var oModel = new sap.ui.model.json.JSONModel();
                            oModel.setData(oResult.data);
                            that.getView().setModel(oModel, oResult.name); // Set model with a name like 'entityset1'
                        }
                    });

                    // Call function to bind data to tables or other UI elements
                    // that.bindDataToTables();
                    var aTables = [
                        //{ id: "tblOverheadPayble", model: "overheadpayableappx3aset" }
                    ];

                    aTables.forEach(function (oTableInfo) {
                        var oTable = that.byId(oTableInfo.id);
                        oTable.binditems({
                            path: "/" + oTableInfo.model + "/results"
                        });
                        oTable.getBinding("items").refresh(); // Refresh the binding if necessary
                    });
                    let aSchB4PerOhPay = [],
                        aSchBDividendPayableAppx3B = [],
                        aDividendPayableAppx3A = [],
                        aOverheadPayableAppx3A = [];

                    const oDividendPayableAppx3A = this.getView().getModel('DividendPayableAppx3A');
                    const oOverheadPayableAppx3A = this.getView().getModel('OverheadPayableAppx3A');
                    aResults.forEach((Obj) => {

                        if (Obj.name == "OverheadPayableAppx3A") {
                            Obj.data.results.forEach((oOvrPay) => {
                                if (oOvrPay.OverheadExpenses == 'Overheads due but not Paid') {
                                    aSchB4PerOhPay.push({
                                        ...oOvrPay
                                    });
                                }

                                if (oOvrPay.OverheadExpenses == 'Overheads Accrued' && oOvrPay.Particulars == 'Total') {
                                    aOverheadPayableAppx3A.push(oOvrPay)

                                }
                                if (oOvrPay.OverheadExpenses == 'Overheads Paid' && oOvrPay.Particulars == 'Total') {
                                    aOverheadPayableAppx3A.push(oOvrPay)

                                }
                                if (oOvrPay.OverheadExpenses == 'Overheads due but not Paid' && oOvrPay.Particulars == 'Total') {
                                    aOverheadPayableAppx3A.push({
                                        ...oOvrPay,
                                        isTotal: "X"
                                    })

                                }
                            });

                            let aHeads = ["YearToDateLastMonth","CurrentMonth","YearToDate","InceptionTillDate"];
                            let bOverheadPayableAppx3A = [];
                            aOverheadPayableAppx3A.forEach((oItem)=>{
                                bOverheadPayableAppx3A.push(Object.assign({},oItem));
                            });
                            aOverheadPayableAppx3A.forEach(function(oItem){
                              if(oItem.OverheadExpenses === "Overheads due but not Paid"){
                                let aPaid = bOverheadPayableAppx3A.find((oPaid)=>{
                                    return oPaid.OverheadExpenses === "Overheads Paid" ;
                                });
                                let aAccured = bOverheadPayableAppx3A.find((oAcc)=>{
                                    return oAcc.OverheadExpenses === "Overheads Accrued" ;
                                });
                                if(aAccured && aPaid){
                                    aHeads.forEach((sHead)=>{
                                        oItem[sHead] = parseFloat(aAccured[sHead]) - parseFloat(aPaid[sHead]);
                                        oItem[sHead] = oItem[sHead].toString();
                                    });
                                }
                              }
                           }.bind(this));
                            oOverheadPayableAppx3A.setProperty('/aOverheadPayableAppx3A', aOverheadPayableAppx3A)

                        }



                        if (Obj.name == "DividendPayableAppx3A") {
                            Obj.data.results.forEach((oOvrPay) => {
                                if (oOvrPay.DividendExpenses == "Dividend due but not Paid") {
                                    aSchBDividendPayableAppx3B.push({
                                        ...oOvrPay
                                    });
                                }
                                if (oOvrPay.DividendExpenses == 'Dividend Accrued' && oOvrPay.Particulars == 'Total') {
                                    aDividendPayableAppx3A.push(oOvrPay)

                                }
                                if (oOvrPay.DividendExpenses == 'Dividend Paid' && oOvrPay.Particulars == 'Total') {
                                    aDividendPayableAppx3A.push(oOvrPay)

                                }
                                if (oOvrPay.DividendExpenses == 'Dividend due but not Paid' && oOvrPay.Particulars == 'Total') {
                                    aDividendPayableAppx3A.push({
                                        ...oOvrPay,
                                        isTotal: "X"
                                    })

                                }
                            });
                            let aHeads = ["YearToDateLastMonth","CurrentMonth","YearToDate","InceptionTillDate","ITDDec"];
                            let bDividendPayableAppx3A = [];
                            aDividendPayableAppx3A.forEach((oItem)=>{
                                bDividendPayableAppx3A.push(Object.assign({},oItem));
                            });

                           aDividendPayableAppx3A.forEach(function(oItem){
                              if(oItem.DividendExpenses === "Dividend due but not Paid"){
                                let aPaid = bDividendPayableAppx3A.find((oPaid)=>{
                                    return oPaid.DividendExpenses === "Dividend Paid" ;
                                });
                                let aAccured = bDividendPayableAppx3A.find((oAcc)=>{
                                    return oAcc.DividendExpenses === "Dividend Accrued" ;
                                });
                                if(aAccured && aPaid){
                                    aHeads.forEach((sHead)=>{
                                        oItem[sHead] = parseFloat(aAccured[sHead]) - parseFloat(aPaid[sHead]);
                                        oItem[sHead] = oItem[sHead].toString();
                                    });
                                }
                              }
                           }.bind(this));

                            oDividendPayableAppx3A.setProperty('/aDividendPayableAppx3A', aDividendPayableAppx3A)
                        }
                        if (Obj.name == "SchBAdvRevSet") {
                            let aSchBTimCostRechPay = [],
                                aSchBPayTowOthOper = [],
                                aSchBOtherRec = [];
                            Obj.data.results.forEach((record) => {
                                if (record.CostObjectGrp == "OTHREC") {
                                    aSchBOtherRec.push(record)
                                } else if (record.CostObjectGrp == "PAYOTHOPR") {
                                    aSchBPayTowOthOper.push(record)
                                } else {
                                    aSchBTimCostRechPay.push(record)
                                }
                            })
                            oSchBAdvDueModel.setProperty("/aSchBTimCostRechPay", aSchBTimCostRechPay)
                            oSchBAdvDueModel.setProperty("/aSchBPayTowOthOper", aSchBPayTowOthOper)
                            oSchBAdvDueModel.setProperty("/aSchBOtherRec", aSchBOtherRec)
                        }
                        if (Obj.name == "Appex4Set") {
                            this.updateAppex4Set(Obj.data.results)
                        }

                        if (Obj.name == "SchDLoansSet") {
                            this.updateSchDLoansSet(Obj.data.results)
                        }
                        if (Obj.name == "SchCStateSet") {
                            this.updateSchCStateSet(Obj.data.results)
                        }
                    })
                    let aSchB4PerOhPayTotal = { ...oCommonTotal, Particulars: "Total", Style: "Bold", isTotal: "X" }
                    aSchB4PerOhPay.forEach(oOHPay => {
                        aSchB4PerOhPayTotal["ITDDec"] += parseFloat(oOHPay["ITDDec"]) || 0;
                        aSchB4PerOhPayTotal["YearToDateLastMonth"] += parseFloat(oOHPay["YearToDateLastMonth"]) || 0
                        aSchB4PerOhPayTotal["YearToDate"] += parseFloat(oOHPay["YearToDate"]) || 0
                        aSchB4PerOhPayTotal["CurrentMonth"] += parseFloat(oOHPay["CurrentMonth"]) || 0
                        aSchB4PerOhPayTotal["InceptionTillDate"] +=
                            (parseFloat(oOHPay["InceptionTillDate"]) || 0)
                    });
                    aSchB4PerOhPay.push(aSchB4PerOhPayTotal)

                    let aSchBDividendPayableAppx3BTotal = { ...oCommonTotal, Particulars: "Total", Style: "Bold", isTotal: "X" }
                    aSchBDividendPayableAppx3B.forEach(oOHPay => {
                        aSchBDividendPayableAppx3BTotal["ITDDec"] += parseFloat(oOHPay["ITDDec"]) || 0
                        aSchBDividendPayableAppx3BTotal["YearToDateLastMonth"] += parseFloat(oOHPay["YearToDateLastMonth"]) || 0
                        aSchBDividendPayableAppx3BTotal["YearToDate"] += parseFloat(oOHPay["YearToDate"]) || 0
                        aSchBDividendPayableAppx3BTotal["CurrentMonth"] += parseFloat(oOHPay["CurrentMonth"]) || 0
                        aSchBDividendPayableAppx3BTotal["InceptionTillDate"] += aSchBDividendPayableAppx3BTotal["ITDDec"] +
                            aSchBDividendPayableAppx3BTotal["YearToDate"] + (parseFloat(oOHPay["InceptionTillDate"]) || 0)
                    });

                    aSchBDividendPayableAppx3B.push(aSchBDividendPayableAppx3BTotal)

                    oSchBAdvDueModel.setProperty("/aSchB4PerOhPay", aSchB4PerOhPay)
                    oSchBAdvDueModel.setProperty("/aSchBDividendPayableAppx3B", aSchBDividendPayableAppx3B)
                    this.updateSchBAdvDueLoanPay()



                }.bind(this))
                .catch(function (sError) {
                    // Handle errors
                    sap.m.MessageToast.show(sError);
                });

            // Bind data from entity sets to the corresponding tables

        },
        updateAppex4Set(oData) {
            let oAppx4RevRecModel = oView.getModel("appx4RevRec");
            let oSchCAggrRevCRRModel = oView.getModel("schCAggrRevCRR");
            oAppx4RevRecModel.setProperty("/aAppex4Set", oData)
            //Sch C : Table 1 - Statement of Aggregate Revenues and Application
            let aSchCAggrRevApp = [];
            let oRow1 = oData.find(item => item.Identifier == "APPX4SUBTOTALCOLL")
            if (!oRow1) {
                oRow1 = Object.assign({}, oCommonTotal)
            }
            oRow1.Particulars = "Total Collections (A)"
            oRow1.Appendix = "Appendix 4"

            aSchCAggrRevApp.push(oRow1)
            let oRow2 = Object.assign({}, oCommonTotal)
            oRow2.Particulars = "Application of aggregate revenue received -"
            oRow2.isHeading = "X"
            oRow2.Style = "BOLD"
            oRow2.Appendix = ''
            aSchCAggrRevApp.push(oRow2)
            let oRow3 = Object.assign({}, oCommonTotal)
            oRow3.Particulars = "Remuneration Fees retained (B)";
            aNumericColumns.forEach(item => {
                oRow3[item] = oRow1[item] ? Number(oRow1[item]) * 0.22 : 0
                oRow3[item] = parseFloat(oRow3[item]).toFixed(0)
            });
            aSchCAggrRevApp.push(oRow3)

            let oRow4 = Object.assign({}, oCommonTotal)
            oRow4.Particulars = "Petroleum Cost recovered (C)"




            let oRow5 = Object.assign({}, oCommonTotal)
            oRow5.Particulars = "Surplus remaining after Recovery of the Petroleum Costs and Remuneration Fees (D = A - B - C)"
            oRow5.Style = "BOLD"
            oRow5.isTotal = "X"
            oRow5.Appendix = ''
            aNumericColumns.forEach(item => {

                oRow4[item] = (oRow1[item] || 0) - (oRow3[item] || 0)
                oRow4[item] = parseFloat(oRow4[item]).toFixed(0)
                // oRow5[item] = oRow5 - 
            });

            aSchCAggrRevApp.push(oRow4)
            aSchCAggrRevApp.push(oRow5)
            oSchCAggrRevCRRModel.setProperty("/aSchCAggrRevApp", aSchCAggrRevApp)


            // Sch C Table 2 - Cost Recovery statement of Recoverable Petroleum Cost

            let aSchCCostRecovPetrolCost = []
            let oTab2Row1 = Object.assign({}, oCommonTotal)
            oTab2Row1.Particulars = "Total Recoverable Petroleum Costs (A)";
            oTab2Row1.Appendix = "Appendix 1"

            let oTab2Row2 = Object.assign({}, oCommonTotal)
            oTab2Row2.Particulars = "Amount of Petroleum Costs recovered by the company for the period (B)"
            oTab2Row2.Appendix = ''

            let oTab2Row3 = Object.assign({}, oCommonTotal)
            oTab2Row3.Particulars = "Amount of Recoverable Petroleum Costs carried forward into the next period (C = A - B)"
            oTab2Row3.Style = "BOLD"
            oTab2Row3.isTotal = "X"

            aNumericColumns.forEach(item => {
                oTab2Row3[item] = (oTab2Row1[item] || 0) - (oTab2Row2[item] || 0)
            });
            oTab2Row3.Appendix = ''
            aSchCCostRecovPetrolCost = [oTab2Row1, oTab2Row2, oTab2Row3]
            oSchCAggrRevCRRModel.setProperty("/aSchCCostRecovPetrolCost", aSchCCostRecovPetrolCost)

        },
        updateSchCStateSet(oData) {
            let oSchCAggrRevCRRModel = oView.getModel("schCAggrRevCRR");
            oSchCAggrRevCRRModel.setProperty("/aSchCIRR", oData)
        },
        updateSchDLoansSet(oData) {
            let oSchDThirdPartyLoansModel = oView.getModel("schDThirdPartyLoans");
            let aLoanFacilityOutStandBal = [],
                aFacilityD = [],
                aDFC250 = [],
                aNodic = [];
            oData.forEach((record) => {
                if (record.CostObjectGrp == "FACILITYD") {
                    aFacilityD.push(record)
                } else if (record.CostObjectGrp == "DFC250") {
                    aDFC250.push(record)
                } else if (record.CostObjectGrp == "NODICBOND") {
                    aNodic.push(record)
                } else {
                    aLoanFacilityOutStandBal.push(record)
                }
            })
            oSchDThirdPartyLoansModel.setProperty("/aFacilityD", aFacilityD)
            oSchDThirdPartyLoansModel.setProperty("/aDFC250", aDFC250)
            oSchDThirdPartyLoansModel.setProperty("/aNodic", aNodic)
            oSchDThirdPartyLoansModel.setProperty("/aLoanFacilityOutStandBal", aLoanFacilityOutStandBal)
        },
        updateSchBAdvDueLoanPay() {
            let oSchBAdvDueModel = oView.getModel("schBAdvDue");
            let aSchBShareLoanPay = [];
            aSchBShareLoanPay.push(this.buildSchbLaonPay('_oOriginalData_CRSTShareholderLoanSet', 'Crescent'))
            aSchBShareLoanPay.push(this.buildSchbLaonPay('_oOriginalData_DGasShareholderLoanSet', 'Dana Gas'))
            aSchBShareLoanPay.push(this.buildSchbLaonPay('_oOriginalData_MOLShareholderLoanSet', 'MOL'))
            aSchBShareLoanPay.push(this.buildSchbLaonPay('_oOriginalData_OMVShareholderLoanSet', 'OMV'))
            aSchBShareLoanPay.push(this.buildSchbLaonPay('_oOriginalData_RWEShareholderLoanSet', 'RWE'))
            aSchBShareLoanPay = aSchBShareLoanPay.filter(Boolean)
            let oTotal = { ...oCommonTotal, Particulars: "Total", Style: "Bold", isTotal: "X" };
            aSchBShareLoanPay.forEach(obj => {
                oTotal['ITDDec'] += parseFloat(obj['ITDDec']) || 0
                oTotal['InceptionTillDate'] += parseFloat(obj['InceptionTillDate']) || 0
            })
            aSchBShareLoanPay.push(oTotal)
            oSchBAdvDueModel.setProperty("/aSchBShareLoanPay", aSchBShareLoanPay)
        },

        buildSchbLaonPay(objName, sParticular) {

            let oData = this[objName];
            if (oData) {
                let oTotal = oData.find(obj => obj.Particular == "TOTAL")
                let oShTotal = Object.assign({}, oCommonTotal, { Particulars: sParticular });
                oShTotal.ITDDec = parseFloat(oTotal?.Total) || 0
                oShTotal.InceptionTillDate = oShTotal.ITDDec
                return oShTotal
            } else {
                return undefined;
            }

        },

        bindDataToTables: function () {
            var that = this;
            var aFilters = this.getView().getModel("data").getProperty("/filters");

            aFilters.forEach(function (filterInfo) {
                // Access the model containing the original data
                var oOriginalModel = that.getView().getModel("billingSchedule");

                // Create a new array to hold filtered results
                var aFilteredResults = [];

                // Filter the original data
                var aData = oOriginalModel.getProperty("/results"); // Assuming results is the root of your data
                aData.forEach(function (item) {
                    if (item.CostObjectGRP === filterInfo.filterValue ||
                        item.CostObjectGRP === filterInfo.filterValue2 ||
                        item.CostObjectGRP === filterInfo.filterValue3)
                    //&&
                    //item.Gjahr === that.getView().getModel("data").getProperty("/Year")) 
                    {
                        aFilteredResults.push(item);
                    }
                });

                // Create a new JSON model for the filtered results
                var oFilteredModel = new sap.ui.model.json.JSONModel();
                oFilteredModel.setData({ results: aFilteredResults });

                // Set the filtered model to the table
                var oTable = that.byId(filterInfo.tableId);
                oTable.setModel(oFilteredModel, filterInfo.tableId);
                calculation.calculateSubTotals.apply(that, [filterInfo.tableId]);
                // hide no data tables
                if (oFilteredModel.getProperty("/results").length === 0) {
                    oTable.setVisible(false);
                }
            });
            calculation.computeGrandTotal.apply(this, []);
            var oModel = this.getView().getModel("data");
            oModel.setProperty("/Visible", true);
            var oIconTabBar = that.getView().byId('idIconTabBar')
            oIconTabBar.setBusy(false);
            that.getView().byId('htbButtonPrint').setBusy(false);
            that.getView().byId('htbInputMonthYear').setBusy(false);
        },

        // Function to calculate totals for a specific table


        calculateTotals: function (tableIds) {
            var totalITDDec = 0;
            var totalYTDLastMonth = 0;
            var totalCurrentMonth = 0;
            var totalYTD = 0;
            var totalInception = 0;

            tableIds.forEach(tableId => {
                const model = this.getView().getModel("totals_" + tableId);
                if (model) {
                    const data = model.getData();
                    if (data.totals) {
                        totalITDDec += Number(data.totals.ITDDec) || 0;
                        totalYTDLastMonth += Number(data.totals.YearToDateLastMonth) || 0;
                        totalCurrentMonth += Number(data.totals.CurrentMonth) || 0;
                        totalYTD += Number(data.totals.YearToDate) || 0;
                        totalInception += Number(data.totals.InceptionTillDate) || 0;
                    }
                } else {
                    console.warn("Model not found for tableId:", tableId);
                }
            });

            return {
                ITDDec: totalITDDec.toFixed(2),
                YTDLastMonth: totalYTDLastMonth.toFixed(2),
                CurrentMonth: totalCurrentMonth.toFixed(2),
                YTD: totalYTD.toFixed(2),
                Inception: totalInception.toFixed(2)
            };  // Return the totals as an object
        },


        addValues: function (value1, value2, value3) {
            if (value3) {
                return (parseFloat(value1) || 0) + (parseFloat(value2) || 0) + (parseFloat(value3) || 0);
            }
            else {
                return (parseFloat(value1) || 0) + (parseFloat(value2) || 0);
            }
        },
        handleInputChange: function (oEvent) {
            this.getView().byId('idIconTabBar').setVisible(true);
            this.getView().byId('htbButtonPrint').setEnabled(true);
            this.getView().byId('idIconTabBar').setBusy(true);
            this.getView().byId('htbButtonPrint').setBusy(true);
            var selectedDate = oEvent.getParameter("value");
            var dateParts = selectedDate.split('-');
            var selectedMonth = parseInt(dateParts[0], 10); // MM
            var selectedYear = parseInt(dateParts[1], 10); // yyyy

            // Update model with the selected month and year
            var oModel = this.getView().getModel("data");
            oModel.setProperty("/SelectedPeriod", selectedMonth);
            oModel.setProperty("/Year", selectedYear);
            oModel.setProperty("/Visible", false);
            if (selectedYear) {
                this.onSearch();
            }
        },
        onGo: function (oEvent) {
            // var oIconTabBar = this.getView().byId('idIconTabBar')
            //  oIconTabBar.setVisible(true);
            //    this.getView().byId('htbButtonPrint').setEnabled(true);
            //Initiate Appendix4 & Schedule D
            //Define an array of entity set names

        },

        //Appendix 2B - Outstanding Dana Gas Shareholder Loan
        initAppx2Tables: function () {
            var that = this;
            // Define an array of entity set names
            var aEntitySetNames = ["ShareholderLoanDueSet", "CRSTShareholderLoanSet",
                "DGasShareholderLoanSet", "OMVShareholderLoanSet",
                "MOLShareholderLoanSet", "RWEShareholderLoanSet"];

            // Get the OData model from the owner component
            var oModel = this.getOwnerComponent().getModel();

            // Iterate through each entity set name
            aEntitySetNames.forEach(function (sEntitySetName) {
                // Read data from the OData service for each entity set
                oModel.read("/" + sEntitySetName, {
                    success: function (oData) {
                        // Process the data for each entity set
                        oData = this.parseData(oData);
                        this.processEntitySetData(sEntitySetName, oData.results);
                    }.bind(this),
                    error: function (oError) {
                        // Handle error if data fetching fails
                        console.error("Failed to fetch data from OData service for entity set: " + sEntitySetName);
                    }
                });

                // Initialize a JSON model for UI state
                var oUiModel = new JSONModel({ editMode: false });
                // Set the UI model for each entity set
                this.getView().setModel(oUiModel, "ui_" + sEntitySetName);
            }, this);
        },

        processEntitySetData: function (sEntitySetName, aEntitySetData) {
            // Define an array of primary keys for each entity set
            var aPrimaryKeys = [
                { sParticular: "OPNG_BAL", sParticularText: "Opening Balance" },
                { sParticular: "FUNDING", sParticularText: "Funding" },
                { sParticular: "INTEREST", sParticularText: "Interest" },
                { sParticular: "REPAYMENT", sParticularText: "Repayment" },
                { sParticular: "TOTAL", sParticularText: "Total" }
            ];

            // Extract existing records from OData response 
            var aExistingRecords = aEntitySetData;

            // Check and add missing primary key records
            aPrimaryKeys.forEach(function (oPrimaryKey) {
                var bRecordExists = aExistingRecords.some(function (oRecord) {
                    return oRecord.Particular === oPrimaryKey.sParticular;
                });

                if (!bRecordExists) {
                    aExistingRecords.push({
                        Currency: "USD",
                        Particular: oPrimaryKey.sParticular,
                        ParticularText: oPrimaryKey.sParticularText
                    });
                }
            });

            // Store original data for reverting
            this["_oOriginalData_" + sEntitySetName] = JSON.parse(JSON.stringify(aExistingRecords));

            // Create a JSON model for the processed data
            var oJsonModel = new JSONModel({ [sEntitySetName]: aExistingRecords });

            // Set the JSON model for the corresponding table
            var sTableId = sEntitySetName.replace('Set', 'Table').replace('/', '');
            this.getView().byId(sTableId).setModel(oJsonModel, 'data');

            // Initialize a JSON model for UI state
            var oUiModel = new JSONModel({ editMode: false });
            // Set the UI model for each entity set
            this.getView().setModel(oUiModel, "ui_" + sEntitySetName);
        },
        onEditToggle: function (oEvent) {
            // Toggle edit mode for the clicked entity set
            var sEntitySetName = oEvent.getSource().getParent().getParent().getBindingInfo('rows').path;
            var oUiModel = this.getView().getModel("ui_" + sEntitySetName.replace('/', ''));
            var beditMode = oUiModel.getProperty("/editMode");
            oUiModel.setProperty("/editMode", !beditMode);
            var sTableId = oEvent.getSource().getParent().getParent().getId().split('Main')[1].replace('--', '');
            // Get the table by its ID
            var oTable = this.byId(sTableId);
            // Set the visibleRowCount to 4
            oTable.setVisibleRowCount(4);
        },

        onSave: function (oEvent) {
            try {
                oView.setBusy(true)
                var sTableId = oEvent.getSource().data()["sTableId"]
                // Get the table by its ID
                var oTable = oView.byId(sTableId);
                // Save the data for the clicked entity set
                var sEntitySetName = oEvent.getSource().getParent().getParent().getBindingInfo('rows').path.replace('/', '');
                var oModel = this.getView().byId(sEntitySetName.replace('Set', 'Table')).getModel('data');
                var aData = oModel.getData()[sEntitySetName];
                var oODataModel = this.getView().getModel();

                // Use a deferred group for the batch request
                var sGroupId = "batchGroup";
                oODataModel.setDeferredGroups([sGroupId]);
                oODataModel.setChangeBatchGroups({
                    sEntitySetName: { groupId: sGroupId, changeSetId: "changeSet" },
                });
                var oTotals = {
                    Particular: "TOTAL", // Label for the total row
                    ParticularText: sEntitySetName === 'ShareholderLoanDueSet' ? "Total" : "Closing Balance",
                    Currency: "USD"
                };
                var sTotal = 0.00;
                // Check if aData is not empty before trying to delete the last record
                if (aData.length > 0) {
                    var lastRow = aData[aData.length - 1]; // Get the last row
                    aData.splice(aData.length - 1, 1); // Remove the last row
                    console.log("Deleted last row:", lastRow);
                }

                // Iterate over the data and create update requests
                aData.forEach(function (oEntry) {
                    // Iterate through each property of oRecord
                    Object.keys(oEntry).forEach(function (key) {
                        if (key !== "Particular" && key !== "ParticularText" && !key.startsWith("_")) {
                            // Add the current input value to the total
                            if (oEntry[key] !== "") {
                                // Remove commas from the input string
                                oEntry[key] = oEntry[key]?.replace(/,/g, '');
                                var value = parseFloat(oEntry[key]);
                                if (!isNaN(value)) {
                                    oTotals[key] = (oTotals[key] || 0.00) + value;
                                    if (key === 'Total') {
                                        sTotal = (sTotal || 0.00) + value;
                                    }
                                }
                            }
                            // Sum numeric values

                        }
                        else if (key === "__metadata" && !oTotals[key]) {
                            oTotals[key] = oEntry[key];
                        }
                        // Check if the value is not enclosed in double quotes
                        if (typeof oEntry[key] !== "string" && key !== "__metadata" && key !== "Total") {
                            oEntry[key] = oEntry[key]?.toString();
                        }
                    });
                    var sPath = "/" + sEntitySetName + "('" + oEntry.Particular + "')"; // Ensure you have the correct primary key ID here
                    oODataModel.update(sPath, oEntry, {
                        groupId: sGroupId,
                        changeSetId: "changeSet",
                        merge: true
                    });
                });
                Object.keys(oTotals).forEach(function (key) {
                    if (key !== "string" && key !== "Particular" && key !== "ParticularText" && !key.startsWith("_") && key !== "Currency") {
                        //oTotals[key] = oTotals[key].toString();
                        // Check if the value is a valid number
                        if (key === 'Total') {
                            oTotals[key] = sTotal;
                        }
                        if (typeof oTotals[key] === 'number' && !isNaN(oTotals[key])) {
                            // Format the number to two decimal places
                            oTotals[key] = oTotals[key].toFixed(2);
                            /*if (typeof oTotals[key] !== "string" && key !== "__metadata" && key !== "Total") {
                                oTotals[key] = oTotals[key].toString();
                            } */
                        } else {
                            // If it's not a number, ensure it's treated as "0.00"
                            oTotals[key] = "0.00";
                        }
                    }

                    if (key === '__metadata') {
                        oTotals[key].id = oTotals[key].id.replace('OPNG_BAL', 'TOTAL');
                        oTotals[key].uri = oTotals[key].uri.replace('OPNG_BAL', 'TOTAL');
                    }
                });
                var sPath = "/" + sEntitySetName + "('" + oTotals.Particular + "')"; // Ensure you have the correct primary key ID here

                oODataModel.update(sPath, oTotals, {
                    groupId: sGroupId,
                    changeSetId: "changeSet",
                    merge: true
                });

                aData.push(oTotals);
            } catch (oErr) {
                oView.setBusy(false)
                MessageToast.show(JSON.stringify(oErr))
            }
            oView.setBusy(true)
            // Submit the batch request
            oODataModel.submitChanges({
                groupId: sGroupId,
                success: function (oData) {
                    this.updateSchBAdvDueLoanPay()
                    oView.setBusy(false)
                    MessageToast.show("Data saved successfully!");
                    // Set edit mode to false after saving
                    oView.getModel("ui_" + sEntitySetName).setProperty("/editMode", false);
                    // Step 20: Update original data to the current data after saving
                    this["_oOriginalData_" + sEntitySetName] = JSON.parse(JSON.stringify(aData));
                    oModel.setProperty("/" + sEntitySetName, JSON.parse(JSON.stringify(this["_oOriginalData_" + sEntitySetName])));
                    //Get table ID

                    // Set the visibleRowCount to 5
                    oTable.setVisibleRowCount(5);
                }.bind(this),
                error: function (oError) {
                    oView.setBusy(false)
                    MessageToast.show("Failed to save data.");
                    console.error("Batch save error:", oError);
                }
            });

            // // Set edit mode to false after saving
            // this.getView().getModel("ui_" + sEntitySetName).setProperty("/editMode", false);
            // // Step 20: Update original data to the current data after saving
            // this["_oOriginalData_" + sEntitySetName] = JSON.parse(JSON.stringify(aData));
            // oModel.setProperty("/" + sEntitySetName, JSON.parse(JSON.stringify(this["_oOriginalData_" + sEntitySetName])));
            // //Get table ID
            // var sTableId = oEvent.getSource().getParent().getParent().getId().split('Main')[1].replace('--', '');
            // // Get the table by its ID
            // var oTable = this.byId(sTableId);
            // // Set the visibleRowCount to 5
            // oTable.setVisibleRowCount(5);
        },
        onCancel: function (oEvent) {
            // Cancel editing for the clicked entity set
            var sEntitySetName = oEvent.getSource().getParent().getParent().getBindingInfo('rows').path.replace('/', '');

            var oModel = this.getView().byId(sEntitySetName.replace('Set', 'Table')).getModel('data');

            // Revert changes by resetting to original data
            oModel.setProperty("/" + sEntitySetName, JSON.parse(JSON.stringify(this["_oOriginalData_" + sEntitySetName])));

            // Set edit mode to false
            this.getView().getModel("ui_" + sEntitySetName).setProperty("/editMode", false);
            //Get table ID
            var sTableId = oEvent.getSource().getParent().getParent().getId().split('Main')[1].replace('--', '')
            // Get the table by its ID
            var oTable = this.byId(sTableId);
            // Set the visibleRowCount to 5
            oTable.setVisibleRowCount(5);
        },
        validateDecimalInput: function (oEvent) {
            var oInput = oEvent.getSource();
            var sValue = oInput.getValue();

            // Regular expression to match numbers with two decimal places
            var decimalRegex = /^-?(?=\d)(\d{1,3}(,\d{3})*|(\d+))([.,]\d{1,2})?$/;

            if (!decimalRegex.test(sValue) && sValue !== "") {
                // Clear the input field or show an error message
                oInput.setValueState("Error");
                oInput.setValueStateText("Please enter a valid number with up to two decimal places.");
            } else {
                oInput.setValueState("None");

                // Get the current item context
                var oitemContext = oInput.getBindingContext("data");

                // Get the model object for the current item
                var oitemData = oitemContext.getObject();

                // Get the binding path name for the cell
                var sBindingPath = oInput.getBindingInfo("value").binding.getPath();
                if (sBindingPath == undefined) {
                    sBindingPath = oInput.getBindingInfo("value").binding.aBindings[0].sPath;
                }
                // Initialize total
                var total = 0.00;
                //Opening Blanace to zero
                if (oitemData.Particular !== 'OPNG_BAL') {
                    // Add the current input value to the total
                    if (sValue !== "") {
                        // Remove commas from the input string
                        const sanitizedValue = sValue.replace(/,/g, '');
                        total += parseFloat(sanitizedValue);
                    }
                    // Iterate over the properties of the item data object
                    for (var key in oitemData) {
                        // Check if the property is a numeric value and not "Total" or the current input field
                        if (!isNaN(parseFloat(oitemData[key])) && key !== "Total" && key !== sBindingPath) {
                            // Add the numeric value to the total
                            const sanitizedValue = oitemData[key].replace(/,/g, '');
                            total += parseFloat(sanitizedValue);
                        }
                    }
                } //if( oitemData.Particular !== 'OPNG_BAL' )

                // Set the calculated total back to the model
                oitemData.Total = total.toFixed(2); // Ensure total is formatted with 2 decimal places

                // Refresh the model to reflect the changes
                oitemContext.getModel().refresh();
            }
        },
        adjustDecimalInput: function (oEvent) {
            var oInput = oEvent.getSource();
            var sValue = oInput.getValue();

            // Regular expression to check if the value has decimal places
            //var decimalRegex = /^-?(?=\d)(\d{1,3}(,\d{3})*|(\d+))([.,]\d{1,2})?$/;

            if (!sValue.split('.')[1] && sValue !== "") {
                debugger;
                // If the value doesn't have decimal places, append .00 to it
                sValue += ".00";
                oInput.setValue(sValue);
            }
        },
        _applyitemStyles: function (oEvent) {
            let oTableRow = this.byId(oEvent.getSource().getId().split('Main--')[1]).getRows()[4];
            // Add style class to every 5th item
            if (oTableRow) {
                oTableRow.addStyleClass("totalRow");
            }
        },
        onPrintBackend: function () {
            let oPayload = this._getPayload();
            let oModel = this.getView().getModel();
            oModel.setUseBatch(false);

            try {
                this.getView().setBusy(true);
                oModel.create("/PDFFormSet", oPayload, {
                    success: (oData) => {
                        // console.log(oData)
                        this.getView().setBusy(false);
                        var decodedPdfContent = atob(oData.pdf);
                        var byteArray = new Uint8Array(decodedPdfContent.length)
                        for (var i = 0; i < decodedPdfContent.length; i++) {
                            byteArray[i] = decodedPdfContent.charCodeAt(i);
                        }
                        var blob = new Blob([byteArray.buffer], { type: 'application/pdf' });
                        var _pdfurl = URL.createObjectURL(blob);
                        var _PDFViewer = new sap.m.PDFViewer({
                            width: "auto",
                            source: _pdfurl // my blob url
                        });
                        jQuery.sap.addUrlWhitelist("blob");

                        _PDFViewer.open();
                    }, error: (oError) => {
                        this.getView().setBusy(false);
                        console.log(oError)
                    }
                });
            } catch (e) {
                this.getView().setBusy(false);
                debugger;
            }
        },
        _getPayload: function () {
            let oPrint = { "id": "Print", "pdf": " " };
            oPrint.sch_shareSet = this._getShareData();
            oPrint.bill_schSet = this._getBills();
            oPrint.over_payableSet = this._getOverheadPayable();
            oPrint.div_payableSet = this._getDivPayable();
            oPrint.out_rweSet = this.getout_rweSet();
            oPrint.out_molSet = this.getout_molSet();
            oPrint.out_omvSet = this.getout_omvSet();
            oPrint.out_danaSet = this.getout_danaSet();
            oPrint.out_crescentSet = this.getout_crescentSet();
            oPrint.sch_shareSet = this.getsch_shareSet();
            oPrint.out_appendix4Set = this.getout_CommonTabs("appx4RevRec");
            oPrint.out_schbSet = this.getout_CommonTabs("schBAdvDue");
            oPrint.out_schcSet = this.getout_CommonTabs("schCAggrRevCRR");
            oPrint.out_schdSet = this.getout_CommonTabs("schDThirdPartyLoans");
            return oPrint;
        },

        getout_CommonTabs(sModelName) {
            let oAppx4RevRecModel = oView.getModel(sModelName);
            let oData = oAppx4RevRecModel.getData();
            if (!oData) return []

            let aOutput = [];
            let aKeys = Object.keys(oData);
            for (const sSection of aKeys) {
                const aRecords = oData[sSection];
                if (aRecords.length > 0) {
                    // Create a copy of the common PDF header
                    let oCopyPDFOutputHeader = { ...oCommonPDF };

                    // If the section is a Table, update the header with additional info
                    const oSectionView = oView.byId("_ID" + sSection);
                    if (oSectionView?.getMetadata()?._sClassName === "sap.m.Table") {
                        const obj = this._getHeader(oSectionView.getColumns());
                        if (obj) {
                            oCopyPDFOutputHeader = {
                                ...oCopyPDFOutputHeader,
                                ...obj,
                                Style: "Bold",
                                isHeading: "X",
                                SectionID: sSection,
                                TabId: sModelName
                            };
                            aOutput.push(oCopyPDFOutputHeader)
                        }
                    }

                    // Process each record in the section
                    aRecords.forEach(record => {
                        let oCopyPDFOutput = { ...oCommonPDF };
                        Object.keys(oCommonPDF).forEach(sPDFKey => {
                            // Map values from record using the mapping object
                            oCopyPDFOutput[sPDFKey] = record[oCommonPDFMapping[sPDFKey]]?.toString() || '';

                        });

                        // Assign SectionID and TabId explicitly
                        oCopyPDFOutput["SectionID"] = sSection;
                        oCopyPDFOutput["TabId"] = sModelName;

                        aOutput.push(oCopyPDFOutput);
                        console.log("sectionId", sSection, oCopyPDFOutput);
                    });
                }
            }
            return aOutput;

        },
        _getShareData: function () {
            let aMapping = {
                Crescent: "FIELD1",
                Currency: "FIELD2",
                CurrentMonth: "FIELD3",
                DanaGas: "FIELD4",
                ITDDec: "FIELD5",
                InceptionTillDate: "FIELD6",
                Mol: "FIELD7",
                Omv: "FIELD8",
                Particular: "FIELD9",
                ParticularText: "FIELD10",
                Rwe: "FIELD11",
                Total: "FIELD12"
            };

            let aShareTables = ["ShareholderLoanDueTable", "CRSTShareholderLoanTable", "DGasShareholderLoanTable", "OMVShareholderLoanTable", "MOLShareholderLoanTable", "RWEShareholderLoanTable"];
            let aDataSet = aShareTables.map((sTable) => {
                return this.getView().byId(sTable).getModel("data").getProperty("/" + sTable.replace("Table", "Set"))
            });
            let aItems = [];
            aDataSet.forEach((aData) => {
                aData.forEach((oData) => {
                    let aItem = {};
                    Object.keys(aMapping).forEach((oProp) => {
                        aItem[aMapping[oProp]] = oData[oProp];
                    });
                    aItems.push(aItem);
                });
            });
            return aItems;
        },
        onPrintPDF: function () {
            const { jsPDF } = window.jspdf;
            if (!jsPDF) {
                MessageToast.show("jsPDF library is not loaded.");
                return;
            }

            //Page Size
            var pdfsize = 'a2';
            var doc = new jsPDF('p', 'pt', pdfsize);

            // Set the title for the PDF
            doc.setFontSize(22);
            doc.setFont("helvetica", "bold");
            const mainTitle = "Pearl Petroleum Company Limited";
            const titleWidth = doc.getTextWidth(mainTitle);
            const pageWidth = doc.internal.pageSize.getWidth();

            // Set the color for the title
            doc.setTextColor(0, 102, 204); // RGB color (Blue)

            // Center the title
            doc.text(mainTitle, (pageWidth - titleWidth) / 2, 27);

            //Prepare table array
            const aTableId = this.getView().getModel("data").getProperty("/tables");

            var getColumns = function (tableId) {
                var columns2 = [];
                var table = this.byId(tableId); // Use the passed table ID to get the table

                // Check if the table exists
                if (table, tableId) {
                    // Iterate through each column of the table
                    table.getColumns().forEach(function (column) {
                        if (tableId.endsWith("e")) {
                            columns2.push(column.getLabel().getText());
                        }
                        else {
                            columns2.push(column.getHeader().getText()); // Get the text of the column header
                        }
                    });
                } else {
                    console.warn("Table with ID '" + tableId + "' not found."); // Log a warning if the table is not found
                }

                return columns2;
            }.bind(this);
            var currentIndex = [];
            function numberWithCommas(x) {
                if (isNaN(x)) return x; // Return the input if it's not a number
                return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            }
            var getAppx1 = function (tableIds) {
                var allData = []; // Array to hold data for all tables    
                currentIndex = 0;
                // Loop through each provided table ID
                tableIds.forEach(function (tableId,) {
                    currentIndex += currentIndex + 1
                    var data = []; // Array to hold data for the current table
                    var table = this.byId(tableId.tableId); // Use the passed table ID to get the table

                    // Check if the table exists
                    if (table, tableId) {
                        var itemData = [];
                        // Check if the tableId ends with "e" sap.ui.table
                        if (tableId.tableId.endsWith("e")) {
                            table.getRows().forEach(function (row) {
                                var rowData = []; //{};
                                row.getCells().forEach(function (cell, index) {
                                    rowData.push(cell.getAggregation('items')[0].getText());
                                });
                                allData.push(rowData);
                            });
                        }
                        else {
                            // Get the binding for the 'items' aggregation
                            if (tableId.tableId.endsWith("T")) {
                                let total = [];
                                table.getItems()[0].getCells().forEach(function (cell, currentIndex) {
                                    let cellValue = currentIndex === 0 ? cell.getHtmlText().replace(/<\/?(p|strong|br)[^>]*>|amp;/g, '') : cell.getProperty('text')
                                    total.push(cellValue);
                                });
                                allData.push(total);
                            }
                            else {
                                table.getBinding('items').oList.forEach(function (item) {
                                    itemData = [];
                                    if (tableId.tableId.endsWith("H")) {
                                        itemData.push((item.value1).replace(/<\/?(p|strong|br)[^>]*>|amp;/g, ''));
                                    }
                                    else {
                                        // Determine the main value based on the tableId
                                        const mainValue = tableId.tableId.endsWith("A") || tableId.tableId.endsWith("B")
                                            ? (item.DividendExpenses || item.OverheadExpenses)
                                            : (item.Post1 || item.CLText);
                                        itemData.push(mainValue);

                                        // Push values conditionally based on the tableId
                                        if (tableId.tableId.endsWith("A") || tableId.tableId.endsWith("B")) {
                                            itemData.push(item.Particulars);
                                        }
                                        // Always push these values
                                        itemData.push(
                                            numberWithCommas(item.ITDDec),
                                            numberWithCommas(item.YearToDateLastMonth),
                                            numberWithCommas(item.CurrentMonth),
                                            numberWithCommas(item.YearToDate),
                                            numberWithCommas(item.InceptionTillDate));
                                    }
                                    data.push(itemData); // Add item data to the current table data
                                    allData.push(itemData);
                                });
                            }
                            if (tableId.tableId.endsWith("SD") || tableId.tableId.endsWith("ST")) {
                                let total = [];
                                table.getColumns().forEach(function (column) {
                                    if (column.getFooter().aCustomStyleClasses) {
                                        var footerValue = column.getFooter().getHtmlText().replace(/<\/?(p|strong|br)[^>]*>|amp;/g, '');
                                    }
                                    else {
                                        footerValue = column.getFooter().getText();
                                    }

                                    if (footerValue) {
                                        total.push(footerValue);
                                    }
                                });
                                if (total) {
                                    allData.push(total);
                                }
                            }
                        }
                    }
                }, this); // Maintain context
                return allData; // Return data for all tables
            }.bind(this);

            let startY = 39;
            aTableId.forEach(function (tableInfo) {
                // Reset font to regular for other text
                doc.setFont("helvetica", "normal");

                // First table
                doc.setFontSize(12); // Set font size for the title 

                var columnStyles = {
                    0: { halign: 'left' } // Left align for the first column (index 0)
                };
                const endsWithAB = tableInfo.tableHeader.endsWith("A") || tableInfo.tableHeader.endsWith("B");
                // Set alignment for remaining columns based on the condition
                for (let i = endsWithAB ? 2 : 1; i <= 12; i++) {
                    columnStyles[i] = { halign: 'right' }; // Right align for all relevant columns
                }

                // Check if there is enough space for the table
                const tableHeight = doc.autoTable.previous.finalY + 115; // Height required for the table
                const remainingSpace = doc.internal.pageSize.height; // 10 is the margin from the bottom

                // If there's not enough space, move to the next page
                if (remainingSpace < tableHeight) {
                    doc.addPage(); // Add a new page
                    startY = 20; // Reset startY for the new page

                    // Re-add title and line to the new page
                    doc.text(tableInfo.tableTitle, 40, startY);
                    //startY = 39; // Update startY again
                }
                else {
                    doc.text(tableInfo.tableTitle, 40, startY);
                }

                // Use AutoTable to create a table in the PDF with customized options
                doc.autoTable({
                    theme: 'grid',
                    startY: startY + 10,
                    head: [getColumns(tableInfo.tableHeader)],
                    body: getAppx1(tableInfo.tableData),
                    pageBreak: 'auto', // Automatically handle page breaks
                    headStyles: {
                        fillColor: [0, 76, 153], // Set background color for header Dark Blue 
                        textColor: [255, 255, 255], // Set text color for header White
                        fontStyle: 'bold' // Set font style for header (optional)
                    },
                    styles: {
                        lineColor: [0, 0, 0],
                        lineWidth: 0.75,
                        fontSize: 10
                    },
                    willDrawCell: function (hook) {
                        if (hook.section === 'body' && Array.isArray(hook.row.raw) && hook.row.raw.length > 0) {
                            // Now it's safe to access hook.row.raw[0]
                            const firstElement = hook.row.raw[0]; // Access the first element
                            const secondElement = hook.row.raw[1]; // Access the second element
                            const rowCell = firstElement || secondElement;
                            doc.setFontSize(10);
                            // Check if includes is defined on the first element
                            if (rowCell && typeof rowCell.includes === 'function') {
                                if (rowCell.includes('Total') || rowCell.includes('Closing Balance')) {
                                    doc.setFillColor(255, 248, 220); //Light Gray
                                    doc.setFont('helvetica', 'bold');
                                    doc.setTextColor(0, 100, 0); //Dark Blue
                                    //doc.setFontSize(10);
                                }
                                else if (rowCell.includes('Sub-total')) {
                                    doc.setFillColor(240, 240, 240); //Light Gray
                                    doc.setFont('helvetica', 'bold');
                                    doc.setTextColor(0, 0, 139); //Dark Blue
                                    //doc.setFontSize(10);
                                }
                                else if (secondElement === undefined) {
                                    doc.setFillColor(230, 230, 250); //230, 230, 250
                                    doc.setFont('helvetica', 'bold');
                                    doc.setTextColor(65, 105, 225); //65, 105, 225
                                    //doc.setFontSize(10);
                                }
                                else {
                                    doc.setTextColor(0, 0, 0); //230, 230, 250
                                    doc.setFontSize(9);
                                    //doc.setFont('helvetica', 'bold');
                                }
                            }
                        }
                    },
                    columnStyles: columnStyles,
                    tableLineColor: [44, 62, 80],
                    tableLineWidth: 0.75
                });
                startY = doc.lastAutoTable.finalY + 15;
            });
            // Save the document
            var selectedPeriod = this.getView().getModel('data').getProperty("/SelectedPeriod");
            var selectedYear = this.getView().getModel('data').getProperty("/Year");
            doc.save('JIB_' + selectedPeriod + '_' + selectedYear + '.pdf');
        },
        _getFooter: function (aColumns) {
            let oColPay = {};
            aColumns.forEach((oColumn, index) => {

                if (oColumn.getFooter) {
                    if (oColumn.getFooter() && oColumn.getFooter().aCustomStyleClasses) {
                        oColPay["FIELD" + (index + 1)] = oColumn.getFooter().getHtmlText().replace(/<\/?(p|strong|br)[^>]*>|amp;/g, '');
                    }
                    else {
                        oColPay["FIELD" + (index + 1)] = oColumn.getFooter() ? oColumn.getFooter().getText() : "";
                    }
                }
            });


            return oColPay;
        },
        _getHeader: function (aColumns) {
            let oColPay = {};
            aColumns.forEach((oColumn, index) => {
                if (oColumn.getHeader && oColumn.getHeader() && oColumn.getHeader().getText()) {
                    oColPay["FIELD" + (index + 1)] = oColumn.getHeader().getText ? oColumn.getHeader().getText() : oColumn.getHeader().getHtmlText ? oColumn.getHeader().getHtmlText().replace(/<\/?(p|strong|br)[^>]*>|amp;/g, '') : "";
                }
                if (oColumn.getLabel && oColumn.getLabel() && oColumn.getLabel().getText()) {
                    oColPay["FIELD" + (index + 1)] = oColumn.getLabel().getText ? oColumn.getLabel().getText() : oColumn.getLabel().getHtmlText ? oColumn.getLabel().getHtmlText().replace(/<\/?(p|strong|br)[^>]*>|amp;/g, '') : "";
                }
            });
            return oColPay;
        },
        _getBills: function () {
            let aTables = ["tblKM250ExProjH", "tblKM250ExProjA1SD", "tblKM250ExProjA2SD", "tblKM250ExProjA3SD", "tblKM250T", "tblEPActH", "tblEPActSD", "tblProComActH", "tblProComActSD", "tblProComActST", "tblEPActClsdH", "tblEPActClsdSD", "tblProComActClsdH", "tblProComActClsdSD", "tblProComActClsdST", "tblFinPreCstsPDAH", "tblIntCstsSD", "tblOvhCstsPDAH", "tblOvhCstsPDAD", "tblFinCstsPDAD", "tblProDevCstsFCOHST", "tblKMCHH", "tblKMCHSD", "tblOpKorOpxH", "tblKMOpxSD", "tblTotalOperationsST"];
            let aPay = [];
            aTables.forEach((sTable) => {
                let oTable = this.getView().byId(sTable);
                let aItems = oTable.getItems ? oTable.getItems() : oTable.getRows()
                if (aItems.length > 0) {

                    let aColumns = oTable.getColumns();
                    let oColPay = this._getHeader(aColumns);
                    if (Object.keys(oColPay).length > 0) {
                        let bAllEmpty = Object.keys(oColPay).find((sKey) => {
                            return oColPay[sKey] !== "" ? true : false;
                        });
                        if (bAllEmpty) {
                            aPay.push(oColPay);
                        }
                    }




                    aItems.forEach((oItem) => {
                        let oPay = {};
                        oItem.getCells().forEach((oCell, index) => {
                            if (oCell.getMetadata()._sClassName === "sap.m.HBox") {
                                oCell = oCell.getItems()[0];
                            }
                            oPay["FIELD" + (index + 1)] = oCell.getText ? oCell.getText() : oCell.getHtmlText ? oCell.getHtmlText() : "";
                        });
                        if (Object.keys(oPay).length > 0) {
                            let bAllEmpty = Object.keys(oPay).find((sKey) => {
                                return oPay[sKey] !== "" ? true : false;
                            });
                            if (bAllEmpty) {
                                aPay.push(oPay);
                            }
                        }
                    });

                    let oFootPay = this._getFooter(aColumns);

                    if (Object.keys(oFootPay).length > 0) {
                        let bAllEmpty = Object.keys(oFootPay).find((sKey) => {
                            return oFootPay[sKey] !== "" ? true : false;
                        });
                        if (bAllEmpty) {
                            aPay.push(oFootPay);
                        }
                    }
                }
            });
            return aPay;
        },
        _getOverheadPayable: function () {
            let aTables = ["tblOverheadPayable3A"];
            let aPay = [];
            aTables.forEach((sTable) => {
                let oTable = this.getView().byId(sTable);
                let aItems = oTable.getItems ? oTable.getItems() : oTable.getRows()
                if (aItems.length > 0) {

                    let aColumns = oTable.getColumns();
                    let oColPay = this._getHeader(aColumns);
                    if (Object.keys(oColPay).length > 0) {
                        let bAllEmpty = Object.keys(oColPay).find((sKey) => {
                            return oColPay[sKey] !== "" ? true : false;
                        });
                        if (bAllEmpty) {
                            aPay.push(oColPay);
                        }
                    }




                    aItems.forEach((oItem) => {
                        let oPay = {};
                        oItem.getCells().forEach((oCell, index) => {
                            if (oCell.getMetadata()._sClassName === "sap.m.HBox") {
                                oCell = oCell.getItems()[0];
                            }
                            oPay["FIELD" + (index + 1)] = oCell.getText ? oCell.getText() : oCell.getHtmlText ? oCell.getHtmlText() : "";
                        });
                        if (Object.keys(oPay).length > 0) {
                            let bAllEmpty = Object.keys(oPay).find((sKey) => {
                                return oPay[sKey] !== "" ? true : false;
                            });
                            if (bAllEmpty) {
                                aPay.push(oPay);
                            }
                        }
                    });

                    let oFootPay = this._getFooter(aColumns);

                    if (Object.keys(oFootPay).length > 0) {
                        let bAllEmpty = Object.keys(oFootPay).find((sKey) => {
                            return oFootPay[sKey] !== "" ? true : false;
                        });
                        if (bAllEmpty) {
                            aPay.push(oFootPay);
                        }
                    }
                }
            });
            return aPay;
        },
        _getDivPayable: function () {
            let aTables = ["tblDividendPayable3B"];
            let aPay = [];
            aTables.forEach((sTable) => {
                let oTable = this.getView().byId(sTable);
                let aItems = oTable.getItems ? oTable.getItems() : oTable.getRows()
                if (aItems.length > 0) {

                    let aColumns = oTable.getColumns();
                    let oColPay = this._getHeader(aColumns);
                    if (Object.keys(oColPay).length > 0) {
                        let bAllEmpty = Object.keys(oColPay).find((sKey) => {
                            return oColPay[sKey] !== "" ? true : false;
                        });
                        if (bAllEmpty) {
                            aPay.push(oColPay);
                        }
                    }




                    aItems.forEach((oItem) => {
                        let oPay = {};
                        oItem.getCells().forEach((oCell, index) => {
                            if (oCell.getMetadata()._sClassName === "sap.m.HBox") {
                                oCell = oCell.getItems()[0];
                            }
                            oPay["FIELD" + (index + 1)] = oCell.getText ? oCell.getText() : oCell.getHtmlText ? oCell.getHtmlText() : "";
                        });
                        if (Object.keys(oPay).length > 0) {
                            let bAllEmpty = Object.keys(oPay).find((sKey) => {
                                return oPay[sKey] !== "" ? true : false;
                            });
                            if (bAllEmpty) {
                                aPay.push(oPay);
                            }
                        }
                    });

                    let oFootPay = this._getFooter(aColumns);

                    if (Object.keys(oFootPay).length > 0) {
                        let bAllEmpty = Object.keys(oFootPay).find((sKey) => {
                            return oFootPay[sKey] !== "" ? true : false;
                        });
                        if (bAllEmpty) {
                            aPay.push(oFootPay);
                        }
                    }
                }
            });
            return aPay;
        },
        getout_rweSet: function () {
            let aTables = ["RWEShareholderLoanTable"];
            let aPay = [];
            aTables.forEach((sTable) => {
                let oTable = this.getView().byId(sTable);
                let aItems = oTable.getItems ? oTable.getItems() : oTable.getRows()
                if (aItems.length > 0) {

                    let aColumns = oTable.getColumns();
                    let oColPay = this._getHeader(aColumns);
                    if (Object.keys(oColPay).length > 0) {
                        let bAllEmpty = Object.keys(oColPay).find((sKey) => {
                            return oColPay[sKey] !== "" ? true : false;
                        });
                        if (bAllEmpty) {
                            aPay.push(oColPay);
                        }
                    }




                    aItems.forEach((oItem) => {
                        let oPay = {};
                        oItem.getCells().forEach((oCell, index) => {
                            if (oCell.getMetadata()._sClassName === "sap.m.HBox") {
                                oCell = oCell.getItems()[0];
                            }
                            oPay["FIELD" + (index + 1)] = oCell.getText ? oCell.getText() : oCell.getHtmlText ? oCell.getHtmlText() : "";
                        });
                        if (Object.keys(oPay).length > 0) {
                            let bAllEmpty = Object.keys(oPay).find((sKey) => {
                                return oPay[sKey] !== "" ? true : false;
                            });
                            if (bAllEmpty) {
                                aPay.push(oPay);
                            }
                        }
                    });

                    let oFootPay = this._getFooter(aColumns);

                    if (Object.keys(oFootPay).length > 0) {
                        let bAllEmpty = Object.keys(oFootPay).find((sKey) => {
                            return oFootPay[sKey] !== "" ? true : false;
                        });
                        if (bAllEmpty) {
                            aPay.push(oFootPay);
                        }
                    }
                }
            });
            return aPay;
        },
        getout_molSet: function () {
            let aTables = ["MOLShareholderLoanTable"];
            let aPay = [];
            aTables.forEach((sTable) => {
                let oTable = this.getView().byId(sTable);
                let aItems = oTable.getItems ? oTable.getItems() : oTable.getRows()
                if (aItems.length > 0) {

                    let aColumns = oTable.getColumns();
                    let oColPay = this._getHeader(aColumns);
                    if (Object.keys(oColPay).length > 0) {
                        let bAllEmpty = Object.keys(oColPay).find((sKey) => {
                            return oColPay[sKey] !== "" ? true : false;
                        });
                        if (bAllEmpty) {
                            aPay.push(oColPay);
                        }
                    }




                    aItems.forEach((oItem) => {
                        let oPay = {};
                        oItem.getCells().forEach((oCell, index) => {
                            if (oCell.getMetadata()._sClassName === "sap.m.HBox") {
                                oCell = oCell.getItems()[0];
                            }
                            oPay["FIELD" + (index + 1)] = oCell.getText ? oCell.getText() : oCell.getHtmlText ? oCell.getHtmlText() : "";
                        });
                        if (Object.keys(oPay).length > 0) {
                            let bAllEmpty = Object.keys(oPay).find((sKey) => {
                                return oPay[sKey] !== "" ? true : false;
                            });
                            if (bAllEmpty) {
                                aPay.push(oPay);
                            }
                        }
                    });

                    let oFootPay = this._getFooter(aColumns);

                    if (Object.keys(oFootPay).length > 0) {
                        let bAllEmpty = Object.keys(oFootPay).find((sKey) => {
                            return oFootPay[sKey] !== "" ? true : false;
                        });
                        if (bAllEmpty) {
                            aPay.push(oFootPay);
                        }
                    }
                }
            });
            return aPay;
        },
        getout_omvSet: function () {
            let aTables = ["OMVShareholderLoanTable"];
            let aPay = [];
            aTables.forEach((sTable) => {
                let oTable = this.getView().byId(sTable);
                let aItems = oTable.getItems ? oTable.getItems() : oTable.getRows()
                if (aItems.length > 0) {

                    let aColumns = oTable.getColumns();
                    let oColPay = this._getHeader(aColumns);
                    if (Object.keys(oColPay).length > 0) {
                        let bAllEmpty = Object.keys(oColPay).find((sKey) => {
                            return oColPay[sKey] !== "" ? true : false;
                        });
                        if (bAllEmpty) {
                            aPay.push(oColPay);
                        }
                    }




                    aItems.forEach((oItem) => {
                        let oPay = {};
                        oItem.getCells().forEach((oCell, index) => {
                            if (oCell.getMetadata()._sClassName === "sap.m.HBox") {
                                oCell = oCell.getItems()[0];
                            }
                            oPay["FIELD" + (index + 1)] = oCell.getText ? oCell.getText() : oCell.getHtmlText ? oCell.getHtmlText() : "";
                        });
                        if (Object.keys(oPay).length > 0) {
                            let bAllEmpty = Object.keys(oPay).find((sKey) => {
                                return oPay[sKey] !== "" ? true : false;
                            });
                            if (bAllEmpty) {
                                aPay.push(oPay);
                            }
                        }
                    });

                    let oFootPay = this._getFooter(aColumns);

                    if (Object.keys(oFootPay).length > 0) {
                        let bAllEmpty = Object.keys(oFootPay).find((sKey) => {
                            return oFootPay[sKey] !== "" ? true : false;
                        });
                        if (bAllEmpty) {
                            aPay.push(oFootPay);
                        }
                    }
                }
            });
            return aPay;
        },
        getout_danaSet: function () {
            let aTables = ["DGasShareholderLoanTable"];
            let aPay = [];
            aTables.forEach((sTable) => {
                let oTable = this.getView().byId(sTable);
                let aItems = oTable.getItems ? oTable.getItems() : oTable.getRows()
                if (aItems.length > 0) {

                    let aColumns = oTable.getColumns();
                    let oColPay = this._getHeader(aColumns);
                    if (Object.keys(oColPay).length > 0) {
                        let bAllEmpty = Object.keys(oColPay).find((sKey) => {
                            return oColPay[sKey] !== "" ? true : false;
                        });
                        if (bAllEmpty) {
                            aPay.push(oColPay);
                        }
                    }




                    aItems.forEach((oItem) => {
                        let oPay = {};
                        oItem.getCells().forEach((oCell, index) => {
                            if (oCell.getMetadata()._sClassName === "sap.m.HBox") {
                                oCell = oCell.getItems()[0];
                            }
                            oPay["FIELD" + (index + 1)] = oCell.getText ? oCell.getText() : oCell.getHtmlText ? oCell.getHtmlText() : "";
                        });
                        if (Object.keys(oPay).length > 0) {
                            let bAllEmpty = Object.keys(oPay).find((sKey) => {
                                return oPay[sKey] !== "" ? true : false;
                            });
                            if (bAllEmpty) {
                                aPay.push(oPay);
                            }
                        }
                    });

                    let oFootPay = this._getFooter(aColumns);

                    if (Object.keys(oFootPay).length > 0) {
                        let bAllEmpty = Object.keys(oFootPay).find((sKey) => {
                            return oFootPay[sKey] !== "" ? true : false;
                        });
                        if (bAllEmpty) {
                            aPay.push(oFootPay);
                        }
                    }
                }
            });
            return aPay;
        },
        getout_crescentSet: function () {
            let aTables = ["CRSTShareholderLoanTable"];
            let aPay = [];
            aTables.forEach((sTable) => {
                let oTable = this.getView().byId(sTable);
                let aItems = oTable.getItems ? oTable.getItems() : oTable.getRows()
                if (aItems.length > 0) {

                    let aColumns = oTable.getColumns();
                    let oColPay = this._getHeader(aColumns);
                    if (Object.keys(oColPay).length > 0) {
                        let bAllEmpty = Object.keys(oColPay).find((sKey) => {
                            return oColPay[sKey] !== "" ? true : false;
                        });
                        if (bAllEmpty) {
                            aPay.push(oColPay);
                        }
                    }




                    aItems.forEach((oItem) => {
                        let oPay = {};
                        oItem.getCells().forEach((oCell, index) => {
                            if (oCell.getMetadata()._sClassName === "sap.m.HBox") {
                                oCell = oCell.getItems()[0];
                            }
                            oPay["FIELD" + (index + 1)] = oCell.getText ? oCell.getText() : oCell.getHtmlText ? oCell.getHtmlText() : "";
                        });
                        if (Object.keys(oPay).length > 0) {
                            let bAllEmpty = Object.keys(oPay).find((sKey) => {
                                return oPay[sKey] !== "" ? true : false;
                            });
                            if (bAllEmpty) {
                                aPay.push(oPay);
                            }
                        }
                    });

                    let oFootPay = this._getFooter(aColumns);

                    if (Object.keys(oFootPay).length > 0) {
                        let bAllEmpty = Object.keys(oFootPay).find((sKey) => {
                            return oFootPay[sKey] !== "" ? true : false;
                        });
                        if (bAllEmpty) {
                            aPay.push(oFootPay);
                        }
                    }
                }
            });
            return aPay;
        },
        getsch_shareSet: function () {
            let aTables = ["ShareholderLoanDueTable"];
            let aPay = [];
            aTables.forEach((sTable) => {
                let oTable = this.getView().byId(sTable);
                let aItems = oTable.getItems ? oTable.getItems() : oTable.getRows()
                if (aItems.length > 0) {

                    let aColumns = oTable.getColumns();
                    let oColPay = this._getHeader(aColumns);
                    if (Object.keys(oColPay).length > 0) {
                        let bAllEmpty = Object.keys(oColPay).find((sKey) => {
                            return oColPay[sKey] !== "" ? true : false;
                        });
                        if (bAllEmpty) {
                            aPay.push(oColPay);
                        }
                    }




                    aItems.forEach((oItem) => {
                        let oPay = {};
                        oItem.getCells().forEach((oCell, index) => {
                            if (oCell.getMetadata()._sClassName === "sap.m.HBox") {
                                oCell = oCell.getItems()[0];
                            }
                            oPay["FIELD" + (index + 1)] = oCell.getText ? oCell.getText() : oCell.getHtmlText ? oCell.getHtmlText() : "";
                        });
                        if (Object.keys(oPay).length > 0) {
                            let bAllEmpty = Object.keys(oPay).find((sKey) => {
                                return oPay[sKey] !== "" ? true : false;
                            });
                            if (bAllEmpty) {
                                aPay.push(oPay);
                            }
                        }
                    });

                    let oFootPay = this._getFooter(aColumns);

                    if (Object.keys(oFootPay).length > 0) {
                        let bAllEmpty = Object.keys(oFootPay).find((sKey) => {
                            return oFootPay[sKey] !== "" ? true : false;
                        });
                        if (bAllEmpty) {
                            aPay.push(oFootPay);
                        }
                    }
                }
            });
            return aPay;
        },
        formatTotal: function () {
            // Get the model and data
            var oModel = this.getView().getModel("data");
            var aData = oModel.getProperty("/RWEShareholderLoanSet");

            // Calculate the totals
            var totalAntecedentLoan = 0;
            var totalM16may = 0;
            var totalY2010 = 0;
            var totalY2011 = 0;
            var totalY2012 = 0;
            var totalY2013 = 0;
            var totalY2014 = 0;
            var totalY2015 = 0;
            var totalY2016 = 0;
            var totalY2017 = 0;

            aData.forEach(function (item) {
                totalAntecedentLoan += parseFloat(item.AntecedentLoan) || 0;
                totalM16may += parseFloat(item.M16may) || 0;
                totalY2010 += parseFloat(item.Y2010) || 0;
                totalY2011 += parseFloat(item.Y2011) || 0;
                totalY2012 += parseFloat(item.Y2012) || 0;
                totalY2013 += parseFloat(item.Y2013) || 0;
                totalY2014 += parseFloat(item.Y2014) || 0;
                totalY2015 += parseFloat(item.Y2015) || 0;
                totalY2016 += parseFloat(item.Y2016) || 0;
                totalY2017 += parseFloat(item.Y2017) || 0;
            });

            // Return the total values
            return {
                AntecedentLoan: totalAntecedentLoan,
                M16may: totalM16may,
                Y2010: totalY2010,
                Y2011: totalY2011,
                Y2012: totalY2012,
                Y2013: totalY2013,
                Y2014: totalY2014,
                Y2015: totalY2015,
                Y2016: totalY2016,
                Y2017: totalY2017,
            };
        }
    });
});