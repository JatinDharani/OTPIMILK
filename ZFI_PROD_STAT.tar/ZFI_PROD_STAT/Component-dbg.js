sap.ui.define(["sap/ui/core/UIComponent","sap/ui/Device","com/ui/crescent/zuiproductionstatement/model/models"],function(e,t,i){"use strict";return e.extend("com.ui.crescent.zuiproductionstatement.Component",{metadata:{manifest:"json"},init:function(){e.prototype.init.apply(this,arguments);this.getRouter().initialize();this.setModel(i.createDeviceModel(),"device")}})});




