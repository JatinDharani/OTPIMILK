sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageBox",
    "sap/m/MessageToast",
    "sap/ui/core/routing/History",
    "com/ui/crescent/zsalesgasdpr/model/oDataHelper",
    "com/ui/crescent/zsalesgasdpr/model/formatter",
    "sap/ui/model/json/JSONModel"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, MessageBox, MessageToast, History, oDataHelper, formatter,JSONModel) {
        "use strict";

        return Controller.extend("com.ui.crescent.zsalesgasdpr.controller.Nomination", {
            formatter: formatter,
            onInit: function () {
                let oMinDate = {
                    date:new Date("2024","00","01")
                }
                
                this.getView().setModel(new JSONModel(oMinDate), "dateValidator");


            },
            onDateChange:function(oEvent){
                var oDatePicker = oEvent.getSource();
                var oSelectedDate = oDatePicker.getDateValue();
                var oMinDate = new Date(2024, 0, 1); // January 1, 2023
                
                if (oSelectedDate < oMinDate) {
                    sap.m.MessageToast.show("Selected date is before the minimum allowed date.");
                    oDatePicker.setDateValue(oMinDate); // Reset to minimum date
                }
            },
            onBack: function () {
                this.getOwnerComponent().getRouter().navTo("Routeapp");

            },

            onSubmitNomDetails: async function (oEvent) {
                var oNomination = {};
                var nomModel = this.getView().getModel('nomModel');
                var oDataValues = this.getView().getModel('oNomModel').getData();
                oNomination.Vbeln = oDataValues.Vbeln;
                oNomination.Tplnr = oDataValues.Tplnr;
                oNomination.Zdate = oDataValues.Zdate;
                oNomination.Pstation1 = oDataValues.Pstation1;
                oNomination.Pstation2 = oDataValues.Pstation2;
                oNomination.Pstation3 = oDataValues.Pstation3;
                oNomination.Pstation4 = oDataValues.Pstation4;

                //if (this.checkNominationDataMandatoryField(oNomination.Pstation1, oNomination.Pstation2, oNomination.Pstation3, oNomination.Pstation4)) {

                 
                oNomination.Propernom = (this.getView().byId("nomPN").getValue() == '') ? "0" : this.getView().byId("nomPN").getValue().toString();;
                oNomination.Correctednom = (this.getView().byId("nomCN").getValue() == '') ? "0" : this.getView().byId("nomCN").getValue().toString();
                oNomination.Sellshort = oDataValues.Sellshort;
                oNomination.Quntmaint = oDataValues.Quntmaint;
                oNomination.Qunatfm = oDataValues.Qunatfm;
                oNomination.Qunstoffspec = oDataValues.Qunstoffspec;
                oNomination.ShortFall = oDataValues.ShortFall;
                oNomination.Ztims = oDataValues.Ztims;
                oNomination.Todate = oDataValues.Todate;
                oNomination.Totime = oDataValues.Totime;
                oNomination.PropernomFlag = oDataValues.PropernomFlag;
                oNomination.EditFlag = oDataValues.EditFlag;

                var sPath = nomModel.createKey("/NominationSet", { "Vbeln": oDataValues.Vbeln, "Zdate": oDataValues.Zdate });
                //var sPath = "/NominationSet";
                var that = this;
                oDataHelper.updateOData(nomModel, sPath, oNomination)
                    .then(function (data) {
                        that.onSuccessNomUpdate(data.Vbeln, data.Zdate)
                    })
                    .catch(function (oError) {
                        MessageBox.error("Error during update, please try again")
                    });
                //}
            },

            checkNominationDataMandatoryField(Pstation1, Pstation2, Pstation3, Pstation4) {
                if (Pstation1 == "0") {
                    this.byId("pStation1").setValueState(sap.ui.core.ValueState.Error);
                    this.byId("pStation1").setValueStateText("Mandatory Field");
                    this.getView().byId("nomSubDetails").setEnabled(false);
                    return false;
                }else {
                    this.byId("pStation1").setValueState(sap.ui.core.ValueState.None);
                    this.byId("pStation1").setValueStateText("Mandatory Field");
                    this.getView().byId("nomSubDetails").setEnabled(true);
                }
                if (Pstation2 == "0") {
                    this.byId("pStation2").setValueState(sap.ui.core.ValueState.Error);
                    this.byId("pStation2").setValueStateText("Mandatory Field");
                    this.getView().byId("nomSubDetails").setEnabled(false);
                    return false;
                }else {
                    this.byId("pStation2").setValueState(sap.ui.core.ValueState.None);
                    this.byId("pStation2").setValueStateText("Mandatory Field");
                    this.getView().byId("nomSubDetails").setEnabled(true);
                }
                if (Pstation3 == "0") {
                    this.byId("pStation3").setValueState(sap.ui.core.ValueState.Error);
                    this.byId("pStation3").setValueStateText("Mandatory Field");
                    this.getView().byId("nomSubDetails").setEnabled(false);
                    return false;

                }else {
                    this.byId("pStation3").setValueState(sap.ui.core.ValueState.None);
                    this.byId("pStation3").setValueStateText("Mandatory Field");
                    this.getView().byId("nomSubDetails").setEnabled(true);
                }
                if (Pstation4 == "0") {
                    this.byId("pStation4").setValueState(sap.ui.core.ValueState.Error);
                    this.byId("pStation4").setValueStateText("Mandatory Field");
                    this.getView().byId("nomSubDetails").setEnabled(false);
                    return false;

                }else {
                    this.byId("pStation4").setValueState(sap.ui.core.ValueState.None);
                    this.byId("pStation4").setValueStateText("Mandatory Field");
                    this.getView().byId("nomSubDetails").setEnabled(true);
                    
                }
                return true;
            },

            onSuccessNomUpdate: function (Vbeln, Zdate) {

                jQuery.sap.delayedCall(1000, this, this.showSuccessToast, [Vbeln]);
                this.onBack();

            },

            showSuccessToast: function (Vbeln) {
                MessageToast.show("Contract :" + Vbeln + " successfully updated");
            },


            onPstationLiveChange: function (oEvent) {
                var oNomination = {};
                var newValue = oEvent.getParameter('newValue');
                var inputId = oEvent.getParameter('id');
                var regex = /^[0-9]+$/;
                var oDataValues = this.getView().getModel('oNomModel').getData();
                oNomination.Pstation1 = oDataValues.Pstation1;
                oNomination.Pstation2 = oDataValues.Pstation2;
                oNomination.Pstation3 = oDataValues.Pstation3;
                oNomination.Pstation4 = oDataValues.Pstation4;
                // if (this.checkNominationDataMandatoryField(oNomination.Pstation1, oNomination.Pstation2, oNomination.Pstation3, oNomination.Pstation5)) {



                if (!newValue.match(regex)) {
                    this.byId(inputId).setValueState(sap.ui.core.ValueState.Error);
                    this.byId(inputId).setValueStateText("Only numbers allowed ");
                    this.getView().byId("nomSubDetails").setEnabled(false);
                    this.getView().byId(inputId).setValue('');
                } else {
                    this.byId(inputId).setValueState(sap.ui.core.ValueState.None);
                    this.getView().byId("nomSubDetails").setEnabled(true)
                }

                var oDataValues = this.getView().getModel('oNomModel').getData();
                if (oDataValues.PropernomFlag == 'X') {
                    oDataValues.Propernom = parseInt(oDataValues.Pstation1) + parseInt(oDataValues.Pstation2) + parseInt(oDataValues.Pstation3) + parseInt(oDataValues.Pstation4);
                    if (oDataValues.Propernom <= oDataValues.Dcq ) {
                        this.getView().byId("nomPN").setValue(oDataValues.Propernom);
                    }else {
                        this.getView().byId("nomSubDetails").setEnabled(false);
                        var msgError = this.getView().getModel("i18n").getResourceBundle().getText("DcqError");
                        msgError = msgError.replace("{dcq}", oDataValues.Dcq);
                        msgError = msgError.replace(".000", "");
                        msgError = msgError.replace("{uom}", oDataValues.DcqUom);
                        MessageBox.error(msgError);
                    }
                    
                } else {
                    oDataValues.Correctednom = parseInt(oDataValues.Pstation1) + parseInt(oDataValues.Pstation2) + parseInt(oDataValues.Pstation3) + parseInt(oDataValues.Pstation4);
                    if (oDataValues.Correctednom > oDataValues.Propernom) {
                        this.getView().byId("nomSubDetails").setEnabled(false);
                        MessageBox.error(this.getView().getModel("i18n").getResourceBundle().getText("IncorrectCorrectNom"));
                        oDataValues.Correctednom = "";

                    } else {
                        this.getView().byId("nomCN").setValue(oDataValues.Correctednom);
                        this.getView().byId("nomCN").setValueState(sap.ui.core.ValueState.None);
                        this.byId(inputId).setValueStateText("");
                        this.getView().byId("nomSubDetails").setEnabled(true);
                    }
                }
                // }
            }
                
            


        })
    });
