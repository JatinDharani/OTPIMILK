sap.ui.define([],function(){"use strict";return{addValues:function(n,e,t,r){return parseInt(n)+parseInt(e)+parseInt(t)+parseInt(r)}}});
//# sourceMappingURL=formatter.js.map