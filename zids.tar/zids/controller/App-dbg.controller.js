sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/model/Filter",
  "sap/ui/model/json/JSONModel",
  "sap/m/MessageBox",
  "sap/m/PDFViewer",
  "sap/m/BusyDialog",
  "sap/ui/core/util/File",
  "sap/ui/core/format/DateFormat"
],
  /**
   * @param {typeof sap.ui.core.mvc.Controller} Controller
   */
  function (Controller, Filter, JSONModel, MessageBox, PDFViewer, BusyDialog,File,DateFormat) {
    "use strict";
    var inbox = '',
    prodNet = '',
    DPRDate = '';
    return Controller.extend("com.ui.crescent.zdailyprodop.controller.App", {
      onInit: function () {
        let oProdModel, oView;
        const oData = {
          header: {
            GenFlag: false,
            ReviseFlag: false,
            EditFlag: false,
            SaveFlag: false, 
            CommentFlag: false
          },
          status: []
        }

        let oMinDate = {
          date:new Date("2024","00","01")
      }
      
      this.getView().setModel(new JSONModel(oMinDate), "dateValidator");

        // Navigation from My Inbox - Open task and preset the Values 
        if (window.location.href.split("?").length > 2){
          if ( window.location.href.split("?")[2].split("&")[0].split("=")[0]  == 'DPRDate' ){
            this.prodNet = window.location.href.split("?")[2].split("&")[1].split("=")[1];
            this.DPRDate = window.location.href.split("?")[2].split("&")[0].split("=")[1];
          } else { //If not from the direct launchpad
            this.prodNet = window.location.href.split("?")[2].split("&")[0].split("=")[1];
            this.DPRDate = window.location.href.split("?")[2].split("&")[1].split("=")[1];
          }

          
          this.byId("DPRDate").setValue(this.DPRDate); 
          this.byId("ProdNet").setValue(this.prodNet);
          this.inbox = 'X';
        }


        var operationsModel = this.getOwnerComponent().getModel("operations");
        this.getView().setModel(operationsModel, "operations");

        oProdModel = new JSONModel(oData);
        oView = this.getView();
        oView.setModel(oProdModel, "oProdModel");
        this.onProdNetInit()
      },

      onProdNetInit(){
        if (this.inbox == 'X'){
          this.byId("ProdNet").setValue(this.prodNet);
          this.byId("DPRDate").setValue(this.DPRDate);
          this.inbox = ''; // this the last method to be called
          
        }else{
          this.byId("ProdNet").setValue("ISP");
          var dateObj = new Date((new Date).setDate((new Date).getDate() - 1));
          this.getView().byId("DPRDate").setDateValue(dateObj);
        }
       
      },

      onAfterRendering: function(){
        if (this.inbox == 'X'){
          this.getData();
          // this.inbox = '';
        }
        
      },

      getData: async function () {
        try {
          let oModel, oView, sMonYear;
          oView = this.getView();
          oModel = oView.getModel();
          
          //Get the ProdNet Value
          const sProdNet = oView?.byId("ProdNet")?.getSelectedKey()    //oView?.byId("ProdNet")?.getValue();

          if(!sProdNet){
            MessageBox.error("Please select the valid Network")
            return
          }

          var oBusyDialog = new BusyDialog();
          oBusyDialog.open();
          
          //Get DPRDate
          const sDPRDate = this.resolveTimeDifference(oView?.byId("DPRDate")?.getDateValue());

          //const sDPRDate = this.getView().getModel("operations").getData().operationsData.date;

          if (sProdNet && sDPRDate) {
            const aFilters = [
              new Filter({
                path: "ProdNet",
                operator: "EQ",
                value1: sProdNet
              }),
              new Filter({
                path: "ExeDate",
                operator: "EQ",
                value1: sDPRDate
              })
            ];

            const aStatusFilters = [
              new Filter({
                path: "prod_net",
                operator: "EQ",
                value1: sProdNet
              }),
              new Filter({
                path: "exe_date",
                operator: "EQ",
                value1: sDPRDate
              })
            ];


            const aOverallStatusFilters = [
              new Filter({
                path: "ProdNet",
                operator: "EQ",
                value1: sProdNet
              }),
              new Filter({
                path: "ExeDate",
                operator: "EQ",
                value1: sDPRDate
              }),
              new Filter({
                path: "Prtype",
                operator: "EQ",
                value1: '1'
              })
            ];

            let oOverallStatus = [{
              ProdNet : "",
              ExeDate : "",
              Prstatus : "",
              PrstatusText : "",
              ToDate : "",
              ToTime : "",
              FromTime : ""
            }];
              

            //Fetch the Production Model
            let oProdModel = oView.getModel("oProdModel");
            //Fetch the header data
            const oProdData = await this.getProductionData(oModel, aFilters);
            if (oProdData && oProdData?.results[0]) {
              // Set the visible row count of "Well Information" table as per the table row. 
              var wellInTableCount = oProdData?.results[0].NVHeadWelIn.results.length; 
              this.getView().byId("prodTable").setVisibleRowCount(wellInTableCount);
              // Reverse the sign 
              oProdData.results[0].NVHeadLab.GasHc = this.reverseStringNeg(oProdData?.results[0].NVHeadLab.GasHc);
              oProdData.results[0].NVHeadLab.GasGhv = this.reverseStringNeg(oProdData?.results[0].NVHeadLab.GasGhv);
              oProdData.results[0].NVHeadLab.GasH2o = this.reverseStringNeg(oProdData?.results[0].NVHeadLab.GasH2o);
              oProdData.results[0].NVHeadLab.NglRvp = this.reverseStringNeg(oProdData?.results[0].NVHeadLab.NglRvp);
              oProdData.results[0].NVHeadLab.LpgSG = this.reverseStringNeg(oProdData?.results[0].NVHeadLab.LpgSG);
              oProdData.results[0].NVHeadLab.NglSg = this.reverseStringNeg(oProdData?.results[0].NVHeadLab.NglSg);
              oProdData.results.forEach(function(oItem){
                if(oItem.NVHeadProc && oItem.NVHeadProc.results){
                oItem.NVHeadProc.results.forEach(function(oNVHead){
                  if(oNVHead.MeterDesc === "Sales Gas Production"){
                    oNVHead.MeterDesc = "Gas Production";
                  }
                });
              }
              
              });
              oProdModel.setProperty("/header", oProdData?.results[0]);
            }

            //Fetch the Status Data
            const oStatusData = await this.getStatusData(oModel, aStatusFilters);
            if (oStatusData?.results && Array.isArray(oStatusData?.results)) {
              oProdModel.setProperty("/status", oStatusData?.results);
            }

            //Fetch the Overall Status 
            let  oOverallStatusData = await this.getOverallStatusData(oModel,sProdNet, sDPRDate );
            if (oOverallStatusData !== undefined) {
             
              var dateFormat = DateFormat.getDateTimeInstance({pattern : "dd.MM.yyyy" });
              oOverallStatusData.ToDate = new Date(sDPRDate.setDate(sDPRDate.getDate() + 1));
              oOverallStatusData.ToTime = "6:00:00";
              oOverallStatusData.FromTime = "6:00:00";
              oProdModel.setProperty("/overAllStatus", oOverallStatusData);
            }else{
              oOverallStatus[0].ExeDate = new Date(sDPRDate.setDate(sDPRDate.getDate()));
              oOverallStatus[0].ToDate = new Date(sDPRDate.setDate(sDPRDate.getDate() + 1));
              oOverallStatus[0].ToTime = "6:00:00";
              oOverallStatus[0].FromTime = "6:00:00";
              oProdModel.setProperty("/overAllStatus", oOverallStatus[0]);
            }


            oBusyDialog.close();

          } else {
            oBusyDialog.close();
            MessageBox.error("Enter the Mandatory Fields.", {
              title: "Error",
              onClose: function () {
              }
            });
          }


        }
        catch (e) {
          oBusyDialog.close();
          console.log(e);
          var oMessage= JSON.parse(e.responseText).error.message.value;
          MessageBox.error(oMessage, {
            title: "Error",
            onClose: function () {
            }
          });
        }
      },

      reverseStringNeg(string){
        let StringRev = "";
        let StringOut = "";
        let inputString = string.trim();
        if (inputString == ""){
          StringOut = inputString;
        }else{
          if (inputString[inputString.length - 1] == '-'){
            for (var i=0; i<inputString.length - 1; i++){
              StringRev = StringRev + inputString[i];
            }
            StringOut = "-" + StringRev;
          }else{
            StringOut = inputString;
          }
         return StringOut;
        }
       
    },

      getProductionData: function (oModel, aFilters) {
        return new Promise((resolve, reject) => {
          const sPath = `/HeadNetSet`;
          // Perform Read operation and pass billingdoc as parameter to URL
          oModel.read(sPath,
            {
              urlParameters: {
                "$expand": "NVHeadOpr,NVHeadPlnt,NVHeadProc,NVHeadSep,NVHeadExppr,NVHeadTurb,NVHeadWel,NVHeadDyHigh,NVHeadLab,NVHeadLoad,NVHeadPipe,NVHeadRemrk,NVHeadWelIn,NVHeadNotes"
              },
              filters: aFilters,
              success: function (oData, oResponse) {
                resolve(oData);
              },
              error: function (oError) {
                 reject(oError);
              }
            });
        })
      },

      getStatusData: function (oModel, aFilters) {
        return new Promise((resolve, reject) => {
          const sPath = `/ZI_UHAM_DPR_STATUS`;
          // Perform Read operation and pass billingdoc as parameter to URL
          oModel.read(sPath,
            {
              filters: aFilters,
              success: function (oData, oResponse) {
                resolve(oData);
              },
              error: function (oError) {
                 reject(oError);
              }
            });
        })
      },


      getOverallStatusData: function (oModel, sProdNet, sDate) {
        return new Promise((resolve, reject) => {
          var sPath = oModel.createKey("/OverallStatusSet", { "ProdNet": sProdNet, "ExeDate": sDate, "Prtype" : '1' });
          // Perform Read operation and pass billingdoc as parameter to URL
          oModel.read(sPath,
            {
              success: function (oData, oResponse) {
                resolve(oData);
              },
              error: function (oError,oData) {
                var oMessage= JSON.parse(oError.responseText).error.message.value;
                if ( oMessage == 'No Data Found.' ) {
                  resolve(oData);
                } else {
                   reject(oError);
                }
                
              }
            });
        })
      },

      /**
       * Returns the response of post oData call
       * @param {object} oModel  OData Model
       * @param {object} oProdData  OData 
       * @param {string} sId Table ID
       * @returns {object}  oData response
       */
      postData: async function (oModel, oProdData, sPath,oBusyDialog) {
        const sToken = oModel.getSecurityToken();
        this.oBusyDialog = oBusyDialog;
        var that = this; 
        const oHeaders = {
          "x-csrf-token": sToken
        };
        return new Promise((resolve, reject) => {
          // Perform Read operation and pass billingdoc as parameter to URL
          oModel.create(sPath, oProdData,
            {
              headers: oHeaders,
              success: function (oData, oResponse) {
                resolve(oData);
              },
              error: function (oError) {
                // reject(oError);
                that.oBusyDialog.close();
                  var sDetails = JSON.parse(oError.responseText).error.message.value;
                  sap.m.MessageBox.error(sDetails,  {
                    title: "Error",                                      
                    initialFocus: null                                   
                  });
                 
               
               
              }
            });
        })
      },

      /**
        * action triggered on Generate action
        * @param {object} oEvent sap.ui.base.Event
        */
      onGenerate: async function (oEvent) {
        try {
          var oBusyDialog = new BusyDialog();
          oBusyDialog.open();
          let oModel, oView, sMonYear, oProdModel;
          oView = this.getView();
          // get the Model reference
          oModel = oView.getModel();
          oProdModel = oView.getModel("oProdModel");

          //Get the ProdNet Value
          const sProdNet = oView?.byId("ProdNet")?.getValue();

          //Get DPRDate
          const sDPRDate = oView.byId("DPRDate")?.getDateValue();

          if (sProdNet && sDPRDate) {

            const oData =
            {
              "d": {
                "ProdNet": sProdNet,
                "ExeDate": sDPRDate

              }
            }
            const data = await this.postData(oModel, oData, `/DprWFGenerateSet`,oBusyDialog);
            if (data) {
              if (data?.MsgType === 'S') {
                oProdModel.setProperty("/header/GenFlag",false);
                oBusyDialog.close();
                MessageBox.success(data?.Message, {
                  title: "Success",
                  onClose: function () {
                    this.getData();
                  }.bind(this)
                });
              } else {
                oBusyDialog.close();
                MessageBox.error(data?.Message, {
                  title: "Error",
                  onClose: function () {
                  }
                });
              }
            }
            oBusyDialog.close();
          }
          else {
            oBusyDialog.close();
            MessageBox.error("Enter the Mandatory Fields.", {
              title: "Error",
              onClose: function () {
              }
            });
          }

        }
        catch (e) {
          oBusyDialog.close();
        }
      },

      /**
       * action triggered on print preview
       * @param {object} oEvent sap.ui.base.Event
       */
      onPrint: async function (oEvent) {
        try {
          var oResourceBundle = this.getView().getModel("i18n").getResourceBundle();
          var opdfViewer = new PDFViewer();
          this.getView().addDependent(opdfViewer);

          var oBusyDialog = new BusyDialog({
            title: 'Generating Form...'
          });
          oBusyDialog.open();
          let oModel, oView;
          oView = this.getView();
          // get the Model reference
          // oModel = oView.getModel();
          oModel = this.getView().getModel('dailyUhamDprOperations');
          //Get the ProdNet Value
          const sProdNet = oView?.byId("ProdNet")?.getValue();

          //Get DPRDate
          const sDPRDate = oView.byId("DPRDate")?.getDateValue();

          if (sProdNet && sDPRDate) {


            const oData =
            {
              "d": {
                "p_prodnet": sProdNet,
                "p_date": sDPRDate

              }
            }

            var sPath = oModel.createKey("/Print", { "p_prodnet": sProdNet, "p_date": sDPRDate }) + "/Set";

            //var vPDF = await this.postData(oModel, oData, sPath);
            var vPDF = await this.getPDFData(oModel, sPath);
            //if (vPDF?.FormData) {
            if (vPDF?.results[0]?.stream_data) {
              let base64EncodedPDF = vPDF?.results[0].stream_data;
              let decodedPdfContent = atob(base64EncodedPDF);
              let byteArray = new Uint8Array(decodedPdfContent.length);
              for (var i = 0; i < decodedPdfContent.length; i++) {
                byteArray[i] = decodedPdfContent.charCodeAt(i);
              }
              var blob = new Blob([byteArray.buffer], {
                type: 'application/pdf'
              });
              var pdfurl = URL.createObjectURL(blob);
              jQuery.sap.addUrlWhitelist("blob"); // register blob url as whitelist
              opdfViewer.setSource(pdfurl);
              opdfViewer.setVisible(true);
              opdfViewer.setTitle(oResourceBundle.getText("pdfTitle"));
              // Download the file with the following format .. DPR_dd-MMM-yyyy.pdf
              opdfViewer.downloadPDF = function(){
                var dprDate = DateFormat.getDateInstance({pattern: "dd-MMM-yyyy"}).format(sDPRDate);
                var fileName = 'DPR_'+dprDate;
                File.save(byteArray.buffer, fileName, "pdf", "application/pdf");
              };
              opdfViewer.open();
            }
            oBusyDialog.close();
          }
          else {
            oBusyDialog.close();
            MessageBox.error("Enter the Mandatory Fields.", {
              title: "Error",
              onClose: function () {
              }
            });
          }

        }
        catch (e) {
          oBusyDialog.close();
        }
      },

      /**
        * action triggered on Update action
        * @param {object} oEvent sap.ui.base.Event
        */
      onUpdate: async function (oEvent) {
        try {
          var oBusyDialog = new BusyDialog();
          oBusyDialog.open();
          let oModel, oView, sMonYear, oProdModel;
          oView = this.getView();
          // get the Model reference
          oModel = oView.getModel();
          oProdModel = oView.getModel("oProdModel");

          //Get the ProdNet Value
          const sProdNet = oView?.byId("ProdNet")?.getValue();

          //Get DPRDate
          const sDPRDate = oView.byId("DPRDate")?.getDateValue();

          if (sProdNet && sDPRDate) {

            const oHead = { ...oProdModel.getData().header };
            oHead.NVHeadExppr = {
              "ProdNet": oHead?.ProdNet,
              "ExeDate": oHead?.ExeDate,
              "Exced57": this.getExceedValue("exceededBarg"),
              "NotifiedHop": this.getExceedValue("buyerNotified"),
              "NomAdj": this.getExceedValue("nominationAdjusted"),
            }

            const oData = {
              d: oHead
            };

            const data = await this.postData(oModel, oData, `/HeadNetSet`,oBusyDialog);
            if (data) {
              if (data) {
                oBusyDialog.close();
                MessageBox.success("Updated Successfully", {
                  title: "Success",
                  onClose: function () {
                  }.bind(this)
                });
              } else {
                oBusyDialog.close();
                MessageBox.error("Error while Updating", {
                  title: "Error",
                  onClose: function () {
                  }
                });
              }
            }
            oBusyDialog.close();
          }
          else {
            oBusyDialog.close();
            MessageBox.error("Enter the Mandatory Fields.", {
              title: "Error",
              onClose: function () {
              }
            });
          }

        }
        catch (e) {
          oBusyDialog.close();
          MessageBox.error(e.message, {
            title: "Error",
            onClose: function () {
            }
          });
        }
      },

      getExceedValue: function (sId) {
        const sIndex = this.getView().byId(sId).getSelectedIndex();
        return sIndex === 0 ? 'Y' : 'N';
      },

      getPDFData: async function (oModel, sPath) {

        return new Promise((resolve, reject) => {
          // Perform Read operation and pass billingdoc as parameter to URL
          oModel.read(sPath,
            {
              success: function (oData, oResponse) {
                resolve(oData);
              },
              error: function (oError) {
                 // reject(oError);
                 var sDetails = JSON.parse(oError.responseText).error.message.value;
                 sap.m.MessageBox.error(sDetails);
              }
            });
        })
      },
      onHSELiveChange: function (oEvent) {

        var newValue = oEvent.getParameter('newValue');
        var inputId = oEvent.getParameter('id');
        var regex = /^[0-9]+$/;
        if (!newValue.match(regex)) {
          this.byId(inputId).setValueState(sap.ui.core.ValueState.Error);
          this.byId(inputId).setValueStateText("Only numbers allowed ");
          this.byId(inputId).setValue("");
        } else {
          this.byId(inputId).setValueState(sap.ui.core.ValueState.None);

        }
      },
      resolveTimeDifference: function (dateTime) {

        if (dateTime !== undefined && dateTime !== null && dateTime !== "") {
          var offSet = dateTime.getTimezoneOffset();
          var offSetVal = dateTime.getTimezoneOffset() / 60;
          var h = Math.floor(Math.abs(offSetVal));
          var m = Math.floor((Math.abs(offSetVal) * 60) % 60);
          dateTime = new Date(dateTime.setHours(h, m, 0, 0)); return dateTime;
        }

        return null;

      },

      /*
        * action triggered on Revise action
        * @param {object} oEvent sap.ui.base.Event
        */
      onRevise: async function (oEvent) {
        try {
          let oView = this.getView();
          var oBusyDialog = new BusyDialog();
          let oS1Date = oView.byId("DPRDate");
          var oFormat = DateFormat.getDateInstance({
            pattern: "dd.MM.YYYY"
        });
        let osDate = oFormat.format(oS1Date);
        let sMessage = "Do you want to revise the Operational DPR for "+osDate+"?";
          MessageBox.warning(sMessage, {
            actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
            emphasizedAction: MessageBox.Action.OK,
            onClose: async function (sAction) {
              oBusyDialog.open();
          let oModel, oView, sMonYear, oProdModel;
          oView = this.getView();
          // get the Model reference
          oModel = oView.getModel();
          oProdModel = oView.getModel("oProdModel");

          //Get the ProdNet Value
          const sProdNet = oView?.byId("ProdNet")?.getValue();

          //Get DPRDate
          const sDPRDate = oView.byId("DPRDate")?.getDateValue();

          if (sProdNet && sDPRDate) {

            const oData =
            {
              "d": {
                "ProdNet": sProdNet,
                "ExeDate": sDPRDate,
                "ReviseFlag" : true

              }
            }
            const data = await this.postData(oModel, oData, `/DprWFGenerateSet`,oBusyDialog);
            if (data) {
              if (data?.MsgType === 'S') {
                oProdModel.setProperty("/header/ReviseFlag",false);
                oBusyDialog.close();
                MessageBox.success(data?.Message, {
                  title: "Success",
                  onClose: function () {
                    this.getData();
                  }.bind(this)
                });
              } else {
                oBusyDialog.close();
                MessageBox.error(data?.Message, {
                  title: "Error",
                  onClose: function () {
                  }
                });
              }
            }
            oBusyDialog.close();
          }
          else {
            oBusyDialog.close();
            MessageBox.error("Enter the Mandatory Fields.", {
              title: "Error",
              onClose: function () {
              }
            });
          }


            }.bind(this)});
                  }
        catch (e) {
          oBusyDialog.close();
        }
      },

    });
  });
