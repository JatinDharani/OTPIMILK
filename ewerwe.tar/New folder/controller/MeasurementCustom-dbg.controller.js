sap.ui.define([
	"oil/ups/fdcs1/controller/BaseController",
	"oil/ups/fdcs1/util/unifiedRenderingFactory",
	"oil/ups/fdcs1/util/Utility",
	"oil/ups/fdcs1/util/Formatter",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/m/Dialog",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/format/DateFormat",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/BusyDialog",
	"sap/ui/core/ValueState",
	"sap/m/ObjectIdentifier",
	"sap/m/ObjectListItem",
	"sap/m/ObjectAttribute",
	"sap/m/ColumnListItem",
	"sap/m/Text",
	"sap/ui/core/Fragment",
	"sap/ui/layout/form/FormContainer",
	"sap/ui/layout/form/FormElement",
	"sap/ui/layout/GridData",
	"sap/ui/core/Item",
	"sap/ui/core/Title",
	"sap/ui/core/MessageType",
	"sap/ui/layout/form/ResponsiveGridLayout",
	"sap/ui/model/Sorter",
	"sap/m/Token",
	"sap/oil/ups/lib/commonss1/UomFilterBar"
], function (BaseController, unifiedRenderingFactory, Utility, Formatter, MessageBox, MessageToast, Dialog, JSONModel, DateFormat, Filter,
	FilterOperator, BusyDialog, ValueState, ObjectIdentifier, ObjectListItem, ObjectAttribute, ColumnListItem, Text, Fragment, FormContainer,
	FormElement, GridData, Item, Title, MessageType, ResponsiveGridLayoutData, Sorter, Token, UomFilterBar) {
	/* eslint-enable max-params */
	"use strict";
	"use strict";
	return BaseController.extend("oil.ups.fdcs1.UPS_FDCS1Extension1.controller.MeasurementCustom", {
			aData: [], //Array to store dynamic rendering information
			sQtytype: null, //Selected Quantity Type
			sMeasCatId: null, //Selected Measurement Category Id
			sType: null, //Network Object Type
			sMode: null, //Mode determiner
			sDesc: null, //Network Object Description
			sNetObjTypeCode: null, //Code for network object type
			aMetadata: [], //Metadata for each block. Used at the time of deletion
			aEtags: [], //Array to store Etags
			aCanBeDeleted: [], //Array to store boxes not to be sent to backend
			//oPPADialog: null, //Handle for PPA popup
			_oAuditDialog: null, //Handle for Audit popup
			sEligibility: "", //Eligibility Code for PPA/Audit
			sAuditReasonCode: "", //Audit Reason Code
			sPPAReason: "", //PPA Reason
			bDataChanged: false, //Flag to determine if data is changed
			_mesBusyDialog: null,
			bDeleteFlag: false, // Delete Button is Pressed
			_bIsPRAFiledsChanged: false, //PRA Input Fields Are changed or not
			sQtyCategory: null,
			aAuditReasonCodes: [],
			apprComments: "",
			/**
			 * This method initialize property (oBundle, oModel, formatter) and captures parameter passed from landing page.
			 * @method onInit
			 */
			onInit: function () {
				this.oBundle = this.getResourceBundle();
				this.oModel = this.getModel();
				this.formatter = Formatter;
				this.goBack = true;
				this._mesBusyDialog = new BusyDialog();
				this.oModelPage = new JSONModel();
                this.oHistoryPage = new JSONModel();
                this.getView().setModel(this.oHistoryPage,"history");
				//## The page title was not getting changed in very first navigation 
				//## So the funcation call has been placed here.
				this.startUpParamtersModelInit();
				//## 
				this._appConfignDataLoaded = this.getOwnerComponent().loadConfigCollections([
					"PRAIntSwitchSet"
				]);
				this.getRouter().attachRoutePatternMatched(function (oEvent) {
					if (oEvent.getParameter("name") === "measurement") {
						//## The page title was not getting changed in very first navigation
						//## So the funcation call has been placed to the upper level.
						// this.startUpParamtersModelInit();

						//Initializing the global variables by incoming variables from landing page
						this.oInputVar = Utility.decodeURLParameters(oEvent.getParameter("arguments"));
						this.sNetObjTypeCode = this.oInputVar.NetObjTyp;
						this.oInputVar.FromDate = new Date(this.fnConvertStringToDate(this.oInputVar.FromDate));
						this.oInputVar.AlertId = !this.oInputVar.AlertId ? "" : this.oInputVar.AlertId;
						this.oInputVar.OriginatingMp = !this.oInputVar.OriginatingMp ? "" : this.oInputVar.OriginatingMp;
						this.byId("idlistboxes").destroyFormContainers();
						this.byId("idfeqtytype").setVisible(false);
						this.byId("idfemeascatid").setVisible(false);
						this.byId("BtnMeasErrorMessage").setVisible(false);
						this.initPRAInputFields();
						this.getFilterBar();
                      //  this._readHistory();
						this._appConfignDataLoaded.always(function () {
							this.fnRefresh();
							// Instantiate the Message Manager
							this.initializeMessageManager(this.getView().getModel());
							this.setPRAStartUpParams();
						}.bind(this));
					}
				}, this);
			},
            _readHistory:function(oObject){
                this.oHistoryPage.setProperty("/items",[]);
              var  oODataModel = this.getOwnerComponent().getModel("history");
              var aFilters = [new Filter("Productionnetwork",FilterOperator.EQ,oObject.Productionnetwork),
			  new Filter("Networkobject",FilterOperator.EQ,oObject.Networkobject),
			  new Filter("NetworkobjectType",FilterOperator.EQ,oObject.NetworkobjectType),
			  new Filter("MeasmntTimestamp",FilterOperator.EQ,oObject.MeasmntTimestamp)];
			  
              oODataModel.read("/FDCApprovalHistSet",{
				filters:aFilters,
                success:function(oData,oResponse){
                    this.oHistoryPage.setProperty("/items",oData.results);
                    this.oHistoryPage.updateBindings();
                }.bind(this),
                error:function(oError){}.bind(this)
              });
            },

			/**
			 * Comment The below section for local run
			*/
			onBeforeRendering: function () {
				var i18n = this.getModel("i18n"); //get the standard i18n file
				var sBundleURL = this.getModel("i18nCustom").getResourceBundle().oUrlInfo.url;
				i18n.enhance({
					bundleUrl: sBundleURL
				}); // merge the custom i18n file with standard one
			},
			
			/**
			 * This function set the initial value for the StartupParameters JSON model data
			 * @public
			 */
			startUpParamtersModelInit: function () {
				var oStartupPramModel = new JSONModel({
					IsDisplayMode: true,
					IsPRAfieldEnabled: true,
					IsPRASwitch: false,
					IsTransDetailReq: false,
					IsTransDetailVisible: false,
					IsOrigMPVisible: false,
					IsDetailToInfoVisible: false,
					CategoryContainerVisible: true,
					IsMesDateFieldVisible: false,
					MesDate: "",
					MesTime: "",
					MesDateState: ValueState.None,
					ColumnL: 2,
					GridDataSpan: "L6 M6 S12",
					PPAStatus: "",
					Lock: "",
					PageTitle: this.getPageTitle(),
					ShareOnJam: {
						bVisible: true
					}
				});
				this.getView().setModel(oStartupPramModel, "StartupParameters");
			},

			/**
			 * Function to fill the JSON Model for page with initial values and then setting it as the model for the control(s)
			 */
			fnUpdateModel: function () { //Function to fill the JSON Model for page with initial values
				var oModelData = {
						title: this.oInputVar.NetObj,
						attr1text: this.sType,
						attr2text: this.sDesc,
						attr4text: this.oInputVar.ProdNetwork,
						attr3text: "",
						attr5text: "",
						zzlock: false,
						zzapproved: false
					},
					oStartupParametersModel = this.getView().getModel("StartupParameters");

				var oMediumDate = DateFormat.getDateInstance({
					style: "medium"
				}).format(this.oInputVar.FromDate);

				var frequencyCodes = {
					"D": {
						FreqText: "MEAS_FREQ_DAILY",
						Date: oMediumDate
					},
					"H": {
						FreqText: "MEAS_FREQ_HOURLY",
						Date: DateFormat.getDateTimeInstance({
							style: "short"
						}).format(this.oInputVar.FromDate)
					},
					"W": {
						FreqText: "MEAS_FREQ_WEEKLY",
						Date: oMediumDate
					},
					"M": {
						FreqText: "MEAS_FREQ_MONTHLY",
						Date: oMediumDate
					}
				};

				oModelData.attr3text = this.oInputVar.Frequency;
				oModelData.attr5text = (this.sNetObjTypeCode !== "GHO_WELL") ? DateFormat.getDateTimeInstance({
					style: "medium"
				}).format(this.oInputVar.FromDate) : DateFormat.getDateInstance({
					style: "medium"
				}).format(this.oInputVar.FromDate); //Default
				if (this.oInputVar.Frequency in frequencyCodes) {
					oModelData.attr3text = this.oBundle.getText(frequencyCodes[this.oInputVar.Frequency].FreqText);
					if (this.sNetObjTypeCode === "GHO_WELL") { // Use Frequency Specific Display only for Well Test in PRA OR UOM 
						oModelData.attr5text = frequencyCodes[this.oInputVar.Frequency].Date;
					}
				}


				// Enable / Disable the EDIT button based on the approval pending
				oModelData.zzlock = this.zzlock;
				oModelData.zzapproved = this.zzapproved;
				
				
				//Setting it as model for various controls
				this.oModelPage.setData(oModelData);
				this.getView().setModel(this.oModelPage, "HeaderDetails");
				oStartupParametersModel.setProperty("/MesDateState", ValueState.None);
				oStartupParametersModel.setProperty("/MesDate", this.oInputVar.FromDate);
				oStartupParametersModel.setProperty("/MesTime", this.oInputVar.FromDate);
			},

			/**
			 * Function to perform get batch call for getting FDCPNWorklistSet,
			 * Quantity type and Measurement Category Id.
			 * Setting the models for respective dropdowns and changing their state
			 * based on the values and no. of values backend returns
			 * Returning to landing page after showing error message if any batch call fails
			 */
			fnRefresh: function () {
				var oBatchCallPromises = [],
					sBatchCallGrp = "measurementDataRead",
					oODataModel = this.getView().getModel(),
					oFDCPNWorklistSetReadExecuted = jQuery.Deferred(),
					oPNQuantityTypeSetReadExecuted = jQuery.Deferred(),
					oPNMeasCatIdSetReadExecuted = jQuery.Deferred();

				//Refresh Module to gather all things needed before screen rendering
				this.sMode = null;
				this.sAuditReasonCode = "";
				this.sPPAReason = "";
				this.sEligibility = "";

				//Clear the ppa lock message.
				this._resetPPAStatus();
				var queryParam = {
					Networkobject: this.oInputVar.NetObj,
					Productionnetwork: this.oInputVar.ProdNetwork,
					NetworkobjectType: this.oInputVar.NetObjTyp,
					FdKey: "1",
					AddnlKey: "",
					MsmtStartdate: this.fnConvertDateToString(this.oInputVar.FromDate),
					OriginatingMp: this.oInputVar.OriginatingMp ,
                    BusKey:this.oInputVar.BusKey
                    // Add Originating Measurement Point
				};
				var afilterData = [{
					path: "Productionnetwork",
					operator: FilterOperator.EQ,
					value1: this.oInputVar.ProdNetwork
				}, {
					path: "Networkobject",
					operator: FilterOperator.EQ,
					value1: this.oInputVar.NetObj
				}, {
					path: "Networkobjecttype",
					operator: FilterOperator.EQ,
					value1: this.oInputVar.NetObjTyp
				}, {
					path: "Frequency",
					operator: FilterOperator.EQ,
					value1: this.oInputVar.Frequency
				}, {
					path: "MeasmntTimestamp",
					operator: FilterOperator.EQ,
					value1: this.fnConvertDateToString(this.oInputVar.FromDate)
				}];

				var oFilterQType = new Filter({
					filters: Utility.createODataFilters(afilterData),
					and: true
				});
				var oFilterMeasCatId = new Filter({
					filters: Utility.createODataFilters(afilterData),
					and: true
				});

				oODataModel.setDeferredGroups([sBatchCallGrp]);
				oODataModel.read(oODataModel.createKey("/FDCPNWorklistSet", queryParam), {
					groupId: sBatchCallGrp,
					success: oFDCPNWorklistSetReadExecuted.resolve,
					error: oFDCPNWorklistSetReadExecuted.reject
				});
				oBatchCallPromises.push(oFDCPNWorklistSetReadExecuted.promise());

				// For Quantity Type Set
				oODataModel.read("/PNQuantityTypeSet", {
					filters: [oFilterQType],
					groupId: sBatchCallGrp,
					success: oPNQuantityTypeSetReadExecuted.resolve,
					error: oPNQuantityTypeSetReadExecuted.reject
				});
				oBatchCallPromises.push(oPNQuantityTypeSetReadExecuted.promise());

				// For Measurement Category ID
				oODataModel.read("/PNMeasCatIdSet", {
					filters: [oFilterMeasCatId],
					groupId: sBatchCallGrp,
					success: oPNMeasCatIdSetReadExecuted.resolve,
					error: oPNMeasCatIdSetReadExecuted.reject
				});
				oBatchCallPromises.push(oPNMeasCatIdSetReadExecuted.promise());
				oODataModel.setUseBatch(true);
				this._mesBusyDialog.open();
				oODataModel.submitChanges({
					groupId: sBatchCallGrp
				});
				jQuery.when.apply(this, oBatchCallPromises)
					.done(function () {
						this._onMeasurementDataReadSuccess.apply(this, arguments);
					}.bind(this))
					.fail(function (oError) {
						this._mesBusyDialog.close();
						this.fnHandleError({
							messageKey: jQuery.parseJSON(oError.responseText).error.message.value,
							titleKey: this.getResourceBundle().getText("BATCH_FAILED")
						});
					}.bind(this));
			},

			/**
			 * Callback Function for Read Batch Operations,
			 * This functions will have the reponse of all the batch calls as parameters, which are accessed by aruguments array
			 * Response of batch calls further used to populate the Model Data accordingly
			 * @private
			 */
			_onMeasurementDataReadSuccess: function () {
				var batchResponses = arguments,
					oBundle = this.getResourceBundle();

				this._mesBusyDialog.close();
				if (batchResponses[0][1].statusCode === "200") {
					this.goBack = false;
					this.fnFillTypeDesc(batchResponses[0][1].data);
				} else {
					this.fnHandleError({
						messageKey: batchResponses[0][1].statusText,
						titleKey: oBundle.getText("BATCH_FAILED")
					});
					return;
				}
				if (batchResponses[1][1].statusCode === "200") {
					this.goBack = false;
					this.fnFillQType(batchResponses[1][1].data);
				} else {
					this.fnHandleError({
						messageKey: batchResponses[1][1].statusText,
						titleKey: oBundle.getText("BATCH_FAILED")
					});
					return;
				}
				if (batchResponses[2][1].statusCode === "200") {
					this.goBack = false;
					this.fnFillMeasCatId(batchResponses[2][1].data);
				} else {
					this.fnHandleError({
						messageKey: batchResponses[2][1].statusText,
						titleKey: oBundle.getText("BATCH_FAILED")
					});
					return;
				}
				this.bDataChanged = false;
				this.fnReadMeasurementData();
			},

			/**
			 * Success function of the PNWorklistSet Entity. Initializes the global variables and sets the model for control(s)
			 * @param	{object}	data	Data object coming from the read call
			 */
			fnFillTypeDesc: function (data) {
				this.sType = data.NetobjTypeDesc;
				this.sDesc = data.NetobjDesc;
				this.sNetObjTypeCode = data.NetworkobjectType;
				this.zzlock = data.Zzlock;
				this.zzapproved = data.ZZALLOCATED;				;
				this._appConfignDataLoaded.always(function () {
					this.setPRAStartUpParams();
				}.bind(this));
				this.fnUpdateModel(); // When all the variables are initialized, then only call the update model
			},

			/**
			 * Generic Error Handler function all 3 components of the batch.
			 * Called when any one query fails, displays the error message and goes back to the landing page on click on OK
			 * @param	{object}	oErr	Error object coming from the read call containing error information
			 */
			fnHandleError: function (oErr) {
				this._showError(oErr, false, {}, function () {
					if (this.goBack) {
						this._navBack();
					}
				}.bind(this));
			},

			/**
			 * Success function of the PNQuantityTypeSet Entity. Creates Model for the dropdown and fills it with the values coming from backend.
			 * Adjusts its visibility and enable property based on the no of values coming from backend
			 * @param	{object}	oResponse	Odata object coming from the read call
			 */
			fnFillQType: function (oResponse) {
				var oControlQType = this.byId("selqtytype");
				var oModelQtyType = new JSONModel();
				oModelQtyType.setData({
					qtytype: oResponse.results
				});
				oControlQType.setModel(oModelQtyType);
				oControlQType.bindItems("/qtytype", new Item({
					key: "{Qtytype}",
					text: "{Qtydesc}"
				}));
				if (oResponse.results.length > 0) {
					this.byId("idfeqtytype").setVisible(true);
					if (this.oInputVar.AlertId !== "") {
						this.oInputVar.QtyType = "000";
					}
					if (this.oInputVar.QtyType !== "000" && this.oInputVar.QtyType !== "") {
						oControlQType.setVisible(true).setEnabled(true).setSelectedItem(oControlQType.getItemByKey(this.oInputVar.QtyType));
						this.sQtytype = this.oInputVar.QtyType;
					} else {
						oControlQType.setVisible(true).setEnabled(true).setSelectedItem(oControlQType.getFirstItem());
						this.sQtytype = oControlQType.getFirstItem().getKey();
					}
				} else {
					this.byId("idfeqtytype").setVisible(false);
					oControlQType.setVisible(false);
					this.sQtytype = "";
				}
				if (oResponse.results.length === 1) {
					oControlQType.setEnabled(false);
				}
			},

			/**
			 * Success function of the PNMeasCatIdSet Entity. Creates Model for the dropdown and fills it with the values coming from backend.
			 * Adjusts its visibility and enable property based on the no of values coming from backend
			 * @param	{object}	oResponse	Odata object coming from the read call
			 */
			fnFillMeasCatId: function (oResponse) {
				var oControlMeasCatId = this.byId("selmeascatid");
				var oMeasCatid = this.byId("idfemeascatid");
				var oModelMeasCatId = new JSONModel(),
					oStartupParameters = this.getView().getModel("StartupParameters");
				oStartupParameters.setProperty("/CategoryContainerVisible", true);
				oModelMeasCatId.setData({
					meascatid: oResponse.results
				});
				oControlMeasCatId.setModel(oModelMeasCatId);
				oControlMeasCatId.bindItems("/meascatid", new Item({
					key: "{MeasCatId}",
					text: "{MeasCatIdDesc}"
				}));
				if (oResponse.results.length > 0) {
					oMeasCatid.setVisible(true);
					if (this.oInputVar.MeasCatId && this.oInputVar.MeasCatId !== "") {
						oControlMeasCatId.setVisible(true).setEnabled(true).setSelectedItem(oControlMeasCatId.getItemByKey(this.oInputVar.MeasCatId));
						this.sMeasCatId = this.oInputVar.MeasCatId;
					} else {
						oControlMeasCatId.setVisible(true).setEnabled(true).setSelectedItem(oControlMeasCatId.getFirstItem());
						this.sMeasCatId = oControlMeasCatId.getFirstItem().getKey();
					}
				} else {
					oMeasCatid.setVisible(false);
					oControlMeasCatId.setVisible(false);
					this.sMeasCatId = "";
				}
				if (oResponse.results.length === 1) {
					oControlMeasCatId.setEnabled(false);
				}
			},

			/**
			 * Event fired on change of Quantity Type dropdown value to update global variable(s) and re render screen
			 * @param	{object}	oEvent	Object containing information about the Event fired
			 */
			fnOnChangeQtyType: function (oEvent) {
				this.sQtytype = oEvent.getSource().getSelectedItem() === null ? "" : oEvent.getSource().getSelectedItem().getKey();
				this.sMode = "switch";
				this.bDataChanged = false;
				this.fnReadMeasurementData();
				this.removeAllMessages();
			},

			/**
			 * Event fired on change of Measurement Category Id dropdown value to update global variable(s) and re render screen
			 * @param	{object}	oEvent	Object containing information about the Event fired
			 */
			fnOnChangeMeasCatId: function (oEvent) {
				this.sMeasCatId = oEvent.getSource().getSelectedItem() === null ? "" : oEvent.getSource().getSelectedItem().getKey();
				this.sMode = "switch";
				this.bDataChanged = false;
				this.fnReadMeasurementData();
			},

			/**
			 * Function to update the details form in the view by putting form container and form elements
			 * @param	{object}	data response of odata read call
			 */
			fnUpdateView: function (data) {
				var i,
					oFormContainer,
					oFormContainer1,
					oFormContainer2,
					oJSONModel,
					oJSONModel1,
					oData,
					sTitle,
					sStdTitle,
					len = data.results.length,
					oControl = this.byId("idlistboxes"),
					oContro11 = this.byId("idstdlistboxes"),
					oDataPageSection = this.byId("idDataSection"),
					bPRASwitch = this.getPRASwitch();
				oControl.destroyFormContainers(); //if successful destroying the table previous content
				oContro11.destroyFormContainers(); //if successful destroying the table previous content
				this.fnSetMode(this.sExistenceFlag);
				this.setPRAStartUpParams(data);
				if (this.sMode === "display" && this.sQtyCategory === "09" && this.oInputVar.NetObjTyp !== "GHO_WELL") {
					oDataPageSection.setVisible(false);
				} else {
					oDataPageSection.setVisible(true);
				}
				// if(this.sMode === "display"){
                //  this.getView().byId("idHistorySection").setVisible(false);
				// }else{
				// 	this.getView().byId("idHistorySection").setVisible(true);
				// }
				if (this.fnSetHeadingAndButtons(data)) {
					this.fnCacheData(data);
					oData = jQuery.extend(true, {}, this.aData);
					this.initPRAInputFields(this.aData);
					for (i = 0; i < len; i++) {
						//create form container
						oFormContainer = new FormContainer();
						oFormContainer1 = new FormContainer();
						oFormContainer2 = new FormContainer();
						if (this.sNetObjTypeCode === "GHO_WELL") {
							this.byId("idDetailSection").setVisible(false);
						} else {
							sTitle = data.results[i].Medium;
							//set the title of the form container, if GHO_WELL its well reading otherwise measurement medium
							oFormContainer.setTitle(new Title({
								text: sTitle
							}));
							//set the title of the form container, if GHO_WELL its well reading otherwise measurement medium
							oFormContainer1.setTitle(new Title({
								text: ""
							}));
							if (bPRASwitch) {
								//set the title of the form container, if GHO_WELL its well reading otherwise measurement medium
								oFormContainer2.setTitle(new Title({
									text: ""
								}));
							}
						}
						oDataPageSection.setTitle(this.getDataSectionTitle());
						var sItemsLen, sHalfIndex, sFullIndex;
						sItemsLen = oData[i].FDCMeasurementRawSet.length;


						// Trim the FNUM Values // 
						for (var k=0; k<sItemsLen; k++){
							oData[i].FDCMeasurementRawSet[k].Fnumvalue = oData[i].FDCMeasurementRawSet[k].Fnumvalue.trim();
						}

						if (bPRASwitch) {
							sHalfIndex = sItemsLen ? Math.ceil(sItemsLen / 3) : 0;
							sFullIndex = sItemsLen ? Math.ceil(2 * sItemsLen / 3) : 0;
						} else {
							sHalfIndex = sItemsLen ? Math.ceil(sItemsLen / 2) : 0;
						}
						if (sHalfIndex && sFullIndex) {
							oData[i].FDCMeasurementRawSet.ItemData2 = oData[i].FDCMeasurementRawSet.slice(sFullIndex, sItemsLen);
							oData[i].FDCMeasurementRawSet.ItemData1 = oData[i].FDCMeasurementRawSet.slice(sHalfIndex, sFullIndex);
							oData[i].FDCMeasurementRawSet.ItemData = oData[i].FDCMeasurementRawSet.slice(0, sHalfIndex);
						} else if (sHalfIndex) {
							oData[i].FDCMeasurementRawSet.ItemData1 = oData[i].FDCMeasurementRawSet.slice(sHalfIndex, sItemsLen);
							oData[i].FDCMeasurementRawSet.ItemData = oData[i].FDCMeasurementRawSet.slice(0, sHalfIndex);
						}
						oJSONModel = new JSONModel(oData[i].FDCMeasurementRawSet.ItemData);
						oFormContainer.setModel(oJSONModel);
						oJSONModel = new JSONModel(oData[i].FDCMeasurementRawSet.ItemData1);
						oFormContainer1.setModel(oJSONModel);
						if (bPRASwitch) {
							oJSONModel = new JSONModel(oData[i].FDCMeasurementRawSet.ItemData2);
							oFormContainer2.setModel(oJSONModel);
						}
						oJSONModel1 = new JSONModel(oData[i]);
						this.getView().setModel(oJSONModel1, "DynamicModel");
						if (oData[i].FDCMeasurementRawSet.ItemData.length > 0) {
							//bind aggregation formElements to show the characteristics
							oFormContainer.bindAggregation("formElements", {
								path: "/",
								factory: this.fnDisplayFactory.bind(this)
							});
						}
						oControl.addFormContainer(oFormContainer);
						if (oData[i].FDCMeasurementRawSet.ItemData1.length > 0) {
							//bind aggregation formElements to show the characteristics
							oFormContainer1.bindAggregation("formElements", {
								path: "/",
								factory: this.fnDisplayFactory.bind(this)
							});
						}
						oControl.addFormContainer(oFormContainer1);
						if (bPRASwitch) {
							if (oData[i].FDCMeasurementRawSet.ItemData2.length > 0) {
								//bind aggregation formElements to show the characteristics
								oFormContainer2.bindAggregation("formElements", {
									path: "/",
									factory: this.fnDisplayFactory.bind(this)
								});
							}
							oControl.addFormContainer(oFormContainer2);
						}

						// Show Standardized Values Section only in Display Mode
						if (this.sMode === "display") {
							if (this.sNetObjTypeCode !== "GHO_WELL") {
								var sStdItemsLen, sHalfStdIndex, sFullStdIndex,
									oFormStdContainer, oFormStdContainer1, oFormStdContainer2;
								sStdTitle = data.results[i].Medium;
								this.byId("idStdSection").setVisible(true);
								//set the title of the form container, if GHO_WELL its well reading otherwise measurement medium
								oFormStdContainer = new FormContainer();
								oFormStdContainer.setModel(oJSONModel1);
								oFormStdContainer.setTitle(new Title({
									text: sStdTitle
								}));
								sStdItemsLen = oData[i].FDCMeasurementStdQtySet.length;
								if (bPRASwitch) {
									sHalfStdIndex = sStdItemsLen ? Math.ceil(sStdItemsLen / 3) : 0;
									sFullStdIndex = sStdItemsLen ? Math.ceil(2 * sStdItemsLen / 3) : 0;
								} else {
									sHalfStdIndex = sStdItemsLen ? Math.ceil(sStdItemsLen / 2) : 0;
								}

								if (sHalfStdIndex && sFullStdIndex) {
									oData[i].FDCMeasurementStdQtySet.ItemData2 = oData[i].FDCMeasurementStdQtySet.slice(sFullStdIndex, sItemsLen);
									oData[i].FDCMeasurementStdQtySet.ItemData1 = oData[i].FDCMeasurementStdQtySet.slice(sHalfStdIndex, sFullStdIndex);
									oData[i].FDCMeasurementStdQtySet.ItemData = oData[i].FDCMeasurementStdQtySet.slice(0, sHalfStdIndex);
								} else if (sHalfStdIndex) {
									oData[i].FDCMeasurementStdQtySet.ItemData1 = oData[i].FDCMeasurementStdQtySet.slice(sHalfStdIndex, sItemsLen);
									oData[i].FDCMeasurementStdQtySet.ItemData = oData[i].FDCMeasurementStdQtySet.slice(0, sHalfStdIndex);
								} else {
									oData[i].FDCMeasurementStdQtySet.ItemData2 = [];
									oData[i].FDCMeasurementStdQtySet.ItemData1 = [];
									oData[i].FDCMeasurementStdQtySet.ItemData = [];
								}

								if (oData[i].FDCMeasurementStdQtySet.ItemData.length > 0) {
									//bind aggregation formElements to show the characteristics
									oFormStdContainer.bindAggregation("formElements", {
										path: "/FDCMeasurementStdQtySet/ItemData",
										factory: this.fnDisplayFactory.bind(this)
									});
								} else {
									oFormStdContainer.addFormElement(new FormElement({
										fields: [
											new Text({
												text: this.getResourceBundle().getText("STD_RES_DONT_EXIST", [sStdTitle])
											}).setLayoutData(new GridData({
												span: "L12 M12 S12"
											}))
										]
									}));
								}
								// Check if Standardized values exist, add standardized values container else
								// display no standardized values exist message
								oContro11.addFormContainer(oFormStdContainer);

								oFormStdContainer1 = new FormContainer();
								oFormStdContainer1.setModel(oJSONModel1);
								if (oData[i].FDCMeasurementStdQtySet.ItemData1.length > 0) {
									//bind aggregation formElements to show the characteristics
									oFormStdContainer1.bindAggregation("formElements", {
										path: "/FDCMeasurementStdQtySet/ItemData1",
										factory: this.fnDisplayFactory.bind(this)
									});
									//set the title of the form container, if GHO_WELL its well reading otherwise measurement medium
									oFormStdContainer1.setTitle(new Title({
										text: ""
									}));
								}
								oContro11.addFormContainer(oFormStdContainer1);

								if (bPRASwitch) {
									oFormStdContainer2 = new FormContainer();
									oFormStdContainer2.setModel(oJSONModel1);
									if (oData[i].FDCMeasurementStdQtySet.ItemData2.length > 0) {
										//set the title of the form container, if GHO_WELL its well reading otherwise measurement medium
										oFormStdContainer2.setTitle(new Title({
											text: ""
										}));
										//bind aggregation formElements to show the characteristics
										oFormStdContainer2.bindAggregation("formElements", {
											path: "/FDCMeasurementStdQtySet/ItemData2",
											factory: this.fnDisplayFactory.bind(this)
										});
									}
									oContro11.addFormContainer(oFormStdContainer2);
								}
							}
							// >>> Insert >>>> //
						} else if (this.sMode === "edit" || this.sMode === "create") {
							if (this.sNetObjTypeCode !== "GHO_WELL") {
								var sStdItemsLen, sHalfStdIndex, sFullStdIndex,
									oFormStdContainer, oFormStdContainer1, oFormStdContainer2;
								sStdTitle = data.results[i].Medium;
							    this.byId("idStdSection").setVisible(true);
								
								//set the title of the form container, if GHO_WELL its well reading otherwise measurement medium
								oFormStdContainer = new FormContainer();
								oFormStdContainer.setModel(oJSONModel1);
								oFormStdContainer.setTitle(new Title({
									text: sStdTitle
								}));
								sStdItemsLen = oData[i].FDCMeasurementStdQtySet.length;
								if (bPRASwitch) {
									sHalfStdIndex = sStdItemsLen ? Math.ceil(sStdItemsLen / 3) : 0;
									sFullStdIndex = sStdItemsLen ? Math.ceil(2 * sStdItemsLen / 3) : 0;
								} else {
									sHalfStdIndex = sStdItemsLen ? Math.ceil(sStdItemsLen / 2) : 0;
								}

								if (sHalfStdIndex && sFullStdIndex) {
									oData[i].FDCMeasurementStdQtySet.ItemData2 = oData[i].FDCMeasurementStdQtySet.slice(sFullStdIndex, sItemsLen);
									oData[i].FDCMeasurementStdQtySet.ItemData1 = oData[i].FDCMeasurementStdQtySet.slice(sHalfStdIndex, sFullStdIndex);
									oData[i].FDCMeasurementStdQtySet.ItemData = oData[i].FDCMeasurementStdQtySet.slice(0, sHalfStdIndex);
								} else if (sHalfStdIndex) {
									oData[i].FDCMeasurementStdQtySet.ItemData1 = oData[i].FDCMeasurementStdQtySet.slice(sHalfStdIndex, sItemsLen);
									oData[i].FDCMeasurementStdQtySet.ItemData = oData[i].FDCMeasurementStdQtySet.slice(0, sHalfStdIndex);
								} else {
									oData[i].FDCMeasurementStdQtySet.ItemData2 = [];
									oData[i].FDCMeasurementStdQtySet.ItemData1 = [];
									oData[i].FDCMeasurementStdQtySet.ItemData = [];
								}

								if (oData[i].FDCMeasurementStdQtySet.ItemData.length > 0) {
									//bind aggregation formElements to show the characteristics
									oFormStdContainer.bindAggregation("formElements", {
										path: "/FDCMeasurementStdQtySet/ItemData",
										factory: this.fnDisplayFactory.bind(this)
									});
								} else {
									oFormStdContainer.addFormElement(new FormElement({
										fields: [
											new Text({
												text: this.getResourceBundle().getText("STD_RES_DONT_EXIST", [sStdTitle])
											}).setLayoutData(new GridData({
												span: "L12 M12 S12"
											}))
										]
									}));
								}
								// Check if Standardized values exist, add standardized values container else
								// display no standardized values exist message
								oContro11.addFormContainer(oFormStdContainer);
								
								oFormStdContainer1 = new FormContainer();
								oFormStdContainer1.setModel(oJSONModel1);
								if (oData[i].FDCMeasurementStdQtySet.ItemData1.length > 0) {
									//bind aggregation formElements to show the characteristics
									oFormStdContainer1.bindAggregation("formElements", {
										path: "/FDCMeasurementStdQtySet/ItemData1",
										factory: this.fnDisplayFactory.bind(this)
									});
									//set the title of the form container, if GHO_WELL its well reading otherwise measurement medium
									oFormStdContainer1.setTitle(new Title({
										text: ""
									}));
								}
								oContro11.addFormContainer(oFormStdContainer1);

								if (bPRASwitch) {
									oFormStdContainer2 = new FormContainer();
									oFormStdContainer2.setModel(oJSONModel1);
									if (oData[i].FDCMeasurementStdQtySet.ItemData2.length > 0) {
										//set the title of the form container, if GHO_WELL its well reading otherwise measurement medium
										oFormStdContainer2.setTitle(new Title({
											text: ""
										}));
										//bind aggregation formElements to show the characteristics
										oFormStdContainer2.bindAggregation("formElements", {
											path: "/FDCMeasurementStdQtySet/ItemData2",
											factory: this.fnDisplayFactory.bind(this)
										});
									}
									oContro11.addFormContainer(oFormStdContainer2);
								}
							}
						}
						// <<<< Insert <<<< //
						else {
							this.byId("idStdSection").setVisible(false);
						}
					}
				}
			},
			/**
			 * Function to initialize PRA Input fields
			 * @param	{Array}	aMesDataArr	Measurement Response Results Data Array
			 */
			initPRAInputFields: function (aMesDataArr) {
				var oMesData;
				this.getToProdNetworkInputField().removeAllTokens();
				this.getToNetobjTyDesInputField().removeAllTokens();
				this.getToNetworkObjInputField().removeAllTokens();
				this.getOrigMpInputField().removeAllTokens();
				this.getTransporterInputField().removeAllTokens();
				this.getTransporterRefInputField().removeAllTokens();
				this.getTransporterRefInputField().setValueState(ValueState.None);
				if (aMesDataArr && aMesDataArr.length > 0) {
					oMesData = aMesDataArr[0];
					if (oMesData.ToProdNetwork) {
						this.getFilterBar().addTokenToObject(this.getToProdNetworkInputField(), oMesData.ToProdNetwork);
					}
					if (oMesData.ToNetobjTyDes) {
						this.getFilterBar().addTokenToObject(this.getToNetobjTyDesInputField(), oMesData.ToNetobjTyDes);
					}
					if (oMesData.ToNetworkObj) {
						this.getFilterBar().addTokenToObject(this.getToNetworkObjInputField(), oMesData.ToNetworkObj);
					}
					if (oMesData.TrnspNo) {
						this.addMultiInputToken(this.getTransporterInputField(), oMesData.TrnspNo, oMesData.TranspName + " (" + oMesData.TrnspNo + ")");
					}
					if (oMesData.TrnspRefNo) {
						this.addMultiInputToken(this.getTransporterRefInputField(), oMesData.TrnspRefNo);
					}
					if (oMesData.OriginatingMp) {
						this.addMultiInputToken(this.getOrigMpInputField(), oMesData.OriginatingMp);
					}
				}
				//Very important keep this at the end of function as above token removal might set this flag as true
				this._bIsPRAFiledsChanged = false;
			},
			/**
			 * Event Handler when the User clicks on Save or Edit. Updates a global variable sMode if required
			 * presents a warning popup (in case of edit) if data is validated
			 * @param	{object}	oEvent	Object containing information about the Event fired
			 */
			fnOnClickHandleSaveEdit: function (oEvent) { //first button event for update and save actions based on its text
				var oBundle = this.getResourceBundle();
				var allocated = this.getView().getModel("HeaderDetails").getData().zzapproved;
				if (oEvent.getSource().getText() === oBundle.getText("MEAS_BUTTON_TEXT_EDIT")) {
					this.sMode = "edit";
					this.bDataChanged = false;
					this.fnReadMeasurementData();
				} else {
					if (this.fnCheckForValidity()) {
						if (this.sMode === "edit") {
							if (this._isDataChanged()) {
								if (allocated){
									MessageBox.confirm(oBundle.getText("MESSAGE_CONFIRM_ON_EDIT"), {
										title: oBundle.getText("WTMEAS_EDIT_HEADING"),
										onClose: this.fnHandleSave.bind(this)
									});
								}else{
									MessageBox.confirm(oBundle.getText("MESSAGE_CONFIRM_ON_EDIT"), {
										title: oBundle.getText("WTMEAS_EDIT_HEADING"),
										onClose: this.fnHandleApprvComment.bind(this)
									});
								}
							} else {
								this._showError({
									messageKey: oBundle.getText("VALUES_NOT_UPDATED"),
									titleKey: oBundle.getText("MEAS_UPDATE_FAILED")
								}, false, {});
							}
						} else {
							this.fnHandleSave();
						}
					}
				}
			},

			/*
			 * Function to check weather form data is changed or not
			 * @return	{Bolean}	true/false weather form data is changed or not
			 */
			_isDataChanged: function () {
				var i, j = 0,
					k = 0,
					iCols,
					len, len1,
					oCacheData,
					bChangeFlag,
					aFormContainer,
					oFormContainerData,
					oMergedFormContainerData = [],
					oForm = this.byId("idlistboxes"),
					bPRASwitch = this.getPRASwitch();
				len = this.aData.length;
				if (this._bIsPRAFiledsChanged) {
					return true;
				}
				aFormContainer = oForm.getFormContainers();
				iCols = bPRASwitch ? 3 : 2;
				for (i = 0; i < len; i++) {
					oCacheData = this.aData[i];
					if (oCacheData.FDCMeasurementRawSet.length > 2) {
						len1 = 3;
					} else if (oCacheData.FDCMeasurementRawSet.length > 1) {
						len1 = 2;
					} else if (oCacheData.FDCMeasurementRawSet.length >= 0) {
						len1 = 1;
					} else {
						//No Else
					}
					oMergedFormContainerData = [];
					if (i !== 0) { // Calculate the value of j based on the number of columns in the layout
						j += iCols;
						len1 += j;
						k = j;
					}
					for (j; j < len1; j++) {
						oFormContainerData = aFormContainer[j] ? aFormContainer[j].getModel().getData() : undefined;
						if (oFormContainerData) {
							jQuery.merge(oMergedFormContainerData, oFormContainerData);
						}
					}
					j = (i === 0) ? 0 : k; // reset j value for the next iteration
					bChangeFlag = oMergedFormContainerData.some(function (obj, index) {
						return obj.Fnumvalue !== oCacheData.FDCMeasurementRawSet[index].Fnumvalue;
					});
					if (bChangeFlag) {
						return true;
					}
				}

				var aStdFormContainer = [],
					oStdMergedFormContainerData = [],
					oStdFormContainerData;
				var oStdForm = this.byId("idstdlistboxes");
				bPRASwitch = this.getPRASwitch();
				len = this.aData.length;
				if (this._bIsPRAFiledsChanged) {
					return true;
				}
				aStdFormContainer = oStdForm.getFormContainers();
				iCols = bPRASwitch ? 3 : 2;
				for (i = 0; i < len; i++) {
					oCacheData = this.aData[i];
					if (oCacheData.FDCMeasurementStdQtySet.length > 2) {
						len1 = oCacheData.FDCMeasurementStdQtySet.length;
					} else if (oCacheData.FDCMeasurementStdQtySet.length > 1) {
						len1 = 2;
					} else if (oCacheData.FDCMeasurementStdQtySet.length >= 0) {
						len1 = 1;
					} else {
						//No Else
					}
					var oMergedStdFormContainerData = [];
					if (i !== 0) { // Calculate the value of j based on the number of columns in the layout
						j += iCols;
						len1 += j;
						k = j;
					}
					for (j; j < len1; j++) {

						oStdFormContainerData = aStdFormContainer[0].getModel().getData().FDCMeasurementStdQtySet[j];
						if (oStdFormContainerData) {
							// jQuery.merge(oStdMergedFormContainerData, oStdFormContainerData);
							oStdMergedFormContainerData.push(oStdFormContainerData);
						}
					}
					j = (i === 0) ? 0 : k; // reset j value for the next iteration
					bChangeFlag = oStdMergedFormContainerData.some(function (obj, index) {
						return obj.Fnumvalue !== oCacheData.FDCMeasurementStdQtySet[index].Fnumvalue;
					});
					if (bChangeFlag) {
						return true;
					}
				}

				return false;
			},

			/**
			 * Function to act accordingly to the user's choice when a warning was presented when user clicked on Cancel based on user's Mode
			 * @param	{object}	oResult    Object containing information about the User's choice
			 */
			fnHandleUserChoice: function (oResult) {
				if (!oResult || oResult === MessageBox.Action.OK) {
					if (this.sMode === "create") {
						this._navBack();
					} else {
						this.sMode = null;
						this.bDataChanged = false;
						this.fnReadMeasurementData();
					}
				}
			},

			/**
			 * Event Handler when the User clicks on Cancel or Delete. Presents a warning popup if cancel was clicked and user has changed some values
			 * Presents a warning popup if delete was clicked
			 * @param	{object}	oEvent	Object containing information about the Event fired
			 */
			fnOnClickHandleDeleteCancel: function (oEvent) { //second button event for cancel and delete actions based on its text
				if (oEvent.getSource().getText() === this.oBundle.getText("MEAS_BUTTON_TEXT_DELETE")) {
					this.fnShowPopupToConfirmDelete();
				} else {
					if (this.sMode === "edit") {
						if (this.bDataChanged || this._bIsPRAFiledsChanged) {
							MessageBox.confirm(this.oBundle.getText("MESSAGE_ON_CANCEL"), {
								title: this.oBundle.getText("ZONC_WARNING"),
								onClose: this.fnHandleUserChoice.bind(this)
							});
						} else {
							this.sMode = null;
							this.bDataChanged = false;
							this.fnReadMeasurementData(); // if cancel was pressed re render the screen if in edit mode
						}
					} else {
						if (this.bDataChanged || this._bIsPRAFiledsChanged) {
							MessageBox.confirm(this.oBundle.getText("MESSAGE_ON_CANCEL"), {
								title: this.oBundle.getText("ZONC_WARNING"),
								onClose: this.fnHandleUserChoice.bind(this)
							});
						} else {
							this._navBack(); // if cancel was pressed from create mode, go back to landing page
						}
					}
				}
			},

			/**
			 * Get the map of operators containing validation function and corresponding error messageKey
			 * @return	{object}	Range rule operator map
			 */
			_getRangeRuleOperatorMap: function () {
				return {
					"LE": {
						validator: function (a, b) {
							return a > b;
						},
						messageKey: "MEAS_MESSAGE_LE"
					},
					"GE": {
						validator: function (a, b) {
							return a < b;
						},
						messageKey: "MEAS_MESSAGE_GE"
					},
					"EQ": {
						validator: function (a, b) {
							return a !== b;
						},
						messageKey: "MEAS_MESSAGE_EQ"
					},
					"GT": {
						validator: function (a, b) {
							return a <= b;
						},
						messageKey: "MEAS_MESSAGE_GT"
					},
					"LT": {
						validator: function (a, b) {
							return a >= b;
						},
						messageKey: "MEAS_MESSAGE_LT"
					},
					"BT": {
						validator: function (a, b, c) {
							return !(a >= b && a <= c);
						},
						messageKey: "MEAS_MESSAGE_BW"
					},
					"NB": {
						validator: function (a, b, c) {
							return (a >= b && a <= c);
						},
						messageKey: "MEAS_MESSAGE_NB"
					},
					"NE": {
						validator: function (a, b) {
							return a === b;
						},
						messageKey: "MEAS_MESSAGE_NE"
					}
				};
			},

			/**
			 * Validate range rule for given raw measurement object and set control's value state in case of error
			 * @param	{object}				oRawMeasurement 	Raw measurement values
			 * @param	{sap.ui.core.Control}	oControl			Reference of control for which range rule needs to be validated
			 * @return	{boolean}				true/false			Return true if range rule is validated else false
			 */
			_isValidRangeRule: function (oRawMeasurement, oControl) {
				var sValue,
					iLow,
					iHigh,
					sOperator,
					mapOperators,
					sMsg,
					sTarget = oControl.getBindingContext().sPath + "/" + oControl.getBindingPath("value"),
					oMessageProcessor = oControl.getModel();
				sOperator = oRawMeasurement.Fopt;
				if (sOperator) {
					//convert string values to float values
					sValue = parseFloat(oRawMeasurement.Fnumvalue);
					iLow = parseFloat(oRawMeasurement.Flow);
					iHigh = parseFloat(oRawMeasurement.Fhigh);
					//get map of operators to do range rule validation
					mapOperators = this._getRangeRuleOperatorMap();
					if ((sOperator in mapOperators) && (mapOperators[sOperator].validator(sValue, iLow, iHigh))) {
						//range rule validation failed. Set control state to Error and show corresponding error message.

						sMsg = jQuery.sap.formatMessage(
							this.getResourceBundle().getText(mapOperators[sOperator].messageKey), iLow, iHigh);

						this._addMessage(sTarget, sMsg, sMsg, MessageType.Error, oMessageProcessor);
						return false;
					}
				}
				this._removeMessage(sTarget, oMessageProcessor);
				return true;
			},

			/**
			 * Check if any field in the form is in error state or violates range rule
			 * @param	{sap.ui.layout.form.Form}	oForm		Reference of form to be validated
			 * @return	{boolean}					true/false	Returns true is no control is in error state or violates range rule else false     
			 */
			_validateErrorStateAndRange: function (oForm) {
				var i,
					j,
					oControl,
					oControlValue,
					oFormContainerData,
					oFormContainer,
					iFormElementLen,
					aFormElements,
					bIsNaN = true,
					bValidForm = true,
					aFormContainers = oForm.getFormContainers(),
					iFormContLen = aFormContainers.length;
				for (i = 0; i < iFormContLen; i++) {
					oFormContainer = aFormContainers[i];
					aFormElements = oFormContainer.getFormElements();
					//get the reference of data object bound to the form container
					oFormContainerData = oFormContainer.getModel().getProperty("/");
					//store the length of the raw measurement set for better performance
					iFormElementLen = oFormContainerData.length;
					for (j = 0; j < iFormElementLen; j++) {
						//get the reference of control for which validation/checks should be done
						oControl = aFormElements[j].getFields()[0];
						if (oControl.getMetadata().getName() === "sap.m.Select") {
							oControlValue = oControl.getSelectedKey();
						} else {
							oControlValue = oControl.getValue();
							bIsNaN = isNaN(parseInt(oControlValue, 10));
						}
						//if some value is entered, check control's value state and perform range rule validation
						if (oControlValue !== "") {
							/* if control value state is error, return false
							   else if range rule validation fails, return false*/
							if (oControl.getValueState() === ValueState.Error) {
								this._setFirstErrorStateControl(oControl);
								bValidForm = false;
							} else if (!this._isValidRangeRule(oFormContainerData[j], oControl)) {
								this._setFirstErrorStateControl(oControl);
								bValidForm = false;
							}
						} else if (oControl.getValueState() === ValueState.Error && !bIsNaN) {
							this._setFirstErrorStateControl(oControl);
							bValidForm = false;
						}
					}
				}
				return bValidForm;
			},

			/**
			 * Check if any field in the form is in error state or violates range rule
			 * @param	{sap.ui.layout.form.Form}	oForm		Reference of form to be validated
			 * @return	{boolean}					true/false	Returns true is no control is in error state or violates range rule else false     
			 */
			_stdvalidateErrorStateAndRange: function (oForm) {
				var i,
					j,
					oControl,
					oControlValue,
					oFormContainerData,
					oFormContainer,
					iFormElementLen,
					aFormElements,
					bIsNaN = true,
					bValidForm = true,
					aFormContainers = oForm.getFormContainers(),
					iFormContLen = aFormContainers.length;
				for (i = 0; i < iFormContLen; i++) {
					oFormContainer = aFormContainers[i];
					aFormElements = oFormContainer.getFormElements();
					//get the reference of data object bound to the form container
					oFormContainerData = oFormContainer.getModel().getProperty("/");
					//store the length of the raw measurement set for better performance
					iFormElementLen = oFormContainerData.length;
					for (j = 0; j < 1; j++) {
						//get the reference of control for which validation/checks should be done
						if (aFormElements[j] !== undefined) {
							oControl = aFormElements[j].getFields()[0];
							if ((oControl.getMetadata().getName() === "sap.m.Select") || (oControl.getMetadata().getName() === "sap.m.Input")) {

								if (oControl.getMetadata().getName() === "sap.m.Select") {
									oControlValue = oControl.getSelectedKey();
								} else if (oControl.getMetadata().getName() === "sap.m.Input") {
									oControlValue = oControl.getValue();
									bIsNaN = isNaN(parseInt(oControlValue, 10));
								}
								//if some value is entered, check control's value state and perform range rule validation
								if ((oControlValue !== "") && (oControlValue !== undefined)) {
									/* if control value state is error, return false
									   else if range rule validation fails, return false*/
									if (oControl.getValueState() === ValueState.Error) {
										this._setFirstErrorStateControl(oControl);
										bValidForm = false;
										// Not required as Fopt field is not applicable here. 	

										// } else if (!this._isValidRangeRule(oFormContainerData[j], oControl)) {
										// 	this._setFirstErrorStateControl(oControl);
										// 	bValidForm = false;
									}
								} else if (oControl.getValueState() === ValueState.Error && !bIsNaN) {
									this._setFirstErrorStateControl(oControl);
									bValidForm = false;
								}
							}
						}
					}
				}
				return bValidForm;
			},

			/**
			 * If there is only one form container, return the index of that form container in an array, else,
			 * find the form containers having atleast one field in corresponding form elements filled with some value
			 * or if BusKey has some value, i.e. corresponding measurement document was already created
			 * @param	{sap.ui.layout.form.FormContainers[]}	aFormContainer	Array of form containers to search for filled field value
			 * @return	{array} 								Returns an array of indexes of form container having atleast one field filled
			 */
			_getDataFormContainerIndexes: function (aFormContainer) {
				var i,
					bHasData,
					/*iFormElementLen,*/
					oFormContainerData,
					len = aFormContainer.length,
					aFormIndexes = [];
				if (len === 1) {
					aFormIndexes.push(0);
					return aFormIndexes;
				} else {
					for (i = 0; i < len; i++) {
						//get the reference of data object bound to the form container
						oFormContainerData = aFormContainer[i].getModel().getProperty("/");
						bHasData = oFormContainerData.some(function (obj) {
							return obj.Fnumvalue !== "";
						});
						if (bHasData) {
							aFormIndexes.push(i);
						}
					}
					return aFormIndexes;
				}
			},
			/**
			 * If there is only one form container, return the index of that form container in an array, else,
			 * find the form containers having atleast one field in corresponding form elements  with some value
			 * or if BusKey has some value, i.e. corresponding measurement document was already created
			 * @param	{sap.ui.layout.form.FormContainers[]}	aFormContainer	Array of form containers to get all field value
			 * @return	{array} 								Returns an array of indexes of form container having all fields 
			 */
			_getAllFormContainerIndexes: function (aFormContainer) {
				var i,
					len = aFormContainer.length,
					aFormIndexes = [];
				if (len === 1) {
					aFormIndexes.push(0);
					return aFormIndexes;
				} else {
					for (i = 0; i < len; i++) {
						aFormIndexes.push(i);
					}
					return aFormIndexes;
				}
			},

			/**
			 * Find the form containers with all blank fields in corresonding form elements
			 * This is calculated by removing the indexes of form container with data from total indexes of form containers
			 * @param	{sap.ui.layout.form.FormContainers[]} aFormContainer Array of form containers to search for filled field value
			 * @param	{array} aDataFormContainerIndexes Array of indexes of form containers with data
			 * @return	{array} Returns an array of indexes of form container with all blank fields
			 */
			_getBlankFormContainerIndexes: function (aFormContainer, aDataFormContainerIndexes) {
				var i,
					aBlankIndexes = [],
					len = aFormContainer.length;
				for (i = 0; i < len; i++) {
					/* check if current index is part of indexes of form container with data,
					   if not, add it to the indexes of blank form containers */
					if (aDataFormContainerIndexes.indexOf(i) < 0) {
						aBlankIndexes.push(i);
					}
				}
				return aBlankIndexes;
			},

			/**
			 * Perform mandatory field validation for all the fields marked as Required in the given form
			 * In case of Well Reading i.e. this.sNetObjTypeCode === "GHO_WELL", perform validation for all form containers
			 * In other cases i.e. Measurement, perform validation of form containers with indexes returned by _getDataFormContainerIndexes
			 * @param  {sap.ui.layout.form.Form} oForm Reference of form for which validation needs to be done
			 * @return {boolean} Returns true if there is no mandatory field violation else false
			 */
			_validateMandatoryFields: function (oForm) {
				var i,
					j,
					len,
					index,
					oControl,
					oControlValue,
					oMessageProcessor,
					aFormElements,
					iFormElementLen,
					aBlankContIndexes,
					oFormContainerData,
					aDataContIndexes = [],
					bValidForm = true,
					aFormContainer = oForm.getFormContainers(),
					oBundle = this.getResourceBundle(),
					sTarget,
					sTargetField;
				bValidForm = this._validatePRAFields();
				//check if the validation is for Well Reading ,then add indexes of all form containers to aDataContIndexes
				if (this.sNetObjTypeCode === "GHO_WELL") {
					len = aFormContainer.length;
					for (i = len - 1; i >= 0; i--) {
						aDataContIndexes.push(i);
					}
				} else { //if not well reading, get the indexes of form containers with some data or generated business key
					aDataContIndexes = this._getDataFormContainerIndexes(aFormContainer);
				}
				len = aDataContIndexes.length;
				for (i = 0; i < len; i++) {
					index = aDataContIndexes[i];
					oFormContainerData = aFormContainer[index].getModel().getProperty("/");
					aFormElements = aFormContainer[index].getFormElements();
					iFormElementLen = oFormContainerData.length;
					for (j = 0; j < iFormElementLen; j++) {
						oControl = aFormElements[j].getFields()[0];
						oMessageProcessor = oControl.getModel();
						if (oControl.getMetadata().getName() === "sap.m.Select") {
							sTargetField = oControl.getBindingPath("selectedKey");
							oControlValue = oControl.getSelectedKey();
						} else {
							sTargetField = oControl.getBindingPath("value");
							oControlValue = oControl.getValue();
						}
						sTarget = oControl.getBindingContext().sPath + "/" + sTargetField;

						//check if current field/characteristic is marked as required and if it has blank value.
						if (oFormContainerData[j].Fmode === "R" && oControlValue === "") {
							this._addMessage(sTarget, oBundle.getText("MEAS_MESSAGE_FIELDS_MISSING"), oBundle.getText("MEAS_MESSAGE_FIELDS_MISSING"),
								MessageType.Error, oMessageProcessor);
							oControl.setValueState(ValueState.Error)
								.setValueStateText(oBundle.getText("COMM_INVALID_VALUE"));
							this._setFirstErrorStateControl(oControl);
							bValidForm = false;
						} else if (oControl.getValueState() === ValueState.Error) {
							bValidForm = false;
						} else {
							//oControl.setValueState(ValueState.None);
							this._removeMessage(sTarget, oMessageProcessor);
						}
					}
				}
				//get the indexes of form containers with all blank fields
				aBlankContIndexes = this._getBlankFormContainerIndexes(aFormContainer, aDataContIndexes);
				for (i = 0; i < aBlankContIndexes.length; i++) {
					index = aBlankContIndexes[i];
					oFormContainerData = aFormContainer[index].getModel().getProperty("/");
					//oFormContainerData = oFormContainersData;
					aFormElements = aFormContainer[index].getFormElements();
					iFormElementLen = oFormContainerData.length;
					//set value state to None of all fields of current form container
					for (j = 0; j < iFormElementLen; j++) {
						oControl = aFormElements[j].getFields()[0];
						oMessageProcessor = oControl.getModel();
						if (oControl.getMetadata().getName() === "sap.m.Select") {
							sTargetField = oControl.getBindingPath("selectedKey");
							oControlValue = oControl.getSelectedKey();
						} else {
							sTargetField = oControl.getBindingPath("value");
							oControlValue = oControl.getValue();
						}
						sTarget = oControl.getBindingContext().sPath + "/" + sTargetField;
						if (oFormContainerData[j].Fmode === "R" && oControlValue === "") {
							this._addMessage(sTarget, oBundle.getText("MEAS_MESSAGE_FIELDS_MISSING"), oBundle.getText("MEAS_MESSAGE_FIELDS_MISSING"),
								MessageType.Error, oMessageProcessor);
							oControl.setValueState(ValueState.Error)
								.setValueStateText(oBundle.getText("MEAS_MESSAGE_FIELDS_MISSING"));
							this._setFirstErrorStateControl(oControl);
							bValidForm = false;
						} else {
							oControl.setValueState(ValueState.None);
							this._removeMessage(sTarget, oMessageProcessor);
						}
					}
				}
				return bValidForm;
			},
			/**
			 * Function to validate PRA fields
			 * @returns	{Boolean}	true/false Weather Valid PRA field Data or Not
			 */
			_validatePRAFields: function () {
				var bIsPRAfieldsValid = true,
					oStartupParamsData = this.getView().getModel("StartupParameters").getData();
				//If Measurement Date is visible than valid or not
				if (oStartupParamsData.IsMesDateFieldVisible && !this._isMesDateTimeValid()) {
					bIsPRAfieldsValid = false;
				}
				//To Production Network, To Network Object Type & To Network Object Should be Selected
				if (oStartupParamsData.IsDetailToInfoVisible) {
					if (!this.checkMultiInputValidaity(this.getToProdNetworkInputField())) { //To Production Network
						bIsPRAfieldsValid = false;
					}
					if (!this.checkMultiInputValidaity(this.getToNetobjTyDesInputField())) { //To Network Object Type
						bIsPRAfieldsValid = false;
					}
					if (!this.checkMultiInputValidaity(this.getToNetworkObjInputField())) { //To Network Object
						bIsPRAfieldsValid = false;
					}
					if (!this._isToInfoValid()) {
						bIsPRAfieldsValid = false;
					}
				}
				/*//Originating MP Should Be Selected, if visible for Well Completion Volumes
				if (oStartupParamsData.IsOrigMPVisible) {
					if (!this.checkMultiInputValidaity(this.getOrigMpInputField())) { //Originating MP
						bIsPRAfieldsValid = false;
					}
				}*/
				//Transporter Should be Selected
				if (oStartupParamsData.IsTransDetailReq) {
					if (!this.checkMultiInputValidaity(this.getTransporterInputField())) {
						bIsPRAfieldsValid = false;
					}

					bIsPRAfieldsValid = this._isTransRefValid() ? bIsPRAfieldsValid : false;
				}
				return bIsPRAfieldsValid;
			},
			/**
			 * Function to check the validity of To Production Network and Network Object Type
			 * @returns	{Boolean}	true/false
			 */
			_isToInfoValid: function () {
				var bIsToInfoValid = true,
					oStartupParamsData = this.getView().getModel("StartupParameters").getData(),
					oDynamicModel = this.getView().getModel("DynamicModel"),
					oToProdNetInputObj = this.getToProdNetworkInputField(),
					oToProdNetVal = this.getMultiInputSelTokenValue(oToProdNetInputObj),
					oToNetObjInputObj = this.getToNetworkObjInputField(),
					sErrMsg1 = this.getResourceBundle().getText("FROM_TO_CANNOT_SAME_VALUE_STATE_TEXT"),
					sErrMsg2 = this.getResourceBundle().getText("TO_PROD_NETWORK_VALUE_STATE_TEXT");
				if (oStartupParamsData.IsDetailToInfoVisible) { //Check Only When To Prod Network is selected
					if (this.sQtyCategory === "08" && oToProdNetVal && oToProdNetVal === this.oInputVar.ProdNetwork &&
						this.getMultiInputSelTokenValue(oToNetObjInputObj) === this.oInputVar.NetObj
					) {
						oToProdNetInputObj.setValueState(ValueState.Error);
						oToProdNetInputObj.setValueStateText(sErrMsg1);
						this._addMessage(oToProdNetInputObj.getId(), sErrMsg1, sErrMsg1,
							MessageType.Error, oDynamicModel);
						this._setFirstErrorStateControl(oToProdNetInputObj);
						bIsToInfoValid = false;
					} else {
						oToProdNetInputObj.setValueStateText(sErrMsg2);
						if (oToProdNetVal) {
							oToProdNetInputObj.setValueState(ValueState.None);
							if (oDynamicModel) {
								this.removeMessage(oToProdNetInputObj.getId(), oDynamicModel);
								this.showMessages();
							}
						}
					}
				}
				return bIsToInfoValid;
			},
			/**
			 * Function to check the MultiInput Fields Validaity, weather have valid Tokens Selected Or Not
			 * @param	{Object}	oSrcObj	MultiInput Source Object
			 * @returns	{Boolean}	true/false weather MultiInput selection is correct or not
			 */
			checkMultiInputValidaity: function (oSrcObj) {
				var bIsMInputValid = true,
					oDynamicModel = this.getView().getModel("DynamicModel");
				if (oSrcObj && oSrcObj.getTokens) {
					if (oSrcObj.getTokens().length <= 0) {
						oSrcObj.setValueState(ValueState.Error);
						this._addMessage(oSrcObj.getId(), oSrcObj.getValueStateText(), oSrcObj.getValueStateText(),
							MessageType.Error, oDynamicModel);
						this._setFirstErrorStateControl(oSrcObj);
						bIsMInputValid = false;
					} else {
						oSrcObj.setValueState(ValueState.None);
						this.removeMessage(oSrcObj.getId(), oDynamicModel);
					}
				}
				return bIsMInputValid;
			},
			/**
			 * Function to check the validity of Transporter Reference Field
			 * @param	{String}	sNewVal	New Input value for Transporter Reference
			 * @returns	{Boolean}	true/false weather Transporter Reference Field input is valid or not
			 */
			_isTransRefValid: function (sNewVal) {
				var oDynamicModel = this.getView().getModel("DynamicModel"),
					oDynamicModelData = oDynamicModel.getData(),
					oTansRef = this.getTransporterRefInputField(),
					bIsTransRefValid = true,
					sVal = sNewVal ? sNewVal : oDynamicModelData.TrnspRefNo;
				if (!sVal && oTansRef.getRequired()) {
					bIsTransRefValid = false;
					oTansRef.setValueState(ValueState.Error);
					this._addMessage(oTansRef.getId(), oTansRef.getValueStateText(), oTansRef.getValueStateText(),
						MessageType.Error, oDynamicModel);
				} else {
					oTansRef.setValueState(ValueState.None);
					this._removeMessage(oTansRef.getId(), oDynamicModel);
				}
				return bIsTransRefValid;
			},
			/**
			 * Validation function to validate the data entered by the user before passing it to the batch calls to save and update
			 * @return {Bolean}	true/false weather data enter by user is valid ot not
			 */
			fnCheckForValidity: function () {
				var aFormContainer,
					bValidErrorStateAndRange,
					bValidMandatoryFields,
					// Standard Gas Reading
					oStdForm,
					aStdFormContainer,
					bValidNoMandatoryFields = true,
					oForm = this.byId("idlistboxes"),
					oBundle = this.getResourceBundle();
				aFormContainer = oForm.getFormContainers();
				if (aFormContainer.length > 0) {
					//validate the form for error state control and range rules
					bValidErrorStateAndRange = this._validateErrorStateAndRange(oForm);
					//perform mandatory field validations
					bValidMandatoryFields = this._validateMandatoryFields(oForm);
					if (bValidErrorStateAndRange && bValidMandatoryFields) {

						if (!(this._getBlankFormContainerIndexes(aFormContainer, this._getDataFormContainerIndexes(aFormContainer)).length ===
								aFormContainer.length)) {
							if (bValidNoMandatoryFields !== false) {
								bValidNoMandatoryFields = true;
							}
						} else {
							this._showError({
								messageKey: oBundle.getText("MEAS_MESSAGE_ENTER_DATA"),
								titleKey: oBundle.getText("MEAS_DATA_MISSING")
							}, false, {});
							if (bValidNoMandatoryFields === true) {
								bValidNoMandatoryFields = false;
							}
						}

					} else {
						if (bValidNoMandatoryFields === true) {
							bValidNoMandatoryFields = false;
						}

					}
				}

				//** Enhancment for the Standard Gas Reading ** // 
				oStdForm = this.byId("idstdlistboxes");
				oBundle = this.getResourceBundle();
				aStdFormContainer = oStdForm.getFormContainers();
				if (aStdFormContainer.length > 0) {
					//validate the form for error state control and range rules
					bValidErrorStateAndRange = this._stdvalidateErrorStateAndRange(oStdForm);
					bValidNoMandatoryFields = true;
					//perform mandatory field validations - Check Not required for Standard Gas Reading
					// bValidMandatoryFields = this._validateMandatoryFields(oStdForm);
					// if (bValidErrorStateAndRange && bValidMandatoryFields) {

					// 	if (!(this._getBlankFormContainerIndexes(aStdFormContainer, this._getDataFormContainerIndexes(aStdFormContainer)).length ===
					// 		aStdFormContainer.length)) {
					// 		if (bValidNoMandatoryFields !== false) {
					// 			bValidNoMandatoryFields = true;
					// 		}
					// 	} else {
					// 		this._showError({
					// 			messageKey: oBundle.getText("MEAS_MESSAGE_ENTER_DATA"),
					// 			titleKey: oBundle.getText("MEAS_DATA_MISSING")
					// 		}, false, {});
					// 		if (bValidNoMandatoryFields === true) {
					// 			bValidNoMandatoryFields = false;
					// 		}
					// 	}

					// } else {
					// 	if (bValidNoMandatoryFields === true) {
					// 		bValidNoMandatoryFields = false;
					// 	}

					// }
				}

				return bValidNoMandatoryFields;
			},

			/** 
			 * Approval Workflow comments to be entered by the user
			 * This comments will be stored in a separate table 
			 */
			fnHandleApprvComment: function (oResult) {
				if (!this.oAPPRCONDialog) {
					var sAPPRCONFragId = this.createId("APPRDialogFragment");
					this.oAPPRCONDialog = sap.ui.xmlfragment(sAPPRCONFragId, "oil.ups.fdcs1.UPS_FDCS1Extension1.fragments.apprComments", this);

				}
				this.byId(Fragment.createId("APPRDialogFragment", "apprConDescription")).setValue("");
				this.getView().addDependent(this.oAPPRCONDialog);
				this.oAPPRCONDialog.open();
			},

			/**
			 * Approval text submit button - Enable the submit button only if 
			 * the text is entered
			 */

			textAPPRCONDialog: function () {
				var apprComments = this.byId(Fragment.createId("APPRDialogFragment", "apprConDescription")).getValue();
				var oBtn = this.byId(Fragment.createId("APPRDialogFragment", "idapprComBeginBtn"));
				if (apprComments != "") {
					oBtn.setEnabled(true);
				} else {
					oBtn.setEnabled(false);
				}
			},

			/**
			 * Cancel the Approval dialog window
			 */

			cancelAPPRCONDialog: function (oEvent) {
				if (this.oAPPRCONDialog && this.oAPPRCONDialog.isOpen()) {
					this.oAPPRCONDialog.close();
				}
			},

			/**
			 * Confirm the Approval confirmation submit button action 
			 */
			confirmAPPRCONDailog: function () {
				this.oAPPRCONDialog.close();
				var apprComments = this.byId(Fragment.createId("APPRDialogFragment", "apprConDescription")).getValue();
				this.apprComments = "";
				if (apprComments != "") {
					if (this.sMode === "edit") {
						this.apprComments = apprComments;
						this.fnHandleSave();
					}
				}

			},

			/**
			 * Save module. Calls batch after data is validated, fills 0 for empty textfields. Goes back to Landing page if save/update is successful.
			 * If error comes for PPA it opens the corresponding popups and called again based on the requirement. It also adds extra batch call for
			 * Function Import depending upon the PPA Audit Status
			 * @param	{object}	oResult	User's choice when asked if he wants to update the record via a popup. Always true in create mode
			 */
			fnHandleSave: function (oResult) {
				var i,
					j,
					k,
					len,
					index,
					aDataSave = [],
					aFormContainer,
					aDataContIndexes = [],
					oForm,
					oODataModel = this.getModel(),
					oBatchSaveCallPromises = [],
					sSaveBatchGrp = "measurementDataSave",

					//** >> Standard Gas Reading RTEKI_C */
					oStdForm,
					oStdFormContainer,
					aDataStdContIndexes,
					stdlen;
				//** << Standard Gas Reading RTEKI_C */

				if (!oResult || oResult === MessageBox.Action.OK) {

					/*aDataContIndexes = this._getDataFormContainerIndexes(oForm.getFormContainers());
					len = aDataContIndexes.length;*/
					if (this.sEligibility === "05") {
						this._showPPARejectedError();
						return;
					}
					oODataModel.setDeferredGroups([sSaveBatchGrp]);
					if (this.sEligibility === "01" || this.sEligibility === "06") {
						oBatchSaveCallPromises.push(this._getPPAAuditBatchOperation(sSaveBatchGrp));
					}
					oForm = this.byId("idlistboxes");
					aFormContainer = oForm.getFormContainers();
					aDataContIndexes = this._getAllFormContainerIndexes(aFormContainer);
					len = aDataContIndexes.length;

					//** >> Standard Gas Reading RTEKI_C */
					oStdForm = this.byId("idstdlistboxes");
					oStdFormContainer = oStdForm.getFormContainers();
					aDataStdContIndexes = this._getAllFormContainerIndexes(oStdFormContainer);
					stdlen = aDataStdContIndexes.length;
					//** << Standard Gas Reading RTEKI_C */
					
					//** >> Map Appoval Comments   RTEKI_C */
					this.aData[0].zzcomment = this.apprComments; 
					//** << Map Appoval Comments  RTEKI_C */

					aDataSave = JSON.parse(JSON.stringify(this.aData));

					if (len > 0) {
						if (this.sEligibility === "01" || this.sEligibility === "06" || this.sEligibility === "03" || this.sEligibility === "02" ||
							this.sEligibility === "") {
							for (j = 0; j < aDataSave.length; j++) {
								aDataSave[j].FDCMeasurementRawSet = [];
								//** >> Standard Gas Reading RTEKI_C */
								aDataSave[j].FDCMeasurementStdQtySet = [];
								//** << Standard Gas Reading RTEKI_C */
								aDataSave[j].ChangedTst = this.aData[j].ChangedTst;
							}
							for (j = 0; j < aDataSave.length; j++) {
								for (i = 0; i < len; i++) {
									index = aDataContIndexes[i];
									var oMeasurementSaveExecuted = jQuery.Deferred(),
										oMesReadingSetDataObj;
									for (k = 0; k < aFormContainer[index].getModel().getProperty("/").length; k++) {
										oMesReadingSetDataObj = aFormContainer[index].getModel().getProperty("/")[k];
										if (aDataSave[j].AllocMat === oMesReadingSetDataObj.AllocMat) {
											delete oMesReadingSetDataObj.ErrorCount;
											aDataSave[j].FDCMeasurementRawSet.push(oMesReadingSetDataObj);
										} else {
											continue;
										}
									}
								}

								//** >> Standard Gas Reading RTEKI_C */
								
								var oStdMesReadingSetDataObj;
								if (oStdFormContainer.length > 0){
									for (k = 0; k < oStdFormContainer[0].getModel().getProperty("/").FDCMeasurementStdQtySet.length; k++) {
										oStdMesReadingSetDataObj = oStdFormContainer[index].getModel().getProperty("/").FDCMeasurementStdQtySet[k];
										if (oStdMesReadingSetDataObj !== undefined){
											if (aDataSave[j].AllocMat === oStdMesReadingSetDataObj.AllocMaterial) {
												delete oStdMesReadingSetDataObj.ErrorCount;
												aDataSave[j].FDCMeasurementStdQtySet.push(oStdMesReadingSetDataObj);
											} else {
												continue;
											}
										}
									}
								}
							//** << Standard Gas Reading RTEKI_C */

							aDataSave[j] = this.setPRAFields(aDataSave[j]);
							oODataModel.create("/FDCMeasurementReadingSet",
								aDataSave[j], {
									groupId: sSaveBatchGrp,
									success: oMeasurementSaveExecuted.resolve,
									error: oMeasurementSaveExecuted.reject
								});
							oBatchSaveCallPromises.push(oMeasurementSaveExecuted.promise());
						}
						oODataModel.setUseBatch(true);
						this._mesBusyDialog.open();
						oODataModel.submitChanges({
							groupId: sSaveBatchGrp
						});
						jQuery.when.apply(this, oBatchSaveCallPromises)
							.done(function () {
								this._onSuccessDataSave.apply(this, arguments);
							}.bind(this))
							.fail(function (oError) {
								this._onErrorDataSave.apply(this, arguments);
							}.bind(this));
					}
				}
			}
		},
		/**
		 * success handler of batch call during save for edit/create
		 * @param  {object} oData data received in OData response
		 * @param  {object} oResponse OData request response reference
		 */
		_onSuccessDataSave: function (oData, oResponse) {
			this._mesBusyDialog.close();
			jQuery.sap.delayedCall(1000, this, this._showSuccessToast, [this.sEligibility, this.sMode, this.sNetObjTypeCode]);
			this.navBack();
		},
		/**
		 * error handler of batch call during save for edit/create
		 * @param  {object} oError Error response object reference
		 */
		_onErrorDataSave: function (oError) {
			this._mesBusyDialog.close();
			try {
				this._handleBatchErrorOnSave(oError);
			} catch (cx) {
				jQuery.sap.log.fatal("onDataSave: Error response parse exception", JSON.stringify(cx), "Measurement.controller.js");
			}
		},

		/**
		 * handles various types of error that can occur while saving data for edit/create scenarios
		 * Delegates call to show appropriate error message depending upon error code
		 * @param  {object} oError Error response object reference
		 */
		_handleBatchErrorOnSave: function (oError) {
			var oErrorBody;
			if (oError.statusCode === "412") {
				this._showMeasurementLockedError();
			} else {
				try {
					oErrorBody = JSON.parse(oError.responseText);
					//check if errordetails exists or if errordetails is empty
					if (!oErrorBody.error.innererror.errordetails ||
						oErrorBody.error.innererror.errordetails.length <= 0) {
						MessageBox.error(oErrorBody.error.message.value);
					} else {
						this._processErrorCode(this.sMode, oErrorBody.error.innererror.errordetails[0]);
					}
				} catch (cx) {
					jQuery.sap.log.fatal("onDataSave: Batch error response parse exception", JSON.stringify(cx), "Measurement.controller.js");
				}
			}
		},

		/**
		 * shows success toast message depending upon the mode,
		 * i.e. create/edit/delete or if PPA was raised
		 * @param  {string} sEligibility PPA eligibility indicator
		 * @param  {string} sMode Mode of the screen
		 * @param  {string} sNetObjTypeCode Network Object Type Code
		 */
		_showSuccessToast: function (sEligibility, sMode, sNetObjTypeCode) {
			var sMessage,
				oBundle = this.oBundle;
			var allocated = this.getView().getModel("HeaderDetails").getData().zzapproved;
			if (sEligibility === "01") {
				sMessage = oBundle.getText("SUCCESSFUL_SUBMIT_PPA");
			} else {
				switch (sMode) {
				case "create":
					sMessage = sNetObjTypeCode !== "GHO_WELL" ? sNetObjTypeCode === "GHO_WC" ? oBundle.getText(
						"WCVMEAS_MESSAGE_ENTRIES_CREATED") : oBundle.getText("MEAS_MESSAGE_ENTRIES_CREATED") : oBundle.getText(
						"WRMEAS_MESSAGE_ENTRIES_CREATED");
					break;
				case "edit":
					if (allocated){
						sMessage = sNetObjTypeCode !== "GHO_WELL" ? sNetObjTypeCode === "GHO_WC" ? oBundle.getText(
							"WCVMEAS_MESSAGE_UPDATED") : oBundle.getText("MEAS_MESSAGE_UPDATED") : oBundle.getText("WRMEAS_MESSAGE_UPDATED");	
					}else{
					sMessage = sNetObjTypeCode !== "GHO_WELL" ? sNetObjTypeCode === "GHO_WC" ? oBundle.getText(
						// "WCVMEAS_MESSAGE_UPDATED") : oBundle.getText("MEAS_MESSAGE_UPDATED") : oBundle.getText("WRMEAS_MESSAGE_UPDATED");
						"WCVMEAS_MESSAGE_UPDATED") : oBundle.getText("MEAS_MESSAGE_UPDATED_WF") : oBundle.getText("WRMEAS_MESSAGE_UPDATED");
					}
						break;
				case "delete":
					sMessage = sNetObjTypeCode !== "GHO_WELL" ? sNetObjTypeCode === "GHO_WC" ? oBundle.getText(
						"WCVMEAS_MESSAGE_DELETED") : oBundle.getText("MEAS_MESSAGE_DELETED") : oBundle.getText("WRMEAS_MESSAGE_DELETED");
					break;
				}
			}
			MessageToast.show(sMessage);
		},

		/**
		 * shows PPA rejected error message
		 */
		_showPPARejectedError: function () {
			MessageBox.error(this.getResourceBundle().getText("MEAS_PPA_REJECTED"));
			/*this._showMessageBox({
				type: sap.ca.ui.message.Type.ERROR,
				message: this.oApplicationFacade
					.getResourceBundle().getText("MEAS_PPA_REJECTED")
			});*/
		},

		/**
		 * shows error message for measurement/well reading update failed
		 * due to already locked data
		 * @param  {function} fnCallBack function callback for OK click
		 */
		_showMeasurementLockedError: function (fnCallBack) {
			MessageBox.error(this.getResourceBundle().getText("MEAS_UPDATE_FAILED_LOCKED"), {
				onClose: fnCallBack
			});
		},

		/**
		 * create and return the batch operation for PPA function import
		 * @param	{String}	sBatchGrp	Batch Request Group String
		 * @return {jQuery.Deferred.promise} PPA function import batch operation object
		 */
		_getPPAAuditBatchOperation: function (sBatchGrp) {
			var mParams = {
					"ProcessType": "ACTQTY",
					"PpaAuditIndicator": this.sEligibility,
					"AuditReasonCode": this.sAuditReasonCode,
					"PpaReqReason": this.sPPAReason
				},
				oPPAFuncExecuted = jQuery.Deferred();
			this.getView().getModel().callFunction("/set_ppa_audit_for_meas", {
				"method": "POST",
				"urlParameters": mParams,
				groupId: sBatchGrp,
				success: oPPAFuncExecuted.resolve,
				error: oPPAFuncExecuted.reject
			});
			return oPPAFuncExecuted.promise();
		},

		/**
		 * Process the error code received from backend
		 * to show PPA/Audit dialog or error messages
		 * and set this.sEligibility flag
		 * @param  {string} sMode current mode of the screen i.e. edit/create/delete
		 * @param  {object} oErrorDetail Errordetail object reference
		 */
		_processErrorCode: function (sMode, oErrorDetail) {
			var oResourceBundle = this.getResourceBundle(),
				sTitle = this.sNetObjTypeCode === "GHO_WC" ? oResourceBundle.getText("WELL_COMP_VOL_ERROR") : oResourceBundle.getText("MEAS_ERROR");
			switch (oErrorDetail.code) {
			case "GHO_FDC_UI/010":
				this.sEligibility = "01";
				this.openPPADialog();
				break;
			case "GHO_FDC_UI/011":
				this.sEligibility = "06";
				this.openAuditDialog();
				break;
			case "GHO_FDC_UI/013":
				this.sEligibility = "05";
				this._showPPARejectedError();
				break;
			case "GHO_FDC_UI/012":
				this.sEligibility = "03";
				MessageBox.error(this.getResourceBundle().getText("MEAS_PPA_PENDING"), {
					onClose: this._focusFirstErrorStateControl.bind(this)
				});
				break;
			default:
				if (sMode === "delete") {
					this.sMode = "display";
				}
				this.showError(sTitle, oErrorDetail.message, false);
				this.removeAllMessages();
			}
		},

		/**
		 * Delete module. Calls batch to Delete the record. Goes back to Landing page if delete is successful
		 * If error comes for PPA it opens the corresponding popups and called again based on the requirement. It also adds extra batch call for
		 * Function Import depending upon the PPA Audit Status
		 * @param {object} oResult User's choice when asked if he wants to delete the record via a popup.
		 */
		fnHandleDelete: function (oResult) {
			var i,
				len,
				iIndex,
				oODataModel = this.getModel(),
				oBatchDelCallPromises = [],
				oFDCMesRadingDelExecuted,
				sDelBatchGrp = "FDCMesReadingDeletion";
			if (!oResult || oResult === MessageBox.Action.OK) {
				this.sMode = "delete";
				this.bDeleteFlag = true;
				if (this.sEligibility === "05") {
					this._showPPARejectedError();
					return;
				}
				oODataModel.setDeferredGroups(["FDCMesReadingDeletion"]);
				if (this.sEligibility === "01" || this.sEligibility === "06") {
					oBatchDelCallPromises.push(this._getPPAAuditBatchOperation(sDelBatchGrp));
				}
				if (this.sEligibility === "01" || this.sEligibility === "06" || this.sEligibility === "03" || this.sEligibility === "") {
					// len = this.aData.length;
					len = this.aDeleteIndex.length;
					for (i = 0; i < len; i++) {
						iIndex = this.aDeleteIndex[i];
						oFDCMesRadingDelExecuted = jQuery.Deferred();
						oODataModel.remove(jQuery.sap.formatMessage("{0}{1}", "/", this.aMetadata[iIndex]), {
							groupId: sDelBatchGrp,
							eTag: this.aEtags[iIndex],
							success: oFDCMesRadingDelExecuted.resolve,
							error: oFDCMesRadingDelExecuted.reject
						});
						oBatchDelCallPromises.push(oFDCMesRadingDelExecuted.promise());
					}
					oODataModel.setUseBatch(true);
					this._mesBusyDialog.open();
					oODataModel.submitChanges({
						groupId: sDelBatchGrp,
						error: this._onErrorDataDelete.bind(this)
					});
					jQuery.when.apply(this, oBatchDelCallPromises)
						.done(function () {
							this._onSuccessDataDelete.apply(this, arguments);
						}.bind(this))
						.fail(function (oError) {
							this._onErrorDataDelete.apply(this, arguments);
						}.bind(this));
				}
			}
		},

		/**
		 * success handler of batch call during delete
		 * @param  {object} oData data received in OData response
		 * @param  {object} oResponse OData request response reference
		 */
		_onSuccessDataDelete: function (oData, oResponse) {
			this._mesBusyDialog.close();
			jQuery.sap.delayedCall(1000, this, this._showSuccessToast, [this.sEligibility, this.sMode, this.sNetObjTypeCode]);
			this.navBack();
		},

		/**
		 * error handler of batch call during delete
		 * @param  {object} oError Error response object reference
		 */
		_onErrorDataDelete: function (oError) {
			var oErrorBody;
			this._mesBusyDialog.close();
			try {
				oErrorBody = JSON.parse(oError.responseText);
				jQuery.sap.log.error("Error occured while Measurment/Well Reading delete", oError.responseText, "Measurement.controller.js");
				switch (oErrorBody.error.code) {
				case "GHO_FDC_UI/010":
					this.sEligibility = "01";
					this.openPPADialog();
					break;
				case "GHO_FDC_UI/011":
					this.sEligibility = "06";
					this.openAuditDialog();
					break;
				case "GHO_FDC_UI/013":
					this.sEligibility = "05";
					this._showPPARejectedError();
					break;
				case "GHO_FDC_UI/012":
					this.sEligibility = "03";
					this._showError({
						messageKey: this.getResourceBundle().getText("MEAS_PPA_PENDING"),
						titleKey: this.getResourceBundle().getText("PPA_PENDING")
					}, false, {}, this._focusFirstErrorStateControl.bind(this));
					break;
				default:
					this.bDataChanged = false;
					this.fnReadMeasurementData();
					var oMsg = {
						messageKey: oErrorBody.error.innererror.errordetails[0].message,
						titleKey: this.getResourceBundle().getText("AUTHORITY_CHECK")
					};
					this._showError(oMsg, false, {});
				}
			} catch (cx) {
				jQuery.sap.log.fatal("onDataDelete: Error response parse exception", JSON.stringify(cx), "Measurement.controller.js");
			}
		},

		/**
		 * handles various types of error that can occur while deleting data
		 * Delegates call to show appropriate error message depending upon error code
		 * @param  {object} oError Error response object reference
		 */
		_handleBatchErrorOnDelete: function (oError) {
			var oErrorBody;
			if (oError.statusCode === "412") {
				this._showMeasurementLockedError(this._onOKMeasurementLockedError.bind(this));
			} else {
				try {
					oErrorBody = JSON.parse(oError.responseText);
					if (!oErrorBody.error.innererror.errordetails ||
						oErrorBody.error.innererror.errordetails.length <= 0) {
						this.sMode = "display";
						this._showError({
							messageKey: oErrorBody.error.message.value,
							titleKey: this.getResourceBundle().getText("BATCH_FAILED")
						}, false, {});
					} else {
						this._processErrorCode(this.sMode,
							oErrorBody.error.innererror.errordetails[0]);
					}
				} catch (cx) {
					jQuery.sap.log.fatal("onDataDelete: Batch error response parse exception", JSON.stringify(cx), "Measurement.controller.js");
				}
			}
		},

		/**
		 * callback function for Measurement locked error message during delete operation
		 */
		_onOKMeasurementLockedError: function () {
			this.sMode = "display";
			this.bDataChanged = false;
			this.fnReadMeasurementData();
		},

		/**
		 * Presents a warning popup when the user tries to delete data
		 *
		 */
		fnShowPopupToConfirmDelete: function () {
			MessageBox.confirm(this.oBundle.getText("MESSAGE_CONFIRM_ON_DELETE"), {
				title: this.oBundle.getText("MEAS_DELETE_HEADING"),
				onClose: this.fnHandleDelete.bind(this)
			});
		},

		/**
		 * Create a Query string based on filters for Batch Calls
		 * @param {string} path The EntitySet Name
		 * @param {array} filterarray The Array of filters
		 * @return {string} str Query string formed based on filters
		 */
		fnFormFilterString: function (path, filterarray) {
			var str = filterarray.map(function (key) {
				return jQuery.sap.formatMessage("{0} {1} ''{2}''", [key.sPath, key.sOperator === "EQ" ? "eq" : key.sOperator, key.oValue1]);
			}).join(" and ");
			var query = encodeURI(jQuery.sap.formatMessage("/{0}?$filter={1}", [path, str]));
			while (query.indexOf("'") !== -1) {
				query = query.replace("'", "%27");
			}
			return query;
		},

		/**
		 * Create a Query string based on object for Batch Calls Function Import
		 * @param {string} sPath The Function Import Name
		 * @param {object} oObj Object whose keys and their values are supposed to be part of query string
		 * @return {string} str Query string formed based on Object/Path passed
		 */
		fnFormFunctionQueryString: function (sPath, oObj) {
			var str = "";
			var attr = "";
			for (attr in oObj) {
				if (attr) {
					str = jQuery.sap.formatMessage("{0}{1}{2}{3}''{4}''", [str, "&", attr, "=", oObj[attr]]);
				}
			}
			return jQuery.sap.formatMessage("{0}{1}{2}", [sPath, "?", str.substring(1, str.length)]);
		},

		/**
		 * Parse a date string to JS Date Object; parse based on the dateTimeFormat in the configuration object
		 * @param {String} sDate  Date value in string format
		 * @return {Object} dDate Equivalent Date Object. Expected that string will always be in this pattern and not null/blank
		 */
		fnConvertStringToDate: function (sDate) {
			var dDate;
			if (sDate && sDate !== "") {
				dDate = DateFormat.getDateTimeInstance({
					pattern: "yyyyMMddHHmmss"
				}).parse(sDate);
			} else {
				dDate = null;
			}
			return dDate;
		},

		/**
		 * Format a JS Date Object to string, based on the dateTimeFormat in the configuration object
		 * @param {Object} dDate JS-date object to be converted to string format expected in the backend
		 * @return {String} sDate dateValueString	Equivalent date string. Expected that date object is valid and not null
		 */
		fnConvertDateToString: function (dDate) {
			var sDate;
			if (dDate && dDate !== null) {
				sDate = DateFormat.getDateTimeInstance({
					pattern: "yyyyMMddHHmmss"
				}).format(dDate);
			} else {
				sDate = "";
			}
			return sDate;
		},
		/**
		 * This method is executed for opening an Audit popup
		 * @param {object} oEvent event when audit value help pressed in PPA dialog
		 * @param {boolean} bAuditCalled audit reason code read called
		 * @param {object} oAuditCodeData Audit reason codes data from backend
		 */
		openAuditDialog: function (oEvent, bAuditCalled, oAuditCodeData) {
			var aAuditCodeCallPromises = [],
				sAuditCodeGrpId = "AuditCodeCall",
				oModel = this.getModel(),
				oAuditCodes = new JSONModel({
					AuditCodeSet: this.aAuditReasonCodes
				});
			if (oEvent) {
				var oAuditInput = this.byId(Fragment.createId("PPADialogFragment", "reasonCodeInput"));
				this.sAudInput = oAuditInput.getValue();
				oAuditInput.setValue("");
			}
			this.isAudit = true;
			this.getView().setModel(oAuditCodes, "AuditCodes");
			if (!this._oAuditDialog) {
				var sFragId = this.createId("staticFragId");
				this._oAuditDialog = sap.ui.xmlfragment(sFragId, "oil.ups.fdcs1.fragments.Auditcodes", this);
				this.getView().addDependent(this._oAuditDialog);
				this._oAuditDialog.setModel(this.getView().getModel("AuditCodes"));
			}
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oAuditDialog);
			if (this.aAuditReasonCodes && this.aAuditReasonCodes.length > 0) {
				this.getView().getModel("AuditCodes").setProperty("/AuditCodeSet", this.aAuditReasonCodes);
				this._oAuditDialog.open();
			} else if (bAuditCalled && bAuditCalled === true && oAuditCodeData) {
				this.aAuditReasonCodes = oAuditCodeData.results;
				this.getView().getModel("AuditCodes").setProperty("/AuditCodeSet", this.aAuditReasonCodes);
				this._oAuditDialog.open();
			} else {
				oModel.setDeferredGroups([sAuditCodeGrpId]);
				aAuditCodeCallPromises.push(this._readAuditReasonCodes());
				oModel.setUseBatch(true);
				oModel.submitChanges({
					groupId: sAuditCodeGrpId
				});
				jQuery.when.apply(this, aAuditCodeCallPromises)
					.done(function (oData) {
						this._mesBusyDialog.close();
						this.openAuditDialog.apply(this, [null, true, oData]);
					}.bind(this))
					.fail(function (oError) {
						this._mesBusyDialog.close();
						this.showErrorMessage.apply(this, arguments);
					}.bind(this));
			}
		},

		/**
		 * This method is executed for opening an PPA popup
		 * @param {object} oEvent value help event
		 * @param {boolean} bAuditCalled check for audit reason code read call
		 * @param {object} oAuditCodeData Audit reason codes data from backend
		 */
		openPPADialog: function (oEvent, bAuditCalled, oAuditCodeData) {
			var oAuditInput, oBtn, oDefAuditCode, oAuditCodes,
				aAuditCodeCallPromises = [],
				sAuditCodeGrpId = "AuditCodeCall",
				oModel = this.getModel();

			if (bAuditCalled && bAuditCalled === true && oAuditCodeData) {
				this.aAuditReasonCodes = oAuditCodeData.results;
				oAuditCodes = new JSONModel({
					AuditCodeSet: this.aAuditReasonCodes
				});
				this.getView().setModel(oAuditCodes, "AuditCodes");
				this.isAudit = false;
				if (!this.oPPADialog) {
					var sPPAFragId = this.createId("PPADialogFragment");
					this.oPPADialog = sap.ui.xmlfragment(sPPAFragId, "oil.ups.fdcs1.fragments.PPADialog", this);
				}
				this.getView().addDependent(this.oPPADialog);
				this.oPPADialog.setModel(this.getView().getModel("AuditCodes"));
				oDefAuditCode = this._getAuditReasonCode(this.aAuditReasonCodes, true);
				this.oPPADialog.open();
				oBtn = this.byId(Fragment.createId("PPADialogFragment", "idPPABeginBtn"));
				oAuditInput = this.byId(Fragment.createId("PPADialogFragment", "reasonCodeInput"));
				oAuditInput.setValueState("None").setValueStateText("");
				if (oDefAuditCode !== undefined) {
					oAuditInput.setValue(oDefAuditCode.AuditReasonCodes);
					oBtn.setEnabled(true);
				} else {
					oAuditInput.setValue("");
					oBtn.setEnabled(false);
				}
				this.byId(Fragment.createId("PPADialogFragment", "ppaDescription")).setValue("");
			} else {
				oModel.setDeferredGroups([sAuditCodeGrpId]);
				aAuditCodeCallPromises.push(this._readAuditReasonCodes());
				oModel.setUseBatch(true);
				oModel.submitChanges({
					groupId: sAuditCodeGrpId
				});
				jQuery.when.apply(this, aAuditCodeCallPromises)
					.done(function (oData) {
						this._mesBusyDialog.close();
						this.openPPADialog.apply(this, [null, true, oData]);
					}.bind(this))
					.fail(function (oError) {
						this._mesBusyDialog.close();
						this.showErrorMessage.apply(this, arguments);
					}.bind(this));
			}
		},

		/**
		 * This method do odata read call to get all the audit reason codes
		 * @param {string} sAuditCodeGrpId groupId for the batch call
		 * @return {object} batch call promise object
		 */
		_readAuditReasonCodes: function (sAuditCodeGrpId) {
			var oNetIdFilter, mParameter,
				oModel = this.getModel(),
				oAuditCodeDeferred = jQuery.Deferred();
			oNetIdFilter = new Filter("NetId", FilterOperator.EQ, this.oInputVar.NetObj);
			mParameter = {
				groupId: sAuditCodeGrpId,
				filters: [oNetIdFilter],
				sorters: null,
				success: oAuditCodeDeferred.resolve,
				error: oAuditCodeDeferred.reject
			};
			this._mesBusyDialog.open();
			oModel.read("/AuditReasonCodeSet", mParameter);
			return oAuditCodeDeferred.promise();
		},

		/**
		 * This method is called when value in PPA Reason Code input
		 * changes to enable disable ok button in PPA popover
		 * @method onPPAReasonChange
		 * @param {Object} oEvent Event object
		 */
		onPPAReasonChange: function (oEvent) {
			var oValidAuditCode,
				sAuditReasonInput = oEvent.getSource().getValue(),
				sAuditReasonCode = sAuditReasonInput.toUpperCase(),
				oInput = oEvent.getSource();
			oInput.setValue(sAuditReasonCode);
			if (sAuditReasonCode !== "") {
				oValidAuditCode = this._getAuditReasonCode(this.aAuditReasonCodes, false, sAuditReasonCode);
				if (oValidAuditCode !== undefined) {
					oInput.setValueState("None");
					oInput.setValueStateText("");
					oInput.getParent().getBeginButton().setEnabled(true);
				} else {
					oInput.setValueState("Error");
					oInput.setValueStateText(this._oResourceBundle.getText("INVALID_AUD_CODE"));
					oInput.getParent().getBeginButton().setEnabled(false);
				}
			} else {
				oInput.setValueState("None");
				oInput.setValueStateText("");
				oInput.getParent().getBeginButton().setEnabled(false);
			}
		},

		/**
		 * Event Handler for the confirm event of the Value Help Audit Dialog. Updates value in the PPA dialog
		 */
		confirmPPADailog: function () {
			this.oPPADialog.close();
			this.sAuditReasonCode = this.oPPADialog.getContent()[1].getValue();
			this.sPPAReason = this.oPPADialog.getContent()[2].getValue();
			//this.oPPADialog = null;
			if (this.sMode === "delete") {
				this.fnHandleDelete();
			} else if (this.sMode === "edit" || this.sMode === "create") {
				this.fnHandleSave();
			}
			this.clearPPADialg();
		},

		/**
		 * This method is used to clear all the fields in the PPA Dialog each time it is closed
		 */
		clearPPADialg: function () {
			var oPPAInpt = this.byId(Fragment.createId("PPADialogFragment", "reasonCodeInput"));
			var oPPATxt = this.byId(Fragment.createId("PPADialogFragment", "ppaDescription"));
			oPPAInpt.setValue("");
			oPPATxt.setValue("");
		},

		/**
		 * Event Handler for the confirm event of the Value Help Audit Dialog. Updates value in the PPA dialog
		 */
		confirmAuditDialog: function () {
			var oSlctdItm,
				oAuditTble = this.byId(Fragment.createId("staticFragId", "tableAuditCode")),
				oAuditCodeSearch = this.byId(Fragment.createId("staticFragId", "idAuditCodeSearch"));
			oAuditCodeSearch.setValue("");
			if (this.sEligibility === "01") {
				oSlctdItm = oAuditTble.getSelectedItem();
				if (oSlctdItm) {
					var sDesc = oSlctdItm.getBindingContext("AuditCodes").getProperty("AuditReasonCodes");
					this.oPPADialog.getContent()[1].setValue(sDesc);
					this.oPPADialog.getContent()[1].setValueState("None").setValueStateText("");
					this.oPPADialog.getBeginButton().setEnabled(true);
				}
				this._oAuditDialog.close();
			} else if (this.sEligibility === "06") {
				oSlctdItm = oAuditTble.getSelectedItem();
				if (oSlctdItm) {
					this.sAuditReasonCode = oSlctdItm.getBindingContext("AuditCodes").getProperty("AuditReasonCodes");
				}
				if (this.sMode === "delete" || (this.sMode === "display" && this.bDeleteFlag === true)) {
					this.fnHandleDelete();
				} else if (this.sMode === "edit" || this.sMode === "create") {
					this.fnHandleSave();
				}
				this._oAuditDialog.close();
				this._oAuditDialog.destroy();
				this._oAuditDialog = null;
			}
		},

		/**
		 * Event Handler for the close event of the Value Help Audit Dialog
		 */
		cancelAuditDialog: function () {
			var oAuditCodeSearch = this.byId(Fragment.createId("staticFragId", "idAuditCodeSearch"));
			oAuditCodeSearch.setValue("");
			if (this.sAudInput) {
				this.byId(Fragment.createId("PPADialogFragment", "reasonCodeInput")).setValue(this.sAudInput);
			}
			if (this.sEligibility === "01") {
				this._oAuditDialog.close();
			} else if (this.sEligibility === "06") {
				this.sAuditReasonCode = "";
				this.sPPAReason = "";
				this.sEligibility = "";
				this._oAuditDialog.close();
			}
		},

		/**
		 * Event Handler for the cancel event of the PPA Dialog
		 */
		cancelPPADialog: function () {
			this.sAuditReasonCode = "";
			this.sPPAReason = "";
			this.sEligibility = "";
			this.oPPADialog.close();
			this.oPPADialog.getContent()[1].setValue("");
			this.oPPADialog.getContent()[2].setValue("");
			this.removeAllMessages();
		},

		/**
		 * Event Handler if the selection in the Audit Reason Code popup table has been changed.
		 * It enables the OK button if we have first item selected.
		 * @param {sap.ui.base.Event} oEvent Object containing the information about the event fired
		 */
		auditTabSelectionChange: function (oEvent) {
			var oBeginBtn = oEvent.getSource().getParent().getBeginButton();
			if (oEvent.getParameters().selected && oBeginBtn) {
				oBeginBtn.setEnabled(true);
			} else {
				oBeginBtn.setEnabled(false);
			}
		},

		/**
		 * This function is to perform search on list of Audit Reason codes in the value help
		 * @param {object} oEvent event object for the reason code search operation
		 */
		onAuditCodeSearch: function (oEvent) {
			var aFilters = [];
			var sAuditSearch = oEvent.getSource().getValue();
			if (sAuditSearch && sAuditSearch.length > 0) {
				var filter = new Filter("AuditReasonCodes", sap.ui.model.FilterOperator.Contains, sAuditSearch);
				aFilters.push(filter);
			}
			var oAuditTable = this.byId(Fragment.createId("staticFragId", "tableAuditCode"));
			var binding = oAuditTable.getBinding("items");
			binding.filter(aFilters, "Application");
		},

		/**
		 * This function is to check for default or valid audit reason code
		 * @param {array} aAuditReasonCodes array of audit reason codes
		 * @param {boolean} bDefault flag to indicate method called for default arc
		 * @param {string} sArc Audit reason code user input value
		 * @return {object} Audit reason code
		 */
		_getAuditReasonCode: function (aAuditReasonCodes, bDefault, sArc) {
			var i, iLen = aAuditReasonCodes.length;
			if (bDefault) {
				for (i = 0; i < iLen; i++) {
					if (aAuditReasonCodes[i].DefaultArc === "X") {
						return aAuditReasonCodes[i];
					}
				}
			} else if (sArc) {
				for (i = 0; i < iLen; i++) {
					if (aAuditReasonCodes[i].AuditReasonCodes === sArc) {
						return aAuditReasonCodes[i];
					}
				}
			}
		},

		/**
		 * Provides filters and does check for default code for audit before filling the Audit Code Table
		 * @param {string} sQuery Tells if Audit is needed or PPA
		 */
		fnFillAuditCodeTable: function (sQuery) {
			this.oTable = null;
			if (sQuery === "PPA") {
				this.oTable = this.byId(Fragment.createId("PPA_Needed", "tableAuditCode"));
			} else {
				this.oTable = this.byId(Fragment.createId("staticFragId", "tableAuditCode"));
			}
			this.oTable.getParent().getBeginButton().setEnabled(false);
			var afilterData = [{
				path: "NetId",
				operator: FilterOperator.EQ,
				value1: this.oInputVar.NetObj
			}, {
				path: "Frequency",
				operator: FilterOperator.EQ,
				value1: this.oInputVar.Frequency
			}];
			var oBindingInfo = {
				path: "/AuditReasonCodeSet",
				factory: jQuery.proxy(function (sId, oContext) {
					var sCode = oContext.getProperty("AuditReasonCodes");
					var sDesc = oContext.getProperty("AuditReasonDescr");
					var sIsDefault = oContext.getProperty("DefaultArc");
					if (sIsDefault) {
						this.oTable.getParent().getBeginButton().setEnabled(true);
					}
					return new ColumnListItem({
						cells: [new ObjectIdentifier({
								title: sCode
							}),
							sIsDefault === "X" ? new ObjectIdentifier({
								title: sDesc
							}) : new Text({
								text: sDesc
							})
						]
					}).setSelected(!!sIsDefault);
				}, this),
				filters: Utility.createODataFilters(afilterData)
			};
			this.oTable.bindAggregation("items", oBindingInfo);
		},

		/**
		 * Save the data, metadata(used in delete) and Etag(also used in delete) to buffer variables
		 * @param {Object} data Data set returned on successful OData read
		 */
		fnCacheData: function (data) {
			this.aData = []; // global variable to store the rendering info
			this.aMetadata = []; // formatting metadata. It will be freshly filled everytime and will be used at the time of deletion
			this.aEtags = []; // formatting Etags. It will be freshly filled everytime and will be used at the time of delete/update
			this.aDeleteIndex = []; // global variable to store the index of rendering records to delete
			var i, j, bIsPRASwitch = this.getPRASwitch();
			var oObjHeader = {};
			var oObjItem = {};
			var oObjStdVal = {};

			for (i = 0; i < data.results.length; i++) {
				var bDeleteFlag = true;
				oObjHeader = jQuery.extend(true, {}, data.results[i]);
				oObjHeader.FDCMeasurementRawSet = [];
				oObjHeader.FDCMeasurementStdQtySet = [];
				delete oObjHeader.__metadata;

				oObjHeader.AlertId = this.oInputVar.AlertId;
				oObjHeader.Operation = this.sMode === "create" ? "C" : "U";

				this.aMetadata.push(data.results[i].__metadata.uri.split("/").pop());
				this.aEtags.push(data.results[i].__metadata.etag);

				for (j = 0; j < data.results[i].FDCMeasurementRawSet.results.length; j++) {
					oObjItem = jQuery.extend(true, {}, data.results[i].FDCMeasurementRawSet.results[j]);
					if (!bIsPRASwitch && this.sMode === "create") {
						oObjItem.Fnumvalue = "";
					}
					oObjItem.Fmode = oObjItem.Fmode === "X" ? "R" : oObjItem.Fmode;
					oObjHeader.FDCMeasurementRawSet.push(oObjItem);
					//Get the index of record for deletion, if at least one characteristics has value per medium
					if (oObjItem.Fnumvalue !== "" && bDeleteFlag === true) {
						this.aDeleteIndex.push(i);
						bDeleteFlag = false;
					}
				}
				if (data.results[i].FDCMeasurementStdQtySet.results) {
					for (j = 0; j < data.results[i].FDCMeasurementStdQtySet.results.length; j++) {
						oObjStdVal = jQuery.extend(true, {}, data.results[i].FDCMeasurementStdQtySet.results[j]);
						oObjHeader.FDCMeasurementStdQtySet.push(oObjStdVal);
					}
				}
				this.aData.push(oObjHeader);
			}
		},

		/**
		 * Sets the global variable sMode based on the Existance Flag and raises an error messages when
		 * the mode and the existance flag contradict for example if the mode is edit and the data does not exist
		 * which can happen because of concurrent access
		 * @param {Object} ExistenceFlag	check Existance flags. Will be same for all hence checking only the first one
		 */
		fnSetMode: function (ExistenceFlag) {
			var oStartupParamModel = this.getView().getModel("StartupParameters"),
				bIsDisplayMode = false;
			if (this.sMode !== "edit") {
				if (ExistenceFlag === "X") {
					this.sMode = "create";
				} else {
					this.sMode = "display";
					bIsDisplayMode = true;
				}
			} else {
				if (ExistenceFlag === "X") {
					this._showError({
						messageKey: this.getResourceBundle().getText("MEAS_EDIT_FAILED_DNE"),
						titleKey: this.getResourceBundle().getText("RECORD_NOT_FOUND")
					}, false, {}, this.navBack.bind(this));
				}
			}
			oStartupParamModel.setProperty("/IsDisplayMode", bIsDisplayMode);
		},

		/**
		 * Sets the Page Heading and footer buttons with appropriate texts based on the User's authorizations
		 * @param {Object} data Object to check Authorizations
		 * @return {boolean} bReturn check whether to load screen or not
		 */
		fnSetHeadingAndButtons: function (data) {
			var bBtn1 = true,
				bBtn2 = true,
				bReturn = true;
			this.byId("saveBtn").setVisible(false);
			this.byId("cancelBtn").setVisible(false);
			this.byId("editBtn").setVisible(false);
			this.byId("deleteBtn").setVisible(false);
			this.byId("measView").setShowFooter(true);
			switch (this.sMode) {
			case "display":
				this._readHistory(data.results[0]);
				if (data.results[0].AuthDis === "") {
					this.fnHandleError({
						messageKey: this.oBundle.getText("MEAS_AUTH_DISPLAY_FAILED"),
						titleKey: this.oBundle.getText("AUTHORITY_CHECK")
					});
					bReturn = false;
					break;
				}
				if (this.oInputVar.NetObjTyp !== "GHO_WELL" && this.sQtyCategory === "09") { //No Edit Delete for Load Oil Received
					this.byId("measView").setShowFooter(false);
					break;
				}
				if (data.results[0].AuthChg !== "" && data.results[0].AuthDel !== "") {
					this.byId("editBtn").setVisible(true);
					this.byId("deleteBtn").setVisible(true);
				} else if (data.results[0].AuthChg !== "" && data.results[0].AuthDel === "") {
					this.byId("editBtn").setVisible(true);
				} else if (data.results[0].AuthChg === "" && data.results[0].AuthDel !== "") {
					this.byId("deleteBtn").setVisible(true);
				} else {
					//Do Nothing
				}
				this.byId("measView").setShowFooter(false);
				break;
			case "create":
				if (data.results[0].AuthIns === "") {
					this.fnHandleError({
						messageKey: this.oBundle.getText("MEAS_AUTH_CREATE_FAILED"),
						titleKey: this.oBundle.getText("AUTHORITY_CHECK")
					});
					bReturn = false;
					break;
				} else {
					this.byId("saveBtn").setVisible(true);
					this.byId("cancelBtn").setVisible(true);
				}
				break;
			case "edit":
				if (data.results[0].AuthChng === "") {
					this.fnHandleError({
						messageKey: this.oBundle.getText("MEAS_AUTH_EDIT_FAILED"),
						titleKey: this.oBundle.getText("AUTHORITY_CHECK")
					});
					bReturn = false;
					break;
				} else {
					this.byId("saveBtn").setVisible(true);
					this.byId("cancelBtn").setVisible(true);
				}

				break;
			default: //do nothing
				break;
			}
			this.updateStartupParametersModelData(data, bBtn1, bBtn2);
			return bReturn;
		},

		/**
		 * This function update the StartupParameters model Data based on the model and user's authorization
		 * @param	{Object}	oData		Object to check Authorizations
		 * @param	{Boolean}	bButton1	weather button1 in view should be visible or Not based on user's authorization
		 * @param	{Boolean}	bButton2	weather button2 in view should be visible or Not based on user's authorization
		 */
		updateStartupParametersModelData: function (oData, bButton1, bButton2) {
			var oStartupParametersModel = this.getView().getModel("StartupParameters");
			if (this.sMode !== "create" && this.sMode !== "edit") {
				//PPA Lock is enabled. Disable the edit and delete buttons.
				if (oData && oData.results[0].PPALock) {
					this.byId("editBtn").setEnabled(false);
					this.byId("deleteBtn").setEnabled(false);
					oStartupParametersModel.setProperty("/Lock", "sap-icon://locked");
					if (oData.results[0].PPARequesterFlag) { //Display message on the screen
						oStartupParametersModel.setProperty("/PPAStatus", this.oBundle.getText("PPA_PENDING_BY_OTHER"));
					} else { //Display message on the screen
						oStartupParametersModel.setProperty("/PPAStatus", this.oBundle.getText("PPA_PENDING_BY_USER", [oData.results[0].PPARequester]));
					}
				} else {
					this.byId("editBtn").setEnabled(true);
					this.byId("deleteBtn").setEnabled(true);
					this._resetPPAStatus();
				}
			}
			if (this.sMode === "display") {
				if (oData && oData.results[0].MrhIndicator === "" && !oData.results[0].PPALock) { //data not created from Fiori UI 
					this.byId("editBtn").setEnabled(true);
				} else {
					this.byId("editBtn").setEnabled(false);
				}
			}

			if (this.zzlock){
				this.getView().byId("editBtn").setEnabled(false);
				this.getView().byId("deleteBtn").setEnabled(false);
				this.getView().byId("lockIcon").setVisible(true);
			}
			else{
				// this.getView().byId("editBtn").setEnabled(true);
				// this.getView().byId("deleteBtn").setEnabled(true);
				this.getView().byId("lockIcon").setVisible(false);
			}

			oStartupParametersModel.setProperty("/PageTitle", this.getPageTitle());
			var oShareOnJam = {
				Visible: true
			};
			oStartupParametersModel.setProperty("/ShareOnJam", oShareOnJam);
		},

		/**
		 * This function resets the status text and icon in the object header
		 */
		_resetPPAStatus: function () {
			var oMeasPPA = this.getView().getModel("StartupParameters");
			oMeasPPA.setProperty("/PPAStatus", "");
			oMeasPPA.setProperty("/Lock", "");
		},

		/**
		 * Calls the unified factory rendering function, and creates a form element for each item record
		 * @param  {string} sId	Id of the element
		 * @param  {object}	oContext	context object
		 * @return {sap.ui.layout.form.FormElement} oFormElement Returns a form element (Label, Input and Unit-of-measure)
		 */
		fnDisplayFactory: function (sId, oContext) {
			var oItems,
				sCharVal = "Measurement",
				sGridDataSpan = this.getPRASwitch() ? "L8 M6 S12" : null;
			this.byId("idlistboxes").setEditable(this.sMode !== "display");
			

			if (this.sMode === "display") { //Display mode - input fields are non-editable
				oItems = unifiedRenderingFactory(sId, oContext, "", false, undefined, undefined, this, sGridDataSpan);
			} else {
				// Always show the Standard Gas reading in DISPLAY mode
				if (oContext.sPath.match("FDCMeasurement")){
					oItems = unifiedRenderingFactory(sId, oContext, "", false, undefined, undefined, this, sGridDataSpan);
				}else{
				
					oItems = unifiedRenderingFactory(sId, oContext, "", true, { //Call UnifiedRendering function
						change: jQuery.proxy(function (oEvent) {
							var oSource = oEvent.getSource(),
								sTarget, oMessageProcessor;
							if (oEvent.getParameter("selectedItem") !== undefined) {
								if (oSource.getValueState() === "Error" && (oSource.getSelectedKey() !== "")) {
									oSource.setValueState(ValueState.None);
									sTarget = oSource.getBindingContext().getPath() + "/" + "Fnumvalue";
									oMessageProcessor = oSource.getBindingContext().getModel();
									this.removeMessage(sTarget, oMessageProcessor);
									this.showMessages();
								}
							}
							this.bDataChanged = true;
						}, this)
					}, undefined, this, sGridDataSpan, sCharVal);
				}
			}
			return oItems;
		},
		/**
		 * This method returns settings object for JAM Share integration
		 * @returns {object} - Jam Share settings object
		 */
		getJamShareSettings: function () {
			var i;
			var objectHeader = this.byId("idHeader");
			var oShareListItem = new ObjectListItem();
			oShareListItem.setTitle(objectHeader.getTitle());
			var aAttributes = objectHeader.getAttributes();
			for (i = 0; i < aAttributes.length; i++) {
				var oAttribute = new ObjectAttribute();
				oAttribute.setTitle(aAttributes[i].getTitle());
				oAttribute.setText(aAttributes[i].getText());
				oShareListItem.addAttribute(oAttribute);
			}
			var sDate;
			if (this.oInputVar.Frequency !== "H") {
				sDate = DateFormat.getDateInstance({
					style: "medium"
				}).format(this.oInputVar.FromDate);
			} else {
				sDate = DateFormat.getDateTimeInstance({
					style: "short"
				}).format(this.oInputVar.FromDate);
			}
			var sFrequency;
			switch (this.oInputVar.Frequency) {
			case "D":
				sFrequency = this.oBundle.getText("MEAS_FREQ_DAILY");
				break;
			case "W":
				sFrequency = this.oBundle.getText("MEAS_FREQ_WEEKLY");
				break;
			case "M":
				sFrequency = this.oBundle.getText("MEAS_FREQ_MONTHLY");
				break;
			case "H":
				sFrequency = this.oBundle.getText("MEAS_FREQ_HOURLY");
				break;
			default:
				sFrequency = this.oInputVar.Frequency;
			}
			var sShareMsg = jQuery.sap.formatMessage("{0}:\n{1}: {2}\n{3}: {4} ({5})\n{6}: {7}\n{8}: {9}", [this.oBundle.getText("DETAIL_TITLE"),
				this.oBundle.getText("MEAS_TEXT_PRODUCTION_NETWORK"), this.oInputVar.ProdNetwork,
				this.oBundle.getText("XCOL_NET_OBJECT"), this.oInputVar.NetObj, this.sType,
				this.oBundle.getText("MEAS_TEXT_FREQUENCY"), sFrequency,
				this.oBundle.getText("MEAS_TEXT_MEASUREMENT_DATE"), sDate
			]);
			return {
				object: {
					id: window.location.href,
					display: oShareListItem,
					share: sShareMsg
				}
			};
		},

		/**
		 * This method reads measurement data by sending read call to FDCMeasurementReadingSet entity
		 */
		fnReadMeasurementData: function () {
			var fnSuccess, fnError, afilterData, mParameter, sType, sMsg, dDateUtcAdjusted, oMsg, sUrlExpandParams, bPRASwitch;
			dDateUtcAdjusted = this.oInputVar.FromDate;

			fnSuccess = jQuery.proxy(function (oData) {
				this.sExistenceFlag = oData.results[0].FDCMeasurementRawSet.results[0].ExistenceFlag;
				for (var i = 0; i < oData.results.length; i++) {
					//Add Logic to Override Date Back to what is sent from UI to Remove Furture Date in case of multiple Measurement
					var sMesDateStr = this.fnConvertDateToString(this.oInputVar.FromDate),
						sMesRawSetLen = (oData.results[i].FDCMeasurementRawSet.results && oData.results[i].FDCMeasurementRawSet.results.length) ?
						oData.results[i].FDCMeasurementRawSet.results.length : 0,
						sMesStdQtySetLen = (oData.results[i].FDCMeasurementStdQtySet.results && oData.results[i].FDCMeasurementStdQtySet.results.length) ?
						oData.results[i].FDCMeasurementStdQtySet.results.length : 0;
					oData.results[i].MeasmntTimestamp = sMesDateStr;
					if (sMesRawSetLen > 0) {
						for (var j = 0; j < sMesRawSetLen; j++) {
							oData.results[i].FDCMeasurementRawSet.results[j].Fdatevalue = sMesDateStr;
							oData.results[i].FDCMeasurementRawSet.results[j].MeasmntTimestamp = sMesDateStr;
						}
					}
					if (sMesStdQtySetLen > 0) {
						for (var k = 0; k < sMesStdQtySetLen; k++) {
							oData.results[i].FDCMeasurementStdQtySet.results[k].Proddate = sMesDateStr;
						}
					}
				}
				this._mesBusyDialog.close();
				this.fnUpdateView(oData);
			}, this);
			fnError = jQuery.proxy(function (oError) {
				this._mesBusyDialog.close();
				sType = (jQuery.parseJSON(oError.responseText).error.innererror.errordetails[0].severity).toUpperCase();
				sMsg = jQuery.parseJSON(oError.responseText).error.innererror.errordetails[0].message;

				switch (sType) {
				case "ERROR":
					oMsg = {
						messageKey: sMsg,
						titleKey: this.sNetObjTypeCode === "GHO_WC" ? "WELL_COMP_VOL_ERROR" : "MEAS_ERROR"
					};
					this._showError(oMsg, false, {}, this.navBack.bind(this));
					break;
				case "INFO":
					this._showInfoMessage(sMsg, this.navBack.bind(this));
					break;
				}
			}, this);
			afilterData = [{
				path: "Productionnetwork",
				operator: FilterOperator.EQ,
				value1: this.oInputVar.ProdNetwork
			}, {
				path: "NetworkobjectType",
				operator: FilterOperator.EQ,
				value1: this.sNetObjTypeCode
			}, {
				path: "Frequency",
				operator: FilterOperator.EQ,
				value1: this.oInputVar.Frequency
			}, {
				path: "QtyType",
				operator: FilterOperator.EQ,
				value1: this.sQtytype
			}, {
				path: "MeasCatId",
				operator: FilterOperator.EQ,
				value1: this.sMeasCatId
			}, {
				path: "Networkobject",
				operator: FilterOperator.EQ,
				value1: this.oInputVar.NetObj
			}, {
				path: "MeasmntTimestamp",
				operator: FilterOperator.EQ,
				value1: this.fnConvertDateToString(dDateUtcAdjusted)
			}, {
				path: "OriginatingMp",
				operator: FilterOperator.EQ,
				value1: this.oInputVar.OriginatingMp
			}];
			bPRASwitch = this.getPRASwitch();
			// Send Operation as "C" if Create Button was pressed on landing screen 1st time,
			//Send "E" when Edit button is pressed it will be treated as "D" in backend,
			//otherwise "D" to check existance of record
			if (this.sNetObjTypeCode !== "GHO_WELL") {
				afilterData.push({
					path: "Operation",
					operator: FilterOperator.EQ,
					value1: (this.sMode === null && this.oInputVar.Mode === "C") ? "C" : (this.sMode === "edit") ? "U" : "D"
				});
			}
			if (bPRASwitch) {
				sUrlExpandParams = {
					$expand: "FDCMeasurementRawSet/FDCMeasCharValue,FDCMeasurementStdQtySet"
				};
			} else {
				sUrlExpandParams = {
					$expand: "FDCMeasurementRawSet,FDCMeasurementStdQtySet"
				};
			}
			mParameter = {
				context: null,
				urlParameters: sUrlExpandParams,
				async: true,
				filters: Utility.createODataFilters(afilterData),
				sorters: null,
				success: fnSuccess,
				error: fnError
			};
			this._mesBusyDialog.open();
			this.getView().getModel().read("/FDCMeasurementReadingSet", mParameter);
		},

		/**
		 * Displays the error message using the messageKey and parameters provided in oMessage object.
		 * @param	{Object}	oMessage		Map of object containing messageKey and parametrs
		 * @param	{Boolean}	bShowDetails	flag to show details
		 * @param	{Object}	oDetails		Error message details
		 * @param	{function}	fnCallback		callback function to be called on click of OK in error message
		 */
		_showError: function (oMessage, bShowDetails, oDetails, fnCallback) {
			var sMsg = this.getResourceBundle().getText(oMessage.messageKey, oMessage.parameters),
				sTitle = this.getResourceBundle().getText(oMessage.titleKey);

			sMsg = sMsg ? sMsg : oMessage.messageKey;
			sTitle = sTitle ? sTitle : oMessage.titleKey;

			this.showError(sTitle, sMsg, bShowDetails, oDetails, fnCallback);
			this.removeAllMessages();
		},

		/**
		 * This method shows info message box
		 * @param  {String} sMsg text of info message
		 * @param  {function} fnCallBack call back function
		 */
		_showInfoMessage: function (sMsg, fnCallBack) {
			var oErrorHandler = this.getOwnerComponent().getErrorHandler();
			oErrorHandler.setMessageOpen(true);
			MessageBox.information(sMsg, {
				onClose: function () {
					oErrorHandler.setMessageOpen(false);
					fnCallBack.call();
				}
			});
		},

		/**
		 * This method returns Audit Dialog with default audit code selected ,
		 * And enables OK button(if there is any default value).
		 * @param	{String}	sDefaultArc	default auidt code
		 * @return	{Boolean}	true/false
		 */
		auditItemSelectedFormatter: function (sDefaultArc) {
			if (sDefaultArc === "X") {
				this._oAuditDialog.getBeginButton().setEnabled(true);
				return true;
			} else {
				return false;
			}
		},

		/**
		 * Setter method for this._firstErrorStateControl. This control will have focus
		 * after user clicks on 'OK' button in error dialog.
		 * @param {sap.ui.core.Control} oControl First control in the view with error state
		 */
		_setFirstErrorStateControl: function (oControl) {
			if (!this._firstErrorStateControl) {
				this._firstErrorStateControl = oControl;
			}
		},

		/**
		 * Getter method for this._firstErrorStateControl. This control will have focus
		 * after user clicks on 'OK' button in error dialog.
		 * @return {sap.ui.core.Control} First control in the view with error state
		 */
		_getFirstErrorStateControl: function () {
			return this._firstErrorStateControl;
		},

		/**
		 * Set the focus to first error state control in the view
		 */
		_focusFirstErrorStateControl: function () {
			if (this._getFirstErrorStateControl() && this._getFirstErrorStateControl().focus) {
				this._getFirstErrorStateControl().focus();
				this._setFirstErrorStateControl(undefined);
			}
		},

		//----------------------------------------Message Manager handling----------------------------------------
		/**
		 * Event handler method for press event of button which is to display the Message PopOver
		 * @param{sap.ui.base.Event} oEvent Press Event
		 * @public
		 */
		onOpenMessageLog: function (oEvent) {
			this._openOrCloseMsgPopOver();
		},

		/**
		 * method to open or close the message pop over
		 * @param{boolean} bOpen Open MessagePopOver if true, Close if false and toggle if undefined
		 * @private
		 */
		_openOrCloseMsgPopOver: function (bOpen) {
			var oButton = this.byId("BtnMeasErrorMessage"),
				oMsgPop = this.byId("MsgPopUpMeasurement");
			switch (bOpen) {
			case true: // Open MessagePopover
				if (!oMsgPop.isOpen()) {
					oMsgPop.openBy(oButton);
				}
				break;
			case false: //Close MessagePopOver
				if (oMsgPop.isOpen()) {
					oMsgPop.close();
				}
				break;
			default: // Toggle MessagePopOver
				oMsgPop.toggle(oButton);
				break;
			}
		},

		/**
		 *  method to set the error count on the Button
		 *  @returns{integer} Error Count
		 *  @private
		 */
		_setErrorCount: function () {
			var iErrorCount = this.getMessagesCount(),
				sErrorCount,
				oErrorAlertBtn = this.byId("BtnMeasErrorMessage");

			if (iErrorCount === 0) {
				sErrorCount = "";
				oErrorAlertBtn.setVisible(false);
			} else {
				sErrorCount = iErrorCount;
				oErrorAlertBtn.setVisible(true);
				oErrorAlertBtn.rerender();
			}
			this.getView().getModel("DynamicModel").setProperty("/ErrorCount", sErrorCount);
			return iErrorCount;
		},

		/**
		 * method to show the messages in pop over based on the number of messages.
		 * @private
		 */
		showMessages: function () {
			var iErrorCount = this._setErrorCount();

			if (iErrorCount === 0) {
				// Close the message pop over if it is open
				this._openOrCloseMsgPopOver(false);
			} else {
				// Open the message pop over if it is open
				this._openOrCloseMsgPopOver(true);
			}
		},

		/**
		 * helper method to add the message to Message Processor Model
		 * and updates the ErrorCount in the model
		 * @param{string} sTarget Binding Path of the Control
		 * @param{string} sMessage MessageText
		 * @param{string} sLongText Long Description Text
		 * @param{string} sMessageType MessageType
		 * @param{object} oMessageProcessor Message Processor Model
		 * @private
		 */
		_addMessage: function (sTarget, sMessage, sLongText, sMessageType, oMessageProcessor) {
			this._removeMessage(sTarget, oMessageProcessor);
			this.addMessage(sTarget, sMessage, sLongText, sMessageType, oMessageProcessor);
			this.showMessages();
		},

		/**
		 * helper method to remove the message from message processor model
		 * based on target path and updates the ErrorCount in the model.
		 * @param{string} sTarget Binding path of the Control
		 * @param{object} oMessageProcessor Message Processor Model
		 * @private
		 */
		_removeMessage: function (sTarget, oMessageProcessor) {
			this.removeMessage(sTarget, oMessageProcessor);
			this.showMessages();
		},

		/**
		 * This function is called when use click on the Share Action It will Open up dialog
		 * for Bookmarkas tile and share on Jam
		 * @param	{Object}	oEvent	Action List Button Press Event
		 */
		onActionBtnPress: function (oEvent) {
			this.byId("adActionSheetAllocRes").openBy(oEvent.getSource());
		},

		/**
		 * Function to set the PRA fields Visibility and Column Layouts
		 * @param	{Array}	oMesResData	Measurement Resposne Data
		 */
		setPRAStartUpParams: function (oMesResData) {
			this.sQtyCategory = (oMesResData && oMesResData.results && oMesResData.results.length > 0) ? oMesResData.results[0].QtyCategory :
				"";
			var oStartupParameters = this.getView().getModel("StartupParameters"),
				bIsPRASwitch = this.getPRASwitch(),
				bIsDetailToInfoVisible = this.isDetailToInfoVisible(bIsPRASwitch),
				bIsOrigMPVisible = (this.sNetObjTypeCode === "GHO_WC" && bIsPRASwitch) ? true : false,
				bMesCatVisible = this.byId("idfemeascatid").getVisible(),
				oDummyContainer = this.byId("dummyContainer");
			oStartupParameters.setProperty("/IsPRASwitch", bIsPRASwitch);
			oStartupParameters.setProperty("/IsPRAfieldEnabled", (this.sMode === "edit" && this.oInputVar &&
				this.oInputVar.NetObjTyp !== "GHO_WELL") ? false : true);
			oStartupParameters.setProperty("/IsTransDetailReq", this.isTransDetailReq(bIsPRASwitch));
			oStartupParameters.setProperty("/IsTransDetailVisible", (this.oInputVar && bIsPRASwitch && this.oInputVar.NetObjTyp !== "GHO_WELL") ?
				true : false);
			oStartupParameters.setProperty("/IsDetailToInfoVisible", bIsDetailToInfoVisible);
			oStartupParameters.setProperty("/IsOrigMPVisible", bIsOrigMPVisible);
			oStartupParameters.setProperty("/IsMesDateFieldVisible", (this.sMode === "create" && this.oInputVar && this.oInputVar
					.NetObjTyp !== "GHO_WELL") ?
				true : false);
			oStartupParameters.setProperty("/ColumnL", bIsPRASwitch ? 3 : 2);
			oStartupParameters.setProperty("/GridDataSpan", "L8 M6 S12");
			if (bIsPRASwitch && (bIsDetailToInfoVisible || bIsOrigMPVisible) && !bMesCatVisible) {
				oStartupParameters.setProperty("/CategoryContainerVisible", false);
			}
			if ((!this.sQtytype && bIsOrigMPVisible) ||
				(this.sQtytype && !bMesCatVisible && !bIsOrigMPVisible && !bIsDetailToInfoVisible)) {
				oDummyContainer.setVisible(true);
			} else {
				oDummyContainer.setVisible(false);
			}
			oStartupParameters.setProperty("/PageTitle", this.getPageTitle());

		},

		/**
		 * function to check the visibility of To fields
		 * @param	{Boolean}	bIsPRASwitch	PRA Switch
		 * @returns	{Boolean}	true/false weather To Fields are visible or not
		 */
		isDetailToInfoVisible: function (bIsPRASwitch) {
			var bIsDetailToInfoVisible;
			if (this.sNetObjTypeCode !== "GHO_WELL" && this.sNetObjTypeCode !== "GHO_WC" && (this.sQtyCategory === "08")) {
				bIsDetailToInfoVisible = true;
			} else {
				bIsDetailToInfoVisible = false;
			}
			return bIsDetailToInfoVisible;
		},

		/**
		 * function to check the visibility of Transporter Details
		 * @param	{Boolean}	bIsPRASwitch	PRA Switch
		 * @returns	{Boolean}	true/false weather Transporter Details are visible or not
		 */
		isTransDetailReq: function (bIsPRASwitch) {
			var bIsTransDetailReq;
			if (this.sNetObjTypeCode !== "GHO_WELL" && bIsPRASwitch && (this.sQtyCategory === "05" || (this.sQtyCategory >= "08" && this.sQtyCategory <=
					"12" && this.sQtyCategory !== "09"))) {
				bIsTransDetailReq = true;
			} else {
				bIsTransDetailReq = false;
			}
			return bIsTransDetailReq;
		},

		/**
		 * Function to set the PRA Fields for Measurements
		 * @param	{Object}	oMesObj Measurement Oject
		 * @returns	{Object}	Measurement Oject with populated fields of PRA from forms.
		 */
		setPRAFields: function (oMesObj) {
			var oDynamicModelData = this.getView().getModel("DynamicModel").getData();
			oMesObj.ToProdNetwork = this.getMultiInputSelTokenValue(this.getToProdNetworkInputField());
			oMesObj.ToNetobjTyDes = this.getMultiInputSelTokenValue(this.getToNetobjTyDesInputField());
			oMesObj.ToNetworkObj = this.getMultiInputSelTokenValue(this.getToNetworkObjInputField());
			oMesObj.OriginatingMp = this.getMultiInputSelTokenValue(this.getOrigMpInputField());
			oMesObj.TrnspNo = this.getMultiInputSelTokenValue(this.getTransporterInputField());
			oMesObj.TranspName = oMesObj.TrnspNo ? oDynamicModelData.TranspName : "";
			oMesObj.TrnspRefNo = oDynamicModelData.TrnspRefNo;
			oMesObj.TktNo = oDynamicModelData.TktNo;
			oMesObj.LdOilWoRecov = oDynamicModelData.LdOilWoRecov;
			oMesObj = this.removeDuplicateTranspNo(oMesObj);
			return oMesObj;
		},
		/**
		 * function to remove the transportno property duplicate values
		 * @returns	{Object} Payload object
		 */
		removeDuplicateTranspNo: function (oData) {
			var aTranspNo = oData.TrnspNo.split(","),
				oTraspNo = {};

			aTranspNo.forEach(function (oValue) {
				oTraspNo[oValue] = oValue;
			});
			oData.TrnspNo = Object.values(oTraspNo).join(",");
			return oData;
		},

		/**
		 * function to get the data section title text
		 * @returns	{String}	Data Section title Text String
		 */
		getDataSectionTitle: function () {
			var sI18nTextKey;
			switch (this.sNetObjTypeCode) {
			case "GHO_WC":
				sI18nTextKey = "WELL_COMPLETION_VOLUMES";
				break;
			case "GHO_WELL":
				sI18nTextKey = "WELL_READING_DATA";
				break;
			default:
				sI18nTextKey = "MEAS_DATA";
				break;
			}
			return this.oBundle.getText(sI18nTextKey);
		},

		/**
		 * function to get the Page Title text
		 * @returns {String}  Page Title text String
		 */
		getPageTitle: function () {
			var sI18nTextKey;
			switch (this.sMode) {
			case "create":
				if (this.sNetObjTypeCode === "GHO_WC") {
					sI18nTextKey = "CREATE_WELL_COMPLETION_VOLUMES";
				} else if (this.sNetObjTypeCode === "GHO_WELL") {
					sI18nTextKey = "CREATE_WELLREADING";
				} else {
					sI18nTextKey = "CREATE_MEASUREMENT";
				}
				break;
			case "edit":
				if (this.sNetObjTypeCode === "GHO_WC") {
					sI18nTextKey = "EDIT_WELL_COMPLETION_VOLUMES";
				} else if (this.sNetObjTypeCode === "GHO_WELL") {
					sI18nTextKey = "EDIT_WELLREADING";
				} else {
					sI18nTextKey = "EDIT_MEASUREMENT";
				}
				break;
			default:
				if (this.sNetObjTypeCode === "GHO_WC") {
					sI18nTextKey = "DISPLAY_WELL_COMPLETION_VOLUMES";
				} else if (this.sNetObjTypeCode === "GHO_WELL") {
					sI18nTextKey = "DISPLAY_WELLREADING";
				} else {
					sI18nTextKey = "DISPLAY_MEASUREMENT";
				}
				break;
			}
			return this.oBundle.getText(sI18nTextKey);
		},

		/**
		 * This is called when user click the Transporter input box value help, this will open the transporter selection dialog box
		 * @public
		 */
		onTransporterValueHelp: function () {
			if (!this._oTransporterDialog) {
				this._oTransporterDialog = sap.ui.xmlfragment("oil.ups.fdcs1.fragments.TransporterValueHelpDialog", this);
				this.getView().addDependent(this._oTransporterDialog);
			}
			this._oTransporterDialog.open();
			this._oTransporterDialog.fireSearch();
		},

		/**
		 * This is called when user search a transporter from transporter selection dialogs -  transporter list
		 * This will take the search input and filter the transporter data based on that in transporter selection dialogs -  transporter list
		 * @public
		 * @param   {object}    oEvent  user search a transporter from transporter selection dialog
		 */
		onTransporterValueHelpSearch: function (oEvent) {
			var oTable = oEvent.getSource(),
				sValue = oEvent.getParameter("value"),
				sNoTransporterText = this.oBundle.getText("TRANSPORTER_NOT_FOUND"),
				//sEnterTransporterTxt = this.oBundle.getText("ENTER_TRANSPORTER_DATA"),
				oTemplate;
			// remove all the items if the search query is empty
			/*if (!sValue) {
				oTable.setNoDataText(sEnterTransporterTxt);
				oTable.removeAllItems();
				return;
			}*/
			// get the template
			oTemplate = sap.ui.xmlfragment("oil.ups.fdcs1.fragments.TransporterValueHelpListItem", this);
			// bind the items to the table with the filter query
			oTable.bindItems({
				path: "/FDCTransporterDetailSet",
				sorter: new Sorter("CustomerNo", false),
				parameters: {
					select: "CustomerNo,CustomerName",
					custom: {
						search: sValue
					}
				},
				template: oTemplate,
				events: {
					dataReceived: function () {
						oTable.setNoDataText(sNoTransporterText);
					}
				}
			});
		},

		/**
		 * This is called when user select a transporter from transporter selection dialog or close the transporter selection dialog
		 * This will take the selected transporter and add that to create model and transporter input field
		 * @public
		 * @param   {object}    oEvent  user select a transporter from dialog
		 */
		onTransporterValueHelpConfirm: function (oEvent) {
			var aContexts = oEvent.getParameter("selectedContexts"),
				oDynamicModel = this.getView().getModel("DynamicModel"),
				sTranspNo = oDynamicModel.getProperty("/TrnspNo"),
				sTranspName = oDynamicModel.getProperty("/TranspName");
			if (aContexts && aContexts.length && this.getTransporterInputField().getTokens().length == 0) {
				// populate the Transporter Number
				sTranspNo = aContexts.map(function (oContext) {
					return oContext.getObject().CustomerNo;
				}).join(", ");
				sTranspName = aContexts.map(function (oContext) {
					return oContext.getObject().CustomerName;
				}).join(", ");
				oDynamicModel.setProperty("/TrnspNo", sTranspNo);
				oDynamicModel.setProperty("/TranspName", sTranspName);
				this.addMultiInputToken(this.getTransporterInputField(), sTranspNo, sTranspName + " (" + sTranspNo + ")");
			}

			oEvent.getSource().setNoDataText(this.oBundle.getText("ENTER_TRANSPORTER_DATA"));
			// removing all the items
			oEvent.getSource().removeAllItems();
		},

		/**
		 * This is called when user close the transporter selection dialog
		 * @public
		 * @param   {object}    oEvent  user close transporter selection dialog
		 */
		onTransporterValueHelpClose: function (oEvent) {
			oEvent.getSource().setNoDataText(this.oBundle.getText("ENTER_TRANSPORTER_DATA"));
			oEvent.getSource().removeAllItems(); // remove items if present
		},

		/**
		 * This is called when user click the Transporter input box value help, this will open the transporter selection dialog box
		 * @public
		 */
		onTransporterXrefValueHelp: function () {
			if (!this._oTransporterXRefDialog) {
				this._oTransporterXRefDialog = sap.ui.xmlfragment("oil.ups.fdcs1.fragments.TransporterXRefValueHelpDialog", this);
				this.getView().addDependent(this._oTransporterXRefDialog);
			}
			this._oTransporterXRefDialog.open();
			this._oTransporterXRefDialog.fireSearch();
		},

		/**
		 * This is called when user search a transporter from transporter selection dialogs -  transporter list
		 * This will take the search input and filter the transporter data based on that in transporter selection dialogs -  transporter list
		 * @public
		 * @param   {object}    oEvent  user search a transporter from transporter selection dialog
		 */
		onTransporterXRefValueHelpSearch: function (oEvent) {
			var oTable = oEvent.getSource(),
				sValue = oEvent.getParameter("value"),
				sNoTransporterXRefText = this.oBundle.getText("TRANSPORTER_REF_NOT_FOUND"),
				//sEnterTransporterXRefTxt = this.oBundle.getText("ENTER_TRANSPORTER_XREF_DATA"),
				oTemplate,
				aFilters = this._getTransporterXRefFilters();
			// remove all the items if the search query is empty
			/*if (!sValue) {
				oTable.setNoDataText(sEnterTransporterXRefTxt);
				oTable.removeAllItems();
				return;
			}*/
			// get the template
			oTemplate = sap.ui.xmlfragment("oil.ups.fdcs1.fragments.TransporterXRefValueHelpListItem", this);
			// bind the items to the table with the filter query
			oTable.bindItems({
				path: "/FDCTransporterXrefSet",
				sorter: new Sorter("TrnspRefNo", false),
				filters: aFilters,
				parameters: {
					select: "CustomerNo,CustomerName,TrnspRefNo",
					custom: {
						search: sValue
					}
				},
				template: oTemplate,
				events: {
					dataReceived: function () {
						oTable.setNoDataText(sNoTransporterXRefText);
					}
				}
			});
		},

		/**
		 * Function to get the Transporter Refernece Filters
		 * @return	{Array}	Array of Filters
		 * @private
		 */
		_getTransporterXRefFilters: function () {
			var oDynamicModel = this.getView().getModel("DynamicModel"),
				sTranspNo = oDynamicModel.getProperty("/TrnspNo"),
				aFilters = [new Filter("MpNo", FilterOperator.EQ, this.oInputVar.NetObj),
					new Filter("NetobjType", FilterOperator.EQ, this.oInputVar.NetObjTyp),
					new Filter("EffFromTs", FilterOperator.EQ, oDynamicModel.getProperty("/MeasmntTimestamp"))
				];
			if (sTranspNo !== "") {
				aFilters.push(new Filter("CustomerNo", FilterOperator.EQ, sTranspNo));
			}
			return aFilters;
		},

		/**
		 * This is called when user select a transporter from transporter selection dialog or close the transporter selection dialog
		 * This will take the selected transporter and add that to create model and transporter input field
		 * @public
		 * @param   {object}    oEvent  user select a transporter from dialog
		 */
		onTransporterXRefValueHelpConfirm: function (oEvent) {
			var aContexts = oEvent.getParameter("selectedContexts"),
				oDynamicModel = this.getView().getModel("DynamicModel"),
				sTranspXRefNo = oDynamicModel.getProperty("/TrnspRefNo"),
				sTranspNo = oDynamicModel.getProperty("/TrnspNo"),
				sTranspName = oDynamicModel.getProperty("/TranspName");
			if (aContexts && aContexts.length) {
				// populate the Transporter Number
				sTranspXRefNo = aContexts.map(function (oContext) {
					return oContext.getObject().TrnspRefNo;
				}).join(", ");
				oDynamicModel.setProperty("/TrnspRefNo", sTranspXRefNo);
				this.addMultiInputToken(this.getTransporterRefInputField(), sTranspXRefNo);
				//Override transporter value, so that if not selected already than it will be filled 
				sTranspNo = aContexts.map(function (oContext) {
					return oContext.getObject().CustomerNo;
				}).join(", ");
				sTranspName = aContexts.map(function (oContext) {
					return oContext.getObject().CustomerName;
				}).join(", ");

				oDynamicModel.setProperty("/TrnspNo", sTranspNo);
				oDynamicModel.setProperty("/TranspName", sTranspName);
				this.addMultiInputToken(this.getTransporterInputField(), sTranspNo, sTranspName + " (" + sTranspNo + ")");
			}

			oEvent.getSource().setNoDataText(this.oBundle.getText("ENTER_TRANSPORTER_DATA"));
			// removing all the items
			oEvent.getSource().removeAllItems();
		},
		/**
		 * This is called when user close the transporter selection dialog
		 * @public
		 * @param   {object}    oEvent  user close transporter selection dialog
		 */
		onTransporterXRefValueHelpClose: function (oEvent) {
			oEvent.getSource().setNoDataText(this.oBundle.getText("ENTER_TRANSPORTER_DATA"));
			oEvent.getSource().removeAllItems(); // remove items if present
		},

		/**
		 * Function to add Multiinput token with given token value
		 * @param	{Object}	obj			MultiInput Object
		 * @param	{String}	sTokenKey	Key for the token
		 * @param	{String}	sTokenText	Text for the token
		 * @param	{Boolean}	bSel		Weather Token is Selected or not
		 */
		addMultiInputToken: function (obj, sTokenKey, sTokenText, bSel) {
			var oNewToken = new Token({
				selected: bSel ? bSel : false,
				key: sTokenKey,
				text: sTokenText ? sTokenText : sTokenKey,
				"delete": this.onMultiInputTokenDelete.bind(this)
			});
			obj.addToken(oNewToken);
		},

		/**
		 * Event Handler function for MultiInput Token Delete
		 */
		onMultiInputTokenDelete: function () {
			//Nothing to do as of now
		},

		/**
		 * Event Handler function for MultiInput TOken Changes
		 * @param	{Object}	oEvent	MultiInput Token Change Event
		 */
		onTokenChange: function (oEvent) {
			var oSrcObj = oEvent.getSource(),
				oPrams = oEvent.getParameters(),
				oDynamicModel = this.getView().getModel("DynamicModel");
			if (oPrams.type !== "tokensChanged") {
				if (oSrcObj.getTokens().length <= 0 && oPrams.type !== "removedAll" && oSrcObj.getRequired()) {
					oSrcObj.setValueState(ValueState.Error);
					if (oSrcObj.getId() === this.getTransporterInputField().getId()) {
						oDynamicModel.setProperty("/TrnspNo", "");
						oDynamicModel.setProperty("/TranspName", "");
					}
					if (oSrcObj.getId() === this.getTransporterRefInputField().getId()) {
						oDynamicModel.setProperty("/TrnspRefNo", "");
					}
					if (oDynamicModel) {
						this._addMessage(oSrcObj.getId(), oSrcObj.getValueStateText(), oSrcObj.getValueStateText(),
							MessageType.Error, oDynamicModel);
					}
					this._setFirstErrorStateControl(oSrcObj);
				} else {
					oSrcObj.setValueState(ValueState.None);
					if (oDynamicModel) {
						this.removeMessage(oSrcObj.getId(), oDynamicModel);
						this.showMessages();
					}
				}
				if (oPrams.type === "added") {
					this._bIsPRAFiledsChanged = true;
				}
				if (oPrams.type !== "removedAll") {
					this._isToInfoValid();
				}
			}
		},

		/**
		 * Function to get the MultiInput Selected Token Keys as Array or comma seprated String
		 * @param	{Object}		oSrcObj MultiInput Object
		 * @param	{Boolean}		bIsArrReq Weather Array is Required or String Default is String
		 * @returns	{String/Arry}	MultiInput Selected Token Keys as Array or comma seprated String
		 */
		getMultiInputSelTokenValue: function (oSrcObj, bIsArrReq) {
			var aTokens = [],
				aTokensKeyArr;
			if (oSrcObj && oSrcObj.getTokens) {
				aTokens = oSrcObj.getTokens();
			}
			aTokensKeyArr = aTokens.map(function (oToken) {
				return oToken.getKey();
			});
			return bIsArrReq ? aTokensKeyArr : aTokensKeyArr.join(",");
		},

		/**
		 * Event Handler function for To Production Network Value Help
		 * @param	{Object} oEvent ValueHelp Event
		 */
		onToProdNetworkValueHelp: function (oEvent) {
			this.getFilterBar().onPriSelValueHelp(oEvent, "PRODNETWRK");
		},

		/**
		 * Event Handler function for To Network Object Type Value Help
		 * @param	{Object} oEvent ValueHelp Event
		 */
		onToNetobjTyDesValueHelp: function (oEvent) {
			this.getFilterBar().onPriSelValueHelp(oEvent, "NETOBJ_TYP");
		},

		/**
		 * Event Handler function for To Network Object Value Help
		 * @param	{Object} oEvent ValueHelp Event
		 */
		onToNetworkObjectValueHelp: function (oEvent) {
			this.getFilterBar().onPriSelValueHelp(oEvent, "NETOBJ");
		},

		/**
		 * Event Handler function for Ticket Number Change
		 */
		onTicketNumChange: function () {
			this._bIsPRAFiledsChanged = true;
		},

		/**
		 * Event Handler function for Load Oil w/o Recovery Change
		 */
		onLoadOilWoRecvChange: function () {
			this._bIsPRAFiledsChanged = true;
		},

		/**
		 * Event Handler function for Transporter Reference Change
		 * @param	{Object}	oEvent	Transporter Ref Change Event
		 */
		onTransportRefChange: function (oEvent) {
			var sNewVal = oEvent.getParameter("newValue");
			this._isTransRefValid(sNewVal);
			this._bIsPRAFiledsChanged = true;
		},

		/**
		 * function to get the filter bar Object
		 * @returns	{Object}	Filter Bar Object
		 */
		getFilterBar: function () {
			this._oFilterBar = this.getOwnerComponent().getUomFilterBar();
			if (!this._oFilterBar) {
				this._oFilterBar = new UomFilterBar({
					id: "dummyFilterBar",
					objectType: "NO",
					visible: false,
					filterBarDisplayed: false
				});
				this._oFilterBar.setModel(this.getModel());
				this.getOwnerComponent().setUomFilterBar(this._oFilterBar);
			}
			return this._oFilterBar;
		},

		/**
		 * Function to get the Object reference for To Production Network Input field
		 * @returns	{Object}	To Production Network Input field Reference
		 */
		getToProdNetworkInputField: function () {
			if (!this._oToProdNetwork) {
				this._oToProdNetwork = this.byId("selToProdNetwork");
			}
			return this._oToProdNetwork;
		},

		/**
		 * Function to get the Object reference for To Network Object Type Input field
		 * @returns	{Object}	To Network Object Type Input field Reference
		 */
		getToNetobjTyDesInputField: function () {
			if (!this._oToNetobjTyDes) {
				this._oToNetobjTyDes = this.byId("selToNetobjTyDes");
			}
			return this._oToNetobjTyDes;
		},

		/**
		 * Function to get the Object reference for Network Object Input field
		 * @returns	{Object}	Network Object Input field Reference
		 */
		getToNetworkObjInputField: function () {
			if (!this._oToNetworkObj) {
				this._oToNetworkObj = this.byId("selToNetworkObj");
			}
			return this._oToNetworkObj;
		},

		/**
		 * Function to get the Object reference for Transpoter Input field
		 * @returns	{Object}	Transporter Input field Reference
		 */
		getTransporterInputField: function () {
			if (!this._oTransporter) {
				this._oTransporter = this.byId("selTransporter");
			}
			return this._oTransporter;
		},

		/**
		 * Function to get the Object reference for Transpoter Reference Input field
		 * @returns	{Object}	Transporter ReferenceInput field Reference
		 */
		getTransporterRefInputField: function () {
			if (!this._oTransRef) {
				this._oTransRef = this.byId("transportRef");
			}
			return this._oTransRef;
		},

		/**
		 * Function to get the Object reference for Originating MP Input field
		 * @returns	{Object}	Originating MP Input field Reference
		 */
		getOrigMpInputField: function () {
			if (!this._oOrigMp) {
				this._oOrigMp = this.byId("selOrigMp");
			}
			return this._oOrigMp;
		},

		/**
		 * Event handler function for measurement date/time change event
		 * This will check the validity of measurement date/time 
		 * if ok than refresh the measurement Data from backend for new date
		 */
		onMesDateTimeChange: function () {
			this._bIsPRAFiledsChanged = true;
			if (this._isMesDateTimeValid()) { //If New Measurement Date and Time are Valid than Refresh the data from backend
				this.oInputVar.FromDate = this._getMesDateInputVal();
				this.fnUpdateModel();
				this.sMode = "switch";
				this._bIsPRAFiledsChanged = false;
				this.bDataChanged = false;
				this.fnReadMeasurementData();
				this.removeAllMessages();
			}
		},

		/**
		 * function to check the validity of Measurement Date and Time,
		 * if not valid than set error state and add message to massage manager otherwise remove it
		 * @returns	{Boolean}	true/false - Weather Measurement Date and Time is valid or not
		 */
		_isMesDateTimeValid: function () {
			var oStartupParametersModel = this.getView().getModel("StartupParameters"),
				oStartupParameters = oStartupParametersModel.getData(),
				oMesDateInputObj = this.byId("idMesDate"),
				bIsMesDateTimeValid = true;
			oStartupParametersModel.setProperty("/MesDateState", ValueState.None);
			this.removeMessage(oMesDateInputObj.getId(), oStartupParametersModel);
			if (oStartupParameters.MesDate === null || oStartupParameters.MesTime === null) {
				this._addMessage(oMesDateInputObj.getId(), oMesDateInputObj.getValueStateText(), oMesDateInputObj.getValueStateText(),
					MessageType.Error, oStartupParametersModel);
				oStartupParametersModel.setProperty("/MesDateState", ValueState.Error);
				bIsMesDateTimeValid = false;
			}
			return bIsMesDateTimeValid;
		},

		/**
		 * function to get the Measurement Date and time combined value
		 * @returns	{Object}	Measurement Date Object updated with time
		 */
		_getMesDateInputVal: function () {
			var oStartupParametersModel = this.getView().getModel("StartupParameters"),
				oStartupParameters = oStartupParametersModel.getData(),
				oMesTime = oStartupParameters.MesTime,
				oMesDateTime = new Date(oStartupParameters.MesDate);
			oMesDateTime.setHours(oMesTime.getHours());
			oMesDateTime.setMinutes(oMesTime.getMinutes());
			oMesDateTime.setSeconds(oMesTime.getSeconds());
			return oMesDateTime;
		},

		/**
		 * Navigating Back to the last page in Browser History/Home Page
		 */
		_navBack: function () {
			this.removeAllMessages();
			this.navBack(); //Call navBack of Base Controller
		},

		/**
		 * Called upon destruction of Measurement view
		 * @public
		 */
		onExit: function () {
			if (this._oFilterBar) {
				this._oFilterBar.destroy();
			}
		}
	});
});