sap.ui.controller("hcm.fab.mytimesheet.HCMFAB_MY_TIMEExtension.controller.EditAssignmentCustom", {

	/**
	 * Called when a controller is instantiated and its View controls (if available) are already created.
	 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
	 * @memberOf hcm.fab.mytimesheet.HCMFAB_MY_TIMEExtension.controller.EditAssignmentCustom
	 */
	//	onInit: function() {
	//
	//	},

	/**
	 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
	 * (NOT before the first rendering! onInit() is used for that one!).
	 * @memberOf hcm.fab.mytimesheet.HCMFAB_MY_TIMEExtension.controller.EditAssignmentCustom
	 */
	//	onBeforeRendering: function() {
	//
	//	},

	/**
	 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
	 * This hook is the same one that SAPUI5 controls get after being rendered.
	 * @memberOf hcm.fab.mytimesheet.HCMFAB_MY_TIMEExtension.controller.EditAssignmentCustom
	 */
	//	onAfterRendering: function() {
	//
	//	},

	/**
	 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
	 * @memberOf hcm.fab.mytimesheet.HCMFAB_MY_TIMEExtension.controller.EditAssignmentCustom
	 */
	//	onExit: function() {
	//
	//	},

	//	onDisplayCancel: function() {
	//
	//	}
	//	onDisplayCancelConfirm: function() {
	//
	//	}
	//	handleConfirmationYesButton: function(E) {
	//
	//	}
	//	handleConfirmationNoButton: function(E) {
	//
	//	}
	//	showConfirmBox: function(E, o) {
	//
	//	}
	//	onTaskDeleteConfirm: function(E) {
	//
	//	}
	//	_onObjectMatched: function(E) {
	//
	//	}
	//	_getFormFragment: function(f) {
	//
	//	}
	//	assignmentFragment: function(f, F) {
	//
	//	}
	//	onEdit: function() {
	//
	//	}
	//	showBusy: function() {
	//
	//	}
	//	hideBusy: function(f) {
	//
	//	}
	//	_onBindingChange: function() {
	//
	//	}
	//	onNavBack: function() {
	//
	//	}
	//	onBack: function() {
	//
	//	}
	//	onCancel: function() {
	//
	//	}
	//	onValueHelp: function(E) {
	//
	//	}
	//	valueHelpFragment: function(s) {
	//
	//	}
	//	getValueHelpCollection: function(F, s) {
	//
	//	}
	//	handleClick: function(E) {
	//
	//	}
	//	onSave: function(E) {
	//
	//	}
	//	SubmitTask: function(a) {
	//
	//	}
	//	handleMessagePopover: function(E) {
	//
	//	}
	//	UpdateTask: function(a) {
	//
	//	}
	//	onTaskDelete: function(E) {
	//
	//	}

});