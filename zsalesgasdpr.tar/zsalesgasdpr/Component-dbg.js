sap.ui.define(["sap/ui/core/UIComponent", "sap/ui/Device", 
    "com/ui/crescent/zsalesgasdpr/model/models", 
    "com/ui/crescent/zsalesgasdpr/model/salesmodel", "sap/ui/model/json/JSONModel"], 
    function (e, s, t, i, o) { "use strict"; return e.extend("com.ui.crescent.zsalesgasdpr.Component", { metadata: { manifest: "json" }, init: function () { e.prototype.init.apply(this, arguments); this.getRouter().initialize(); this.setModel(t.createDeviceModel(), "device"); this.setModel(new i, "sales"); let s = new o; this.setModel(s, "oNomModel") } }) });
