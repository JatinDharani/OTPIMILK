/*
 * Copyright (C) 2009-2023 SAP SE or an SAP affiliate company. All rights reserved.
 */
/* eslint-disable max-params */
sap.ui.define([
	"oil/ups/fdcs1/controller/BaseController",
	"oil/ups/fdcs1/util/ConvertToJsonUtil",
	"oil/ups/fdcs1/util/Utility",
	"oil/ups/fdcs1/model/type/Float",
	"sap/ui/core/format/DateFormat",
	"sap/ui/core/ValueState",
	"sap/ui/core/Fragment",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/m/Dialog",
	"sap/m/BusyDialog",
	"sap/m/SelectDialog",
	"sap/m/Link",
	"sap/m/Text",
	"sap/m/TablePersoController",
	"sap/m/ObjectListItem",
	"sap/m/StandardListItem",
	"sap/m/ColumnListItem",
	"sap/m/ObjectIdentifier",
	"sap/ui/core/MessageType",
	"./DefermentEventValidator"
], function (BaseController, ConvertToJsonUtil, Utility, Float, DateFormat, ValueState, Fragment,
	JSONModel, Filter, FilterOperator, MessageBox, MessageToast, Dialog, BusyDialog, SelectDialog,
	Link, Text, TablePersoController, ObjectListItem, StandardListItem,
	ColumnListItem, ObjectIdentifier, MessageType, DefermentEventValidator) {
	/* eslint-enable max-params */
	"use strict";

	return BaseController.extend("oil.ups.fdcs1.UPS_FDCS1Extension1.controller.DefermentEventCustom",
		jQuery.extend(true, {}, DefermentEventValidator, {

			_defEvBusyDialog: null,

			/* =========================================================== */
			/* Lifecycle Methods                                           */
			/* =========================================================== */

			/**
			 * This method initializes View and its properties
			 * @method onInit
			 */
			onInit: function () {
				var oView = this.getView(),
					oCore = sap.ui.getCore(),
					oStartupParameters = new JSONModel();

				// Set the initial form to be the display one
				this.initialLoadFlag = true;
				this._defEvBusyDialog = new BusyDialog();
				this.oHeaderVariables = {
					PPAFlag: false,
					goBackOnError: false,
					sMode: "",
					PpaReqReference: ""
				};

				this.aAuditReasonCodes = [];
				this.oPPAParams = {
					AuditReasonCode: "",
					PpaAuditIndicator: "",
					PpaReqReason: "",
					ProcessType: "DEFEVENT"
				};

				this._initializeFragments();

				oView.setModel(oStartupParameters, "StartupParameters");
				this.getRouter().attachRouteMatched(this._handleRouteMatched, this);
				// attach handlers for validation errors
				oCore.attachValidationError(this._handleValidationParseError, this);
				oCore.attachValidationSuccess(function (evt) {
					var control = evt.getParameter("element");
					if (control && control.setValueState) {
						control.setValueState(ValueState.None);
					}
				});

				oCore.attachParseError(this._handleValidationParseError, this);

				// Instantiate the Message Manager
				this.initializeMessageManager(this._getEventModel());
			},

			/**
			 * This method is triggered after view is rendered
			 * @method onAfterRendering
			 */
			onAfterRendering: function () {
				this.removeAllMessages();
			},

			/* =========================================================== */
			/* Public Methods                                              */
			/* =========================================================== */

			/**
			 * Get Event, Medium and Deferment codes and set the model properties and values
			 * @param {Object}  oFormattedResData  Formatted/processed Derferment event/Codes read result data
			 * @public
			 */
			setClientModelsData: function (oFormattedResData) {
				var oEventModel = this._getEventModel(),
					oTModel2 = new JSONModel({
						MedUOMData: oFormattedResData.PNMediumUoMSet
					}),
					oTModel3 = new JSONModel({
						DeferCodeSet: oFormattedResData.DeferCodeSet
					}),
					oDefEffectTable = this.byId("idEffectTable"),
					oParameters = this.getView().getModel("StartupParameters").getProperty("/Parameters");
				//keep a backup of event data
				this._setEventCache(jQuery.extend(true, {}, oFormattedResData));
				oEventModel.setData(oFormattedResData.DeferEventSet, false);
				oEventModel.setProperty("/EventData", oEventModel.getProperty("/"));
				oEventModel.getData().oDeletedItems = {
					Effects: [],
					WorkOrders: [],
					LinkedEvents: []
				};
				this._setViewModel(oTModel2, "MedUOM");
				this._setViewModel(oTModel3, "DeferCodeModel");
				var oTModel4 = new JSONModel({
					DurationUnit: [{
						"UNIT": "P",
						"Description": "Percentage"
					}, {
						"UNIT": "T",
						"Description": "Time"
					}]
				});
				this._setViewModel(oTModel4, "DurationUnitModel");
				this._bindEffectTableOnInitialLoad();
				var oTabBinding = oDefEffectTable.getBinding("items");
				oTabBinding.attachChange(this._changeEffectTabBinding, this);
				if (oParameters.WorkOrder && oParameters.WorkOrder !== "" && oParameters.Mode === "Change") {
					this.setDataForWorkOrders(oParameters);
				}
				var oBundle = this.getResourceBundle(),
					oEventPPA = this.getView().getModel("EventModel");
				if (oEventPPA.getProperty("/EventData/PPALock")) {
					if (oEventPPA.getProperty("/EventData/PPARequesterFlag")) {
						oEventPPA.setProperty("/EventData/PPAStatus", oBundle.getText("PPA_PENDING_BY_OTHER"));
					} else {
						oEventPPA.setProperty("/EventData/PPAStatus", oBundle.getText("PPA_PENDING_BY_USER", oEventPPA.getProperty(
							"/EventData/PPARequester")));
					}
					oEventPPA.setProperty("/EventData/Lock", "sap-icon://locked");
				}
				this.setHeaderFooter(oParameters.Mode, oEventPPA.getProperty("/EventData/PPALock"));
			},

			/**
			 * This function si called to set the work order data
			 * @param {Object}  oParameters  paramters data object
			 * @public
			 */
			setDataForWorkOrders: function (oParameters) {
				var oFromDateTime = this.getDateFromTimestampString(oParameters.ProdStrtDate),
					oToDateTime = this.getDateFromTimestampString(oParameters.ProdEndDate),
					oDateFormat = this._getDateFormat(),
					oTimeFormat = this._getTimeFormat();
				this._setEventDataProperty("/Tplnr", oParameters.netObjId);
				this._setEventDataProperty("/DefCode", oParameters.DefCode);
				this._setEventDataProperty("/StrtPeriod", oParameters.ProdStrtDate);
				this._setEventDataProperty("/EndPeriod", oParameters.ProdEndDate);
				this._setEventDataProperty("/strtPeriodDate", oDateFormat.format(oFromDateTime));
				this._setEventDataProperty("/strtPeriodTime", oTimeFormat.format(oFromDateTime));
				this._setEventDataProperty("/EndPeriodDate", oDateFormat.format(oToDateTime));
				this._setEventDataProperty("/EndPeriodTime", oTimeFormat.format(oToDateTime));
				this._setEventDataProperty("/WorkOrder", oParameters.WorkOrder);
				this.validateDefermentCode();
				this.getWorkOrder();
			},

			/**
			 * This function is called to read work order details for the event from data
			 * base/backend server
			 * @public
			 */
			getWorkOrder: function () {
				var oEventData = this._getEventModel().getData(),
					oDataModel = this.getModel(),
					aFilters = [
						new Filter("Tplnr", FilterOperator.EQ, oEventData.Tplnr),
						new Filter("StartDate", FilterOperator.GE, oEventData.StrtPeriod),
						new Filter("EndDate", FilterOperator.LE, oEventData.EndPeriod),
						new Filter("WorkOrder", FilterOperator.EQ, oEventData.WorkOrder)
					];

				if (this.getPRASwitch()) {
					aFilters.push(new Filter("NetobjType", FilterOperator.EQ,
						this.getView().getModel("StartupParameters").getProperty("/Parameters/NetObjTyp")));
				}

				oDataModel.read("/PMWorkOrdersSet", {
					filters: aFilters,
					success: this._onWorkOrderReadSuccess.bind(this),
					error: this._onWorkOrderReadError.bind(this)
				});
			},

			/**
			 * Sets the Header and Footer
			 * The Title of the Page will vary based on operation as for Create and Edit functionality
			 * This method accepts the page mode sets the particular page title and footer buttons
			 * @param {string}  sDispFlag  mode of the current view Create/edit/Display
			 * @param {boolean}  PPALock  PPA lock flag
			 * @public
			 */
			setHeaderFooter: function (sDispFlag, PPALock) {
				var oBundle = this.getResourceBundle(),
					oView = this.getView(),
					sPageTitle;
				var oStartupParametersModel = oView.getModel("StartupParameters"),
					oEventModelData = oView.getModel("EventModel").getData();
				this.byId("defEvent").setShowFooter(true);
				this.byId("errorMessageBtn").setVisible(false);
				this.byId("saveBtn").setVisible(true);
				this.byId("cancelBtn").setVisible(true);
				this.byId("idTxtEvntNumber").setVisible(true);
				this.byId("idTxtEvntType").setVisible(true);
				this.byId("editBtn").setVisible(false);
				this.byId("delBtn").setVisible(false);
				if (sDispFlag === "Change") {
					sPageTitle = "PAGE_TITLE_NE";
					//Hide Event Number and Event Type on Create as they Does not exist on create
					this.byId("idTxtEvntNumber").setVisible(false);
					this.byId("idTxtEvntType").setVisible(false);
				} else if (sDispFlag === "Edit") {
					sPageTitle = "PAGE_TITLE_EV";
				} else {
					sPageTitle = "PAGE_TITLE_VE";
					this.byId("defEvent").setShowFooter(false);
					//this.byId("errorMessageBtn").setVisible(false);
					this.byId("saveBtn").setVisible(false);
					this.byId("cancelBtn").setVisible(false);
					if (oEventModelData.AuthUpdate && oEventModelData.AuthUpdate === true) {
						this.byId("editBtn").setVisible(true);
					}
					if (oEventModelData.AuthDelete && oEventModelData.AuthDelete === true) {
						this.byId("delBtn").setVisible(true);
					}
					if (PPALock) {
						this.byId("editBtn").setEnabled(false);
						this.byId("delBtn").setEnabled(false);
					} else {
						this.byId("editBtn").setEnabled(true);
						this.byId("delBtn").setEnabled(true);
					}
				}
				oStartupParametersModel.setProperty("/PageTitle", oBundle.getText(sPageTitle));
			},

			/**
			 * Event Handler for Save/Edit button press
			 * @param {sap.ui.base.Event}  oEvent  Save/Edit button press events
			 * @public
			 */
			onClickHandleSaveEdit: function (oEvent) {
				this.removeAllMessages();
				if (this.oHeaderVariables.sMode === "Change" || this.oHeaderVariables.sMode === "Edit") {
					this.onSavePress(oEvent);
				} else {
					this.onEditPress(oEvent);
				}
			},

			/**
			 * Event Handler for Cancel/Delete button press
			 * @param {sap.ui.base.Event}  oEvent  Cancel/Delete button press events
			 * @public
			 */
			onClickHandleDeleteCancel: function (oEvent) {
				if (this.oHeaderVariables.sMode === "Change" || this.oHeaderVariables.sMode === "Edit") {
					this.onCancelPress(oEvent);
				} else {
					this.onDeletePress(oEvent);
				}
			},

			/**
			 * Checks whether effect detail table is collapsible or not
			 * @param {boolean}  isCollapsed  Weather Collapsed or Expanded
			 * @param {boolean}  bShowErrorMessage  Weather to show error message or not
			 * @returns {boolean}  true/false weather table effective is ok or not
			 * @public
			 */
			fnCheckEffectTableCollapsable: function (isCollapsed, bShowErrorMessage) {
				var aTempEffectExpanded = this.createDeferEffectExpands(isCollapsed),
					aTempDeferEffect = [],
					oValidateEffectValue,
					sTargetUnit,
					sTargetValue;
				var oResourceBundle = this.getResourceBundle();

				for (var j = 0; j < aTempEffectExpanded.length; j++) {
					if (aTempEffectExpanded[j].EffectMedium !== "ALL") {
						aTempDeferEffect.push(aTempEffectExpanded[j]);
					}
				}
				// Check for valid values for Deferment effect values
				/*if (this.validateEffectValues(aTempDeferEffect) !== 1) {
				  return false;
				}*/
				oValidateEffectValue = this.validateEffectValues(aTempDeferEffect);
				if (oValidateEffectValue.messageType === "E") {
					if (bShowErrorMessage) {
						this._addMessage(oValidateEffectValue.sTarget, oValidateEffectValue.MessageKey,
							oValidateEffectValue.Message.Key, MessageType.Error);
					} else {
						this._removeMessage(oValidateEffectValue.sTarget);
					}
					return false;
				}
				for (var i = 0; i < aTempDeferEffect.length; i++) {
					// Validation 1: Check if any of the effect medium units is not %
					// Minimizing or collapse is possible if all the effect medium units are %. else do not collapse
					if (aTempDeferEffect[i].CollapEffectUnit !== "%" && !isCollapsed) {
						sTargetUnit = "/DeferEffectsSet/" + i + "/" + this._getEffectFragBindingPathByFieldName("idDefEffUnitSel");
						if (bShowErrorMessage) {
							this._addMessage(sTargetUnit, oResourceBundle.getText("EFFECT_UNITS_DIFF"), oResourceBundle.getText(
								"EFFECT_UNITS_DIFF"), MessageType.Error);
						} else {
							this._removeMessage(sTargetUnit);
						}

						return false;
					}
					// Validation 2: Check the for each effect, 
					//the mediums have the same value Minimizing or collapse if possible if for each effect the mediums have same value
					if (i !== aTempDeferEffect.length - 1) {
						// Do not check for the value as this is the last row in the effects. 
						// Hence there is no need to check the value of it further.
						// Its value has been checked already
						if ((aTempDeferEffect[i].EffectSeq === aTempDeferEffect[i + 1].EffectSeq) &&
							(aTempDeferEffect[i].CollapEffectVal !== aTempDeferEffect[i + 1].CollapEffectVal)) {
							sTargetValue = "/DeferEffectsSet/" + i + "/" + this._getEffectFragBindingPathByFieldName("idDefEfftDurEfftVal");
							if (bShowErrorMessage) {
								//add message
								this._addMessage(sTargetValue, oResourceBundle.getText("EFFECT_VALUES_DIFFER"), oResourceBundle.getText(
									"EFFECT_VALUES_DIFFER"), MessageType.Error);
							} else {
								this._removeMessage(sTargetValue);
							}
							return false;
						}
					}
				}
				return true;
			},

			/**
			 * Handles the expand/collapse for table
			 * @param {sap.ui.base.Event}  oEvent  expand/collapse for table
			 * @public
			 */
			handleExpandCollapse: function (oEvent) {
				var isCollapsed = this._getEffectCollapsed(),
					isCollapsable = this._isEffectTableCollapsable(this.oHeaderVariables.sMode);
				if (!isCollapsed && isCollapsable) {
					this._setEffectCollapsed(true);
				} else if (!isCollapsed && !isCollapsable) {
					//add information message
					this.fnShowInfoMessage("NOT_COLLAPSABLE");
					return;
				} else {
					this._setEffectCollapsed(false);
				}
				this._showTableFragment(this.oHeaderVariables.sMode, isCollapsed);
			},

			/**
			 * Function to check whether duration unit is percent or not
			 * @param {string}  sDurationUnit  Duration unit text string code
			 * @returns {boolean} true/false whether duration is percent or not
			 * @public
			 */
			changeToPercent: function (sDurationUnit) {
				if (sDurationUnit === "P") {
					return true;
				}
				return false;
			},

			/**
			 * Function to check whether duration unit is time or not
			 * @param {string}  sDurationUnit  Duration unit text string code
			 * @returns {boolean} true/false whether duration is time or not
			 * @public
			 */
			changeToTime: function (sDurationUnit) {
				if (sDurationUnit === "T") {
					return true;
				}
				return false;
			},

			/**
			 * Returns Event Type text/description based on Event type code value
			 * @param {string}  sEventType  Event type code
			 * @returns {string}  Event type text based on Code
			 * @public
			 */
			fnEventTypeFormatter: function (sEventType) {
				var oBundle = this.getResourceBundle();
				if (sEventType === "U") {
					return oBundle.getText("UNPLANNED_QTY");
				} else {
					return oBundle.getText("PLANNED_QTY");
				}
			},

			/**
			 * Formatter function to show duration as percentage or in days,hours,mins
			 * @param {string}  Perc  percent value
			 * @param {string}  Day  Day
			 * @param {string}  Hour  Hours
			 * @param {string}  Min  Minutes
			 * @returns {string}  formatted text string percentage or day/hrs/mins
			 */
			defEvntEfftDurationFormatter: function (Perc, Day, Hour, Min) {
				if (Day === "" && Hour === "" & Min === "") {
					return jQuery.sap.formatMessage("{0} %", [Perc]);
				} else {
					return this.getResourceBundle().getText("EFFECT_DURATION_DISP", [Day, Hour, Min]);
				}
			},

			/**
			 * Returns Deferment Type text/description based on Deferment type code value
			 * @param {string}  sDefType  Event type code
			 * @returns {string}  Deferment type text based on Code
			 * @public
			 */
			defermentTypeFormatter: function (sDefType) {
				var oBundle = this.getResourceBundle();
				if (sDefType === "U") {
					return oBundle.getText("UNPLANNED_QTY");
				} else {
					return oBundle.getText("PLANNED_QTY");
				}
			},

			/**
			 * Deferment code Select event handler
			 * @param {sap.ui.base.Event}  oEvent  Deferment code Select event
			 */
			onSelectDeferCode: function (oEvent) {
				var sValueDeferCode = oEvent.getParameter("selectedItem").getKey();
				oEvent.getSource().setValue(sValueDeferCode);
			},

			/**
			 * Function to handle a new effect row addition in effects table
			 */
			addEventEffect: function () {
				var oEventModel = this.getView().getModel("EventModel");
				if (this.validateDefermentCode() && this._validateDates()) {
					var oEffectEventData = oEventModel.getData();
					var oNewEffectEventData = ConvertToJsonUtil.getNewEventEffect();
					var iLength = oEffectEventData.DeferEffectsSet.length;
					var sSlNo;
					if (iLength) {
						sSlNo = Number(oEffectEventData.DeferEffectsSet[iLength - 1].UIEffectSeq) + 1 + "";
					} else {
						sSlNo = 1 + "";
					}
					oNewEffectEventData.DeferEffectsSet[0].UIEffectSeq = sSlNo;
					oEffectEventData.DeferEffectsSet.push(oNewEffectEventData.DeferEffectsSet[0]);
					oEventModel.setProperty("/EventData/DeferEffectsSet", oEffectEventData.DeferEffectsSet);
					this.handleUpdateTracking();
					this._changeEffectTabBinding();
				} else {
					this._showMessages();
				}
			},

			/**
			 * Funtion to handle On click of Delete Icon in Effects Details table on a Row, Deleting particular row
			 * @param {sap.ui.base.Event}  oEvent  delete table row event
			 */
			deleteEventEffect: function (oEvent) {
				var aEffects, oRemovedRow;
				if (this.oHeaderVariables.sMode === "Edit" || this.oHeaderVariables.sMode === "Change") {
					var index = oEvent.getSource().indexOfItem(oEvent.getParameter("listItem"));
					aEffects = this._getEventDataProperty("/DeferEffectsSet");
					oRemovedRow = aEffects.splice(index, 1)[0];
					aEffects = this.updateUIEffectSeq(index, aEffects);
					this._setEventDataProperty("/DeferEffectsSet", aEffects);
					if (oRemovedRow.EventId) {
						this._getEventModel().getData().oDeletedItems.Effects.push(oRemovedRow);
					}
					this.handleUpdateTracking();
					this._changeEffectTabBinding();
				}
			},

			/**
			 * Function used to set EventEffectSeq for Event Effects. 
			 * @param	{string}	index		index of effects seq
			 * @param	{Array}		aEffects	Effects Array
			 * @returns	{Array}					Effects Array with updated sequence
			 */
			updateUIEffectSeq: function (index, aEffects) {
				var i;
				for (i = index; i < aEffects.length; i++) {
					aEffects[i].UIEffectSeq = aEffects[i].UIEffectSeq - 1;
				}
				return aEffects;
			},

			/**
			 * Function to open Deferment Code dialog
			 */
			openDefermentCodeDialog: function () {
				var sFragId;
				if (!this._defCodeDialog) {
					sFragId = this.createId("idDefCodeDialogFrag");
					this._defCodeDialog = sap.ui.xmlfragment(sFragId, "oil.ups.fdcs1.fragments.DefermentCode", this);
					this.getView().addDependent(this._defCodeDialog);
				}
				this._defCodeDialog.setModel(this.getView().getModel("DeferCodeModel"));
				this._defCodeDialog.open();
			},

			/**
			 * Funtion to check the Deferment code remediation flag weather over or under production
			 * @param	{string}	remFlag	Deferment remediation flag
			 * @returns	{string}			Over/Under production text string
			 */
			defCodeRemidiationFlagCheck: function (remFlag) {
				var oBundle = this.getResourceBundle(),
					sRemMsgKey;
				if (remFlag !== "") {
					sRemMsgKey = "OVER_PROD";
				} else {
					sRemMsgKey = "UNDER_PROD";
				}
				return oBundle.getText("DEFERMENT_TYPE", [oBundle.getText(sRemMsgKey), oBundle.getText("PRODUCTION")]);
			},

			/**
			 * Function to check Deferment Code set value, If the current node is also a Parent node, 
			 * then the current node will not be a leaf node - Hence display navigation pattern
			 * If leaf node, set type as Active
			 * @param	{string}	isChild	Identification Code for Child Node
			 * @returns	{string}			Navigation/Active pattern
			 */
			defCodeParentChildCheck: function (isChild) {
				if ($.grep(this.getView().getModel("DeferCodeModel").getData().DeferCodeSet,
						function (v) {
							return v.ParentCode === isChild;
						}).length > 0) {
					// If the current node is also a Parent node, then the current node will not be a leaf node.Hence display navigation pattern
					return "Navigation";
				} else { // If leaf node, set type as Active
					return "Active";
				}
			},

			/**
			 * Funtion to Display the Duration from Start date to End Date, LiveChange based on To date selection
			 * @param {sap.ui.base.Event}  oEvent  Date Selection change event
			 */
			onDateTimeChange: function (oEvent) {
				this._validateDates();
				this.handleUpdateTracking();
			},

			/**
			 * Function to Find the parent of the deferment code entered (sValue)
			 * @param	{Object} oModelSet	Deferment code model data set 
			 * @param	{string} sValue		Deferment code value to be looked for
			 * @returns  {string}			Parent Deferment code of the sValue
			 */
			findParentDefCode: function (oModelSet, sValue) {
				var parentDefCode = "";
				var y = $.grep(oModelSet, function (v) {
					return v.DefCode === sValue;
				});
				if ((y !== null) && (y.length > 0)) {
					parentDefCode = y[0].ParentCode;
				}
				return parentDefCode;
			},

			/**
			 * Callback function to handle the OK button action
			 * Set the user selected code in the local dataModel and clear the filers. Close the dailog
			 * @param {sap.ui.base.Event}  oEvent  User click event
			 */
			onDefCodeDialogConfirmButton: function (oEvent) {
				var resourseBundle = this.getResourceBundle(),
					oData = this.getView().getModel("DeferCodeModel").getData(),
					oDefCodeTable = this.byId(Fragment.createId("idDefCodeDialogFrag", "idDefCodeDialogTable")),
					oBreadcrumbs = this.byId(Fragment.createId("idDefCodeDialogFrag", "idDefCodeDialogBreadcrumbs")),
					oSelectedListItem = oDefCodeTable.getSelectedItem();
				if (oSelectedListItem) {
					var sDefCode = oSelectedListItem.getBindingContext().getProperty("DefCode"),
						sDefCodeDesc = oSelectedListItem.getBindingContext().getProperty("Description");
					this.getView().getModel("EventModel").setProperty("/EventData/DefCode", sDefCode);
					this.getView().getModel("EventModel").setProperty("/EventData/DefCodeDescription", sDefCodeDesc);
					this.validateDefermentCode();
				}
				oDefCodeTable.getBinding("items").filter([new Filter("ParentCode", FilterOperator.EQ, "")]);
				this._defCodeDialog.close();

				oBreadcrumbs.removeAllLinks();
				oBreadcrumbs.addLink(new Link({
					text: resourseBundle.getText("BASE_DEF_CODE_LVL"),
					press: [this.onClickLink, this]
				}));
				oData.sValuePre = "";
				this.handleUpdateTracking();
			},

			/**
			 * Callback function to handle the close of dialpog or cancel button action 
			 * Clear the filer, header toolbar and close the dialog
			 * @param {sap.ui.base.Event}  oEvent  User click event
			 */
			onDefCodeDialogCloseButton: function (oEvent) {
				var resourseBundle = this.getResourceBundle(),
					oData = this.getView().getModel("DeferCodeModel").getData(),
					oDefCodeTable = this.byId(Fragment.createId("idDefCodeDialogFrag", "idDefCodeDialogTable")),
					oBreadcrumbs = this.byId(Fragment.createId("idDefCodeDialogFrag", "idDefCodeDialogBreadcrumbs"));
				oDefCodeTable.getBinding("items").filter([new Filter("ParentCode", FilterOperator.EQ, "")]);
				this._defCodeDialog.close();
				oDefCodeTable.removeSelections(true);
				this._defCodeDialog.getBeginButton().setEnabled(false);
				oBreadcrumbs.removeAllLinks();
				oBreadcrumbs.addLink(new Link({
					text: resourseBundle.getText("BASE_DEF_CODE_LVL"),
					press: [this.onClickLink, this]
				}));
				oData.sValuePre = "";
			},

			/**
			 * Function to handle the navigation from the header toolbar click event. 
			 * On click, fetch the Deferment code that is clicked (from link) and use it to filter the model associated with table.
			 * First adjust the header links on toolbar and then set the filter Base level is the level 0
			 * @param {sap.ui.base.Event}  oEvent  User click event on Navigation link
			 */
			onClickLink: function (oEvent) {
				var oData = this.getView().getModel("DeferCodeModel").getData(),
					oBreadcrumbs = this.byId(Fragment.createId("idDefCodeDialogFrag", "idDefCodeDialogBreadcrumbs")),
					oDefCodeTable = this.byId(Fragment.createId("idDefCodeDialogFrag", "idDefCodeDialogTable")),
					oBinding = oDefCodeTable.getBinding("items"),
					sValue = oEvent.getSource().getText(),
					aBreadcrumbsLinksArr = oBreadcrumbs.getLinks(),
					iTempIndex = aBreadcrumbsLinksArr.indexOf(oEvent.getSource());
				aBreadcrumbsLinksArr.splice(iTempIndex + 1);
				oBreadcrumbs.removeAllLinks();
				for (var i = 0; i < aBreadcrumbsLinksArr.length; i++) {
					oBreadcrumbs.addLink(aBreadcrumbsLinksArr[i]);
				}
				if (oBreadcrumbs.getLinks().length === 1) {
					sValue = "";
					oData.sValuePre = "";
				}
				oBinding.filter([new Filter("ParentCode", FilterOperator.EQ, sValue)]);
			},

			/**
			 * Selection Change event handler for Deferment Code selection table
			 * @param {sap.ui.base.Event}  oEvent  Deferment code selection change event
			 */
			handleDefCodeSelectionChange: function (oEvent) {
				oEvent.getSource().getParent().getBeginButton().setEnabled(true);
			},

			/**
			 * For each selection on , moving down the hirearchy tree as
			 * per clicks till you reach the child node
			 * @param {sap.ui.base.Event}  oEvent  Deferment code item press event
			 */
			handleDefCodeItemPressed: function (oEvent) {
				var sNavigationType = oEvent.getSource().getType();
				var sValue = oEvent.getSource().getBindingContext().getProperty("DefCode");
				this._onDefCodeChangeTableBinding(sNavigationType, sValue);
			},

			/**
			 * Deferment Code change event handler, Check validation for new deferment code	
			 * @param {sap.ui.base.Event}  oEvent  Deferment Code change event
			 */
			onChangeDefermentCode: function (oEvent) {
				this.validateDefermentCode();
				this.handleUpdateTracking();
			},

			/**
			 * Function to check if work orders date reside between event period (Start date and end date)
			 * If not return false, else return true
			 * @param	{Array} 	aWorkOrderPlanset	Work order set
			 * @returns {boolean}	Returns true if there is overlap else returns false
			 */
			checkWorkOrderOverLap: function (aWorkOrderPlanset) {
				var oEventStartPeriod = this._getFromDateTimeValue(),
					oEventEndPeriod = this._getToDateTimeValue(),
					oWOStartPeriod,
					oWOEndPeriod;
				for (var i = 0; i < aWorkOrderPlanset.length; i++) {
					if (oEventStartPeriod !== null && oEventEndPeriod !== null) {
						oWOStartPeriod = this._getDateTimeFormat().parse(aWorkOrderPlanset[i].PlanStart);
						oWOEndPeriod = this._getDateTimeFormat().parse(aWorkOrderPlanset[i].PlanEnd);
						if (oWOStartPeriod !== null && oWOEndPeriod !== null &&
							oEventEndPeriod >= oWOStartPeriod && oEventStartPeriod <= oWOEndPeriod) {
							return true;
						}
					} else {
						return true;
					}
				}
				return false;
			},

			/**
			 * Function to handle effect expand button  
			 * @param	{boolean}	isCollapsed	Weather Deferment is is collapsed or not
			 * @returns	{Array}		Array of Deferment Effects
			 */
			createDeferEffectExpands: function (isCollapsed) {
				var oTempDeferEffects = this.getView().getModel("EventModel").getProperty("/DeferEffectsSet"),
					oTempDeferExpands = [],
					bEffectValuesSame;
				for (var i = 0; i < oTempDeferEffects.length; i++) {
					var oTempEffectValSet = oTempDeferEffects[i].EffectValSet;
					var oTempMediums = oTempDeferEffects[i].EffectMediumSet;
					if (this.oHeaderVariables.sMode !== "Edit") {
						oTempDeferEffects[i].EffectSeq = String(i + 1);
					}
					bEffectValuesSame = this._isEffectValuesSame(oTempEffectValSet);
					for (var j = 0; j < oTempEffectValSet.length; j++) {
						var oTempDefer = $.extend({}, oTempDeferEffects[i]);
						if (isCollapsed && bEffectValuesSame) {
							oTempEffectValSet[j].EffectValChar = String(oTempDefer.CollapEffectVal);
						} else {
							oTempDeferEffects[i].CollapEffectVal = oTempEffectValSet[j].EffectValChar;
						}
						oTempDefer.EffectMedium = oTempMediums[j].Medium;
						oTempDefer.CollapEffectVal = String(oTempEffectValSet[j].EffectValChar);
						if (this.oHeaderVariables.sMode === "Edit" && this.byId("idButtonExpand").getVisible()) {
							oTempDefer.CollapEffectUnit = oTempEffectValSet[j].EffectUnit;
						} else {
							oTempDefer.CollapEffectUnit = oTempEffectValSet[j].SelEffectUnit;
						}
						oTempDeferExpands.push(oTempDefer);
					}
				}
				return oTempDeferExpands;
			},

			/**
			 * Function which is called when user clicks on the save button
			 * @param {sap.ui.base.Event}  oEvent  save butotn press event
			 */
			onSavePress: function (oEvent) {
				var oODataModel = this.getModel(),
					oEventData = this._getEventDataProperty("/EventData"),
					oDeferEventData,
					attribute = "",
					key = "",
					aBatchCalls = [],
					sGroupId = "DefEventBatchCallsGroup";

				if (!this._performOnSaveValidations()) {
					this._showMessages();
					return;
				}
				for (attribute in oEventData) {
					if (Object.prototype.toString.call(oEventData[attribute]) === "[object Array]" && oEventData[attribute].length > 0) {
						for (key in oEventData[attribute]) {
							if (oEventData[attribute][key] !== undefined) {
								oEventData[attribute][key].EventId = oEventData.EventId;
							}
						}
					}
				}
				oDeferEventData = this._getFinalData(oEventData);
				if (this.oHeaderVariables.sMode === "Edit" && !this.isChanged) {
					this._showError({
						messageKey: "NO_CHANGES_UPDATE",
						titleKey: "NO_CHANGES"
					}, false, {});
				} else if (this._setErrorCount() > 0) {
					this._openOrCloseMsgPopOver(true);
					return;
				} else {
					oODataModel.setDeferredGroups([sGroupId]);
					this._defEvBusyDialog.open();
					this.oHeaderVariables.sMode  = "save";
				
					if (this.oHeaderVariables.sMode === "Edit") {
						aBatchCalls = this._createBatchOperationsForEdit(oDeferEventData, sGroupId);
					} else {
						aBatchCalls = this._createBatchOperationsForSave(oDeferEventData, sGroupId);
					}
					oODataModel.setUseBatch(true);
					oODataModel.submitChanges({
						groupId: sGroupId
					});
					jQuery.when.apply(this, aBatchCalls)
						.done(function () {
							if (this.oHeaderVariables.sMode === "Edit") {
								this._onSuccessEventEdit.apply(this, arguments);
							} else {
								this._onSuccessEventSave.apply(this, arguments);
							}
						}.bind(this))
						.fail(function () {
							if (this.oHeaderVariables.sMode === "Edit") {
								this._onErrorEventEdit.apply(this, arguments);
							} else {
								this._onErrorEventSave.apply(this, arguments);
							}
						}.bind(this));
				}
			},

			/**
			 * Function which is called when user clicks on the cancel button
			 * @param {sap.ui.base.Event}  oEvent  Cancel button press event
			 */
			onCancelPress: function (oEvent) {
				if (this.isChanged) {
					if (this.oHeaderVariables.sMode === "Edit") {
						this._showWarningOnCancel("Edit");
					} else {
						this._showWarningOnCancel("Change");
					}
				} else {
					if (this.oHeaderVariables.sMode === "Edit") {
						this._setToDisplayModeOnCancel("Display");
					} else {
						this._navBack();
					}
				}
			},

			/** Function is called when delete button is pressed
			 * @param {sap.ui.base.Event}  oEvent  Delete button press event
			 */
			onDeletePress: function (oEvent) {
				var oBundle = this.getResourceBundle();
				var msg = oBundle.getText("EVENT_DELETE_CONFIRM");
				var msgTitle = oBundle.getText("EVENT_DELETE_TITLE");
				var fnClose = jQuery.proxy(function (oResult) {
					if (oResult === MessageBox.Action.OK) {
						this.fnDeleteDefEvent();
					}
				}, this);
				MessageBox.confirm(msg, {
					title: msgTitle,
					onClose: fnClose
				});
			},

			/**
			 * Function to create the query parameters object
			 * @returns	{Object}	query parameters JSON object
			 */
			fnCreateQueryParam: function () {
				var PPAData = this.getView().getModel("EventModel").getProperty("/PPAResponseData");
				return {
					ChangeStartPeriod: PPAData.ChangeStartPeriod,
					ChangeEndPeriod: PPAData.ChangeEndPeriod,
					EligibilityIndi: PPAData.EligibilityIndi,
					EventId: PPAData.EventId,
					NetObjId: PPAData.NetobjId,
					PpaAuditIndicator: this.oPPAParams.PpaAuditIndicator,
					AuditReasonCode: this.oPPAParams.AuditReasonCode,
					PpaReasonDesc: this.oPPAParams.PpaReqReason,
					ProcessType: this.oPPAParams.ProcessType
				};
			},

			/**
			 * Function to handle event delete after PPA pop-up confirm button is pressed
			 */
			fnDeleteDefEventOnPPAConfirm: function () {
				var oOdataModel = this.getView().getModel(),
					eventData = this.getView().getModel("EventModel").getProperty("/EventData"),
					etag = this.getView().getModel("EventModel").getProperty("/EventData/__metadata/etag"),
					sDelGroupId = "DelDefEevntGrp",
					aBatchCalls = [],
					oDefEventDelExecuted = jQuery.Deferred(),
					contextPath = oOdataModel.createKey("/DeferEventSet", {
						"EventId": eventData.EventId
					});
				this.oHeaderVariables.PpaReqReference = "";

				oOdataModel.setDeferredGroups([sDelGroupId]);
				aBatchCalls.push(this._ppaAuditFuncCall(sDelGroupId));
				oOdataModel.remove(contextPath, {
					eTag: etag,
					groupId: sDelGroupId,
					success: oDefEventDelExecuted.resolve,
					error: oDefEventDelExecuted.reject
				});
				aBatchCalls.push(oDefEventDelExecuted.promise());
				oOdataModel.setUseBatch(true);
				this._defEvBusyDialog.open();
				oOdataModel.submitChanges({
					groupId: sDelGroupId
				});

				jQuery.when.apply(this, aBatchCalls)
					.done(function () {
						this.onDelDefEventOnPPAConfirmSuccess.apply(this, arguments);
					}.bind(this))
					.fail(function (oError) {
						this.onDelDefEventOnPPAConfirmError(oError);
					}.bind(this));
			},
			/**
			 * Callback function for successful deletion of deferement event data on PPA Confirmation
			 */
			onDelDefEventOnPPAConfirmSuccess: function () {
				var sMsg,
					oBundle = this.getResourceBundle();
				this._defEvBusyDialog.close();
				if (this.oPPAParams.PpaAuditIndicator === "06") {
					sMsg = oBundle.getText("EVENT_DELETE");
				} else {
					sMsg = oBundle.getText("SUCCESSFUL_SUBMIT_PPA");
				}
				jQuery.sap.delayedCall(1000, this, this._showToastMessage, [sMsg]);
				this._navBack();
			},
			/**
			 * Callback function for Error on deletion of deferement event data on PPA Confirmation
			 * @param	{Object}	oError	Error Objetc on Deferment Events Data
			 */
			onDelDefEventOnPPAConfirmError: function (oError) {
				this._defEvBusyDialog.close();
				var sMsg;
				var err = JSON.parse(oError.responseText);
				if (oError.statusCode >= 400 || oError.statusCode <= 500) {
					sMsg = err.error.message.value;
					this._showError({
						messageKey: sMsg,
						titleKey: sMsg
					}, false, {}, function () {
						this.oPPADialog.close();
					}.bind(this));
				}
			},

			/**
			 * Callback function for PPA dialog Confirmaiton, this Is used to delete the current Deferment Event.
			 */
			fnDeleteDefEvent: function () {
				var etag = this.getView().getModel("EventModel").getProperty("/EventData/__metadata/etag");
				var eventId = this.getView().getModel("StartupParameters").getProperty("/Parameters/eventId");
				var sPath = "/DeferEventSet('" + eventId + "')";
				this.getView().getModel().remove(sPath, {
					eTag: etag,
					success: this.onDeleteDefEventSuccess.bind(this),
					error: this.onDeleteDefEventError.bind(this)
				});
			},

			/**
			 * Callback function for deferment event delete success
			 */
			onDeleteDefEventSuccess: function () {
				var oBundle = this.getResourceBundle(),
					sMsg = oBundle.getText("EVENT_DELETE");
				jQuery.sap.delayedCall(1000, this, this._showToastMessage, [sMsg]);
				this._navBack();
			},
			/**
			 * Callback function for deferment event delete error
			 * @param	{Object}	oError	defermetn event delete Error Response Object
			 */
			onDeleteDefEventError: function (oError) {
				var sMsg;
				var err = JSON.parse(oError.responseText);
				if (oError.statusCode >= 400 || oError.statusCode <= 500) {
					sMsg = err.error.message.value;
				}
				var errorDetails = err.error.innererror.errordetails;
				if (errorDetails && errorDetails.length > 0) {
					switch (errorDetails[0].code) {
					case "GHO_DEFERMENT_BO/054":
						this.oHeaderVariables.PpaReqReference = "DELETE";
						this.openPPADialog();
						break;
					case "GHO_DEFERMENT_BO/055":
						this.oHeaderVariables.PpaReqReference = "DELETE";
						this.openAuditDialog();
						break;
					case "GHO_DEFERMENT_BO/056":
						this.fnShowInfoMessage("PPA_APPROV_PENDING");
						break;
					case "GHO_DEFERMENT_BO/057":
						this.fnShowInfoMessage("PPA_APPROV_REJECTED");
						break;
					default:
						sMsg = errorDetails[0].message;
						this.oHeaderVariables.goBackOnError = true;
						this._showError({
							messageKey: sMsg,
							titleKey: sMsg
						}, false, {});
					}
				} else {
					this.oHeaderVariables.goBackOnError = true;
					this._showError({
						messageKey: sMsg,
						titleKey: sMsg
					}, false, {});
				}
			},

			/**
			 * Event Handler for Edit button
			 * @param {sap.ui.base.Event}  oEvent  edit button press event
			 */
			onEditPress: function (oEvent) {
				this.oHeaderVariables.sMode = "Edit";
				this._renderUI("Change");
				this._changeEffectTableForEdit();
				this.setHeaderFooter("Edit");
			},

			/**
			 * This method is executed for opening an PPA popup
			 * @param {sap.ui.base.Event}  oEvent  value help event
			 * @param {boolean} bAuditCalled check for audit reason code read call
			 * @param {object} oAuditCodeData Audit reason codes data from backend
			 */
			openPPADialog: function (oEvent, bAuditCalled, oAuditCodeData) {
				var oAuditInput, oBtn, oDefAuditCode, oAuditCodes,
					aAuditCodeCallPromises = [],
					sAuditCodeGrpId = "AuditCodeCall",
					oModel = this.getModel();

				if (bAuditCalled && bAuditCalled === true && oAuditCodeData) {
					this.aAuditReasonCodes = oAuditCodeData.results;
					oAuditCodes = new JSONModel({
						AuditCodeSet: this.aAuditReasonCodes
					});
					this.getView().setModel(oAuditCodes, "AuditCodes");
					this.isAudit = false;
					if (!this.oPPADialog) {
						var sPPAFragId = this.createId("PPADialogFragment");
						this.oPPADialog = sap.ui.xmlfragment(sPPAFragId, "oil.ups.fdcs1.fragments.PPADialog", this);
					}
					this.getView().addDependent(this.oPPADialog);
					this.oPPADialog.setModel(this.getView().getModel("AuditCodes"));
					oDefAuditCode = this._getAuditReasonCode(this.aAuditReasonCodes, true);
					this.oPPADialog.open();
					oBtn = this.byId(Fragment.createId("PPADialogFragment", "idPPABeginBtn"));
					oAuditInput = this.byId(Fragment.createId("PPADialogFragment", "reasonCodeInput"));
					oAuditInput.setValueState("None").setValueStateText("");
					if (oDefAuditCode !== undefined) {
						oAuditInput.setValue(oDefAuditCode.AuditReasonCodes);
						oBtn.setEnabled(true);
					} else {
						oAuditInput.setValue("");
						oBtn.setEnabled(false);
					}
					this.byId(Fragment.createId("PPADialogFragment", "ppaDescription")).setValue("");
				} else {
					oModel.setDeferredGroups([sAuditCodeGrpId]);
					aAuditCodeCallPromises.push(this._readAuditReasonCodes());
					oModel.setUseBatch(true);
					oModel.submitChanges({
						groupId: sAuditCodeGrpId
					});
					jQuery.when.apply(this, aAuditCodeCallPromises)
						.done(function (oData) {
							this._defEvBusyDialog.close();
							this.openPPADialog.apply(this, [null, true, oData]);
						}.bind(this))
						.fail(function (oError) {
							this._defEvBusyDialog.close();
							this.showErrorMessage.apply(this, arguments);
						}.bind(this));
				}
			},

			/**
			 * This method is called when value in PPA Reason Code input changes to enable/disable ok button in PPA popover
			 * @param {sap.ui.base.Event}  oEvent  PPA Reason Code change event
			 */
			onPPAReasonChange: function (oEvent) {
				var oValidAuditCode,
					sAuditReasonInput = oEvent.getSource().getValue(),
					sAuditReasonCode = sAuditReasonInput.toUpperCase(),
					oInput = oEvent.getSource();
				oInput.setValue(sAuditReasonCode);
				if (sAuditReasonCode !== "") {
					oValidAuditCode = this._getAuditReasonCode(this.aAuditReasonCodes, false, sAuditReasonCode);
					if (oValidAuditCode !== undefined) {
						oInput.setValueState("None");
						oInput.setValueStateText("");
						oInput.getParent().getBeginButton().setEnabled(true);
					} else {
						oInput.setValueState("Error");
						oInput.setValueStateText(this.getResourceBundle().getText("INVALID_AUD_CODE"));
						oInput.getParent().getBeginButton().setEnabled(false);
					}
				} else {
					oInput.setValueState("None");
					oInput.setValueStateText("");
					oInput.getParent().getBeginButton().setEnabled(false);
				}
			},

			/**
			 * This method is called on click of OK button in PPA popover
			 * @param {sap.ui.base.Event}  oEvent  PPA Dialog on button press event
			 */
			confirmPPADailog: function (oEvent) {
				this.oPPAParams.AuditReasonCode =
					this.byId(Fragment.createId("PPADialogFragment", "reasonCodeInput")).getValue();
				this.oPPAParams.PpaReqReason =
					this.byId(Fragment.createId("PPADialogFragment", "ppaDescription")).getValue();
				this.oPPAParams.PpaAuditIndicator = "01";
				this.oPPADialog.close();
				this.callBackForPPAAudit();
			},

			/**
			 * Function to handle the confirm button of the dialog (PPA and Audit)
			 * @param {sap.ui.base.Event}  oEvent  PPA and Audit Confirmaiton button press event
			 */
			confirmAuditDialog: function (oEvent) {
				var oAuditTble, oSlctdItm, oInput, oAuditCodeSearch;
				oAuditCodeSearch = this.byId(Fragment.createId("staticFragId", "idAuditCodeSearch"));
				oAuditTble = this.byId(Fragment.createId("staticFragId", "tableAuditCode"));
				oAuditCodeSearch.setValue("");
				oSlctdItm = oAuditTble.getSelectedItem();
				oInput = this.byId(Fragment.createId("PPADialogFragment", "reasonCodeInput"));
				if (this.oPPADialog !== undefined && this.oPPADialog.isOpen()) {
					oInput.setValue(oSlctdItm.getBindingContext("AuditCodes").getObject().AuditReasonCodes);
					oInput.setValueState("None").setValueStateText("");
					this.oPPADialog.getBeginButton().setEnabled(true);
				} else {
					this.oPPAParams.AuditReasonCode = oSlctdItm.getBindingContext("AuditCodes").getObject().AuditReasonCodes;
					this.oPPAParams.PpaAuditIndicator = "06";
					this.callBackForPPAAudit();
				}
				this._valueHelpDialog.close();
			},

			/**
			 * Callback function for PPA Initiation
			 */
			callBackForPPAAudit: function () {
				if (this.oHeaderVariables.PpaReqReference === "SAVE") {
					this.onSavePress();
				} else if (this.oHeaderVariables.PpaReqReference === "UPDATE") {
					this.onSavePress();
				} else if (this.oHeaderVariables.PpaReqReference === "DELETE") {
					this.fnDeleteDefEventOnPPAConfirm();
				}
			},

			/**
			 * Function to handle close(no button) of the dialog(PPA and Audit)
			 * @param {sap.ui.base.Event}  oEvent  Confirm Canelation/No button press for PPA and Audit
			 */
			cancelAuditDialog: function (oEvent) {
				var oAuditCodeSearch;
				if (this.sAudInput) {
					this.byId(Fragment.createId("PPADialogFragment", "reasonCodeInput")).setValue(this.sAudInput);
				}
				if (this._valueHelpDialog && this._valueHelpDialog.isOpen()) {
					oAuditCodeSearch = this.byId(Fragment.createId("staticFragId", "idAuditCodeSearch"));
					oAuditCodeSearch.setValue("");
					this.clearPPAAuditDetails();
					this._valueHelpDialog.close();
				}
			},

			/**
			 * This method is executed when user clicks on CANCEL in PPA dialog
			 * @param {sap.ui.base.Event}  oEvent  Confirm Canelation/No button press for PPA
			 */
			cancelPPADialog: function (oEvent) {
				if (this.oPPADialog && this.oPPADialog.isOpen()) {
					this.oHeaderVariables.PpaReqReference = "";
					this.clearPPAAuditDetails();
					this.oPPADialog.close();
				}
			},

			/**
			 * Function to clear Audit or PPA data 
			 */
			clearPPAAuditDetails: function () {
				this.oPPAParams.AuditReasonCode = "";
				this.oPPAParams.PpaAuditIndicator = "";
				this.oPPAParams.PpaReqReason = "";
			},
			/**
			 * This method is executed for opening an Audit popup
			 * @param {sap.ui.base.Event}  oEvent  event when audit value help pressed in PPA dialog
			 * @param {boolean} bAuditCalled audit reason code read called
			 * @param {object} oAuditCodeData Audit reason codes data from backend
			 */
			openAuditDialog: function (oEvent, bAuditCalled, oAuditCodeData) {
				var aAuditCodeCallPromises = [],
					sAuditCodeGrpId = "AuditCodeCall",
					oModel = this.getModel(),
					oAuditCodes = new JSONModel({
						AuditCodeSet: this.aAuditReasonCodes
					});
				if (oEvent) {
					var oAuditInput = this.byId(Fragment.createId("PPADialogFragment", "reasonCodeInput"));
					this.sAudInput = oAuditInput.getValue();
					oAuditInput.setValue("");
				}
				this.isAudit = true;
				this.getView().setModel(oAuditCodes, "AuditCodes");
				if (!this._valueHelpDialog) {
					var sFragId = this.createId("staticFragId");
					this._valueHelpDialog = sap.ui.xmlfragment(sFragId, "oil.ups.fdcs1.fragments.Auditcodes", this);
					this.getView().addDependent(this._valueHelpDialog);
					this._valueHelpDialog.setModel(this.getView().getModel("AuditCodes"));
				}
				if (this.aAuditReasonCodes && this.aAuditReasonCodes.length > 0) {
					this.getView().getModel("AuditCodes").setProperty("/AuditCodeSet", this.aAuditReasonCodes);
					this._valueHelpDialog.open();
				} else if (bAuditCalled && bAuditCalled === true && oAuditCodeData) {
					this.aAuditReasonCodes = oAuditCodeData.results;
					this.getView().getModel("AuditCodes").setProperty("/AuditCodeSet", this.aAuditReasonCodes);
					this._valueHelpDialog.open();
				} else {
					oModel.setDeferredGroups([sAuditCodeGrpId]);
					aAuditCodeCallPromises.push(this._readAuditReasonCodes());
					oModel.setUseBatch(true);
					oModel.submitChanges({
						groupId: sAuditCodeGrpId
					});
					jQuery.when.apply(this, aAuditCodeCallPromises)
						.done(function (oData) {
							this._defEvBusyDialog.close();
							this.openAuditDialog.apply(this, [null, true, oData]);
						}.bind(this))
						.fail(function (oError) {
							this._defEvBusyDialog.close();
							this.showErrorMessage.apply(this, arguments);
						}.bind(this));
				}
			},

			/**
			 * Function is called Audit Tab is changed, this set the Audit dialog content - Audit reason code set
			 * @param {sap.ui.base.Event}  oEvent  Audit Tab seleciton change event
			 */
			auditTabSelectionChange: function (oEvent) {
				if (oEvent.getParameters().selected) {
					this._valueHelpDialog.getBeginButton().setEnabled(true);
				} else {
					this._valueHelpDialog.getBeginButton().setEnabled(false);
				}
			},

			/**
			 * This function is to perform search on list of Audit Reason codes in the value help
			 * @param {sap.ui.base.Event}  oEvent  event object for the reason code search operation
			 */
			onAuditCodeSearch: function (oEvent) {
				var aFilters = [];
				var sAuditSearch = oEvent.getSource().getValue();
				if (sAuditSearch && sAuditSearch.length > 0) {
					var filter = new Filter("AuditReasonCodes", sap.ui.model.FilterOperator.Contains, sAuditSearch);
					aFilters.push(filter);
				}
				var oAuditTable = this.byId(Fragment.createId("staticFragId", "tableAuditCode"));
				var binding = oAuditTable.getBinding("items");
				binding.filter(aFilters, "Application");
			},

			/**
			 * Function to get the Audit Dialog Filters
			 * @returns	{Array}		Audit Dialog filter array
			 */
			getAuditDailogFilters: function () {
				var sNetObj = this.getView().getModel("StartupParameters").getProperty("/Parameters/netObjId");
				return [new Filter("NetId", FilterOperator.EQ, sNetObj)];
			},

			/**
			 * Add Event button Handler which link existing deferment
			 * event to current event
			 * @param {sap.ui.base.Event}  oEvent  Event Object
			 */
			addLinkedEvent: function (oEvent) {
				if (this.validateDefermentCode() && this._validateDates()) {
					var oView = this.getView();
					if (!this._LinkedEventTableSelectDialog) {
						this._LinkedEventTableSelectDialog = sap.ui.xmlfragment(this.createId("idAddLinkedDefEventFrag"),
							"oil.ups.fdcs1.fragments.AddLinkedEventValueHelpDialog", this);
						oView.addDependent(this._LinkedEventTableSelectDialog);
					}

					// Multi-select if required
					var aMultiSetting = oEvent.getSource().getCustomData().filter(function (oFilterItem) {
						return oFilterItem.getKey() === "multi";
					});
					if (aMultiSetting.length) {
						this._LinkedEventTableSelectDialog.setMultiSelect(aMultiSetting[0].getValue() === "true");
					}

					this._LinkedEventTableSelectDialog.setModel(oView.getModel());
					this._LinkedEventTableSelectDialog.open();
				} else {
					this._showMessages();
				}
			},

			/**
			 * Callback function for On click of OK button on Select Dialog Box to add the Linked Event to Event Data table
			 * @param {sap.ui.base.Event}  oEvent  Confirmation event to add the Linked Event to Event Data table
			 */
			onAddLinkedEventDialogConfirm: function (oEvent) {
				var oData = this.getView().getModel("EventModel").getData(),
					aSelectedItems = oEvent.getParameter("selectedItems");
				for (var i = 0, len = aSelectedItems.length; i < len; i++) {
					var selectedObject = aSelectedItems[i].getBindingContext().getObject();
					var oInsert = {
						DefCode: selectedObject.DefCode,
						EndPeriod: selectedObject.EndPeriod,
						StrtPeriod: selectedObject.StrtPeriod,
						EventId: "",
						LinkedEventId: selectedObject.EventId,
						Tplnr: selectedObject.Tplnr
					};
					var iDefLinkedLength = oData.EventData.DeferLinkedEventSet.length;
					if (!iDefLinkedLength) {
						oData.EventData.DeferLinkedEventSet.push(oInsert);
						continue;
					}
					for (var j = 0; j < iDefLinkedLength; j++) {
						if (oInsert.LinkedEventId !== oData.EventData.DeferLinkedEventSet[j].LinkedEventId) {
							if (jQuery.isEmptyObject(oData.EventData.DeferLinkedEventSet[j + 1])) {
								oData.EventData.DeferLinkedEventSet.push(oInsert);
							}
						} else {
							j = iDefLinkedLength;
						}
					}
				}
				if (this.oHeaderVariables.sMode === "Edit") {
					this.isChanged = true;
				}
				this.getView().getModel("EventModel").setData(oData);
				oEvent.getSource().getBinding("items").filter([]);
			},

			/**
			 * This function is called On Click of Cancel in Table Select Dialog Box,
			 * Closing the Table Select Dialog Box
			 * @param {sap.ui.base.Event}  oEvent  Cancel button press event of select dialog
			 */
			onAddLinkedEventDialogCancel: function (oEvent) {
				var oSource = oEvent.getSource();
				if (oSource && oSource.getBinding("items")) {
					oSource.getBinding("items").filter([]);
				}
				if (this._LinkedEventTableSelectDialog && this._LinkedEventTableSelectDialog.close) {
					this._LinkedEventTableSelectDialog.close();
				}
			},

			/**
			 * LiveChange Event Handler for search bar of Select Deferment Event Value Help
			 * Select Dialog Box to Search the Linked Events
			 * @param {sap.ui.base.Event}  oEvent  Live change Event Object
			 */
			handleDefEventSearch: function (oEvent) {
				var sValue = oEvent.getParameter("value");
				// 3438225 Begin - Deferment Event VH Search Issue fix for internal incident
				if (sValue && sValue.length > 0) {
					var aFilters = new Filter([
					new Filter("EventId", FilterOperator.Contains, sValue.slice(0, 10)),
					new Filter("EventType", FilterOperator.Contains, sValue.slice(0, 1)),
					new Filter("Description", FilterOperator.Contains, sValue.slice(0, 255)),
					new Filter("Tplnr", FilterOperator.Contains, sValue.slice(0, 30))
					], true);
					oEvent.getSource().getBinding("items").filter(aFilters);
				} else {
					oEvent.getSource().getBinding("items").filter([]);	
				}
				// 3438225 Begin - Deferment Event VH Search Issue fix for internal incident
			},

			/**
			 * Callback function for On click of Delete Button to delete the Linked Event from Table
			 * @param {sap.ui.base.Event}  oEvent  Delete the Linked Event to Event Data table
			 */
			deleteLinkedEvent: function (oEvent) {
				var spath = oEvent.getParameter("listItem").getBindingContextPath();
				var index = spath[spath.length - 1];
				var oEventModel = this.getView().getModel("EventModel");
				var LinkedEvents = oEventModel.getProperty("/EventData/DeferLinkedEventSet");
				var oRemovedRow = LinkedEvents.splice(index, 1)[0];
				oEventModel.setProperty("/EventData/DeferLinkedEventSet", LinkedEvents);
				oEventModel.getData().oDeletedItems.LinkedEvents.push(oRemovedRow);
				if (this.oHeaderVariables.sMode === "Edit") {
					this.isChanged = true;
				}
			},

			/**
			 * Function to handle Work order Search dialog
			 * @param {sap.ui.base.Event}  oEvent  Add workorder event
			 */
			addWorkOrder: function (oEvent) {
				if (this.validateDefermentCode() && this._validateDates()) {
					var aTempFilterPM = [],
						dTempStartDate = this.getView().getModel("EventModel").getProperty("/EventData/StrtPeriod"),
						dTempEndDate = this.getView().getModel("EventModel").getProperty("/EventData/EndPeriod"),
						oTplnr = new Filter("Tplnr", FilterOperator.EQ, this.getView().getModel("StartupParameters").getProperty("/Parameters/netObjId")),
						oNetObjType = new Filter("NetobjType", FilterOperator.EQ, this.getView().getModel("StartupParameters").getProperty(
							"/Parameters/NetObjTyp")),
						oResourceBundle = this.getResourceBundle();
					aTempFilterPM.push(oTplnr);
					// Network Object type is required for PRA
					if (this.getPRASwitch()) {
						aTempFilterPM.push(oNetObjType);
					}
					if (dTempStartDate !== "") {
						if (dTempStartDate !== undefined) {
							aTempFilterPM.push(new Filter("StartDate", FilterOperator.GE, dTempStartDate));
						}
					}
					if (dTempEndDate !== "") {
						if (dTempEndDate !== undefined) {
							aTempFilterPM.push(new Filter("EndDate", FilterOperator.LE, dTempEndDate));
						}
					}
					if (this.getView().getModel("EventModel").getProperty("/sWorkOrder") !== "") {
						if (this.getView().getModel("EventModel").getProperty("/sWorkOrder") !== undefined) {
							aTempFilterPM.push(new Filter("WorkOrder", FilterOperator.EQ, this.getView().getModel("EventModel").getProperty("/sWorkOrder")));
						}
					}
					if (!this.selectDialogPlans) {
						this.selectDialogPlans = new SelectDialog({
							noDataText: oResourceBundle.getText("NO_WORKORDER_DATA"),
							title: oResourceBundle.getText("SELECT_WORKORDER_DATA"),
							multiSelect: true,
							items: {
								path: "/PMWorkOrdersSet",
								templateShareable: false,
								template: new StandardListItem({
									title: "{WorkOrder}",
									description: "{WoDescription}"
								}),
								filters: aTempFilterPM
							},
							// Attach the event handlers
							liveChange: [this.handleSelectDialogSearch, this],
							confirm: [this.handleSelectDialogConfirm, this]
						});
						this.selectDialogPlans.setModel(this.getView().getModel());
					} else {
						var oBinding = this.selectDialogPlans.getBinding("items");
						oBinding.filter(aTempFilterPM, "Application");
					}
					// Multi-select if required
					var aMultiSetting = oEvent.getSource().getCustomData().filter(function (oItem) {
						return oItem.getKey() === "multi";
					});
					if (aMultiSetting.length) {
						this.selectDialogPlans.setMultiSelect(aMultiSetting[0].getValue() === "true");
					}
					this.selectDialogPlans.open();
				} else {
					this._showMessages();
				}
			},

			/**
			 * This Function is called On Click of OK in Select Dialog Box, Adding the Work Orders for Work Order Table
			 * @param {sap.ui.base.Event}  oEvent  Confirmation event to add work order
			 */
			handleSelectDialogConfirm: function (oEvent) {
				var aItems = oEvent.getParameter("selectedItems") || oEvent.getParameter("selectedItem");
				var oData = this.getView().getModel("EventModel").getData();
				for (var i = 0; i < aItems.length; i++) {
					aItems.map(function (oItem) {
						var oItemproperties = oItem.getModel().getProperty(oItem.getBindingContextPath());
						var oInsert = {
							EventId: "",
							WorkOrder: oItemproperties.WorkOrder,
							PlanCode: oItemproperties.WoDescription,
							PlanStart: oItemproperties.StartDate,
							PlanEnd: oItemproperties.EndDate
						};
						var iDefPlanLength = oData.EventData.DeferPlansSet.length;
						if (iDefPlanLength) {
							for (var j = 0; j < iDefPlanLength; j++) {
								if (oInsert.WorkOrder !== oData.EventData.DeferPlansSet[j].WorkOrder) {
									if (jQuery.isEmptyObject(oData.EventData.DeferPlansSet[j + 1])) {
										oData.EventData.DeferPlansSet.push(oInsert);
									}
								} else {
									j = iDefPlanLength;
								}
							}
						} else {
							oData.EventData.DeferPlansSet.push(oInsert);
						}
					}, this);
				}
				if (this.oHeaderVariables.sMode === "Edit") {
					this.isChanged = true;
				}
				this.getView().getModel("EventModel").setData(oData);
				oEvent.getSource().getBinding("items").filter([]);
			},

			/**
			 * This function is called On click of Delete Icon in Work Order table on a Row, Deleting particular row
			 * @param {sap.ui.base.Event}  oEvent  Delete ICON press event of work order row
			 */
			deleteWorkOrder: function (oEvent) {
				var sPath = oEvent.getParameter("listItem").getBindingContextPath();
				var index = sPath[sPath.length - 1];
				var oEventModel = this.getView().getModel("EventModel");
				var LinkedEvents = oEventModel.getProperty("/EventData/DeferPlansSet");
				var oRemovedRow = LinkedEvents.splice(index, 1)[0];
				oEventModel.setProperty("/EventData/DeferPlansSet", LinkedEvents);
				oEventModel.getData().oDeletedItems.WorkOrders.push(oRemovedRow);
				if (this.oHeaderVariables.sMode === "Edit") {
					this.isChanged = true;
				}
			},

			/**
			 * Live Search of Work Order on Select Dialog Box
			 * @param {sap.ui.base.Event}  oEvent  On change event of search box of select dialog
			 */
			handleSelectDialogSearch: function (oEvent) {
				var sValue = oEvent.getParameter("value");
				var binding = oEvent.getSource().getBinding("items");
				if (sValue) {
					binding.filter([new Filter("WorkOrder", FilterOperator.Contains, sValue)]);
				} else {
					binding.filter([]);
				}
			},

			/**
			 * This function returns Date object for the give date string in format yyyyMMddHHmmss
			 * @param	{string}	sDate	Date Value String
			 * @returns	{Object}			Date object
			 */
			getDateFromTimestampString: function (sDate) {
				var oDateFormat = DateFormat.getDateTimeInstance({
					pattern: "yyyyMMddHHmmss"
				});
				var _oDate = oDateFormat.parse(sDate);
				return _oDate;
			},

			/**
			 * This function returns formatted short datetime string for the given Date object
			 * @param	{Object} oDate	Date object
			 * @returns	{string}		Datetime string in short style
			 */
			getShortDateTimeString: function (oDate) {
				var oDateFormat = DateFormat.getDateTimeInstance({
					style: "short"
				});
				return oDateFormat.format(oDate);
			},

			/**
			 * This function is called to get the Query string for oData function Call
			 * @param	{string}	sPath	path of function Call
			 * @param	{Object}	params	function call paramaters object
			 * @returns	{string}			Formatted Query string for function call to make oData call
			 */
			getQueryStringForFunction: function (sPath, params) {
				var queryFilterString = Object.keys(params).map(
					function (key) {
						return jQuery.sap.formatMessage("{0}=''{1}''", [key, params[key]]);
					}).join("&");
				return jQuery.sap.formatMessage("/{0}?{1}", [sPath, queryFilterString]);
			},

			/**
			 * Formatter for effect value. If collapseEffectValue is blank then display '-' with collapseEffectUnit
			 * @param	{string}	collapEffectValue	effect value
			 * @param	{string}	collapEffectUnit	unit of effect
			 * @returns	{string}	Formatted value of Collapse effect
			 */
			collapseEffectValueFormatter: function (collapEffectValue, collapEffectUnit) {
				var effectValue = collapEffectValue === null ? "-" : collapEffectValue;
				return jQuery.sap.formatMessage("{0} {1}", [effectValue, collapEffectUnit]);
			},

			/**
			 * Formatter for visible property of Collapse Effects button. If effect is collapsed, collapse button should be hidden else visible.
			 * @param	{boolean}	bEffectCollapsed	true if effect is collapsed else false 
			 * @returns	{boolean}						false if effect is collapsed else true
			 */
			collapseBtnVisibleFormatter: function (bEffectCollapsed) {
				return !bEffectCollapsed;
			},

			/**
			 * This function is called to format the selected audit item 
			 * @param	{string}	sDefaultArc		Default value
			 * @returns	{boolean}					true/false
			 */
			auditItemSelectedFormatter: function (sDefaultArc) {
				if (sDefaultArc === "X") {
					this._valueHelpDialog.getBeginButton().setEnabled(true);
					return true;
				} else {
					return false;
				}
			},

			/**
			 * Function to set the Audit dailog content - Audit reason code set
			 * @param {sap.m.Table} sTable Table Object
			 */
			setAuditDailogFilters: function (sTable) {
				var oStartUpParameters = this.getView().getModel("StartupParameters");
				var afilters, oBindingInfo, sCode, sDesc, sIsDefault,
					sNetObj = oStartUpParameters.getProperty("/Parameters/netObjId");
				afilters = [new Filter("NetId", FilterOperator.EQ, sNetObj)];
				oBindingInfo = {
					path: "/AuditReasonCodeSet",
					factory: jQuery.proxy(function (sId, oContext) {
						sCode = oContext.getProperty("AuditReasonCodes");
						sDesc = oContext.getProperty("AuditReasonDescr");
						sIsDefault = oContext.getProperty("DefaultArc");
						if (sIsDefault) {
							sTable.getParent().getBeginButton().setEnabled(true);
						}
						return new ColumnListItem({
							cells: [new ObjectIdentifier({
									title: sCode
								}),
								sIsDefault === "X" ? new ObjectIdentifier({
									title: sDesc
								}) : new Text({
									text: sDesc
								})
							]
						}).setSelected(sIsDefault ? true : false);
					}, this),
					filters: afilters
				};
				sTable.bindAggregation("items", oBindingInfo);
			},

			/**
			 * Navigation Back on click of back button
			 */
			navigateBack: function () {
				this._navBack();
			},

			/**
			 * This function is called when use click on the Share Action It will Open up dialog for Bookmarkas tile
			 * @param {sap.ui.base.Event}  oEvent  Action List Button Press Event
			 */
			onActionBtnPress: function (oEvent) {
				this.byId("adActionSheetAllocRes").openBy(oEvent.getSource());
			},

			/* =========================================================== */
			/* Private Methods                                             */
			/* =========================================================== */

			/**
			 * check the mode of screen and set value state of controls
			 * @param {sap.ui.base.Event}  oEvent  Route Match Event
			 * @private
			 */
			_handleRouteMatched: function (oEvent) {
				var oParameters = Utility.decodeURLParameters(oEvent.getParameter("arguments"));
				if (oEvent.getParameter("name") === "defermentEvent") {
					if (this._getEventModel()) {
						this._getEventModel().setData(ConvertToJsonUtil.getNewEventEffect());
					}
					this._setEffectCollapsed(true);
					this.isChanged = false;
					if (oParameters.Mode === "C") {
						oParameters.Mode = "Change";
					} else if (oParameters.Mode === "D") {
						oParameters.Mode = "Display";
					}
					this.getView().getModel("StartupParameters").setProperty("/Parameters", oParameters);
					this.oHeaderVariables.sMode = oParameters.Mode;
					if (oParameters.Mode === "Change") {
						this._renderUI("Change");
					} else {
						this._renderUI("Display");
					}
					this.setHeaderFooter(oParameters.Mode);
					ConvertToJsonUtil.getJSONData(this.getModel(),
						this.setClientModelsData.bind(this), oParameters.eventId, oParameters.Mode, oParameters.netObjId);
				}

				this.removeAllMessages();
			},

			/**
			 * This function is called to initialize the fragments
			 * @private
			 */
			_initializeFragments: function () {
				if (!this.defChangeFormFrag) {
					var sChangeFragId = this.createId("defChangeFormFrag");
					this.defChangeFormFrag = sap.ui.xmlfragment(sChangeFragId, "oil.ups.fdcs1.fragments.DefEventFormChange", this);
				}
				if (!this.defDispFormFrag) {
					var sDisplayFragId = this.createId("defDispFormFrag");
					this.defDispFormFrag = sap.ui.xmlfragment(sDisplayFragId, "oil.ups.fdcs1.fragments.DefEventFormDisp", this);
				}
				if (!this.defEfftEditCollapsedFrag) {
					var sEditCollFragId = this.createId("defEfftEditCollapsedFrag");
					this.defEfftEditCollapsedFrag = sap.ui.xmlfragment(sEditCollFragId, "oil.ups.fdcs1.fragments.DefEvntEfftEditCollapsed", this);
				}
				if (!this.defEfftEditExpandedFrag) {
					var sEditExpFragId = this.createId("defEfftEditExpandedFrag");
					this.defEfftEditExpandedFrag = sap.ui.xmlfragment(sEditExpFragId, "oil.ups.fdcs1.fragments.DefEvntEfftEditExpanded", this);
				}
				if (!this.defEfftDispCollapsedFrag) {
					var sDispCollFragId = this.createId("defEfftDispCollapsedFrag");
					this.defEfftDispCollapsedFrag = sap.ui.xmlfragment(sDispCollFragId, "oil.ups.fdcs1.fragments.DefEvntEfftDispCollapsed", this);
				}
				if (!this.defEfftDispExpandedFrag) {
					var sDispExpFragId = this.createId("defEfftDispExpandedFrag");
					this.defEfftDispExpandedFrag = sap.ui.xmlfragment(sDispExpFragId, "oil.ups.fdcs1.fragments.DefEvntEfftDispExpanded", this);
				}
			},

			/**
			 * This function is called to change the table mode based on view mode Change/Display
			 * @private
			 */
			_changeEffectTabBinding: function () {
				if (this.oHeaderVariables.sMode !== "Display") {
					var oEffectTable = this.byId("idEffectTable"),
						iDeferEffectLength = this._getEventModel().getProperty("/DeferEffectsSet").length;
					if (iDeferEffectLength < 2) {
						oEffectTable.setMode("None");
					} else {
						oEffectTable.setMode("Delete");
					}
				}
			},

			/**
			 * This is a callback function for work order read success handler
			 * @param	{Object}	oSuccessData	Response object of read call for workorder
			 * @private
			 */
			_onWorkOrderReadSuccess: function (oSuccessData) {
				var aPlans = {
						EventId: "",
						WorkOrder: oSuccessData.results[0].WorkOrder,
						PlanCode: oSuccessData.results[0].WoDescription,
						PlanStart: oSuccessData.results[0].StartDate,
						PlanEnd: oSuccessData.results[0].EndDate
					},
					oData = this._getEventModel().getData();
				oData.EventData.DeferPlansSet.push(aPlans);
				this._getEventModel().setData(oData);
			},

			/**
			 * This is a Failure Callback function to getJSONData oData Batch Calls
			 * @param	{Object}	oError	Error Response Object
			 */
			_onWorkOrderReadError: function (oError) {
				this._defEvBusyDialog.close();
				var sMsg;
				var err = JSON.parse(oError.responseText);
				if (oError.statusCode >= 400 || oError.statusCode <= 500) {
					//add message
					sMsg = err.error.message.value;
					this._showError({
						messageKey: sMsg,
						titleKey: "WORK_ORDER_READ_ERROR"
					}, false, {});
				}
			},

			/**
			 * Funtion to Compare old and new effects on edit
			 * @param {object[]} aNewEffects  array of new effects
			 * @param {object[]} aOldEffects  array of old effects
			 * @returns {boolean}  Boolean Flag if values are valid or not
			 * @private
			 */
			_isEffectValuesChanged: function (aNewEffects, aOldEffects) {
				var iNewEffectLength = aNewEffects.length,
					aCommonKeys = ["DurValDay", "DurValHour", "DurValMin", "DurValPerc",
						"EffectSeq", "CollapEffectVal", "CollapEffectUnit", "CollapEffectVal", "CollapEffectUnit"
					],
					oNewEffect,
					oOldEffect,
					i;
				for (i = 0; i < iNewEffectLength; i++) {
					oNewEffect = aNewEffects[i];
					oOldEffect = aOldEffects[i];
					if (this._isObjectPropertiesChanged(oNewEffect, oOldEffect, aCommonKeys)) {
						return true;
					} else {
						return false;
					}
				}
			},

			/**
			 * Funtion to Compare new and Old plans based on workorder
			 * @param	{Object}	aNewPlans	New Plan object
			 * @param	{Object}	aOldPlans	old Plan object
			 * @returns  {boolean}				true/false weather plan work order is changed or not
			 * @private
			 */
			_isPlansChanged: function (aNewPlans, aOldPlans) {
				var iNewPlanLength = aNewPlans.length,
					i;
				for (i = 0; i < iNewPlanLength; i++) {
					if (aNewPlans[i].WorkOrder !== aOldPlans[i].WorkOrder) {
						return true;
					}
				}
				return false;
			},

			/**
			 * Funtion to Check the properties of an object whether it is changed or not
			 * @param	{Object}	oObj1	1st object to be compared
			 * @param	{Object}	oObj2	2nd object to be compared
			 * @param	{Array}		aProp	Array of properties to be compared
			 * @returns  {boolean}			true/false weather object properties changed or not
			 */

			_isObjectPropertiesChanged: function (oObj1, oObj2, aProp) {
				var iPropLength = aProp.length,
					i;
				for (i = 0; i < iPropLength; i++) {
					if (oObj1[aProp[i]] !== oObj2[aProp[i]]) {
						return true;
					}
				}
				return false;
			},

			/**
			 * Funtion to Check whether deferment plans are changed or not
			 * @returns  {boolean}	true/false whether deferment plans are changed or not
			 */
			_isDeferPlansChanged: function () {
				var aNewPlans = this._getEventDataProperty("/DeferPlansSet"),
					aOldPlans = this._getEventCache().DeferEventSet.DeferPlansSet,
					iNewPlanLength = aNewPlans.length,
					iOldPlanLength = aOldPlans.length;
				if (iNewPlanLength !== iOldPlanLength) {
					return true;
				} else if (iNewPlanLength !== 0 && this._isPlansChanged(aNewPlans, aOldPlans)) {
					return true;
				} else {
					return false;
				}
			},

			/**
			 * Function to check Deferment effects is changed new effects and old effects
			 * @returns {boolean}	true/false weather the effects has changed or not
			 */
			_isDeferEffectChanged: function () {
				var aNewEffects = this._getEventDataProperty("/DeferEffectsSet"),
					aOldEffects = this._getEventCache().DeferEventSet.DeferEffectsSet.length,
					iNewEffectLength = aNewEffects.length,
					iOldEffectLength = aOldEffects.length;
				if (iNewEffectLength !== iOldEffectLength) {
					return true;
				} else if (iNewEffectLength !== 0 && this._isEffectValuesChanged(aNewEffects, aOldEffects)) {
					return true;
				} else {
					return false;
				}
			},

			/**
			 * This method will show the warning message when cancel button is clicked after changing the data 
			 * @param {string}	sMode	Mode of the screen
			 */
			_showWarningOnCancel: function (sMode) {
				var oBundle = this.getResourceBundle();
				var onCloseMethod = function (oResult) {
					if (oResult === MessageBox.Action.OK) {
						if (sMode === "Edit") {
							this._setToDisplayModeOnCancel("Display");
						} else {
							this._navBack();
						}
					}
				};
				MessageBox.confirm(oBundle.getText("MESSAGE_ON_CANCEL"), {
					title: oBundle.getText("ZONC_WARNING"),
					onClose: jQuery.proxy(onCloseMethod, this)
				});
			},

			/**
			 * This method is called on CANCEL button to set the page to display mode.
			 * @param	{string}	sMode	Mode of the screen
			 */
			_setToDisplayModeOnCancel: function (sMode) {
				if (this._getEventModel()) {
					this._getEventModel().setData(ConvertToJsonUtil.getNewEventEffect());
				}
				this.oHeaderVariables.sMode = sMode;
				this._renderUI(sMode);
				this.setHeaderFooter(sMode);
				this.isChanged = false;
				var oParameters = this.getView().getModel("StartupParameters").getProperty("/Parameters");
				ConvertToJsonUtil.getJSONData(this.getModel(),
					this.setClientModelsData.bind(this), oParameters.eventId, oParameters.Mode, oParameters.netObjId);
			},

			/**
			 * Function to get final data from the screen after validations check
			 * @param	{Object}	oData	Data Object for current screen
			 * @returns	{Object}			Converted Data Object for current screen
			 */
			_getFinalData: function (oData) {
				var oTempEventData = {};
				var DeferEffectsSet = [];
				oTempEventData.EventId = oData.EventId;
				oTempEventData.Tag = oData.Tag;
				oTempEventData.Description = oData.Description;
				oTempEventData.Tplnr = this.getView().getModel("StartupParameters").getProperty("/Parameters/netObjId");
				oTempEventData.CommentText = oData.CommentText;
				oTempEventData.StrtPeriod = oData.StrtPeriod;
				oTempEventData.EndPeriod = (oData.EndPeriod === "99991231235959") ? "            0" : oData.EndPeriod;
				oTempEventData.DefCode = oData.DefCode;
				oTempEventData.EventType = oData.EventType;
				oTempEventData.DefCodeDescription = oData.DefCodeDescription;
				var oTempDefEffectsExpanded = this.createDeferEffectExpands(this.byId("idButtonExpand").getVisible()),
					oTempDefEffectsExpandedLen = oTempDefEffectsExpanded ? oTempDefEffectsExpanded.length : 0;
				for (var i = 0; i < oTempDefEffectsExpandedLen; i++) {
					var oTempDefEffect = {};
					oTempDefEffect.__metadata = oTempDefEffectsExpanded[i].__metadata;
					oTempDefEffect.EventId = oTempDefEffectsExpanded[i].EventId;
					oTempDefEffect.EffectSeq = oTempDefEffectsExpanded[i].EffectSeq;
					oTempDefEffect.EffectMedium = oTempDefEffectsExpanded[i].EffectMedium;
					if (oTempDefEffectsExpanded[i].DurationUnit === "P") {
						oTempDefEffect.DurValPerc = String(oTempDefEffectsExpanded[i].DurValPerc);
						oTempDefEffect.DurValDay = "";
						oTempDefEffect.DurValHour = "";
						oTempDefEffect.DurValMin = "";
					} else {
						oTempDefEffect.DurValPerc = "";
						oTempDefEffect.DurValDay = String(oTempDefEffectsExpanded[i].DurValDay);
						oTempDefEffect.DurValHour = String(oTempDefEffectsExpanded[i].DurValHour);
						oTempDefEffect.DurValMin = String(oTempDefEffectsExpanded[i].DurValMin);
					}
					oTempDefEffect.EffectValChar = String(oTempDefEffectsExpanded[i].CollapEffectVal);
					oTempDefEffect.EffectUnit = oTempDefEffectsExpanded[i].CollapEffectUnit;
					oTempDefEffect.StrtPeriod = oTempDefEffectsExpanded[i].StrtPeriod;
					oTempDefEffect.EndPeriod = oTempDefEffectsExpanded[i].EndPeriod;
					DeferEffectsSet.push(oTempDefEffect);
				}
				oTempEventData.DeferEffectsSet = DeferEffectsSet;
				oTempEventData.DeferPlansSet = oData.DeferPlansSet;
				oTempEventData.DeferLinkedEventSet = oData.DeferLinkedEventSet;
				return oTempEventData;
			},

			/**
			 * Function to update the Def Code table bindings
			 * @param {string} sNavigationType	Navigation type
			 * @param {string} sValue	Deferment code value
			 * @private
			 */
			_onDefCodeChangeTableBinding: function (sNavigationType, sValue) {
				var oData = this.getView().getModel("DeferCodeModel").getData();
				var oBreadcrumbs = this.byId(Fragment.createId("idDefCodeDialogFrag", "idDefCodeDialogBreadcrumbs"));
				var oDefCodeTable = this.byId(Fragment.createId("idDefCodeDialogFrag", "idDefCodeDialogTable"));
				var binding = oDefCodeTable.getBinding("items");
				oData.sValueNow = sValue;
				if (sValue) {
					if (sNavigationType === "Navigation") { // In case user press the row which has a possible navigation to mode down the hierarchy.
						if (binding.filter([new Filter("ParentCode", FilterOperator.EQ, oData.sValueNow)]).aIndices.length > 0) {
							oData.sValuePre = oData.sValueNow;
							binding.filter([new Filter("ParentCode", FilterOperator.EQ, oData.sValuePre)]);
							oBreadcrumbs.addLink(new Link({
								text: sValue,
								press: [this.onClickLink, this]
							}));
						} else {
							binding.filter([new Filter("ParentCode", FilterOperator.EQ, oData.sValuePre)]);
						}
					}
				} else {
					binding.filter([]);
				}
			},

			/**
			 * Function to make the PPA Audit function import batch call
			 * @param	{string}	sGroupId	group id for btach calls grouping
			 * @returns	{jQuery.Deferred.promise}	Deferred promise object
			 */
			_ppaAuditFuncCall: function (sGroupId) {
				var oOdataModel = this.getModel(),
					oPPAFuncExecuted = jQuery.Deferred(),
					mParams = {
						AuditReasonCode: this.oPPAParams.AuditReasonCode,
						PpaAuditIndicator: this.oPPAParams.PpaAuditIndicator,
						PpaReqReason: this.oPPAParams.PpaReqReason,
						ProcessType: this.oPPAParams.ProcessType
					};
				oOdataModel.callFunction("/set_ppa_audit_for_event", {
					"method": "POST",
					"urlParameters": mParams,
					groupId: sGroupId,
					success: oPPAFuncExecuted.resolve,
					error: oPPAFuncExecuted.reject
				});
				return oPPAFuncExecuted.promise();
			},

			/**
			 * Changes the ui based on the current fragments type
			 * @param	{string}	sFragmentType	fragment type change/display
			 * @private
			 */
			_renderUI: function (sFragmentType) {
				var sTempFragmentType = sFragmentType,
					oParamModel = this.getView().getModel("StartupParameters");
				if (sFragmentType !== "Display") {
					oParamModel.setProperty("/Parameters/Mode", "Change");
					sTempFragmentType = "Change";
				} else {
					oParamModel.setProperty("/Parameters/Mode", "Display");
					sTempFragmentType = "Display";
				}
				this._showFormFragment(sTempFragmentType);
				this._tableButtonsShowHide(sTempFragmentType);
			},

			/**
			 * This function is called to set the visbility of the table button
			 * @param	{string}	sFragmentType	fragment type change/display
			 * @private
			 */
			_tableButtonsShowHide: function (sFragmentType) {
				if (sFragmentType === "Display") {
					this.byId("idEffectTable").setMode("None");
					this.byId("idDefEvntDefPlansTab").setMode("None");
					this.byId("idDefEvntLinkedEventsTab").setMode("None");
					this.byId("idDefEventComment").setEnabled(false);
					this.byId("isAddEventEffectBtn").setVisible(false);
					this.byId("idAddWorkOrdersBtn").setVisible(false);
					this.byId("idAddLinkedEventsBtn").setVisible(false);
				} else {
					var effectData = this.getView().getModel("EventModel");
					if ((effectData !== undefined) && (effectData.getData().DeferEffectsSet.length > 1)) {
						this.byId("idEffectTable").setMode("Delete");
					}
					this.byId("idDefEvntDefPlansTab").setMode("Delete");
					this.byId("idDefEvntLinkedEventsTab").setMode("Delete");
					this.byId("idDefEventComment").setEnabled(true);
					this.byId("isAddEventEffectBtn").setVisible(true);
					this.byId("idAddWorkOrdersBtn").setVisible(true);
					this.byId("idAddLinkedEventsBtn").setVisible(true);
				}
			},

			/**
			 * Returns Deferment Header Form fragment based on screen mode
			 * @param	{string}	sFragmentType	fragment type change/display
			 * @returns	{Faragment}		form fragment Change/Display
			 * @private
			 */
			_getFormFragment: function (sFragmentType) {
				var oFormFragment;
				if (sFragmentType === "Change") {
					oFormFragment = this.defChangeFormFrag;
				} else {
					oFormFragment = this.defDispFormFrag;
				}
				return oFormFragment;
			},

			/**
			 * Function is called to show the form fragment
			 * @param	{string}	sFragmentType	fragment type change/display
			 * @private
			 */
			_showFormFragment: function (sFragmentType) {
				var oPage = this.getView().byId("defEventGrid");
				if (this.initialLoadFlag) {
					this.initialLoadFlag = false;
				} else {
					oPage.removeContent(0);
				}
				oPage.insertContent(this._getFormFragment(sFragmentType), 0);
			},

			/**
			 * Function is called to get the table fragment
			 * @param	{string}	sFragmentType	fragment type change/display
			 * @param	{boolean}	isCollapsed		weather is collapsed or not
			 * @returns	{Faragment}		Deferment event table fragment
			 * @private
			 */
			_getTableFragment: function (sFragmentType, isCollapsed) {
				var oTableListFragment;
				if (sFragmentType !== "Display") {
					if (isCollapsed) {
						oTableListFragment = this.defEfftEditExpandedFrag;
					} else {
						oTableListFragment = this.defEfftEditCollapsedFrag;
					}
				} else {
					if (isCollapsed) {
						oTableListFragment = this.defEfftDispExpandedFrag;
					} else {
						oTableListFragment = this.defEfftDispCollapsedFrag;
					}
				}
				return oTableListFragment;
			},

			/**
			 * Function is called to show the table fragment
			 * @param	{string}	sFragmentType	fragment type change/display
			 * @param	{boolean}	isCollapsed		weather is collapsed or not
			 * @private
			 */

			_showTableFragment: function (sFragmentType, isCollapsed) {
				var oTable = this.byId("idEffectTable"),
					oTempalate = this._getTableFragment(sFragmentType, isCollapsed);
				oTable.bindAggregation("items", {
					path: "EventModel>/DeferEffectsSet/",
					templateShareable: true,
					template: oTempalate
				});
				this._changeEffectTabBinding();
			},

			/**
			 * This function is to check for default or valid audit reason code
			 * @param {array} aAuditReasonCodes array of audit reason codes
			 * @param {boolean} bDefault flag to indicate method called for default arc
			 * @param {string} sArc Audit reason code user input value
			 * @returns {object} Audit reason code  
			 */
			_getAuditReasonCode: function (aAuditReasonCodes, bDefault, sArc) {
				var i, iLen = aAuditReasonCodes.length;
				if (bDefault) {
					for (i = 0; i < iLen; i++) {
						if (aAuditReasonCodes[i].DefaultArc === "X") {
							return aAuditReasonCodes[i];
						}
					}
				} else if (sArc) {
					for (i = 0; i < iLen; i++) {
						if (aAuditReasonCodes[i].AuditReasonCodes === sArc) {
							return aAuditReasonCodes[i];
						}
					}
				}
			},
			/**
			 * Event Handler if the selection in the Audit Reason Code popup table has been changed. 
			 * It enables the OK button if we have first item selected.
			 * @param {sap.ui.base.Event}  oEvent  Object containing the information about the event fired
			 */
			_handleSelectionChange: function (oEvent) {
				if (oEvent.getParameters().selected) {
					this._valueHelpDialog.getBeginButton().setEnabled(true);
				} else {
					this._valueHelpDialog.getBeginButton().setEnabled(false);
				}
			},

			/**
			 * This method do odata read call to get all the audit reason codes
			 * @param {string} sAuditCodeGrpId groupId for the batch call
			 * @returns {object} batch call promise object
			 */
			_readAuditReasonCodes: function (sAuditCodeGrpId) {
				var oNetIdFilter, mParameter,
					oModel = this.getModel(),
					oAuditCodeDeferred = jQuery.Deferred();
				oNetIdFilter = this.getAuditDailogFilters();
				mParameter = {
					groupId: sAuditCodeGrpId,
					filters: oNetIdFilter,
					sorters: null,
					success: oAuditCodeDeferred.resolve,
					error: oAuditCodeDeferred.reject
				};
				this._defEvBusyDialog.open();
				oModel.read("/AuditReasonCodeSet", mParameter);
				return oAuditCodeDeferred.promise();
			},

			/**
			 * This method returns the reference of from date picker
			 * @returns	{sap.m.DatePicker}	From Date Picker Control object
			 */
			_getFromDateControl: function () {
				return this._getFragmentControl("defChangeFormFrag", "idFromDate");
			},

			/**
			 * This method returns the reference of datetime picker type-> time
			 * @returns	{sap.m.DateTimePicker}	From DateTime Picker Control object
			 */
			_getFromTimeControl: function () {
				return this._getFragmentControl("defChangeFormFrag", "idFromTime");
			},

			/**
			 * This method returns the reference of to date picker
			 * @returns {sap.m.DatePicker}	To Date Picker Control object	
			 */
			_getToDateControl: function () {
				return this._getFragmentControl("defChangeFormFrag", "idToDate");
			},

			/**
			 * This method returns the reference of datetime picker type-> time
			 * @returns	{sap.m.DateTimePicker}	To DateTime Picker Control object
			 */
			_getToTimeControl: function () {
				return this._getFragmentControl("defChangeFormFrag", "idToTime");
			},

			/**
			 * utility method to set a given model to view with a given name
			 * @param	{sap.ui.model.Model}	oModel		reference of model to be set to the view
			 * @param	{string}				sModelName	name of the model with which the model should be set to view
			 */
			_setViewModel: function (oModel, sModelName) {
				this.getView().setModel(oModel, sModelName);
			},

			/**
			 * This method checks if effect table is collapsable or not in given mode (i.e. Display/Change)
			 * @param	{string}	sMode				current mode of the screen(Display/Change)
			 * @param	{boolean}	bShowErrorMessage	flag to indicate if error messages during validation should be shown in pop-ups or not
			 * @returns	{boolean}						true if effect table is collapsable else false
			 */
			_isEffectTableCollapsable: function (sMode, bShowErrorMessage) {
				if (sMode !== "Display") {
					return this.fnCheckEffectTableCollapsable(this._getEffectCollapsed(), bShowErrorMessage);
				} else {
					return this.getView().getModel("EventModel").getProperty("/IsCollapsable");
				}
			},

			/**
			 * This method sets the value of EffectCollapsed property to show & hide expand and collapse buttons 
			 * depending upon the collapsability of effect table and
			 * render effect table in appropriate format i.e. expanded or collapsed in respective mode.
			 */
			_bindEffectTableOnInitialLoad: function () {
				var isCollapsable = this._isEffectTableCollapsable(this.oHeaderVariables.sMode, true);
				if (!isCollapsable) {
					this._setEffectCollapsed(false);
				} else {
					this._setEffectCollapsed(true);
				}
				this._showTableFragment(this.oHeaderVariables.sMode, !isCollapsable);
			},

			/**
			 * Setter function for EffectCollapsed property of event model to know if effects are collapsed or not
			 * @param	{boolean}	bEffectCollapsed	true if collapsed else false
			 */
			_setEffectCollapsed: function (bEffectCollapsed) {
				this._getEventModel().setProperty("/EffectCollapsed", bEffectCollapsed);
			},

			/**
			 * Getter function for EffectCollapsed property of event model to know if effects are collapsed or not
			 * @returns	{boolean}	true if effect factors are collapsed else false
			 */
			_getEffectCollapsed: function () {
				return this._getEventModel().getProperty("/EffectCollapsed");
			},

			/**
			 * Change the effect table with editable columnlist item depending upon if the effect could be collapsable in edit mode or not
			 * If effect is not collapsable in edit mode and it is collapsed (diff. effect values with same unit), then it edit mode show effect
			 * factor in expanded format.
			 */
			_changeEffectTableForEdit: function () {
				if (!this._isEffectTableCollapsable(this.oHeaderVariables.sMode, false)) {
					this._setEffectCollapsed(false);
				}
				this._showTableFragment(this.oHeaderVariables.sMode, !this._getEffectCollapsed());
			},

			/**
			 * check if all the effect factor value in given array has same value or not
			 * @param	{Array}		aEffectVal	Array of effect values
			 * @returns	{boolean}				returns true if all effect values in given array are same else false.
			 */
			_isEffectValuesSame: function (aEffectVal) {
				if (aEffectVal.length > 0) {
					var effectValChar = aEffectVal[0].EffectValChar;
					return aEffectVal.every(function (currentValue) {
						return effectValChar === currentValue.EffectValChar;
					});
				} else {
					return false;
				}
			},

			/**
			 * Function to convert string to float if value is not empty string
			 * @param	{string}	sVal	string value
			 * @returns	{Float}				string converted to Float value
			 */
			_toFloat: function (sVal) {
				return sVal === "" ? sVal : parseFloat(sVal);
			},

			/**
			 * Function to get the property from a model
			 * @param	{string}	sPropertyName	property name of Deferment Event
			 * @returns	{String/Object}				Data value/object of given Event Property
			 */

			_getEventDataProperty: function (sPropertyName) {
				return this._getEventModel().getProperty(sPropertyName);
			},

			/**
			 * Function to set the property of a model
			 * @param	{string}		sPropertyName	Derferment Event property name
			 * @param	{String/Object}	oValue			Derferment Event property value
			 */
			_setEventDataProperty: function (sPropertyName, oValue) {
				this._getEventModel().setProperty("/EventData" + sPropertyName, oValue);
			},

			/**
			 * Function to get json model from EventModel
			 * @returns	{Object}	JSON Model of deferment event
			 */
			_getEventModel: function () {
				if (!this.getView().getModel("EventModel")) {
					this._setViewModel(new JSONModel(), "EventModel");
				}
				return this.getView().getModel("EventModel");
			},

			/**
			 * Returns list of deferment code from Deferment code model
			 * @returns	{Array}		Deferment code set array
			 */
			_getDeferCodeList: function () {
				return this.getView().getModel("DeferCodeModel").getProperty("/DeferCodeSet");
			},

			/**
			 * Function to get fragment control 
			 * @param	{string}	sFragmentId		id of the fragment from which the control need to be picked
			 * @param	{String}	sControlId		id of the control to be picked
			 * @returns	{sap.ui.core.Control}					Control object of the given id from given fragment
			 */
			_getFragmentControl: function (sFragmentId, sControlId) {
				return this.byId(Fragment.createId(sFragmentId, sControlId));
			},

			/**
			 * Function to dgt deferment code control 
			 * @returns	{sap.ui.core.Control}	Deferment code control object
			 */
			_getDefermentCodeControl: function () {
				return this._getFragmentControl("defChangeFormFrag", "idDeferCode");
			},

			/**
			 * Function to get control of From Date  
			 * @returns	{sap.ui.core.Control}	From date picker control object
			 */
			_getFromDateTimeControl: function () {
				return this._getFragmentControl("defChangeFormFrag", "idFromDateTime");
			},

			/**
			 * Setter method for this._firstErrorStateControl. This control will have focus
			 * after user clicks on 'OK' button in error dialog.
			 * @param {sap.ui.core.Control} oControl First control in the view with error state
			 */
			_setFirstErrorStateControl: function (oControl) {
				if (!this._firstErrorStateControl || oControl === undefined) {
					this._firstErrorStateControl = oControl;
				}
			},

			/**
			 * Getter method for this._firstErrorStateControl. This control will have focus
			 * after user clicks on 'OK' button in error dialog.
			 * @returns {sap.ui.core.Control} First control in the view with error state
			 */
			_getFirstErrorStateControl: function () {
				return this._firstErrorStateControl;
			},

			/**
			 * Set the focus to first error state control in the view
			 */
			_focusFirstErrorStateControl: function () {
				if (this._getFirstErrorStateControl() && this._getFirstErrorStateControl().focus) {
					this._getFirstErrorStateControl().focus();
					this._setFirstErrorStateControl(undefined);
				}
			},

			/**
			 * Function to get date and time value from its control
			 * @returns {String} From date time string value
			 */
			_getFromDateTimeValue: function () {
				var oFromDate = this._getFromDateControl().getDateValue(),
					oFromTime = this._getFromTimeControl().getDateValue(),
					sFromDateTime;
				if (oFromDate !== null && oFromTime !== null) {
					sFromDateTime = jQuery.sap.formatMessage("{0}{1}", [this._getDateFormat().format(oFromDate),
						this._getTimeFormat().format(oFromTime)
					]);
					return this._getDateTimeFormat().parse(sFromDateTime);
				} else {
					return null;
				}
			},

			/**
			 * Function get date and time value from its control
			 * @returns {String} To date time string value
			 */
			_getToDateTimeValue: function () {
				var oToDate = this._getToDateControl().getDateValue(),
					oToTime = this._getToTimeControl().getDateValue(),
					sToDateTime;
				if (oToDate !== null && oToTime !== null) {
					sToDateTime = jQuery.sap.formatMessage("{0}{1}", [this._getDateFormat().format(oToDate),
						this._getTimeFormat().format(oToTime)
					]);
					return this._getDateTimeFormat().parse(sToDateTime);
				} else {
					return null;
				}
			},

			/**
			 * Function to get date format from its control
			 * @returns {String} formatted date string in yyyyMMdd format
			 */
			_getDateFormat: function () {
				return DateFormat.getDateInstance({
					pattern: "yyyyMMdd"
				});
			},

			/**
			 * Function to get time format from its control
			 * @returns {String} formatted time string in HHmmss
			 */
			_getTimeFormat: function () {
				return DateFormat.getTimeInstance({
					pattern: "HHmmss"
				});
			},

			/**
			 * Function to get date and time format from its control
			 * @returns {String} formatted date time string in yyyyMMddHHmmss
			 */
			_getDateTimeFormat: function () {
				return DateFormat.getDateTimeInstance({
					pattern: "yyyyMMddHHmmss"
				});
			},

			/**
			 * Function to Convert duration and effect to string
			 * @param {Object} oDeferEffect Deferment effect object
			 */
			_convertDurationAndEffectToString: function (oDeferEffect) {
				if (this._isValidNumber(oDeferEffect, "DurValPerc")) {
					oDeferEffect.DurValPerc = oDeferEffect.DurValPerc.toString();
				}
				if (this._isValidNumber(oDeferEffect, "DurValDay")) {
					oDeferEffect.DurValDay = oDeferEffect.DurValDay.toString();
				}
				if (this._isValidNumber(oDeferEffect, "DurValHour")) {
					oDeferEffect.DurValHour = oDeferEffect.DurValHour.toString();
				}
				if (this._isValidNumber(oDeferEffect, "DurValMin")) {
					oDeferEffect.DurValMin = oDeferEffect.DurValMin.toString();
				}
				if (this._isValidNumber(oDeferEffect, "EffectVal")) {
					oDeferEffect.EffectVal = oDeferEffect.EffectVal.toString();
				}
			},

			/**
			 * Function to get mediums of all the effects
			 * @returns {String/Array} mediums of all the effects
			 */
			_getAllMediums: function () {
				return this.getView().getModel("MedUOM").getProperty("/MedUOMData");
			},

			/**
			 * Function to get total duration 
			 * @param {Array} aDeferEffect Deferment effects object array
			 * @returns {Number} Total duration
			 */
			_getTotalDurationTime: function (aDeferEffect) {
				var iMediumLength = this._getAllMediums().length,
					iDeferEffectLength = aDeferEffect.length,
					iTotalTime = null,
					iDayDur = 0,
					iHourDur = 0,
					iMinDur = 0,
					i;
				for (i = 0; i < iDeferEffectLength; i = i + iMediumLength) {
					if (aDeferEffect[i].DurationUnit === "T") {
						iDayDur = parseInt(aDeferEffect[i].DurValDay, 10) * 24 * 3600000;
						iHourDur = parseInt(aDeferEffect[i].DurValHour, 10) * 3600000;
						iMinDur = parseInt(aDeferEffect[i].DurValMin, 10) * 60000;
						iTotalTime += iDayDur + iHourDur + iMinDur;
					}
				}
				return iTotalTime;
			},

			/**
			 * Function to get total duration percentage 
			 * @param {Array} aDeferEffect Deferment effects object array
			 * @returns {Float} Duration percentage
			 */
			_getTotalDurationPercentage: function (aDeferEffect) {
				var iMediumLength = this._getAllMediums().length,
					iDeferEffectLength = aDeferEffect.length,
					fTotalPerc = null,
					i;
				for (i = 0; i < iDeferEffectLength; i = i + iMediumLength) {
					if (aDeferEffect[i].DurationUnit === "P") {
						fTotalPerc += parseFloat(aDeferEffect[i].DurValPerc);
					}
				}
				return fTotalPerc;
			},

			/**
			 * Function to set event cache
			 * @param {Object} oEventData event data object
			 */
			_setEventCache: function (oEventData) {
				this._oEventData = oEventData;
			},

			/**
			 * Function to get event cache data
			 * @returns {Object} event data object
			 */
			_getEventCache: function () {
				return this._oEventData;
			},

			/**
			 * Function to Create Delete Batch operations
			 * @param {Object} oDeletedItems deleted items object
			 * @param {String} sGroupId group id for btach calls grouping
			 * @returns {Array} Batch operation object array
			 */
			_createDeleteBatchOperations: function (oDeletedItems, sGroupId) {
				var oODataModel = this.getModel(),
					aBatchCalls = [],
					etag,
					sUrl,
					i,
					iEffectLength, oEffect;
				// add all deleted to batch
				iEffectLength = (oDeletedItems.Effects && oDeletedItems.Effects.length) ? oDeletedItems.Effects.length : 0;
				//Creating batch for deleted event effects
				for (i = 0; i < iEffectLength; i++) {
					oEffect = oDeletedItems.Effects[i];
					if (oEffect.EffectMediumSet) {
						for (var j = 0; j < oEffect.EffectMediumSet.length; j++) {
							var oDefEventDeleteExecuted = jQuery.Deferred();
							sUrl = oODataModel.createKey("/DeferEffectsSet", {
								EventId: oEffect.EventId,
								EffectSeq: oEffect.EffectSeq,
								EffectMedium: oEffect.EffectMediumSet[j].Medium
							});
							oODataModel.remove(sUrl, {
								eTag: oEffect.EffectMediumSet[j].etag,
								groupId: sGroupId,
								success: oDefEventDeleteExecuted.resolve,
								error: oDefEventDeleteExecuted.reject
							});
							aBatchCalls.push(oDefEventDeleteExecuted.promise());
						}
					}
				}
				//Creating batch for deleted workorders
				for (i = 0; i < oDeletedItems.WorkOrders.length; i++) {
					if (oDeletedItems.WorkOrders[i].__metadata) {
						var oDefPlanDeleteExecuted = jQuery.Deferred();
						//assiging etag for edited objects of effects
						etag = oDeletedItems.WorkOrders[i].__metadata.etag;
						sUrl = oODataModel.createKey("/DeferPlansSet", {
							EventId: oDeletedItems.WorkOrders[i].EventId,
							WorkOrder: oDeletedItems.WorkOrders[i].WorkOrder
						});
						oODataModel.remove(sUrl, {
							sETag: etag,
							groupId: sGroupId,
							success: oDefPlanDeleteExecuted.resolve,
							error: oDefPlanDeleteExecuted.reject
						});
						aBatchCalls.push(oDefPlanDeleteExecuted.promise());
					}
				}
				//Creating batch for deleted Linked Items
				for (i = 0; i < oDeletedItems.LinkedEvents.length; i++) {
					if (oDeletedItems.LinkedEvents[i].__metadata) {
						var oLinkEventDeleteExecuted = jQuery.Deferred();
						//assiging etag for edited objects of effects
						etag = oDeletedItems.LinkedEvents[i].__metadata.etag;
						sUrl = oODataModel.createKey("/DeferLinkedEventSet", {
							EventId: oDeletedItems.LinkedEvents[i].EventId,
							LinkedEventId: oDeletedItems.LinkedEvents[i].LinkedEventId
						});
						oODataModel.remove(sUrl, {
							sETag: etag,
							groupId: sGroupId,
							success: oLinkEventDeleteExecuted.resolve,
							error: oLinkEventDeleteExecuted.reject
						});
						aBatchCalls.push(oLinkEventDeleteExecuted.promise());
					}
				}
				return aBatchCalls;
			},

			/**
			 * Function to Create defereffect batch operations
			 * @param {Array} aDeferEffects Array of objects of deferment effects
			 * @param {String} sGroupId	group id for btach calls grouping
			 * @returns {Array} Batch operation object array
			 */
			_createDeferEffectBatchOperations: function (aDeferEffects, sGroupId) {
				var oODataModel = this.getModel(),
					aBatchCalls = [],
					iDeferEffectLength = (aDeferEffects && aDeferEffects.length) ? aDeferEffects.length : 0,
					i;
				for (i = 0; i < iDeferEffectLength; i++) {
					if (aDeferEffects[i].__metadata) {
						var etag = aDeferEffects[i].__metadata.etag,
							sUrl = aDeferEffects[i].__metadata.uri.split("/").pop(),
							oDefEffectUpdateExecuted = jQuery.Deferred();
						oODataModel.update(jQuery.sap.formatMessage("/{0}", sUrl), aDeferEffects[i], {
							eTag: etag,
							groupId: sGroupId,
							success: oDefEffectUpdateExecuted.resolve,
							error: oDefEffectUpdateExecuted.reject
						});
						aBatchCalls.push(oDefEffectUpdateExecuted.promise());
					} else {
						var oDefEffectCreateExecuted = jQuery.Deferred();
						oODataModel.create("/DeferEffectsSet", aDeferEffects[i], {
							groupId: sGroupId,
							success: oDefEffectCreateExecuted.resolve,
							error: oDefEffectCreateExecuted.reject
						});
						aBatchCalls.push(oDefEffectCreateExecuted.promise());
					}
				}
				return aBatchCalls;
			},

			/**
			 * Function to Create deferment plan batch operation
			 * @param {Array} aDeferPlans Deferment plans array
			 * @param {String} sGroupId	group id for btach calls grouping
			 * @returns {Array} Batch Call array
			 */
			_createDeferPlanBatchOperation: function (aDeferPlans, sGroupId) {
				var oODataModel = this.getModel(),
					iDeferPlanLength = aDeferPlans.length,
					aBatchCalls = [],
					i,
					oDefPlanCreateExecuted = jQuery.Deferred();
				for (i = 0; i < iDeferPlanLength; i++) {
					if (!aDeferPlans[i].__metadata) {
						oODataModel.create("/DeferPlansSet", aDeferPlans[i], {
							groupId: sGroupId,
							success: oDefPlanCreateExecuted.resolve,
							error: oDefPlanCreateExecuted.reject
						});
						aBatchCalls.push(oDefPlanCreateExecuted.promise());
					}
				}
				return aBatchCalls;
			},

			/**
			 * Function to Create deferment linked event 
			 * @param {Array} aLinkedEvent	Linked event array
			 * @param {String} sGroupId	group id for btach calls grouping
			 * @returns {Array} Batch Call array
			 */
			_createDeferLinkedEventBatchOperation: function (aLinkedEvent, sGroupId) {
				var oODataModel = this.getModel(),
					iLinkedEventLength = aLinkedEvent.length,
					aBatchCalls = [],
					i,
					oLinkedEventCreateExecuted = jQuery.Deferred();
				for (i = 0; i < iLinkedEventLength; i++) {
					if (!aLinkedEvent[i].__metadata) {
						oODataModel.create("/DeferLinkedEventSet", aLinkedEvent[i], {
							groupId: sGroupId,
							success: oLinkedEventCreateExecuted.resolve,
							error: oLinkedEventCreateExecuted.reject
						});
						aBatchCalls.push(oLinkedEventCreateExecuted.promise());
					}
				}
				return aBatchCalls;
			},

			/**
			 * Function to Create batch operations for edit
			 * @param {Object}	oDeferEventData	Deferment event data
			 * @param {String}	sGroupId	group id for btach calls grouping
			 * @returns	{Array}		batch call array
			 */
			_createBatchOperationsForEdit: function (oDeferEventData, sGroupId) {
				var oOdataModel = this.getModel(),
					etag = this._getEventDataProperty("/__metadata/etag"),
					eventId = this.getView().getModel("StartupParameters").getProperty("/Parameters/eventId"),
					aBatchCalls = [],
					oDeletedItems = {},
					aDeferEffect = oDeferEventData.DeferEffectsSet,
					aLinkedEvent = oDeferEventData.DeferLinkedEventSet,
					aDeferPlans = oDeferEventData.DeferPlansSet,
					oDefEventUpdateExecuted = jQuery.Deferred();
				// delete values from parent as children sent seprately in batch
				delete oDeferEventData.DeferEffectsSet;
				delete oDeferEventData.DeferLinkedEventSet;
				delete oDeferEventData.DeferPlansSet;
				// add event to batch
				oOdataModel.update(oOdataModel.createKey("/DeferEventSet", {
					EventId: eventId
				}), oDeferEventData, {
					eTag: etag,
					groupId: sGroupId,
					success: oDefEventUpdateExecuted.resolve,
					error: oDefEventUpdateExecuted.reject
				});
				aBatchCalls.push(oDefEventUpdateExecuted.promise());

				oDeletedItems = this._getEventModel().getProperty("/oDeletedItems");
				aBatchCalls = aBatchCalls.concat(this._createDeleteBatchOperations(oDeletedItems, sGroupId));
				if (this._isDeferEffectChanged()) { // Add changes in effect to batch
					aBatchCalls = aBatchCalls.concat(this._createDeferEffectBatchOperations(aDeferEffect, sGroupId));
				}
				if (this._isDeferPlansChanged()) { //Add changes in work orders
					aBatchCalls = aBatchCalls.concat(this._createDeferPlanBatchOperation(aDeferPlans, sGroupId));
				}
				if (this._isDeferEffectChanged()) { //Add changes in linked events
					aBatchCalls = aBatchCalls.concat(this._createDeferLinkedEventBatchOperation(aLinkedEvent, sGroupId));
				}
				if (this.oHeaderVariables.PpaReqReference === "UPDATE") {
					aBatchCalls.push(this._ppaAuditFuncCall(sGroupId));
				}
				return aBatchCalls;
			},

			/**
			 * Function to Create batch operations for save on cleck of save button
			 * @param	{Object}	oDeferEventData	Deferment event data
			 * @param	{String}	sGroupId	group id for btach calls grouping
			 * @return	{Array}		batch call array
			 */
			_createBatchOperationsForSave: function (oDeferEventData, sGroupId) {
				var oODataModel = this.getModel(),
					aBatchCalls = [],
					oDeferEventCreateExecuted = jQuery.Deferred();

				if (this.oHeaderVariables.PpaReqReference === "SAVE") {
					aBatchCalls.push(this._ppaAuditFuncCall(sGroupId));
				}
				oODataModel.create("/DeferEventSet", oDeferEventData, {
					groupId: sGroupId,
					success: oDeferEventCreateExecuted.resolve,
					error: oDeferEventCreateExecuted.reject
				});
				aBatchCalls.push(oDeferEventCreateExecuted.promise());
				return aBatchCalls;
			},

			/**
			 * Callback function for On success event save response with proper msg
			 * @param	{Object}	oData		response data
			 * @param	{Array}	aResponse	batch call response
			 */
			_onSuccessEventSave: function (oData, aResponse) {
				var oBundle = this.getResourceBundle(),
					sMsg = "",
					eventId;
				this._defEvBusyDialog.close();
				if (aResponse[0] && aResponse[0].EventId) {
					eventId = aResponse[0].EventId;
				} else {
					eventId = oData.EventId;
				}
				this._setEventDataProperty("", {});
				if (this.oHeaderVariables.PpaReqReference === "SAVE") {
					if (this.oPPAParams.PpaAuditIndicator === "06") {
						sMsg = oBundle.getText("EVENT_SAVED", eventId);
					} else if (this.oPPAParams.PpaAuditIndicator === "01") {
						sMsg = oBundle.getText("SUCCESSFUL_SUBMIT_PPA");
					} else {
						sMsg = oBundle.getText("EVENT_SAVED", eventId);
					}
				} else {
					sMsg = oBundle.getText("EVENT_SAVED", eventId);
				}
				this.oHeaderVariables.PpaReqReference = "";
				jQuery.sap.delayedCall(1000, this, this._showToastMessage, [sMsg]);
				this._navBack();
			},

			/**
			 * Callback function for On failure event  response with proper error msg
			 * @param	{Object}	oError	Error object
			 */
			_onErrorEventSave: function (oError) {
				var oErrorBody;
				this._defEvBusyDialog.close();
				try {
					oErrorBody = JSON.parse(oError.responseText);
					this._processErroCode(this.oHeaderVariables.sMode, oErrorBody);
				} catch (cx) {
					this._showError({
						messageKey: "EVENT_CREATE_FAILURE",
						titleKey: "EVENT_CREATE_ERROR"
					}, false, {});
					jQuery.sap.log.error("onEventSave: Save failed due to backend exception", JSON.stringify(oError), "DefermentEvent.controller.js");
				}
			},

			/**
			 * Callback function On successfull edit press perform response msgs popup
			 * @param	{Object}	oData		response data
			 */
			_onSuccessEventEdit: function (oData) {
				var oBundle = this.getResourceBundle(),
					sMsg;
				this._defEvBusyDialog.close();
				this._setEventDataProperty("", {});
				if ((this.oHeaderVariables.PpaReqReference === "UPDATE")) {
					if (this.oPPAParams.PpaAuditIndicator === "06") {
						sMsg = oBundle.getText("EVENT_UPDATED");
					} else {
						sMsg = oBundle.getText("SUCCESSFUL_SUBMIT_PPA");
					}
				} else {
					sMsg = oBundle.getText("EVENT_UPDATED");
				}
				this.oHeaderVariables.PpaReqReference = "";
				jQuery.sap.delayedCall(1000, this, this._showToastMessage, [sMsg]);
				this._navBack();
			},

			/**
			 * Callback function for Error message for event update failure
			 * @param	{Object}	oError	error object
			 */
			_onErrorEventEdit: function (oError) {
				var oErrorBody;
				this._defEvBusyDialog.close();
				try {
					oErrorBody = JSON.parse(oError.responseText);
					this._processErroCode(this.oHeaderVariables.sMode, oErrorBody);
				} catch (cx) {
					this._showError({
						messageKey: "EVENT_UPDATE_FAILURE",
						titleKey: "EVENT_UPDATE_ERROR"
					}, false, {});
					jQuery.sap.log.error("onEventEdit: Edit failed due to backend exception", JSON.stringify(oError), "DefermentEvent.controller.js");
				}
			},

			/**
			 * Navigation Back on error/on some conditions
			 */
			_navBack: function () {
				/* eslint-disable no-undef */ //Start Comment to by pass the history code for Eslint
				this.removeAllMessages();
				this.navBack();

				/* eslint-enable no-undef */ //End Comment to by pass the history code for Eslint
			},

			//----------------------------------------Message Manager handling----------------------------------------
			/**
			 * Event handler method for press event of button which is to display the Message PopOver
			 * @param {sap.ui.base.Event}  oEvent  Press Event 
			 * @public
			 */
			onOpenMessageLog: function (oEvent) {
				this._openOrCloseMsgPopOver();
			},

			/**
			 * method to open or close the message pop over
			 * 
			 * @param{boolean} bOpen Open MessagePopOver if true, Close if false and toggle if undefined 
			 * 
			 * @private
			 */
			_openOrCloseMsgPopOver: function (bOpen) {
				var oButton = this.byId("errorMessageBtn"),
					oMsgPop = this.byId("msgPopUpDeferment");
				switch (bOpen) {
				case true: // Open MessagePopover
					if (!oMsgPop.isOpen()) {
						oButton.setVisible(true);
						oMsgPop.openBy(oButton);
					}
					break;
				case false: //Close MessagePopOver
					if (oMsgPop.isOpen()) {
						oButton.setVisible(false);
						oMsgPop.close();
					}
					break;
				default: // Toggle MessagePopOver
					oMsgPop.toggle(oButton);
					break;
				}
			},

			/**
			 *  method to set the error count on the Button
			 *  
			 *  @returns{integer} Error Count
			 *  @private
			 */
			_setErrorCount: function () {
				var iErrorCount = this.getMessagesCount(),
					sErrorCount,
					oErrorAlertBtn = this.byId("errorMessageBtn");

				if (iErrorCount === 0) {
					sErrorCount = "";
					oErrorAlertBtn.setVisible(false);
				} else {
					sErrorCount = iErrorCount;
					oErrorAlertBtn.rerender();
					oErrorAlertBtn.setVisible(true);
				}
				this._getEventModel().setProperty("/ErrorCount", sErrorCount);
				return iErrorCount;
			},

			/**
			 * method to show the messages in pop over based on the number of messages.
			 * 
			 * @private
			 */
			_showMessages: function () {
				var iErrorCount = this._setErrorCount();
				if (iErrorCount === 0) {
					// Close the message pop over if it is open
					this._openOrCloseMsgPopOver(false);
				} else {
					// Open the message pop over if it is open
					this._openOrCloseMsgPopOver(true);
				}
			},

			/**
			 * helper method to add the message to Message Processor Model
			 * and updates the ErrorCount in the model
			 * @param {string} sTarget Binding Path of the Control
			 * @param {string} sMessage MessageText
			 * @param {string} sLongText Long Description Text
			 * @param {string} sMessageType MessageType
			 * @param {boolean} bShowMessage Flag if Message Log should be shown or not
			 * @private
			 */
			_addMessage: function (sTarget, sMessage, sLongText, sMessageType) {
				var oMessageProcessor = this._getEventModel();
				this.addMessage(sTarget, sMessage, sLongText, sMessageType, oMessageProcessor);
				//	this._showMessages();
			},

			/**
			 * helper method to remove the message from message processor model
			 * based on target path and updates the ErrorCount in the model.
			 * @param {string} sTarget Binding path of the Control
			 * @private
			 */
			_removeMessage: function (sTarget) {
				var oMessageProcessor = this._getEventModel();
				this.removeMessage(sTarget, oMessageProcessor);
				//	this._showMessages();
			},

			/**
			 * Function returns fragment ID for effect table in edit mdoe based on
			 * the collapsed/epanded flag
			 * @returns {string} Fragment Name
			 * @private
			 */
			_getEffectFragmentId: function () {
				var bCollapsed = this._getEffectCollapsed();
				if (bCollapsed) {
					return ("defEfftEditCollapsedFrag");
				} else {
					return ("defEfftEditExpandedFrag");
				}
			},

			/**
			 * Returns data binding path based on the field name given
			 * for deferment Effects Fragment fields
			 * @param {string} sFieldName  Field Name
			 * @returns {string}  Binding path
			 * @private
			 */
			_getEffectFragBindingPathByFieldName: function (sFieldName) {
				var sFragId, sBindingPath = "",
					oFragFieldCntrl;
				sFragId = this._getEffectFragmentId();
				oFragFieldCntrl = this._getFragmentControl(sFragId, sFieldName);
				if (oFragFieldCntrl) {
					sBindingPath = this.getBindingPathForProperty(oFragFieldCntrl, "value");
				}
				return sBindingPath;
			}
		}));
});