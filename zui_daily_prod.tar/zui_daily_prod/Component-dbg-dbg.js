sap.ui.define(
    ["sap/suite/ui/generic/template/lib/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("com.ui.crescent.zuidailyprodreport.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);