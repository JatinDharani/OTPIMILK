sap.ui.define([
    "sap/m/PDFViewer",
    "sap/m/BusyDialog",
    "sap/m/MessageBox",
    "sap/ui/core/format/DateFormat",
], function (PDFViewer, BusyDialog, MessageBox, DateFormat) {
    'use strict';

    return {
        onBeforeEdit:function(){
            this._readRemarks();
        },
        onBeforeSave:function(){
            this.onPressSave();
        },
        /**
         * Action triggered on print preview
         * @param {object} oEvent sap.ui.base.Event
         */
        onPrint: async function (oEvent) {
            try {
                const oModel = oEvent?.getSource()?.getModel();
                const oData = oEvent?.getSource()?.getBindingContext()?.getObject();
                if (oData) {
                    var opdfViewer = new PDFViewer();
                    this.getView().addDependent(opdfViewer);
                    var oBusyDialog = new BusyDialog();
                    oBusyDialog.open()
                    var vPDF = await this.getPDFData(oData, oModel);
                    if (vPDF?.results[0]?.stream_data) {
                        let base64EncodedPDF = vPDF.results[0].stream_data;
                        let decodedPdfContent = atob(base64EncodedPDF);
                        let byteArray = new Uint8Array(decodedPdfContent.length);
                        for (var i = 0; i < decodedPdfContent.length; i++) {
                            byteArray[i] = decodedPdfContent.charCodeAt(i);
                        }
                        var blob = new Blob([byteArray.buffer], {
                            type: 'application/pdf'
                        });
                        var pdfurl = URL.createObjectURL(blob);
                        jQuery.sap.addUrlWhitelist("blob"); // register blob url as whitelist
                        opdfViewer.setSource(pdfurl);
                        opdfViewer.setVisible(true);

                        opdfViewer.setTitle(this.geti18nText("DPR"));
                        opdfViewer.open();
                    }
                    oBusyDialog.close();
                }
            }
            catch (e) {
                oBusyDialog.close();
            }
        },

        geti18nText: function (id) {
            const oBundle = this.getView().getModel("@i18n").getResourceBundle();
            return oBundle.getText(id);
        },

        /**
         * Returns the response of printPreview oData call
         * @param {string} sId Table ID
         * @returns {object}  oData response
         */
        getPDFData: async function (oData, oModel) {
            const sPath = `/Print(p_contract='${oData?.Vbeln}',p_date=${this.getOdataDate(oData?.Zdate)})/Set`;
            return new Promise((resolve, reject) => {
                // Perform Read operation and pass billingdoc as parameter to URL
                oModel.read(sPath,
                    {
                        success: function (oData, oResponse) {
                            resolve(oData);
                        },
                        error: function (oError) {
                            reject(oError);
                        }
                    });
            })
        },

        /**
         * Returns the date in Odata format
         * @param {date} date Date()
         * @returns {string}  odata date format
         */
        getOdataDate: function (date) {
            const year = date.getFullYear();
            const month = String(date.getMonth() + 1).padStart(2, '0');
            const day = String(date.getDate()).padStart(2, '0');

            return `datetime'${year}-${month}-${day}T00:00:00'`;
        },

        /**
         * Action triggered on Generate
         * @param {object} oEvent sap.ui.base.Event
         */
        onGenerate: function (oEvent) {
            this.onGenerateRevise(oEvent, "Generate");
        },

        /**
         * Action triggered on Revise
         * @param {object} oEvent sap.ui.base.Event
         */
        onRevise: function (oEvent) {
            this.onGenerateRevise(oEvent, "revise");
        },

        /**
         * Function for generate/revise
         * @param {object} oEvent sap.ui.base.Event
         * @param {string} sId action Id
         */
        onGenerateRevise: async function (oEvent, sId) {
            try {
                const oModel = oEvent?.getSource()?.getModel();
                const oData = oEvent?.getSource()?.getBindingContext()?.getObject();
                if (oData) {
                    var oBusyDialog = new BusyDialog();
                    oBusyDialog.open()
                    const aResponse = await this.getGenerateData(oData, oModel, sId);
                    const oResponse = aResponse?.results[0];
                    oBusyDialog.close();
                    oModel.refresh();
                    if (oResponse?.msgty === 'S') {
                        MessageBox.success(oResponse?.msg, {
                            title: "Success",
                            onClose: function () {
                            }
                        });
                    }
                    else {
                        MessageBox.error(oResponse?.msg, {
                            title: "Error",
                            onClose: function () {
                            }
                        });
                    }
                }
            }
            catch (e) {
                oBusyDialog.close();
            }
        },

        /**
         * Returns the response of Generate/Response oData call
         * @param {object}  oData response
         * @param {object}  oModel data model
         * @param  {string} sId action Id
         */
        getGenerateData: async function (oData, oModel, sId) {
            const sPath = `/${sId}(p_contract='${oData?.Vbeln}',p_date=${this.getOdataDate(oData?.Zdate)})/Set`;
            return new Promise((resolve, reject) => {
                // Perform Read operation and pass billingdoc as parameter to URL
                oModel.read(sPath,

                    {
                        success: function (oData, oResponse) {
                            resolve(oData);
                        },
                        error: function (oError) {
                            reject(oError);
                        }
                    });
            })
        },
        /**
        * Returns the response of Generate/Response oData call
        * @param {object}  oData response
        * @param {object}  oModel data model
        * @param  {string} sId action Id
        */
        onUpload: async function (oData, oModel, sId) {
            if (!this.importDialog) {
                //create instance of fragment
                this.importDialog = sap.ui.xmlfragment("com.ui.crescent.zuidailyprodreport.ext.fragment.fileUpload", this);
            }
            this.getView().addDependent(this.importDialog);
            this.importDialog.open();

        },
        /**
        * Returns the response of Generate/Response oData call
        * @param {object}  oData response
        * @param {object}  oModel data model
        * @param  {string} sId action Id
        */
        handleCancelPress: async function (oData, oModel, sId) {
            this.importDialog.close();
            this.importDialog.destroy();
            this.importDialog = null;
        },
        onTypeMisMatch:function(){
            MessageBox.error("Only PDF files are allowed.");
        },


        handleUploadPress: async function (oData, oModel, sId) {
            //perform upload
            var oModel = this.getView().getModel();
            var oResourceBundle = this.getView().getModel("i18n").getResourceBundle();
            var oData = oData?.getSource()?.getBindingContext()?.getObject();
            var contractData = oData.Vbeln;
            var date = DateFormat.getDateInstance({ pattern: "yyyyMMdd" }).format(oData.Zdate);
            var sOption = sap.ui.getCore().byId("GroupA").getSelectedIndex();
            if(sOption || sOption === 0 ){
                   sOption = (sOption + 1).toString();
            }
          
            var oFileUploader = sap.ui.getCore().byId("fupImport");
            var sMsg = "";

            //check file has been entered
            var sFile = oFileUploader.getValue();
            if (!sFile) {
                sMsg = "Please select a file first";
                sap.m.MessageToast.show(sMsg);
                return;
            }
            else {
                this._saveEmailData(oData.Zdate,contractData,sOption);
                var that = this;
                that._addTokenToUploader(contractData, date);
                oFileUploader.upload();
                that.importDialog.close();

            }

        },
        _saveEmailData:function(date,contractData,sOptions){
            var oModel = this.getView().getModel("remarks");
            var oRemModel = this.getView().getModel("remarksData");
            let sSelectedSign = oRemModel.getProperty("/selectedsign");
            if((!sOptions && sOptions !== "0") || !(sSelectedSign)){
                sap.m.MessageToast.show("Please Select value for 'Approved DPR-GS for the issue' and 'Select Approval Process'");
                return;
            } 
            var oPayload = {
                VBELN:contractData,
                ExeDate:date,
                Option:sOptions ?  sOptions: "0",
                Signature:oRemModel.getProperty("/selectedsign")
            }
            oModel.create("/EMAIL_OPTSet",oPayload,{success:function(){
                MessageBox.success("Data saved successfully!");
            }.bind(this),error:function(){
                MessageBox.error("Error occured during  save.");
            }.bind(this)});
        },

        _addTokenToUploader: function (contractData, date) {
            //Add header parameters to file uploader.
            var oDataModel = this.getView().getModel('gasAttachment');
            var sTokenForUpload = oDataModel.getSecurityToken();
            var oFileUploader = sap.ui.getCore().byId("fupImport");
            var oHeaderParameter = new sap.ui.unified.FileUploaderParameter({
                name: "X-CSRF-Token",
                value: sTokenForUpload
            });

            var sFile = oFileUploader.getValue();
            var oHeaderSlug = new sap.ui.unified.FileUploaderParameter({
                name: "SLUG",
                value: sFile
            });

            //Header parameter need to be removed then added.
            oFileUploader.removeAllHeaderParameters();
            oFileUploader.addHeaderParameter(oHeaderParameter);

            oFileUploader.addHeaderParameter(oHeaderSlug);
            //set upload url
            const sPath = `/ATTACHSet(CONTRACT='${contractData}${date}',REPORT='D')/$value`;
            var sUrl = oDataModel.sServiceUrl + sPath;
            oFileUploader.setUploadUrl(sUrl);
        },

        handleUploadComplete: function (oEvent) {
            var oResourceBundle = this.getView().getModel("i18n").getResourceBundle();
            var sMsg = "";
            var sMsgType = "Error";
            var oResponse = oEvent.getParameters("response");
            if (oResponse) {
                if (oResponse.status === 204) {
                    //TODO use i18n
                    sMsg = oResourceBundle.getText("uploadSuccess");
                    sMsgType = "Information";
                } else {
                    sMsg = oResourceBundle.getText("uploadFailure");
                    sMsgType = "Error";
                }
            }
            this.importDialog.destroy();
            this.importDialog = null;
            sap.m.MessageToast.show(sMsg);
        },
        onDownload: async function (oData, oModel, sId) {

            try {
                //perform Download
                var opdfViewer = new PDFViewer();
                this.getView().addDependent(opdfViewer);
                var oDataModel = this.getView().getModel('gasAttachment');
                var oModel = this.getView().getModel();
                var oResourceBundle = this.getView().getModel("i18n").getResourceBundle();
                var oData = oData?.getSource()?.getBindingContext()?.getObject();
                var contractData = oData.Vbeln;
                var date = DateFormat.getDateInstance({ pattern: "yyyyMMdd" }).format(oData.Zdate);
                const sPath = `/ATTACHSet(CONTRACT='${contractData}${date}',REPORT='D')/$value`;
                var sUrl = oDataModel.sServiceUrl + sPath;
                const aResponse = await this.checkDownloadExist(sPath, oDataModel,opdfViewer);
                if (aResponse.statusCode == 200) {
                    opdfViewer.setSource(sUrl);
                    opdfViewer.setShowDownloadButton(false);
                    opdfViewer.open();
                } else {
                    MessageBox.error(oResourceBundle.getText("downloadFailed"));
                };

               
            } catch (error) {
                console.log("error");
            }
        },
        onInit: function () {
            var onPageDataLoaded = function () {
               var oModel = this.getView().getModel("remarks");
               var oContext = this.getView().getBindingContext();
               var oObject = oContext.getObject();
               if(!oObject){

                return;
               }
               this._context = oContext;
               var sVblen = oObject.Vbeln;
               var oexeDate = oObject.Zdate;
                var oKeys = {VBELN:sVblen,ExeDate:oexeDate};
               var oKey = oModel.createKey("/RemarksSet",oKeys);
               var oRemModel = this.getView().getModel("remarksData");
               oRemModel.setProperty("/VBELN",sVblen);
               oRemModel.setProperty("/ExeDate",oexeDate);
                    oRemModel.setProperty("/text","");
                    let oSaveBtn = this.getView().byId("com.ui.crescent.zuidailyprodreport::sap.suite.ui.generic.template.ObjectPage.view.Details::daily--action::saveButton");
            oModel.read(oKey,{
                "success":function(oData,oResponse){
                   
                    oRemModel.setProperty("/text",oData.Remarks_DPR);
                    
                    
                     if(oData.Display_only === ""){
                    oSaveBtn.setVisible(true);
                    oRemModel.setProperty("/editable",true);
                     }else{
                        oSaveBtn.setVisible(false);
                        oRemModel.setProperty("/editable",false);

                     }
                }.bind(this),
                "error":function(oError){
                    oSaveBtn.setVisible(false);
                    oRemModel.setProperty("/editable",false);
                }.bind(this)
            });
            let oEmailKey =  oModel.createKey("/EMAIL_OPTSet",oKeys);
            oModel.read(oEmailKey,{
                "success":function(oData,oResponse){
                   
                    oRemModel.setProperty("/selectedsign",oData.Signature);
                    oRemModel.setProperty("/selectedRadio",parseInt(oData.Option) - 1);
                    
                    
                }.bind(this),
                "error":function(oError){
                    
                }.bind(this)
            });
            }.bind(this);
        
            // Attach page data loaded callback of extension API
            this.templateBaseExtension.getExtensionAPI().attachPageDataLoaded(onPageDataLoaded.bind(this));
        },
        _readRemarks:function(){
            let  oContext = this._context;
            let oObject = oContext.getObject();
            var oModel = this.getView().getModel("remarks");
            if(!oObject){

             return;
            }
           
             
             
                    let oKeys = {VBELN:sVblen,ExeDate:oexeDate};
                    let oKey = oModel.createKey("/RemarksSet",oKeys);
                    var oRemModel = this.getView().getModel("remarksData");
                    oRemModel.setProperty("/VBELN",sVblen);
                    oRemModel.setProperty("/ExeDate",oexeDate);
                         oRemModel.setProperty("/text","");
                         let oSaveBtn = this.getView().byId("com.ui.crescent.zuidailyprodreport::sap.suite.ui.generic.template.ObjectPage.view.Details::daily--action::saveButton");
                 oModel.read(oKey,{
                     "success":function(oData,oResponse){
                        
                         oRemModel.setProperty("/text",oData.Remarks_DPR);
                         
                         
                          if(oData.Display_only === ""){
                         oSaveBtn.setVisible(true);
                         oRemModel.setProperty("/editable",true);
                          }else{
                             oSaveBtn.setVisible(false);
                             oRemModel.setProperty("/editable",false);
     
                          }
                     }.bind(this),
                     "error":function(oError){
                         oSaveBtn.setVisible(false);
                         oRemModel.setProperty("/editable",false);
                     }.bind(this)
                 });
        },
        handlePreview:function(){
            var opdfViewer = new PDFViewer();
           var oInput = sap.ui.getCore().byId("fupImport");
        var oFile = oInput.FUEl.files[0];
        let toBase64 = file => new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result);
            reader.onerror = reject;
        });
            let base64EncodedPDF =  toBase64(oFile
                );
                base64EncodedPDF.then(function(oData){
                    oData = oData.split("base64,")[1];
                    let decodedPdfContent = atob(oData);
                    let byteArray = new Uint8Array(decodedPdfContent.length);
                    for (var i = 0; i < decodedPdfContent.length; i++) {
                        byteArray[i] = decodedPdfContent.charCodeAt(i);
                    }
                    var blob = new Blob([byteArray.buffer], {
                        type: 'application/pdf'
                    });
                    var pdfurl = URL.createObjectURL(blob);
                    jQuery.sap.addUrlWhitelist("blob"); // register blob url as whitelist
                    opdfViewer.setSource(pdfurl);
                    opdfViewer.setVisible(true);
        
                    opdfViewer.setTitle(this.geti18nText("DPR"));
                    opdfViewer.open();
                }.bind(this));   
            
        },
        onPressSave:function(){
            let oRModel = this.getOwnerComponent().getModel("remarksData");
            var sRemarks = this.getOwnerComponent().getModel("remarksData").getProperty("/text");
            if(sRemarks){
                var oModel = this.getOwnerComponent().getModel("remarks");
                var oPayload = {
                    VBELN:oRModel.getProperty("/VBELN"),
                    ExeDate:oRModel.getProperty("/ExeDate"),
                    Remarks_DPR:oRModel.getProperty("/text")
                }
                oModel.create("/RemarksSet",oPayload,{success:function(){
                    MessageBox.success("Remarks saved successfully!");
                }.bind(this),error:function(){
                    MessageBox.error("Error occured during remarks save.");
                }.bind(this)});
            }
        },
        checkDownloadExist: async function (sPath, oModel) {
            return new Promise((resolve, reject) => {
                // Perform Read operation and pass billingdoc as parameter to URL
                oModel.read(sPath,

                    {
                        success: function (oData,oResponse) {
                           resolve(oResponse);
                            
                        },
                        error: function (oError) {
                           
                            resolve(oError);
                        }
                    });
            })
        }

    };
});