/*
 * Copyright (C) 2009-2023 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([
	"sap/ui/core/ValueState",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/ui/core/MessageType"
], function (ValueState, MessageBox, MessageToast, MessageType) {
	"use strict";

	return {
		/* =========================================================== */
		/* Attributes and Class Constants                              */
		/* =========================================================== */

		/* =========================================================== */
		/* Public Methods                                              */
		/* =========================================================== */

		/**
		 * Function to validate the user entered deferment code in the control-selProdNetwork
		 * @param {sap.ui.base.Event} oEvent  Event Instance
		 * @returns {boolean}  true/false Whether deferement code entered is valid or not
		 */
		validateDefermentCode: function () {
			var oDefCode = this._getDefermentCodeControl(),
				sDefCode = this._getEventDataProperty("/DefCode"),
				aDeferCodeList = this._getDeferCodeList(),
				bValidDefCode = false,
				sTarget = this.getBindingPathForProperty(oDefCode, "value");
			var oResourceBundle = this.getResourceBundle();
		
			// Remove any existing messages for this target
			this._removeMessage(sTarget);
		
			// Check if deferment code is empty
			if (sDefCode.length === 0) {
				this._addMessage(
					sTarget,
					oResourceBundle.getText("ENTER_DEFERCODE_ERR_MSG"),
					oResourceBundle.getText("ENTER_DEFERCODE_ERR_MSG"),
					MessageType.Error
				);
			} else {
				// Validate deferment code and Parent Code
				var oMatchingDefCode = aDeferCodeList.find(item => item.DefCode === sDefCode);
				if (oMatchingDefCode) {
					if (!oMatchingDefCode.ParentCode || oMatchingDefCode.ParentCode.trim() === "") {
						this._addMessage(
							sTarget,
							"Please select the Child Deferment Code",
							"Please select the Child Deferment Code",
							MessageType.Error
						);
						bValidDefCode = false;
					} else {
						this._setEventDataProperty("/DefCodeDescription", oMatchingDefCode.Description);
						bValidDefCode = true;
					}
				} else {
					this._addMessage(
						sTarget,
						oResourceBundle.getText("INVALID_DEFERCODE_ERR_MSG"),
						oResourceBundle.getText("INVALID_DEFERCODE_ERR_MSG"),
						MessageType.Error
					);
					this._setEventDataProperty("/DefCodeDescription", "");
				}
			}
		
			return bValidDefCode;
		},

		/**
		 * Validates the Effect value
		 * Values cannot be blank or 0
		 * If effect unit is % , value should be between 1- 100 Else it should be greater than 0
		 * @param {Object[]} aTempEffectExpanded  Array of effects
		 * @returns {Object}  Object containing the status of Validation S/E and message/paramters if error
		 */
		validateEffectValues: function (aTempEffectExpanded) {
			var oErrorObject = {
				messageType: "E",
				messageKey: "DEF_EFFECT_MED_VAL",
				parameters: []
			};

			var oDurEfftValPath = this._getEffectFragBindingPathByFieldName("idDefEfftDurEfftVal");
			for (var i = 0; i < aTempEffectExpanded.length; i++) {
				oErrorObject.parameters = [aTempEffectExpanded[i].UIEffectSeq, aTempEffectExpanded[i].EffectMedium];
				if (aTempEffectExpanded[i].EffectMedium === "ALL") {
					continue;
				}
				if (aTempEffectExpanded[i].CollapEffectVal !== "") {
					var value = parseFloat(aTempEffectExpanded[i].CollapEffectVal);
					// Effect Unit = % , value can be between 1-100
					if (aTempEffectExpanded[i].CollapEffectUnit === "%") {
						if (!isNaN(value) && (value >= 0.0) && (value <= 100.0)) {
							continue;
						} else {
							oErrorObject.sTarget = "/DeferEffectsSet/" + i + "/" + oDurEfftValPath;
							return oErrorObject;
						}
					} else {
						if (!isNaN(value) && (value >= 0.0)) {
							continue;
						} else {
							oErrorObject.sTarget = "/DeferEffectsSet/" + i + "/" + oDurEfftValPath;
							return oErrorObject;
						}
					}
				} else {
					oErrorObject.sTarget = "/DeferEffectsSet/" + i + "/" + oDurEfftValPath;
					return oErrorObject;
				}
			}
			return {
				messageType: "S"
			};
		},

		/**
		 * Event Handler for From Date Change
		 * @param {sap.ui.base.Event} oEvent  Event Instance
		 */
		onFromDateChange: function (oEvent) {
			var oDateCntrl = oEvent.getSource();
			var sTargetDate = this.getBindingPathForProperty(oDateCntrl, "value");
			this._removeMessage(sTargetDate);
			var oResourceBundle = this.getResourceBundle();
			if (!oEvent.getParameter("valid")) {
				oDateCntrl.setDateValue(null);
				oDateCntrl.setValueState(ValueState.Error);
				this._addMessage(sTargetDate, oResourceBundle.getText("DEF_EVENT_EMPTY_EFF_FROM_DATE"), oResourceBundle.getText(
					"DEF_EVENT_EMPTY_EFF_FROM_DATE"), MessageType.Error, false);
			}
			this.handleUpdateTracking(oEvent);
		},

		/**
		 * Event Handler for To Date Change
		 * @param {sap.ui.base.Event} oEvent  Event Instance
		 */
		onToDateChange: function (oEvent) {
			var oDateCntrl = oEvent.getSource();
			var sTargetDate = this.getBindingPathForProperty(oDateCntrl, "value");
			this._removeMessage(sTargetDate);
			var oResourceBundle = this.getResourceBundle();
			if (!oEvent.getParameter("valid")) {
				oDateCntrl.setDateValue(null);
				oDateCntrl.setValueState(ValueState.Error);
				this._addMessage(sTargetDate, oResourceBundle.getText("DEF_EVENT_EMPTY_EFF_TO_DATE"), oResourceBundle.getText(
					"DEF_EVENT_EMPTY_EFF_TO_DATE"), MessageType.Error, false);
			}
			this.handleUpdateTracking(oEvent);
		},

		/**
		 * Function to Perform Mandatory checks for From and To DateTimes
		 * @returns {boolean}  Boolean Flag if dates are valid or not
		 */
		_validateDates: function () {
			var oFromDateCntrl = this._getFromDateControl(),
				oToDateCntrl = this._getToDateControl();
			var bCheckFromDate = (!this._isBlank(oFromDateCntrl)),
				bCheckFromTime = (!this._isBlank(this._getFromTimeControl())),
				sTargetDate = this.getBindingPathForProperty(oFromDateCntrl, "value"),
				sTargetTime = this.getBindingPathForProperty(this._getFromTimeControl(), "value"),
				bMCheckToDate = (!this._isBlank(oToDateCntrl)),
				bMCheckToTime = (!this._isBlank(this._getToTimeControl())),
				sTargetToDate = this.getBindingPathForProperty(oToDateCntrl, "value"),
				sTargetToTime = this.getBindingPathForProperty(this._getToTimeControl(), "value"),
				oFromDateTime = this._getFromDateTimeValue(),
				oToDateTime = this._getToDateTimeValue(),
				bValidDateTime = true;
			var oResourceBundle = this.getResourceBundle();

			this._removeMessage(sTargetDate);
			this._removeMessage(sTargetTime);
			this._removeMessage(sTargetToDate);
			this._removeMessage(sTargetToTime);

			if (oFromDateCntrl && oToDateCntrl) {
				if (!bCheckFromDate || oFromDateCntrl.getDateValue() === null) {
					this._addMessage(sTargetDate, oResourceBundle.getText("DEF_EVENT_EMPTY_EFF_FROM_DATE"), oResourceBundle.getText(
						"DEF_EVENT_EMPTY_EFF_FROM_DATE"), MessageType.Error, false);
					bValidDateTime = false;
				}
				if (!bCheckFromTime) {
					this._addMessage(sTargetTime, oResourceBundle.getText("DEF_EVENT_EMPTY_EFF_FROM_TIME"), oResourceBundle.getText(
						"DEF_EVENT_EMPTY_EFF_FROM_TIME"), MessageType.Error, false);
					bValidDateTime = false;
				}
				if (!bMCheckToDate && bMCheckToTime) { // To Date is not entered but To Time is entered
					this._addMessage(sTargetToDate, oResourceBundle.getText("DEF_EVENT_EMPTY_EFF_TO_DATE"), oResourceBundle.getText(
						"DEF_EVENT_EMPTY_EFF_TO_DATE"), MessageType.Error, false);
					bValidDateTime = false;
				}

				if (oToDateCntrl.getValue() !== "" && oToDateCntrl.getDateValue() === null) {
					this._addMessage(sTargetToDate, oResourceBundle.getText("DEF_EVENT_EMPTY_EFF_TO_DATE"), oResourceBundle.getText(
						"DEF_EVENT_EMPTY_EFF_TO_DATE"), MessageType.Error, false);
					bValidDateTime = false;
				}

				if (bMCheckToDate && !bMCheckToTime) { // To Date is entered but To Time is not entered
					this._addMessage(sTargetToTime, oResourceBundle.getText("DEF_EVENT_EMPTY_EFF_TO_TIME"), oResourceBundle.getText(
						"DEF_EVENT_EMPTY_EFF_TO_TIME"), MessageType.Error, false);
					bValidDateTime = false;
				}
				if (oFromDateTime !== null && oToDateTime !== null) {
					if (oFromDateTime >= oToDateTime) { //From DateTime is Greater/Equals to To DateTime, then error
						this._addMessage(sTargetToDate, oResourceBundle.getText("END_DATE_GREATER"), oResourceBundle.getText(
							"END_DATE_GREATER"), MessageType.Error, false);
						bValidDateTime = false;
					}
				}

				if (oFromDateTime !== null) {
					this._setEventDataProperty("/StrtPeriod", this._getDateTimeFormat().format(oFromDateTime));
				} else {
					this._setEventDataProperty("/StrtPeriod", "");
				}
				if (oToDateTime !== null) {
					this._setEventDataProperty("/EndPeriod", this._getDateTimeFormat().format(oToDateTime));
				} else {
					this._setEventDataProperty("/EndPeriod", "");
				}

				if (!bValidDateTime) {
					this._showMessages();
				}
			}

			return bValidDateTime;
		},

		/**
		 * Function to Check validity of a number
		 * @param {Object} oObject  Object from which the numbers need to be checked
		 * @param {string} sKey  property/key for which check needs to be done
		 * @return {boolean}  true/false if valid number
		 */
		_isValidNumber: function (oObject, sKey) {
			return oObject[sKey] !== "" && !isNaN(oObject[sKey]);
		},

		/**
		 * Function to Check and validate effective duration
		 * @param {Array} aDeferEffect  Deferment effects object array
		 * @returns {Object}  Validation message object
		 */
		_validateBlankInvalidEffectDuration: function (aDeferEffect) {
			var iMediumLength = this._getAllMediums().length,
				iDeferEffectLength = aDeferEffect.length,
				i,
				durValPerc,
				bValEffDuration = true;
			var oResourceBundle = this.getResourceBundle();

			for (i = 0; i < iDeferEffectLength; i = i + iMediumLength) {
				durValPerc = aDeferEffect[i].DurValPerc;
				if (aDeferEffect[i].DurationUnit === "T") {
					if (!this._checkTimeUnitDefEffectData(aDeferEffect[i].DurValDay, aDeferEffect[i].DurValHour, aDeferEffect[i].DurValMin,
							(i === 0 ? 0 : (i - iMediumLength + 1)))) {
						bValEffDuration = false;
						//break;
					}
				} else {
					var sTarget = "/DeferEffectsSet/" + (i === 0 ? 0 : (i - iMediumLength + 1)) + "/" + this._getEffectFragBindingPathByFieldName(
						"idDefEfftDurValPerc");
					if (durValPerc === "" || isNaN(durValPerc) || durValPerc < 0 || durValPerc > 100) {
						this._addMessage(sTarget, oResourceBundle.getText("DEF_EFFECT_INVALID"), oResourceBundle.getText(
							"DEF_EFFECT_INVALID"), MessageType.Error);
						bValEffDuration = false;
						//	break;
					} else {
						this._removeMessage(sTarget);
					}
				}
			}

			return bValEffDuration;
		},

		/**
		 * Function to check the Time unit Deferment Effect data and the error
		 * message key of i18n text if not correct
		 * @param {string} durValDay  Duration Day Value
		 * @param {string} durValHour  Duration Hour Value
		 * @param {string} durValMin  Duration Min Value
		 * @param {Integer} iTargetPathSeq  path number
		 * @returns {string}  If not valid than Error I18N message key undefined otherwise
		 * @private
		 */
		_checkTimeUnitDefEffectData: function (durValDay, durValHour, durValMin, iTargetPathSeq) {
			var bValidate = false,
				sTargetDay = "/DeferEffectsSet/" + iTargetPathSeq + "/" + this._getEffectFragBindingPathByFieldName("idDefEfftDurValDay"),
				sTargetHour = "/DeferEffectsSet/" + iTargetPathSeq + "/" + this._getEffectFragBindingPathByFieldName("idDefEfftDurValHour"),
				sTargetMin = "/DeferEffectsSet/" + iTargetPathSeq + "/" + this._getEffectFragBindingPathByFieldName("idDefEfftDurValMin"),
				oBundle = this.getResourceBundle();

			if (durValDay === "" && durValHour === "" && durValMin === "") {
				//Add message for day, hour and minutes field
				this._addMessage(sTargetDay, oBundle.getText("TIME_EMPTY"), oBundle.getText("TIME_EMPTY"), MessageType.Error);

			} else if (durValDay === "" || isNaN(durValDay) || durValDay < 0 || durValDay >= 1000) {

				this._addMessage(sTargetDay, oBundle.getText("DEF_EFFECT_INVAL_DAY"), oBundle.getText("DEF_EFFECT_INVAL_DAY"), MessageType.Error);

			} else if (durValHour === "" || isNaN(durValHour) || durValHour < 0 || durValHour >= 24) {

				this._addMessage(sTargetHour, oBundle.getText("DEF_EFFECT_INVAL_HOUR"), oBundle.getText("DEF_EFFECT_INVAL_HOUR"), MessageType.Error);

			} else if (durValMin === "" || isNaN(durValMin) || durValMin < 0 || durValMin >= 60) {

				this._addMessage(sTargetMin, oBundle.getText("DEF_EFFECT_INVAL_MIN"), oBundle.getText("DEF_EFFECT_INVAL_MIN"), MessageType.Error);

			} else if (parseInt(durValDay, 10) === 0 && parseInt(durValHour, 10) === 0 && parseInt(durValMin, 10) === 0) { // Check for initial value

				//Add message for day, hour and minutes field
				this._addMessage(sTargetDay, oBundle.getText("TIME_EMPTY"), oBundle.getText("TIME_EMPTY"), MessageType.Error);

			} else {
				this._removeMessage(sTargetDay);
				this._removeMessage(sTargetHour);
				this._removeMessage(sTargetMin);
				bValidate = true;
			}
			return bValidate;
		},

		/**
		 * Function to track changes to the event in Edit mode
		 * @param {sap.ui.base.Event}  oEvent  user event
		 */
		handleUpdateTracking: function (oEvent) {
			if (this.oHeaderVariables.sMode === "Edit" || this.oHeaderVariables.sMode === "Change") {
				this.isChanged = true;
				//	this._performOnSaveValidations(); //Recheck all validation error, instead of only deferment code
			}
		},

		/**
		 * This method sets value state text of control based on validation error
		 * @param {sap.ui.base.Event}  oEvent  validation Error Event
		 */
		onValidationErrorEffectVal: function (oEvent) {
			var sMsg = oEvent.getParameter("message"),
				sTarget = this.getBindingPathForProperty(oEvent.getParameter("element"), "value");

			if (sMsg) {
				this._addMessage(sTarget, sMsg, sMsg, MessageType.Error);
			}
		},

		/**
		 * This method sets value state of control based on validation success
		 * @param {sap.ui.base.Event}  oEvent  validation Susscess Event
		 */
		onValidationSuccessEffectVal: function (oEvent) {
			var sTarget = this.getBindingPathForProperty(oEvent.getParameter("element"), "value");
			this._removeMessage(sTarget);
		},

		/**
		 * This method sets value state text of control based on parse error
		 * @param {sap.ui.base.Event}  oEvent  parse Error Event
		 */
		onParseErrorEffectVal: function (oEvent) {
			var sMsg = oEvent.getParameter("message"),
				sTarget = this.getBindingPathForProperty(oEvent.getParameter("element"), "value");

			if (sMsg) {
				this._addMessage(sTarget, sMsg, sMsg, MessageType.Error);
			} else {
				this._removeMessage(sTarget);
			}
		},

		/**
		 * This function is called to Show a popup message of type Information
		 * @param {string} infoMessage  Info Message
		 */
		fnShowInfoMessage: function (infoMessage) {
			var oBundle = this.getResourceBundle();
			var textToDisplay = oBundle.getText(infoMessage);
			MessageBox.information(textToDisplay);
		},

		/**
		 * This function is called to Show a popup message of type error
		 * If the text, is found in i18n show
		 * @param {string} errorMessage Error Message
		 * @param {string} additionalParam1 Object
		 * @param {string} additionalParam2 Object
		 */
		fnShowErrorMessage: function (errorMessage, additionalParam1, additionalParam2) {
			var oBundle = this.getResourceBundle();
			var textToDisplay = oBundle.getText(errorMessage);
			if (!!additionalParam1 && !!additionalParam2) {
				textToDisplay = jQuery.sap.formatMessage(oBundle.getText(errorMessage), additionalParam1, additionalParam2);
			}
			this._showError({
				messageKey: textToDisplay,
				titleKey: textToDisplay
			}, false, {}, jQuery.proxy(function () {
				if (this.oHeaderVariables.goBackOnError === true) {
					this.oHeaderVariables.goBackOnError = false;
					this._navBack();
				}
			}, this));
		},

		/**
		 * This method sets value state text of control based on format error
		 * @param {sap.ui.base.Event}  oEvent  format error event
		 */
		onFormatErrorEffectVal: function (oEvent) {
			var sMsg = oEvent.getParameter("message"),
				sTarget = this.getBindingPathForProperty(oEvent.getParameter("element"), "value");

			if (sMsg) {
				this._addMessage(sTarget, sMsg, sMsg, MessageType.Error);
			} else {
				this._removeMessage(sTarget);
			}
		},

		/* =========================================================== */
		/* Private Methods                                             */
		/* =========================================================== */

		/**
		 * Function to Perform all the required validations before saving the data
		 * @returns {boolean}  true/false validation is ok or not
		 */
		_performOnSaveValidations: function () {
			this.removeAllMessages(); //Clear earlier existing messages
			var aEffectExpanded = this.createDeferEffectExpands(this._getEffectCollapsed()),
				//Check if the deferement effect values are proper.
				oValidateEffectValue = this.validateEffectValues(aEffectExpanded),
				aWorkOrderPlanset = this._getEventDataProperty("/DeferPlansSet"),
				aDeferEffect = [],
				bWOEventOverlap = false,
				bValidations = true,
				bPercValue = false;
			var oResourceBundle = this.getResourceBundle();

			aDeferEffect = jQuery.grep(aEffectExpanded, function (oEffectExpanded) {
				return oEffectExpanded.EffectMedium !== "ALL";
			});

			//Validate Deferment Code
			if (!this.validateDefermentCode()) {
				bValidations = false;
			}

			//Validate From and To DateTime
			if (!this._validateDates()) {
				bValidations = false;
			}

			//Validate effect values
			if (aEffectExpanded.length <= 0) {
				this._showError({
					messageKey: "NO_EFFECTS_ERROR_MSG",
					titleKey: "NO_EFFECT_ERROR_TITLE"
				}, false, {});
				bValidations = false;
			}
			aDeferEffect.forEach(this._convertDurationAndEffectToString, this);

			if (this._validateBlankInvalidEffectDuration(aDeferEffect)) {
				if (!(this._isDurationPercentageValid(aDeferEffect) && this._isDurationTimeValid(aDeferEffect))) {
					bValidations = false;
				}
			} else {
				bValidations = false;
			}

			if (oValidateEffectValue.messageType === "E") {
				var sMsg = oResourceBundle.getText(oValidateEffectValue.messageKey, oValidateEffectValue.parameters);
				this._addMessage(oValidateEffectValue.sTarget, sMsg, sMsg, MessageType.Error);
				bValidations = false;
			} else {
				this._removeMessage(oValidateEffectValue.sTarget);
			}

			//Validate work order
			if (aWorkOrderPlanset.length > 0) {
				bWOEventOverlap = this.checkWorkOrderOverLap(aWorkOrderPlanset);

				if (aWorkOrderPlanset.length > 0 && !bWOEventOverlap) { // Check for work order period overlap with event period
					this._showError({
						messageKey: "WORKORDER_OVERLAP",
						titleKey: "WORKORDER_OVERLAP_ERROR"
					}, false, {});
					bValidations = false;
				}
			}

			//UI validation to check percentage value before time
			for (var lv = 0; lv < aDeferEffect.length; lv++) {
				if (aDeferEffect[lv].DurationUnit === "P") {
					bPercValue = true;
				} else if (bPercValue === true && aDeferEffect[lv].DurationUnit === "T") {
					bValidations = false;
					this._addMessage(oValidateEffectValue.sTarget, oResourceBundle.getText("PERCENTAGE_BEFORE_TIME"), oResourceBundle.getText(
						"PERCENTAGE_BEFORE_TIME"), MessageType.Error);
					break;
				}
			}
			return bValidations;
		},

		/**
		 * Function to check validity of effect time duration
		 * @param {object[]} aDeferEffect  Array of objects of deferment effects
		 * @returns {boolean}  Boolean value indicating if the validation was passed or failed
		 */
		_isDurationTimeValid: function (aDeferEffect) {
			var oToDateTime = this._getToDateTimeValue(),
				oFromDateTime = this._getFromDateTimeValue(),
				iTotalTime = this._getTotalDurationTime(aDeferEffect),
				fTotalPerc = this._getTotalDurationPercentage(aDeferEffect),
				iEventDuration,
				oEffectTimeValid = {
					bIsValid: false, //flag for validity
					bTimeGreater: null // flag to check if total effect duration is more than event duration
				},
				bValid = false;

			if (oToDateTime !== null && oFromDateTime !== null && !isNaN(iTotalTime) && iTotalTime !== null) {
				iEventDuration = oToDateTime - oFromDateTime;
				oEffectTimeValid.bTimeGreater = (iEventDuration < iTotalTime);
				if (fTotalPerc === null) {
					oEffectTimeValid.bIsValid = (iEventDuration === iTotalTime);
				} else {
					oEffectTimeValid.bIsValid = (iTotalTime < iEventDuration);
				}
			} else {
				oEffectTimeValid.bIsValid = true;
			}
			var sTargetDay = "/DeferEffectsSet/" + 0 + "/" + this._getEffectFragBindingPathByFieldName("idDefEfftDurValDay"),
				oBundle = this.getResourceBundle();
			if (!oEffectTimeValid.bIsValid) {
				if (oEffectTimeValid.bTimeGreater) {
					this._addMessage(sTargetDay, oBundle.getText("EFFECT_DUR_GREATER_THAN_EVENT_DUR"), oBundle.getText(
						"EFFECT_DUR_GREATER_THAN_EVENT_DUR"), MessageType.Error);
				} else {
					this._addMessage(sTargetDay, oBundle.getText("EFFECT_DUR_LESS_THAN_EVENT_DUR"), oBundle.getText("EFFECT_DUR_LESS_THAN_EVENT_DUR"),
						MessageType.Error);
				}
			} else {
				bValid = true;
			}
			return bValid;
		},

		/**
		 * Function to get duration percentage validity
		 * @param {object[]} aDeferEffect  Array of objects of deferment effects
		 * @returns {boolean}  Boolean value indicating if the validation was passed or failed
		 */
		_isDurationPercentageValid: function (aDeferEffect) {
			var fTotalPerc = this._getTotalDurationPercentage(aDeferEffect),
				sTarget = this._getEffectFragBindingPathByFieldName("idDefEfftDurValPerc");
			var oResourceBundle = this.getResourceBundle();

			if (fTotalPerc !== null && fTotalPerc !== 100) {
				this._addMessage(sTarget, oResourceBundle.getText("EFFECT_DURATION_TOTAL"), oResourceBundle.getText(
					"EFFECT_DURATION_TOTAL"), MessageType.Error);
				return false;
			} else {
				this._removeMessage(sTarget);
				return true;
			}
		},

		/**
		 * Shows message toast
		 * @param {string} sMessage  Message string
		 */
		_showToastMessage: function (sMessage) {
			MessageToast.show(sMessage);
		},

		/**
		 * Function to Process error code with proper popup message
		 * @param {string} sMode  page mode display/edit
		 * @param {object} oError  oError	Error Object
		 */
		_processErroCode: function (sMode, oError) {
			var oBundle = this.getResourceBundle(),
				sMessageKey,
				oErrorDetail,
				sErrorTitle = (sMode === "Edit") ? oBundle.getText("EVENT_UPDATE_ERROR") : oBundle.getText("EVENT_CREATE_ERROR");
			if (!oError.error.innererror.errordetails ||
				oError.error.innererror.errordetails.length <= 0) {
				this._showError({
					messageKey: oError.error.message.value,
					titleKey: sErrorTitle
				}, false, {});
			} else {
				oErrorDetail = oError.error.innererror.errordetails[0];
				switch (oErrorDetail.code) {
				case "GHO_DEFERMENT_BO/054":
					this.oHeaderVariables.PpaReqReference = sMode === "Edit" ? "UPDATE" : "SAVE";
					this.openPPADialog();
					break;
				case "GHO_DEFERMENT_BO/055":
					this.oHeaderVariables.PpaReqReference = sMode === "Edit" ? "UPDATE" : "SAVE";
					this.openAuditDialog();
					break;
				case "GHO_DEFERMENT_BO/056":
					sMessageKey = sMode === "Edit" ? "PPA_UPDATE_PENDING" : "PPA_CREATE_PENDING";
					MessageBox.information(oBundle.getText(sMessageKey));
					break;
				case "GHO_DEFERMENT_BO/057":
					sMessageKey = sMode === "Edit" ? "PPA_UPDATE_REJECTED" : "PPA_CREATE_REJECTED";
					MessageBox.information(oBundle.getText(sMessageKey));
					break;
				case "GHO_DEFERMENT_BO/047":
					break;
				default:
					this._showError({
						messageKey: oErrorDetail.message,
						titleKey: sErrorTitle
					}, false, {}, this._defaultErrorMessageCallback.bind(this));
					break;
				}
			}
		},

		/**
		 * Function to Check for blank value of given control
		 * @param {sap.ui.core.Control}	oControl  control object
		 * @returns {boolean}  true/false whether the value is blank or not
		 */
		_isBlank: function (oControl) {
			var sValue = "";
			if (oControl && oControl.getValue) {
				sValue = oControl.getValue();
			}
			return (sValue === "") ? true : false;
		},

		/**
		 * Default callback to be used for error messages
		 */
		_defaultErrorMessageCallback: function () {
			if (this.oHeaderVariables.goBackOnError === true) {
				this.oHeaderVariables.goBackOnError = false;
				this._navBack();
			} else {
				this._focusFirstErrorStateControl();
			}
		},

		/**
		 * Displays the error message using the messageKey and parameters provided in oMessage object.
		 * @param	{Object}	oMessage	Map of object containing messageKey and parametrs
		 * @param	{function}	fnCallback	callback function to be called on click of OK in error message
		 */
		/*_showErrorMessage: function(oMessage, fnCallback) {
			var callBackFnc,
				sMsg = this.getResourceBundle().getText(oMessage.messageKey, oMessage.parameters);
			sMsg = sMsg ? sMsg : oMessage;
			if (!fnCallback) {
				callBackFnc = this._defaultErrorMessageCallback.bind(this);
			} else {
				callBackFnc = fnCallback;
			}
			MessageBox.error(sMsg, {
				onClose: callBackFnc
			});
		},*/

		/**
		 * Displays the error message using the messageKey and parameters provided in oMessage object.
		 * @param {Object} oMessage  Map of object containing messageKey and parametrs
		 * @param {boolean} bShowDetails  flag to show details
		 * @param {Object} oDetails  Error message details
		 * @param {function} fnCallback  callback function to be called on click of OK in error message
		 * @private
		 */
		_showError: function (oMessage, bShowDetails, oDetails, fnCallback) {
			var callBackFnc,
				oResourceBundle = this.getResourceBundle(),
				sMsg = oResourceBundle.getText(oMessage.messageKey, oMessage.parameters),
				sTitle = oResourceBundle.getText(oMessage.titleKey);

			sMsg = sMsg ? sMsg : oMessage.messageKey;
			sTitle = sTitle ? sTitle : oMessage.titleKey;

			if (!fnCallback) {
				callBackFnc = this._defaultErrorMessageCallback.bind(this);
			} else {
				callBackFnc = fnCallback;
			}
			this.showError(sTitle, sMsg, bShowDetails, oDetails, callBackFnc());
		},

		/**
		 * Handle parsing error and throw proper message
		 * @param {sap.ui.base.Event} oEvent  Element data change event
		 * @private
		 */
		_handleValidationParseError: function (oEvent) {
			var control = oEvent.getParameter("element"),
				oCntrlCustomData = control.getCustomData(),
				oCntrlCustomDataLen = oCntrlCustomData ? oCntrlCustomData.length : 0;
			if (oCntrlCustomData && oCntrlCustomDataLen > 0) {
				for (var iCount = 0; iCount < oCntrlCustomDataLen; iCount++) {
					var oCntrlTempData = oCntrlCustomData[iCount];
					if (oCntrlTempData.getKey() === "blankValidate" && oCntrlTempData.getValue() === "true") {
						var oBindingInfo = control.getBindingInfo("value"),
							oBinding = oBindingInfo.binding,
							oBindingContext = oBinding.getContext(),
							oBindingModel = oBinding.getModel();
						oBindingModel.setProperty(oBindingContext.getPath() + "/" + oBindingInfo.parts[0].path, oEvent.getParameter("newValue"));
					}
				}
			}validateDefermentCode
			/*if (control && control.setValueState) {
				//add message
				control.setValueState(ValueState.Error);
			}*/
		}
	};
});