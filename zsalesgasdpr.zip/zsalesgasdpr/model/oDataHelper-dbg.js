sap.ui.define([], function(){
    return {
        callGetOData: function(oModel, sPath){
            return new Promise( function(resolve, reject){
                oModel.read(sPath,{
                    success: function(data){                   
                            resolve(data);
                        },
                     error: function(oError){
                            reject(oError);
                        }
                    })
                });
        },
        callGetODataFilter: function(oModel, sPath,sFilters){
            return new Promise( function(resolve, reject){
                oModel.read(sPath,{
                    filters : sFilters,     
                    success: function(data){                   
                            resolve(data);
                        },
                     error: function(oError){
                            reject(oError);
                        }
                    })
                });
        },
        updateOData: function(oModel, sPath, oData){
            return new Promise( function(resolve, reject){
                oModel.update(sPath,oData,{
                    method: "PUT",
                    success: function(data){                   
                            resolve(oData);
                        },
                     error: function(oError){
                            reject(oError);
                        }
                    })
                });
        }


    }
});