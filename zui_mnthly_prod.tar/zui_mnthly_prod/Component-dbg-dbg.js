sap.ui.define(
    ["sap/suite/ui/generic/template/lib/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("com.crescent.ui.dpr.monthly.zuimonthlyprod.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);