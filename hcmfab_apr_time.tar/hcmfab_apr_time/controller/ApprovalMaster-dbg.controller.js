/*
 * Copyright (C) 2009-2017 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([
 "hcm/fab/approve/timesheet/controller/BaseController",
 "sap/ui/model/odata/ODataModel",
 "sap/ui/model/json/JSONModel",
 "sap/ui/core/routing/History",
 "hcm/fab/approve/timesheet/model/formatter",
 "sap/ui/model/Filter",
 "sap/ui/model/FilterOperator",
 "sap/ui/Device"
], function (BaseController, ODataModel, JSONModel, History, formatter, Filter, FilterOperator, Device) {
 "use strict";

 return BaseController.extend("hcm.fab.approve.timesheet.controller.ApprovalMaster", {
  formatter: formatter,
  onInit: function () {
   var oEventBus = sap.ui.getCore().getEventBus();
   this.oCEModel = this.getOwnerComponent().getModel("ce");
   this.oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
   oEventBus.subscribe("ApprovalDetail", "refreshMasterList", this.refreshApprovalList, this);
   oEventBus.subscribe("ApprovalDetail", "refreshAll", this.getApprovalList, this);
   this.getOwnerComponent().getRouter().getRoute("master").attachPatternMatched(this._onRouteMatched, this);
   var oModel = new JSONModel({});
   this.setGlobalModel(oModel, "MassApprovalMobileModel");
   var oSharedModel = new JSONModel({});
   this.setGlobalModel(oSharedModel, "MassApprovalSharedModel");
   var oSharedActualModel = new JSONModel({});
   this.setGlobalModel(oSharedActualModel, "MassApprovalActualModel");
   this.oRouter = this.getOwnerComponent().getRouter();
   //this.workitemid = this.getURLParamater('Workitemid');
   this.workitemid = (this.getOwnerComponent().getModel("startupModel"))?this.getOwnerComponent().getModel("startupModel").getData().workitemId:null;
   var data = {
    multiVisible: true
   };
   if (this.workitemid) {
    this.workitemid = this.workitemid.replace(/'/g, "");
    this.setGlobalModel(new JSONModel([{
     "workitemid": this.workitemid
    }]), "WorkItem");
    data.multiVisible = false;
   }
   this.getView().setModel(new JSONModel(data), "controls");
  },
  // getURLParamater: function (name) {
  //  var URLParsing = sap.ushell.Container.getService("URLParsing");
  //  var sShellHash = URLParsing.getShellHash($(location).attr("href"));
  //  var oObject = URLParsing.parseShellHash(sShellHash);

  //  if (oObject.params.Workitemid) {
  //   var results = oObject.params.Workitemid.toString();
  //   if (results) {
  //    return results || 0;
  //   }
  //  } else {
  //   return null;
  //  }

  // },
  setPernr: function (oPernr) {
   var oModel = new sap.ui.model.json.JSONModel();
   oModel.setData(oPernr);
   this.getOwnerComponent().setModel(oModel, "Pernr");
  },
  getPernr: function () {
   var oModel = this.getOwnerComponent().getModel("Pernr");
   if (oModel === undefined) {
    return;
   }
   return oModel.oData;
  },
  setSelection: function (oEmpId) {
   var oModel = new sap.ui.model.json.JSONModel();
   oModel.setData(oEmpId);
   this.getOwnerComponent().setModel(oModel, "Selection");
  },
  getSelection: function () {
   var oModel = this.getOwnerComponent().getModel("Selection");
   if (oModel === undefined) {
    return;
   }
   return oModel.oData;
  },
  onAssignmentsLoaded: function (oEvent) {
   var that = this;
   this.empID = oEvent.getParameter('defaultAssignment');
   this.setPernr(this.empID);
   if (!this.workitemid) {
    this.getApprovalList();
   } else {
    that.getEmployeeDetails(that.empID);
    that.getIndividualWorkItemApprovalDetails(that.workitemid, that.empID);
   }

  },
  onAssignmentSwitch: function (oEvent) {
   var that = this;
   this.empID = oEvent.getParameter('selectedAssignment');
   this.setPernr(this.empID);
   if (!this.workitemid) {
    this.getApprovalList();
   } else {
    that.getEmployeeDetails(that.empID);
    that.getIndividualWorkItemApprovalDetails(that.workitemid, that.empID);
   }
  },
  onExit: function () {
   var eventBus = sap.ui.getCore().getEventBus();
   eventBus.unsubscribe("ApprovalDetail", "refreshMasterList", this.refreshApprovalList, this);
   eventBus.unsubscribe("ApprovalDetail", "refreshAll", this.getApprovalList, this);
  },
  getIndividualWorkItemApprovalDetails: function (workitem, empId) {
   var that = this;
   that.oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
   that.oDataDetailModel = this.getOwnerComponent().getModel();

   // call workitem list to know feature enablement info for each personnel
   that.getWorkItemApprovalList(workitem, empId);

   var a = new sap.ui.model.Filter({
    path: "EmployeeID",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: empId
   });
   var b = new sap.ui.model.Filter({
    path: "Workitemid",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: workitem
   });

   // Handle Concurrent Employee / Switch Personnel Assignment
   var sApproverPernr = this.getOwnerComponent().getModel("Pernr").getData();
   var oApproverPernrFilter = new sap.ui.model.Filter({
      path: "CATSAssignment",
      operator: sap.ui.model.FilterOperator.EQ,
      value1: sApproverPernr
     });

   var filter = [];

   filter.push(a);
   filter.push(b);

   // Push filter for Switch Personnel Assignment
   if( sApproverPernr ){
    filter.push(oApproverPernrFilter);
   }


   var mParameters = {
    filters: filter,
    success: function (oData, oResponse) {
     var date, date1, date2;
     for (var l = 0; l < oData.results.length; l++) {
      if (oData.results[l].CATSHours != 0) {
       oData.results[l].CATSAmount = oData.results[l].CATSHours;
      } else if (oData.results[l].CATSquantity != 0) {
       oData.results[l].CATSAmount = oData.results[l].CATSquantity;
      } else if (oData.results[l].CATSAmount != 0) {
       //Do nothing as CATSAmount field's value is shown
      } else {
       //Contains a zero hours record - so delete the entry from the result
       // oData.results.splice(l, 1);
       // Zero hour records are to be considered hence commenting the above code
      }
      try {
       date1 = new Date(oData.results[l].Workdate);
       date2 = new Date(date1.getUTCFullYear(), date1.getUTCMonth(), date1.getUTCDate());
       date = date2;
      } catch (o) {
       date = new Date(oData.results[l].Workdate);
      }
      oData.results[l].Workdate = date;
     }
     // if (that.workitemid && that.getModel("ApprovalListModel")) {
     //  var listModel = that.getModel("ApprovalListModel").getData()[0];
     //  listModel.NoOfEntries = oData.results.length.toString();
     //  that.setModel(new JSONModel(listModel), "ApprovalListModel");
     // }
     var oModel = new sap.ui.model.json.JSONModel(oData.results);
     that.getView().setModel(oModel, "IndividualApprovalModel");
    },
    error: function (oError) {
     that.byId("PendingEntriesTable").setBusy(false);
     that.processMessage(oError);
    }
   };
   that.oDataDetailModel
    .read(
     "/ApprovalDetailsSet",
     mParameters);
  },

  getWorkItemApprovalList: function (workitem, empId){
   var that = this;
   var oModel = this.getOwnerComponent().getModel();

   var oEmpID = new sap.ui.model.Filter({
    path: "EmployeeID",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: empId
   });

   var oWorkItemID = new sap.ui.model.Filter({
    path: "Workitemid",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: workitem
   });

   var filter = [];
   filter.push(oEmpID);
   filter.push(oWorkItemID);

   var mParameters = {
    filters: filter,
    success: function (oData, oResponse) {
     that.setGlobalEmployeeFeatures(oData.results);
    },
    error: function (oError) {
     that.processMessage(oError);
    }
   };

   oModel.read("/ApprovalListSet", mParameters);
  },

  refreshApprovalList: function () {
   var that = this;
   that.byId("ProcessButton").setEnabled(false);
   that.oDataApproveListModel = this.getOwnerComponent().getModel();
   that.oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
   that.byId("MasterList").setBusy(true);
   var EmpID = this.getPernr();

   if( !EmpID ){
    return;
   }

   var filter = "EmployeeID eq '" + EmpID + "'";
   var oFilter = {
    "$filter": filter
   };
   var mParameters = {
    urlParameters: oFilter,
    success: function (oData, oResponse) {
     //Sort Data by Employee Name on Initial Load
     oData.results.sort(function(a, b){return a.EmployeeName.localeCompare(b.EmployeeName); });
     that.setGlobalEmployeeFeatures(oData.results);

     var oModel = new sap.ui.model.json.JSONModel(oData.results);
     oModel.setData(oData.results);
     if(that.getModel("ApprovalListModel")){
      that.getModel("ApprovalListModel").setData(oData.results);
     }
     //that.getView().setModel(oModel, "ApprovalListModel");
     var masterPageText = that.oBundle.getText("employees", [oData.results.length]);
     var approvalMasterPage = that.byId("ApprovalMasterPage");
     approvalMasterPage.setTitle(masterPageText);
     that.byId("MasterList").setBusy(false);
     var oMasterList = that.byId("MasterList");
     var oItems = oMasterList.getItems();
     var listMode = oMasterList.getMode();
     if (sap.ui.Device.system.phone !== true) {
      if (listMode !== "MultiSelect") {
       for (var i = 0; i < oItems.length; i++) {
        if (oItems[i].getAggregation('customData')[0].getProperty('value') === that.EmpNumber) {
         oItems[i].setSelected(true);
         return;
        }
       }
       if (oItems.length > 0) {
        oItems[0].setSelected(true);
        var detailPathModel = that.getGlobalModel("exchangeModel");
        detailPathModel.oData[1] = oItems[0].getAggregation('customData')[0].getProperty('value');
        that.getOwnerComponent().getRouter()
         .navTo("detail", {
          employee: detailPathModel.oData[1]
         }, true);

       }
      }
     }
    },
    error: function (oError) {
     that.byId("MasterList").setBusy(false);
     that.processMessage(oError);
    }
   };
   that.oDataApproveListModel
    .read(
     "/ApprovalListSet",
     mParameters);
  },
  getApprovalList: function () {
   var that = this;
   that.oDataApproveListModel = this.getOwnerComponent().getModel();
   that.oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
   that.byId("MasterList").setBusy(true);
   var EmpID = this.getPernr();
   var filter = "EmployeeID eq '" + EmpID + "'";
   var oFilter = {
    "$filter": filter
   };
   var mParameters = {
    urlParameters: oFilter,
    success: function (oData, oResponse) {
     //Sort Data by Employee Name on Initial Load
     oData.results.sort(function(a, b){return a.EmployeeName.localeCompare(b.EmployeeName); });
     that.setGlobalEmployeeFeatures(oData.results);

     //If Select All button was enabled, set visibility to false
     that.byId("selectAllButtonID").setVisible(false);

     var masterPageText;
     var approvalMasterPage;
     var oModel = new sap.ui.model.json.JSONModel(oData.results);
     if (oData.results.length === 0) {

      that.byId("sortButton").setVisible(false);
      that.byId("multiSelectButtonID").setVisible(false);
      that.byId("MasterList").setBusy(false);

      oModel = new sap.ui.model.json.JSONModel(oData.results);
      that.getView().setModel(oModel, "ApprovalListModel");

      masterPageText = that.oBundle.getText("employees", [oData.results.length]);
      approvalMasterPage = that.byId("ApprovalMasterPage");
      approvalMasterPage.setTitle(masterPageText);
      that.getRouter().getTargets().display("objectNotFound");
     } else {
      oModel = new sap.ui.model.json.JSONModel(oData.results);
      //that.getView().setModel(oModel, "ApprovalListModel");
      var approvalListModel = that.getView().getModel("ApprovalListModel");
      if (!approvalListModel) {
       that.getView().setModel(oModel, "ApprovalListModel");
      } else {
       approvalListModel.setData(oData.results);
      }

      // oModel = new sap.ui.model.json.JSONModel(oData.results);
      // //that.getView().setModel(oModel, "ApprovalListModel");
      // var approveListModel = that.getView().getModel("ApprovalListModel");
      // approveListModel.setData(oData.results);

      masterPageText = that.oBundle.getText("employees", [oData.results.length]);
      approvalMasterPage = that.byId("ApprovalMasterPage");
      approvalMasterPage.setTitle(masterPageText);
      var detailPathArr = [];
      detailPathArr[0] = "SingleSelectMaster";
      detailPathArr[1] = oData.results[0].EmployeeID;

      that.byId("sortButton").setVisible(true);
      that.byId("multiSelectButtonID").setVisible(true);
      that.byId("MasterList").setBusy(false);

      var oItems = that.byId("MasterList").getItems();

      if (sap.ui.Device.system.phone !== true) {
       that.byId("MasterList").setMode("SingleSelectMaster");
       that.byId("ApprovalMasterPage").getMultiSelectAction().setPressed(false);
       oItems[0].setSelected(true);
       that.setSelection(oData.results[0].EmployeeID);
      }
      var oPassModel = new sap.ui.model.json.JSONModel(detailPathArr);
      that.setGlobalModel(oPassModel, "exchangeModel");

      if (sap.ui.Device.system.phone !== true) {
       that.getOwnerComponent().getRouter()
        .navTo("detail", {
         employee: detailPathArr[1]
        }, true);
      }
     }
    },
    error: function (oError) {
     that.byId("MasterList").setBusy(false);
     that.processMessage(oError);
    }
   };
   that.oDataApproveListModel
    .read(
     "/ApprovalListSet",
     mParameters);

  },

  // Handle messages/errors from backend..
  processMessage: function (oError, filt) {
   var that = this;
   var errorObj = JSON.parse(oError.responseText).error;
   var errorSet = errorObj.innererror.errordetails;
   var messageHeader = errorSet[0].message;
   var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
   sap.m.MessageBox.error(
    messageHeader, {
     styleClass: bCompact ? "sapUiSizeCompact" : "",
     onClose: function () {
      if (filt !== undefined) {
       //that.getIndividualApprovalDetails(filt);
       //that.getView().getModel("IndividualApprovalModel").refresh();
      } else if (sap.ui.Device.system.phone === true) {
       //mass approval mode error in mobile screen
       //that.getOwnerComponent().getRouter().navTo("master", {}, true);
      }
      //var oEventBus = sap.ui.getCore().getEventBus();
      //oEventBus.publish("ApprovalDetail", "refreshAll");
     }
    }
   );
  },

  setGlobalEmployeeFeatures: function(aEmployees){
   // Set configuration specific to each employee having time records to be approved... Like mandatory reject reason during rejection of time records
   var oEmployeeFeatureMap = {};
   var oModel;

   if( this.getGlobalModel("GlobalEmployeeFeatureMap") ){
    oModel = this.getGlobalModel("GlobalEmployeeFeatureMap");
   } else {
    oModel = new sap.ui.model.json.JSONModel();
    this.setGlobalModel(oModel, "GlobalEmployeeFeatureMap");
   }

   // Map the features for each employee
   aEmployees.forEach(function(oEmployee){
    oEmployeeFeatureMap[oEmployee.EmployeeID] = { 
     IsRejectReasonMandatory: oEmployee.IsRejectReasonMandatory
    };
   });

   this.getGlobalModel("GlobalEmployeeFeatureMap").setData(oEmployeeFeatureMap);
  },

  getEmployeeDetails: function (empID) {
   var that = this;
   var oModel = new JSONModel();
   var f = [];
   var c = new sap.ui.model.Filter({
    path: "EmployeeNumber",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: this.empID
   });
   f.push(c);
   this.oCEModel.createKey("EmployeeDetailSet", {
    EmployeeNumber: empID,
    ApplicationId: 'CATS'
   });
   var mParameters = {
    filters: f,
    success: function (oData, oResponse) {
     //Sort Data by Employee Name on Initial Load
     oData.results.sort(function(a, b){return a.EmployeeName.localeCompare(b.EmployeeName); });
     var data = [];
     var oModel = new JSONModel(oData.results[0]);
     that.setModel(oModel, "libCommon");
     var length = 0;
     // if (that.getModel("IndividualApprovalModel")) {
     //  var length = that.getModel("IndividualApprovalModel").getData().length.toString();
     // }
     var oModel = new sap.ui.model.json.JSONModel(oData.results);
     if (oData.results.length > 0) {
      data.push({
       EmployeeID: that.empID,
       EmployeeName: oData.results[0].EmployeeName.FormattedName,
       EmployeePosition: oData.results[0].EmployeePositionId,
       NoOfEntries: "",
       Workitemid: "000000000000"
      });

     }
     oModel.setData(data);
     that.getView().setModel(oModel, "ApprovalListModel");
     var detailPathArr = [];
     detailPathArr.push(that.empID);
     var masterPageText = that.oBundle.getText("manager", [oData.results.length]);
     var approvalMasterPage = that.byId("ApprovalMasterPage");
     approvalMasterPage.setTitle(masterPageText);
     var oItems = that.byId("MasterList").getItems();
     if (sap.ui.Device.system.phone !== true) {
      oItems[0].setSelected(true);
      that.setSelection(oData.results[0].EmployeeID);
     }
     var oPassModel = new sap.ui.model.json.JSONModel(detailPathArr);
     that.setGlobalModel(oPassModel, "exchangeModel");
     if (Device.system.phone !== true) {
      that.getOwnerComponent().getRouter().navTo("detail", {
       employee: that.empID
      }, true);

     }
    },
    error: function (oError) {
     that.oErrorHandler.processError(oError);
    }
   };
   this.oCEModel.read('/EmployeeDetailSet', mParameters);
  },
  _onRouteMatched: function (oEvent) {
   if (!this.workitemid) {
    this.refreshApprovalList();
   }
   this.byId("selectAllButtonID").setType("Default");
   //Initialize the Mass Approval Models to avoid inconsistent data display
   var oModel = new JSONModel({});
   var massModel = this.getGlobalModel("MassApprovalMobileModel");
   if (massModel) {
    this.setGlobalModel(oModel, "MassApprovalMobileModel");
   }
   var massActualModel = this.getGlobalModel("MassApprovalActualModel");
   if (massActualModel) {
    this.setGlobalModel(oModel, "MassApprovalActualModel");
   }
  },
  onMultiSelectPress: function () {
   var that = this;
   //clear search text
   that.byId("searchFieldId").setValue("");
   //clear filtering
   var masterList = that.byId("MasterList");
   var binding = masterList.getBinding("items");
   binding.filter([], "Application");
   var listMode = masterList.getMode();
   if (listMode == "SingleSelectMaster") {
    masterList.setMode("MultiSelect");
    that.byId("selectAllButtonID").setVisible(true);
    if (sap.ui.Device.system.phone === true) {
     that.byId("ProcessButton").setVisible(true);
    }
    if (Device.system.phone !== true) {
     var selectedEmpId = that.getSelection();
     var oItems = masterList.getItems();
     var detailPath = "MassApprove_";
     var detailPathArr = [];
     detailPathArr[0] = masterList.getMode();
     detailPathArr[1] = "Initial";
     detailPath += detailPathArr[1];
     for (var i = 0; i < oItems.length; i++) {
      if (oItems[i].getCustomData()[0].getProperty("value") == selectedEmpId) {
       oItems[i].setSelected(false);
      }
     }
     var oPassModel = new sap.ui.model.json.JSONModel(detailPathArr);
     that.setGlobalModel(oPassModel, "exchangeModel");
     this.getOwnerComponent().getRouter().navTo("detail", {
      employee: detailPath
     }, true);
    }
   } else {
    that.byId("selectAllButtonID").setVisible(false);
    that.byId("selectAllButtonID").setType("Default");
    that.byId("sortButton").setSelectedKey("None");
    masterList.setMode("SingleSelectMaster");
    //Initialize the Mass Approval Model to avoid inconsistent data display
    var massModel = that.getGlobalModel("MassApprovalSharedModel");
    if (massModel) {
     var oModel = new JSONModel({});
     that.setGlobalModel(oModel, "MassApprovalSharedModel");
    }
    that.getApprovalList();
    that.byId("ProcessButton").setVisible(false);
   }
  },
  onListItemPress: function (oEvent) {
   var that = this;
   var masterList = that.byId("MasterList");
   var listMode = masterList.getMode();
   var selectedEmpId = oEvent.getSource("selectedItem").data().empId;
   var selectionStatus = oEvent.getSource().getSelected();
   if (selectionStatus === true) {
    oEvent.getSource().setSelected(false);
   } else {
    oEvent.getSource().setSelected(true);
   }
   //remove hidden selections
   var selectedEmployees = [];
   var employee;
   var oFilt = masterList.getBinding("items").aApplicationFilters[0];
   if (oFilt) {
    //remove filter
    masterList.getBinding("items").filter([], "Application");
    //get selected items' employee info and unmark them
    var oItems = masterList.getItems();
    for (var k = 0; k < oItems.length; k++) {
     if (oItems[k].getProperty("selected") === true) {
      employee = oItems[k].getCustomData()[0].getValue();
      selectedEmployees.push(employee);
      oItems[k].setSelected(false);
     }
    }
    //Re-apply filter
    masterList.getBinding("items").filter(oFilt, "Application");
    //Re-Mark selected among filtered list
    oItems = masterList.getItems();
    for (var j = 0; j < oItems.length; j++) {
     if (selectedEmployees.indexOf(oItems[j].getCustomData()[0].getValue()) !== -1) {
      oItems[j].setSelected(true);
     }
    }
   }

   oItems = masterList.getItems();
   var detailPath = "MassApprove_";
   var detailPathArr = [];
   detailPathArr[0] = listMode;
   var num = 1;
   for (var i = 0; i < oItems.length; i++) {
    if (oItems[i].getProperty("selected")) {
     detailPathArr[num] = oItems[i].getCustomData()[0].getProperty("value");
     detailPath += detailPathArr[num];
     num += 1;
    }
   }
   if (detailPathArr.length > 1) {
    that.byId("ProcessButton").setEnabled(true);
   } else {
    that.byId("ProcessButton").setEnabled(false);
   }
   detailPathArr.push(selectedEmpId);
   var oPassModel = new sap.ui.model.json.JSONModel(detailPathArr);
   that.setGlobalModel(oPassModel, "exchangeModel");
   if (this.workitemid) {
    that.setGlobalModel(new JSONModel([{
     "workitemid": this.workitemid
    }]), "WorkItem");
   }
   if (Device.system.phone !== true) {
    this.getOwnerComponent().getRouter().navTo("detail", {
     employee: detailPath
    }, true);

   }
   var selectAllMode = that.getSelectAllMode();
   that.byId("selectAllButtonID").setType(selectAllMode);
  },
  onLiveChangeApprovalList: function (oEvent) {
   // add filter for search
   var aFilters = [];
   var sQuery = oEvent.getSource().getValue();
   if (sQuery && sQuery.length > 0) {
    var filter = new Filter({
     filters: [
      new Filter({
       path: 'EmployeeName',
       operator: sap.ui.model.FilterOperator.Contains,
       value1: sQuery
      }),
      new Filter({
       path: 'EmployeeID',
       operator: sap.ui.model.FilterOperator.Contains,
       value1: sQuery
      }),
      new Filter({
       path: 'EmployeePosition',
       operator: sap.ui.model.FilterOperator.Contains,
       value1: sQuery
      })
     ],
     and: false
    });
    aFilters.push(filter);
   }
   // update list binding
   var list = this.byId("MasterList");
   var binding = list.getBinding("items");
   binding.filter(aFilters, "Application");
   var bSingleSelection = false;
   try {
    var aListItems = list.getItems(); //Getting items after applying the filter
    for (var i = 0; i < aListItems.length; i++) {
     if (aListItems[i].getProperty("selected")) {
      this.byId("ProcessButton").setEnabled(true);
      bSingleSelection = true;
      break;
     }
    }
    if (!bSingleSelection) {
     this.byId("ProcessButton").setEnabled(false);

    }
   } catch (err) {

   }
  },
  onCheckboxSelect: function (oEvent) {
   var that = this;
   var masterList = that.byId("MasterList");
   var listMode = masterList.getMode();
   var aggr = oEvent.getParameter("listItem").getAggregation("customData");
   var selectedEmpId = aggr[0].getProperty("value");
   var detailPathArr = [];
   var oPassModel;
   detailPathArr[0] = listMode;
   if (listMode !== "MultiSelect") {
    this.EmpNumber = selectedEmpId;
    this.refreshApprovalList(); //Refresh issue in Approval master
    detailPathArr[1] = selectedEmpId;
    that.setSelection(selectedEmpId);
    oPassModel = new sap.ui.model.json.JSONModel(detailPathArr);
    that.setGlobalModel(oPassModel, "exchangeModel");
    if (Device.system.phone === true) {
     oEvent.getSource().removeSelections();
    }
    this.getOwnerComponent().getRouter().navTo("detail", {
     employee: detailPathArr[1]
    }, !sap.ui.Device.system.phone);
   } else {
    //remove hidden selections
    var selectedEmployees = [];
    var employee;
    var oFilt = masterList.getBinding("items").aApplicationFilters[0];
    if (oFilt) {
     //remove filter
     masterList.getBinding("items").filter([], "Application");
     //get selected items' employee info and unmark them
     var oItems = masterList.getItems();
     for (var k = 0; k < oItems.length; k++) {
      if (oItems[k].getProperty("selected") === true) {
       employee = oItems[k].getCustomData()[0].getValue();
       selectedEmployees.push(employee);
       oItems[k].setSelected(false);
      }
     }
     //Re-apply filter
     masterList.getBinding("items").filter(oFilt, "Application");
     //Re-Mark selected among filtered list
     oItems = masterList.getItems();
     for (var j = 0; j < oItems.length; j++) {
      if (selectedEmployees.indexOf(oItems[j].getCustomData()[0].getValue()) !== -1) {
       oItems[j].setSelected(true);
      }
     }
    }
    oItems = masterList.getItems();
    var detailPath = "MassApprove_";
    var num = 1;
    for (var i = 0; i < oItems.length; i++) {
     if (oItems[i].getProperty("selected")) {
      detailPathArr[num] = oItems[i].getCustomData()[0].getProperty("value");
      detailPath += detailPathArr[num];
      num += 1;
     }
    }
    if (detailPathArr.length > 1) {
     that.byId("ProcessButton").setEnabled(true);
    } else {
     that.byId("ProcessButton").setEnabled(false);
    }
    detailPathArr.push(selectedEmpId);
    oPassModel = new sap.ui.model.json.JSONModel(detailPathArr);
    that.setGlobalModel(oPassModel, "exchangeModel");
    if (Device.system.phone !== true) {
     this.getOwnerComponent().getRouter().navTo("detail", {
      employee: detailPath
     }, true);

    }
   }
   var selectAllMode = that.getSelectAllMode();
   that.byId("selectAllButtonID").setType(selectAllMode);
  },
  onProcess: function () {
   var masterList = this.byId("MasterList");
   var listMode = masterList.getMode();
   var oItems = masterList.getItems();
   var detailPathArr = [];
   detailPathArr[0] = listMode;
   var detailPath = "MassApprove_";
   var num = 1;

   for (var i = 0; i < oItems.length; i++) {
    if (oItems[i].getProperty("selected")) {
     detailPathArr[num] = oItems[i].getCustomData()[0].getProperty("value");
     detailPath += detailPathArr[num];
     num += 1;
    }
   }

   var that = this;
   that.selTotal = detailPathArr.length - 1;
   that.selCurr = 0;
   that.detailPath = detailPath;
   sap.ui.core.BusyIndicator.show();

   for (var m = 1; m < detailPathArr.length; m++) {
    var filter = "EmployeeID eq '" + detailPathArr[m] + "'";

    // Handle Concurrent Employee / Switch Personnel Assignment
    var sApproverPernr = this.getOwnerComponent().getModel("Pernr").getData(),
     sApprPernrFilter = " and " + "AssignmentID" +  " eq '" + sApproverPernr + "'";
    if( sApproverPernr ){
     filter += sApprPernrFilter;
    }

    that.oDataMassModel = this.getOwnerComponent().getModel();
    var oMassFilter = {
     "$filter": filter
    };

    var mParametersMass = {
     urlParameters: oMassFilter,
     success: function (oData, oResponse) {
      that.selCurr++;
      var oPassActualModel = new sap.ui.model.json.JSONModel();
      var massActualData = that.getGlobalModel("MassApprovalActualModel").getData();

      if (massActualData.length) {
       massActualData = massActualData.concat(oData.results);
       oPassActualModel.setData(massActualData);
       that.setGlobalModel(oPassActualModel, "MassApprovalActualModel");
      } else {
       oPassActualModel.setData(oData.results);
       that.setGlobalModel(oPassActualModel, "MassApprovalActualModel");
      }

      var oMassModel = new sap.ui.model.json.JSONModel();
      var tempArr = [];
      var tempArrElement = [];
      var assignId, sumAmount = 0, sumMinutes = 0,
       sumTotal = 0;
      var g;

      for (g = 0; g < oData.results.length; g++) {
       if (assignId !== undefined && oData.results[g].AssignmentID !== assignId) {
        tempArrElement.CATSAmount = sumAmount + (sumMinutes / 60);
        tempArrElement.Total = sumTotal;
        var data = $.extend(true, {}, tempArrElement);
        tempArr.push(data);
        sumTotal = 0;
        sumAmount = 0;
        sumMinutes = 0;
       }

       assignId = oData.results[g].AssignmentID;
       tempArrElement.Counter = oData.results[g].Counter;
       tempArrElement.EmployeeID = oData.results[g].EmployeeID;
       tempArrElement.EmployeeName = oData.results[g].EmployeeName;
       tempArrElement.EmployeeRole = oData.results[g].EmployeeRole;
       tempArrElement.Total = oData.results[g].Total;
       tempArrElement.AssignmentID = oData.results[g].AssignmentID;
       tempArrElement.AssignmentText = oData.results[g].AssignmentText;

       if (oData.results[g].CATSHours !== 0) {
        tempArrElement.CATSAmount = 0; //oData.results[g].CATSHours;
        sumMinutes = sumMinutes + Math.round( parseFloat(oData.results[g].CATSHours, 10) * 60 );
       } else if (oData.results[g].CATSQuantity !== 0) {
        tempArrElement.CATSAmount = oData.results[g].CATSQuantity;
       } else {
        tempArrElement.CATSAmount = oData.results[g].CATSAmount;
       }

       sumAmount = sumAmount + parseFloat(tempArrElement.CATSAmount, 10);
       tempArrElement.UnitOfMeasure = oData.results[g].UnitOfMeasure;
       tempArrElement.Currency = oData.results[g].Currency;
       tempArrElement.Unit = oData.results[g].Unit;
       tempArrElement.Status = oData.results[g].Status;
       tempArrElement.Reason = oData.results[g].Reason;
       tempArrElement.DateCreate = oData.results[g].DateCreate;
       tempArrElement.TimeCreate = oData.results[g].TimeCreate;
       sumTotal = sumTotal + 1;
      }

      g--;

      tempArrElement.CATSAmount = sumAmount + (sumMinutes / 60); // Rounding off minutes to hours
      tempArrElement.Counter = oData.results[g].Counter;
      tempArrElement.EmployeeID = oData.results[g].EmployeeID;
      tempArrElement.EmployeeName = oData.results[g].EmployeeName;
      tempArrElement.EmployeeRole = oData.results[g].EmployeeRole;
      tempArrElement.Total = oData.results[g].Total;
      tempArrElement.AssignmentID = oData.results[g].AssignmentID;
      tempArrElement.AssignmentText = oData.results[g].AssignmentText;
      tempArrElement.UnitOfMeasure = oData.results[g].UnitOfMeasure;
      tempArrElement.Currency = oData.results[g].Currency;
      tempArrElement.Unit = oData.results[g].Unit;
      tempArrElement.Status = oData.results[g].Status;
      tempArrElement.Reason = oData.results[g].Reason;
      tempArrElement.DateCreate = oData.results[g].DateCreate;
      tempArrElement.TimeCreate = oData.results[g].TimeCreate;
      tempArrElement.Total = sumTotal;
      var pushData = $.extend(true, {}, tempArrElement);
      tempArr.push(pushData);
      // sumTotal = sumTotal + sumAmount;
      // for (var h = 0; h < tempArr.length; h++) {
      //  tempArr[h].Total = oData.results.length;
      // }
      var massData = that.getGlobalModel("MassApprovalMobileModel").getData();
      if (massData.length) {
       massData = massData.concat(tempArr);
       oMassModel.setData(massData);
       that.setGlobalModel(oMassModel, "MassApprovalMobileModel");
      } else {
       oMassModel.setData(tempArr);
       that.setGlobalModel(oMassModel, "MassApprovalMobileModel");
      }
      if (that.selCurr === that.selTotal) {
       sap.ui.core.BusyIndicator.hide();
       that.getOwnerComponent().getRouter().navTo("detail", {
        employee: that.detailPath
       }, !sap.ui.Device.system.phone);
      }
     },
     error: function (oError) {
      sap.ui.core.BusyIndicator.hide();
      // that.processError(oError);
     }
    };
    that.oDataMassModel
     .read(
      "/MassApprovalSet",
      mParametersMass);
   }
   var oPassModel = new sap.ui.model.json.JSONModel(detailPathArr);
   this.setGlobalModel(oPassModel, "exchangeModel");
  },
  onSortList: function (oEvent) {
   //Setting timeout for reload
   var list = this.byId("MasterList");
   var binding = list.getBinding("items");
   var selectedKey = oEvent.getSource().getSelectedKey();
   var bDescending = "false";
   var sPath = "EmployeeName";
   var sorter;
   if (selectedKey === "NameAtoZ") {
    sorter = new sap.ui.model.Sorter(sPath, bDescending, false);
    sorter.fnCompare = function (b, a) {
     if (b === null) {
      return -1;
     }
     if (a === null) {
      return 1;
     }
     var aa = a.split(" ");
     var bb = b.split(" ");
     if (aa[0] < bb[0]) {
      return -1;
     }
     if (aa[0] > bb[0]) {
      return 1;
     }
     return 0;
    };
   } else if (selectedKey === "NameZtoA") {
    bDescending = "true";
    sPath = "EmployeeName";
    sorter = new sap.ui.model.Sorter(sPath, bDescending, false);
    sorter.fnCompare = function (a, b) {
     if (b === null) {
      return -1;
     }
     if (a === null) {
      return 1;
     }
     var aa = a.split(" ");
     var bb = b.split(" ");
     if (aa[0] < bb[0]) {
      return -1;
     }
     if (aa[0] > bb[0]) {
      return 1;
     }
     return 0;
    };
   } else if (selectedKey === "EntriesHightoLow") {
    bDescending = "true";
    sPath = "NoOfEntries";
    sorter = new sap.ui.model.Sorter(sPath, bDescending, false);
    sorter.fnCompare = function (a, b) {
     if (b === null) {
      return -1;
     }
     if (a === null) {
      return 1;
     }
     var aa = parseInt(a, 10);
     var bb = parseInt(b, 10);
     if (aa < bb) {
      return -1;
     }
     if (aa > bb) {
      return 1;
     }
     return 0;
    };
   } else if (selectedKey === "EntriesLowtoHigh") {
    bDescending = "false";
    sPath = "NoOfEntries";
    sorter = new sap.ui.model.Sorter(sPath, bDescending, false);
    sorter.fnCompare = function (b, a) {
     if (b === null) {
      return -1;
     }
     if (a === null) {
      return 1;
     }
     var aa = parseInt(a, 10);
     var bb = parseInt(b, 10);
     if (aa < bb) {
      return -1;
     }
     if (aa > bb) {
      return 1;
     }
     return 0;
    };
   } else {
    // Do nothing!
   }
   if (sorter) {
    binding.sort([sorter]);
   }
  },
  onSelectAll: function (oEvent) {
   //Initialize the Mass Approval Model to avoid inconsistent data display
   var massModel = this.getGlobalModel("MassApprovalSharedModel");
   if (massModel) {
    var oModel = new JSONModel({});
    this.setGlobalModel(oModel, "MassApprovalSharedModel");
    this.setGlobalModel(oModel, "MassApprovalModel");
    this.setGlobalModel(oModel, "MassApprovalMobileModel");
   }
   var masterList = this.byId("MasterList");
   var oItems = masterList.getItems();
   if (oEvent.getSource().getType() === "Emphasized") {
    for (var j = 0; j < oItems.length; j++) {
     oItems[j].setSelected(false);
    }
    oEvent.getSource().setType("Default");
    this.byId("ProcessButton").setEnabled(false);
    if (sap.ui.Device.system.phone !== true) {
     var detailPathArr = [];
     detailPathArr[0] = masterList.getMode();
     detailPathArr[0] += "ALL";
     var detailPath = "MassApprove_";
     var oPassModel = new sap.ui.model.json.JSONModel(detailPathArr);
     this.setGlobalModel(oPassModel, "exchangeModel");
     this.getOwnerComponent().getRouter().navTo("detail", {
      employee: detailPath
     }, !sap.ui.Device.system.phone);
    }
   } else {
    if (oItems.length <= 0) {
     var toastMsg = this.oBundle.getText("noEntriesToSelect");
     sap.m.MessageToast.show(toastMsg, {
      duration: 3000
     });
     return;
    } else {
     for (var k = 0; k < oItems.length; k++) {
      oItems[k].setSelected(true);
     }
     oEvent.getSource().setType("Emphasized");
     this.byId("ProcessButton").setEnabled(true);
    }
   }
   //Leave processing if it is mobile device
   //If it is not mobile device then load all the mass approval entries
   // in detail screen
   if (sap.ui.Device.system.phone !== true && oEvent.getSource().getType() === "Emphasized") {
    this.onProcessAll();
   }
  },
  onProcessAll: function () {
   var masterList = this.byId("MasterList");
   var listMode = masterList.getMode();
   var oItems = masterList.getItems();
   var detailPathArr = [];
   detailPathArr[0] = listMode;
   detailPathArr[0] += "ALL";
   var detailPath = "MassApprove_";
   var num = 1;
   for (var i = 0; i < oItems.length; i++) {
    if (oItems[i].getProperty("selected")) {
     detailPathArr[num] = oItems[i].getCustomData()[0].getProperty("value");
     detailPath += detailPathArr[num];
     num += 1;
    }
   }
   var that = this;
   that.selTotal = detailPathArr.length - 1;
   that.selCurr = 0;
   that.detailPath = detailPath;
   sap.ui.core.BusyIndicator.show();
   for (var m = 1; m < detailPathArr.length; m++) {
    var filter = "EmployeeID eq '" + detailPathArr[m] + "'";

    // Handle Concurrent Employee / Switch Personnel Assignment
    var sApproverPernr = this.getOwnerComponent().getModel("Pernr").getData(),
     sApprPernrFilter = " and " + "AssignmentID" +  " eq '" + sApproverPernr + "'";
    if( sApproverPernr ){
     filter += sApprPernrFilter;
    }

    that.oDataMassModelAll = this.getOwnerComponent().getModel();
    var oMassFilter = {
     "$filter": filter
    };

    var mParametersMass = {
     urlParameters: oMassFilter,
     success: function (oData, oResponse) {
      that.selCurr++;
      var oPassActualModel = new sap.ui.model.json.JSONModel();
      var massActualData = that.getGlobalModel("MassApprovalActualModel").getData();
      if (massActualData.length) {
       massActualData = massActualData.concat(oData.results);
       oPassActualModel.setData(massActualData);
       that.setGlobalModel(oPassActualModel, "MassApprovalActualModel");
      } else {
       oPassActualModel.setData(oData.results);
       that.setGlobalModel(oPassActualModel, "MassApprovalActualModel");
      }
      var oMassModel = new sap.ui.model.json.JSONModel();
      var tempArr = [];
      var tempArrElement = [];
      var assignId, sumAmount = 0, sumMinutes = 0,
       sumTotal = 0;
      var g;

      for (g = 0; g < oData.results.length; g++) {
       if (assignId !== undefined && oData.results[g].AssignmentID !== assignId) {
        tempArrElement.CATSAmount = sumAmount + (sumMinutes / 60);
        tempArrElement.Total = sumTotal;
        var data = $.extend(true, {}, tempArrElement);
        tempArr.push(data);
        sumTotal = 0;
        sumAmount = 0;
        sumMinutes = 0;
       }

       assignId = oData.results[g].AssignmentID;
       tempArrElement.Counter = oData.results[g].Counter;
       tempArrElement.EmployeeID = oData.results[g].EmployeeID;
       tempArrElement.EmployeeName = oData.results[g].EmployeeName;
       tempArrElement.EmployeeRole = oData.results[g].EmployeeRole;
       tempArrElement.Total = oData.results[g].Total;
       tempArrElement.AssignmentID = oData.results[g].AssignmentID;
       tempArrElement.AssignmentText = oData.results[g].AssignmentText;

       if (oData.results[g].CATSHours !== 0) {
        tempArrElement.CATSAmount = 0; //oData.results[g].CATSHours;
        sumMinutes = sumMinutes + Math.round( parseFloat(oData.results[g].CATSHours, 10) * 60 );
       } else if (oData.results[g].CATSQuantity !== 0) {
        tempArrElement.CATSAmount = oData.results[g].CATSQuantity;
       } else {
        tempArrElement.CATSAmount = oData.results[g].CATSAmount;
       }

       sumAmount = sumAmount + parseFloat(tempArrElement.CATSAmount, 10);
       tempArrElement.UnitOfMeasure = oData.results[g].UnitOfMeasure;
       tempArrElement.Currency = oData.results[g].Currency;
       tempArrElement.Unit = oData.results[g].Unit;
       tempArrElement.Status = oData.results[g].Status;
       tempArrElement.Reason = oData.results[g].Reason;
       tempArrElement.DateCreate = oData.results[g].DateCreate;
       tempArrElement.TimeCreate = oData.results[g].TimeCreate;
       sumTotal = sumTotal + 1;
      }

      g--;

      tempArrElement.CATSAmount = sumAmount + (sumMinutes / 60); // Rounding off minutes to hours
      tempArrElement.Counter = oData.results[g].Counter;
      tempArrElement.EmployeeID = oData.results[g].EmployeeID;
      tempArrElement.EmployeeName = oData.results[g].EmployeeName;
      tempArrElement.EmployeeRole = oData.results[g].EmployeeRole;
      tempArrElement.Total = oData.results[g].Total;
      tempArrElement.AssignmentID = oData.results[g].AssignmentID;
      tempArrElement.AssignmentText = oData.results[g].AssignmentText;
      tempArrElement.UnitOfMeasure = oData.results[g].UnitOfMeasure;
      tempArrElement.Currency = oData.results[g].Currency;
      tempArrElement.Unit = oData.results[g].Unit;
      tempArrElement.Status = oData.results[g].Status;
      tempArrElement.Reason = oData.results[g].Reason;
      tempArrElement.DateCreate = oData.results[g].DateCreate;
      tempArrElement.TimeCreate = oData.results[g].TimeCreate;
      tempArrElement.Total = sumTotal;
      var pushData = $.extend(true, {}, tempArrElement);
      tempArr.push(pushData);
      // sumTotal = sumTotal + sumAmount;
      // for (var h = 0; h < tempArr.length; h++) {
      //  tempArr[h].Total = oData.results.length;
      // }
      var massData = that.getGlobalModel("MassApprovalMobileModel").getData();
      if (massData.length) {
       massData = massData.concat(tempArr);
       oMassModel.setData(massData);
       that.setGlobalModel(oMassModel, "MassApprovalMobileModel");
      } else {
       oMassModel.setData(tempArr);
       that.setGlobalModel(oMassModel, "MassApprovalMobileModel");
      }
      if (that.selCurr === that.selTotal) {
       sap.ui.core.BusyIndicator.hide();
       that.getOwnerComponent().getRouter().navTo("detail", {
        employee: that.detailPath
       }, !sap.ui.Device.system.phone);
      }
     },
     error: function (oError) {
      sap.ui.core.BusyIndicator.hide();
      // that.processError(oError);
     }
    };
    that.oDataMassModelAll
     .read(
      "/MassApprovalSet",
      mParametersMass);
   }
   var oPassModel = new sap.ui.model.json.JSONModel(detailPathArr);
   this.setGlobalModel(oPassModel, "exchangeModel");
  },
  getSelectAllMode: function () {
   var masterList = this.byId("MasterList");
   var oItems = masterList.getItems();
   var selectAllMode = "Emphasized";
   for (var i = 0; i < oItems.length; i++) {
    if (!oItems[i].getProperty("selected")) {
     selectAllMode = "Default";
    }
   }
   return selectAllMode;
  }
 });
});