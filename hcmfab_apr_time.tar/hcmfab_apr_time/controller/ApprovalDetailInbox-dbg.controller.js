/*
 * Copyright (C) 2009-2017 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([
 "hcm/fab/approve/timesheet/controller/BaseController",
 "sap/ui/model/odata/ODataModel",
 "sap/ui/model/json/JSONModel",
 "sap/ui/core/routing/History",
 "hcm/fab/approve/timesheet/model/formatter",
 "sap/ui/model/Filter",
 "sap/ui/model/FilterOperator",
 "sap/ui/Device",
 "sap/m/GroupHeaderListItem",
 "sap/m/TablePersoController"
], function (BaseController, ODataModel, JSONModel, History, formatter, Filter, FilterOperator, Device, GroupHeaderListItem,
 TablePersoController) {
 "use strict";

 return BaseController.extend("hcm.fab.approve.timesheet.controller.ApprovalDetailInbox", {
  formatter: formatter,
  _oDialogInd: null,
  _oDialogMass: null,
  onInit: function () {
   var that = this;
   that.getOwnerComponent().getRouter().getRoute("InBoxdetail").attachPatternMatched(this._onRouteMatched, this);
   that.oDataModel = this.getOwnerComponent().getModel();
   that.oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
   var oModel = new JSONModel({});
   // this.setModel(oModel, "MassApprovalModel");
   // var oErrorModel = new JSONModel({
   //  "EnableError": "true"
   // });
   // this.setModel(oErrorModel, "ErrorModel");
   // this.mGroupFunctionsInd = {
   //  Workdate: function (oContext) {
   //   var date = formatter.dateStringFormat(oContext.getProperty("Workdate"));
   //   return {
   //    key: date,
   //    text: date
   //   };
   //  },
   //  CATSAssignment: function (oContext) {
   //   var assignment = oContext.getProperty("CATSAssignment");
   //   return {
   //    key: assignment,
   //    text: assignment
   //   };
   //  }
   // };
   // this.mGroupFunctionsMass = {
   //  EmployeeName: function (oContext) {
   //   var name = oContext.getProperty("EmployeeName");
   //   return {
   //    key: name,
   //    text: name
   //   };
   //  },
   //  AssignmentText: function (oContext) {
   //   var text = oContext.getProperty("AssignmentText");
   //   return {
   //    key: text,
   //    text: text
   //   };
   //  }
   // };
   // that.initPersonalization();
  },
  onExit: function () {
   // if (this._oDialogInd) {
   //  this._oDialogInd.destroy();
   // }
   // if (this._oDialogMass) {
   //  this._oDialogMass.destroy();
   // }
  },
  _onRouteMatched: function (oEvent) {
   var that = this;
   this.getView().getParent().getParent().setMode("HideMode");
   this.instanceFilter = [];
   if (oEvent.getParameter("arguments").InstanceID) {
    var str = oEvent.getParameter("arguments").InstanceID;
    this.instanceFilter.push(new sap.ui.model.Filter("WorkitemId", sap.ui.model.FilterOperator.EQ, str));
    this.oDataModel.read("/ApprovalListSet", {
     filters: this.instanceFilter,
     success: function (data) {
      sap.m.MessageToast.show("Success");

     },
     error: function () {
      sap.m.MessageToast.show("Error");
     }
    });
   }
   // var approveButtonId;
   // var rejectButtonId;
   // var approveAllButtonId;
   // var rejectAllButtonId;
   // var detailPathModel = this.getGlobalModel("exchangeModel");
   // if (detailPathModel === undefined) {
   //  this.getOwnerComponent().getRouter().navTo("master", {}, true);
   // }
   // var mode = detailPathModel.oData[0];
   // if (mode !== "MultiSelect") {
   //  approveButtonId = this.byId("ApproveButton");
   //  approveButtonId.setVisible(true);
   //  approveButtonId.setEnabled(false);
   //  rejectButtonId = this.byId("RejectButton");
   //  rejectButtonId.setVisible(true);
   //  rejectButtonId.setEnabled(false);
   //  approveAllButtonId = this.byId("ApproveAllButton");
   //  approveAllButtonId.setVisible(false);
   //  rejectAllButtonId = this.byId("RejectAllButton");
   //  rejectAllButtonId.setVisible(false);
   //  var empId = detailPathModel.oData[1];
   //  var filt = "EmployeeID eq '" + empId + "'";
   //  var sReadSingle = "/sap/opu/odata/sap/HCMFAB_APR_TIMESHEET_SRV/EmployeePictureSet('" + empId + "')/$value";
   //  this.byId('ObjectPageLayoutHeaderTitle').setObjectImageURI(sReadSingle);
   //  var employeeText = this.oBundle.getText("employee");
   //  this.byId("ApprovalDetailPage").setTitle(employeeText);
   //  this.getIndividualApprovalDetails(filt);
   //  this.getEmployeeDetails(filt);
   // } else {
   //  if (Device.system.phone === true) {
   //   approveButtonId = this.byId("ApproveButton");
   //   approveButtonId.setVisible(false);
   //   rejectButtonId = this.byId("RejectButton");
   //   rejectButtonId.setVisible(false);
   //   approveAllButtonId = this.byId("ApproveAllButton");
   //   approveAllButtonId.setVisible(true);
   //   rejectAllButtonId = this.byId("RejectAllButton");
   //   rejectAllButtonId.setVisible(true);
   //   var timeTable = this.byId("PendingEntriesTable");
   //   timeTable.setVisible(false);
   //   var massTable = this.byId("MassApproval");
   //   massTable.setVisible(true);
   //   var objHdr = this.byId("ObjectPageLayoutHeaderTitle");
   //   this.oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
   //   var empSelectedText = this.oBundle.getText("employeesSelected");
   //   var detailPathModel = this.getGlobalModel("exchangeModel");
   //   var selectedEmployeesText = this.oBundle.getText("selectedEmployees");
   //   this.byId("ApprovalDetailPage").setTitle(selectedEmployeesText + " (" + (detailPathModel.oData.length - 1) + ")");
   //   objHdr.setObjectTitle(detailPathModel.oData.length - 1 + " " + empSelectedText);
   //   objHdr.setObjectSubtitle("");
   //   this.byId("TeleTitleObjAttrId").setTitle("");
   //   this.byId("MailTitleObjAttrId").setTitle("");
   //   this.byId("TeleTitleObjAttrId").setText("");
   //   this.byId("MailTitleObjAttrId").setText("");
   //   var massData = this.getGlobalModel("MassApprovalMobileModel");
   //   var oMassModelMobile = new sap.ui.model.json.JSONModel(massData.oData);
   //   this.setModel(oMassModelMobile, "MassApprovalModel");
   //   this.applySortingAndGroupingMass();
   //   var massImage = "sap-icon://group";
   //   this.byId("ObjectPageLayoutHeaderTitle").setObjectImageURI(massImage);
   //  } else {
   //   approveButtonId = this.byId("ApproveButton");
   //   approveButtonId.setVisible(false);
   //   rejectButtonId = this.byId("RejectButton");
   //   rejectButtonId.setVisible(false);
   //   approveAllButtonId = this.byId("ApproveAllButton");
   //   approveAllButtonId.setVisible(true);
   //   rejectAllButtonId = this.byId("RejectAllButton");
   //   rejectAllButtonId.setVisible(true);
   //   var selectedArr = [];
   //   for (var i = 1; i < detailPathModel.oData.length - 1; i++) {
   //    selectedArr[i - 1] = detailPathModel.oData[i];
   //   }
   //   var selectedEmp = detailPathModel.oData[i];
   //   var massImageComp = "sap-icon://group";
   //   this.byId('ObjectPageLayoutHeaderTitle').setObjectImageURI(massImageComp);
   //   this.getMassApprovalDetails(selectedArr, selectedEmp);
   //  }
   // }
  },
  applySortingAndGroupingInd: function () {
   var that = this;
   if (that.getView().getModel("IndViewSetModel")) {
    var indViewSet = that.getView().getModel("IndViewSetModel").getData();
    var oBinding = that.getView().byId("PendingEntriesTable").getBinding("items");
    that.byId("DateColumn").setMergeDuplicates(false);
    that.byId("AlreadyApprovedColumn").setMergeDuplicates(false);
    that.byId("TotalOnTargetColumn").setMergeDuplicates(false);
    // apply sorter to binding
    // (grouping comes before sorting)
    var vGroup;
    var aSorters = [];
    //Grouping
    if (indViewSet.grouping === "true") {
     var gPath = indViewSet.gPath;
     var gDescending = indViewSet.gDescending;
     vGroup = that.mGroupFunctionsInd[gPath];
     aSorters.push(new sap.ui.model.Sorter(gPath, gDescending, vGroup));
    }
    //Sorting
    var sPath = indViewSet.sPath;
    var bDescending = indViewSet.bDescending;
    aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
    oBinding.sort(aSorters);
    that.byId("DateColumn").setMergeDuplicates(true);
    that.byId("AlreadyApprovedColumn").setMergeDuplicates(true);
    that.byId("TotalOnTargetColumn").setMergeDuplicates(true);
   } else {
    var oView = that.getView();
    var oTable = oView.byId("PendingEntriesTable");
    var oBinding = oTable.getBinding("items");
    that.byId("DateColumn").setMergeDuplicates(false);
    that.byId("AlreadyApprovedColumn").setMergeDuplicates(false);
    that.byId("TotalOnTargetColumn").setMergeDuplicates(false);
    // apply sorter to binding
    // (grouping comes before sorting)
    var sPath = "Workdate";
    var bDescending = false;
    var vGroup;
    var aSorters = [];
    var oIndividualViewSettingsModel = new JSONModel({
     "grouping": "true",
     "gPath": sPath,
     "gDescending": bDescending,
     "sPath": sPath,
     "bDescending": bDescending
    });
    that.setModel(oIndividualViewSettingsModel, "IndViewSetModel");
    //Grouping
    vGroup = that.mGroupFunctionsInd[sPath];
    aSorters.push(new sap.ui.model.Sorter(sPath, bDescending, vGroup));
    //Sorting
    aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
    oBinding.sort(aSorters);
    that.byId("DateColumn").setMergeDuplicates(true);
    that.byId("AlreadyApprovedColumn").setMergeDuplicates(true);
    that.byId("TotalOnTargetColumn").setMergeDuplicates(true);
   }
  },
  applySortingAndGroupingMass: function () {
   var that = this;
   if (that.getView().getModel("MassViewSetModel")) {
    var massViewSet = that.getView().getModel("MassViewSetModel").getData();
    var oBinding = that.getView().byId("MassApproval").getBinding("items");
    that.byId("MNameColumn").setMergeDuplicates(false);
    that.byId("MRoleColumn").setMergeDuplicates(false);
    // apply sorter to binding
    // (grouping comes before sorting)
    var vGroup;
    var aSorters = [];
    //Grouping
    if (massViewSet.grouping === "true") {
     var gPath = massViewSet.gPath;
     var gDescending = massViewSet.gDescending;
     vGroup = that.mGroupFunctionsMass[gPath];
     aSorters.push(new sap.ui.model.Sorter(gPath, gDescending, vGroup));
    }
    //Sorting
    var sPath = massViewSet.sPath;
    var bDescending = massViewSet.bDescending;
    aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
    oBinding.sort(aSorters);
    that.byId("MNameColumn").setMergeDuplicates(true);
    that.byId("MRoleColumn").setMergeDuplicates(true);
   } else {
    var oView = that.getView();
    var oTable = oView.byId("MassApproval");
    var oBinding = oTable.getBinding("items");
    that.byId("MNameColumn").setMergeDuplicates(false);
    that.byId("MRoleColumn").setMergeDuplicates(false);
    // apply sorter to binding
    // (grouping comes before sorting)
    var sPath = "EmployeeName";
    var bDescending = false;
    var vGroup;
    var aSorters = [];
    var oMassViewSettingsModel = new JSONModel({
     "grouping": "true",
     "gPath": sPath,
     "gDescending": bDescending,
     "sPath": sPath,
     "bDescending": bDescending
    });
    that.setModel(oMassViewSettingsModel, "MassViewSetModel");
    //Grouping
    vGroup = that.mGroupFunctionsMass[sPath];
    aSorters.push(new sap.ui.model.Sorter(sPath, bDescending, vGroup));
    //Sorting
    aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
    oBinding.sort(aSorters);
    that.byId("MNameColumn").setMergeDuplicates(true);
    that.byId("MRoleColumn").setMergeDuplicates(true);
   }
  },
  getIndividualApprovalDetails: function (pFilter) {
   var that = this;
   that.oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
   that.oDataDetailModel = this.getOwnerComponent().getModel();
   that.byId("PendingEntriesTable").setBusy(true);

   // Handle Concurrent Employee / Switch Personnel Assignment
   var sApproverPernr = this.getOwnerComponent().getModel("Pernr").getData(),
    sApprPernrFilter = "CATSAssignment" +  " eq '" + sApproverPernr + "'",
    sFilter = "";

   if (pFilter && sApproverPernr){
    sFilter = pFilter + " and " + sApprPernrFilter;
   } else if ( pFilter ){
    sFilter = pFilter;
   } else if ( sApproverPernr ){
    sFilter = sApprPernrFilter;
   }

   var oFilter = {
    "$filter": sFilter
   };

   var mParameters = {
    urlParameters: oFilter,
    success: function (oData, oResponse) {
     var timeTable = that.byId("PendingEntriesTable");
     timeTable.setVisible(true);
     var massTable = that.byId("MassApproval");
     massTable.setVisible(false);
     for (var l = 0; l < oData.results.length; l++) {
      if (oData.results[l].CATSHours !== 0) {
       oData.results[l].CATSAmount = oData.results[l].CATSHours;
      } else if (oData.results[l].CATSQuantity !== 0) {
       oData.results[l].CATSAmount = oData.results[l].CATSQuantity;
      } else if (oData.results[l].CATSAmount !== 0) {
       //Do nothing as CATSAmount field's value is shown
      } else {
       //Contains a zero hours record - so delete the entry from the result
       oData.results.splice(l, 1);
      }
     }
     var oModel = new sap.ui.model.json.JSONModel(oData.results);
     that.getView().setModel(oModel, "IndividualApprovalModel");
     that.applySortingAndGroupingInd();
     var timeEntriesText;
     if (oData.results.length === 1) {
      timeEntriesText = that.oBundle.getText("timeEntry");
     } else {
      timeEntriesText = that.oBundle.getText("timeEntries", [oData.results.length]);
     }
     that.byId("PendingTabTextId").setText(timeEntriesText);
     that.byId("PendingEntriesTable").setBusy(false);
    },
    error: function (oError) {
     that.byId("PendingEntriesTable").setBusy(false);
     that.processMessage(oError);
    }
   };
   that.oDataDetailModel
    .read(
     "/ApprovalDetailsSet",
     mParameters);
  },
  getEmployeeDetails: function (eFilt) {
   var that = this;
   that.oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
   that.oDataEmployeeModel = this.getOwnerComponent().getModel();
   that.byId("ObjectPageLayout").setBusy(true);
   var oEmpFilter = {
    "$filter": eFilt
   };
   var mParametersEmp = {
    urlParameters: oEmpFilter,
    success: function (oData, oResponse) {
     var objHdr = that.byId("ObjectPageLayoutHeaderTitle");
     objHdr.setObjectTitle(oData.results[0].EmployeeName);
     that.byId("TeleTitleObjAttrId").setTitle(that.oBundle.getText("telephone"));
     that.byId("MailTitleObjAttrId").setTitle(that.oBundle.getText("email"));
     that.byId("TeleTitleObjAttrId").setText(oData.results[0].EmployeeTelephone);
     that.byId("MailTitleObjAttrId").setText(oData.results[0].EmployeeMailID);
     that.byId("ObjectPageLayout").setBusy(false);
    },
    error: function (oError) {
     that.byId("ObjectPageLayout").setBusy(false);
     that.processMessage(oError);
    }
   };
   that.oDataEmployeeModel
    .read(
     "/EmployeeDetailsSet",
     mParametersEmp);
  },
  getMassApprovalDetails: function (pSelectedIds, pLastEmployeeCheckbox) {
   var that = this;
   that.oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
   var massData = that.getGlobalModel("MassApprovalSharedModel").getData();
   var removeIndices = [];
   if (massData.length) {
    for (var n = 0; n < massData.length; n++) {
     if (pSelectedIds.indexOf(massData[n].EmployeeID) === -1) {
      removeIndices.push(n);
     }
    }
   }
   if (removeIndices) {
    for (var i = removeIndices.length - 1; i >= 0; i--) {
     massData.splice(removeIndices[i], 1);
    }
   }
   //Remove actual ungrouped values too
   var massActualData = that.getGlobalModel("MassApprovalActualModel").getData();
   var removeActualIndices = [];
   if (massActualData.length) {
    for (var r = 0; r < massActualData.length; r++) {
     if (pSelectedIds.indexOf(massActualData[r].EmployeeID) === -1) {
      removeActualIndices.push(r);
     }
    }
   }
   if (removeActualIndices) {
    for (var s = removeActualIndices.length - 1; s >= 0; s--) {
     massActualData.splice(removeActualIndices[s], 1);
    }
   }
   var oMassSharedModel = new sap.ui.model.json.JSONModel(massActualData);
   that.setGlobalModel(oMassSharedModel, "MassApprovalActualModel");

   if (pSelectedIds.indexOf(pLastEmployeeCheckbox) === -1) {
    pLastEmployeeCheckbox = "Unchecked";
    var oMassModelNew = new sap.ui.model.json.JSONModel(massData);
    that.setModel(oMassModelNew, "MassApprovalModel");
    that.setGlobalModel(oMassModelNew, "MassApprovalSharedModel");
    var timeTable = that.byId("PendingEntriesTable");
    timeTable.setVisible(false);
    var massTable = that.byId("MassApproval");
    massTable.setVisible(true);
    var selectedEmployeesText = that.oBundle.getText("selectedEmployees");
    that.byId("ApprovalDetailPage").setTitle(selectedEmployeesText + " (" + pSelectedIds.length + ")");
    var objHdr = that.byId("ObjectPageLayoutHeaderTitle");
    var empSelectedText = that.oBundle.getText("employeesSelected");
    objHdr.setObjectTitle(pSelectedIds.length + " " + empSelectedText);
    objHdr.setObjectSubtitle("");
    that.byId("TeleTitleObjAttrId").setTitle("");
    that.byId("MailTitleObjAttrId").setTitle("");
    that.byId("TeleTitleObjAttrId").setText("");
    that.byId("MailTitleObjAttrId").setText("");
    var itemCount = massData.length;
    if (!itemCount) {
     itemCount = 0;
    }
    var noItemsText = that.oBundle.getText("items", [itemCount]);
    that.byId("MassTabTextId").setText(noItemsText);
    that.applySortingAndGroupingMass();
   }
   if (pLastEmployeeCheckbox !== "Unchecked") {
    var filter = "EmployeeID eq '" + pLastEmployeeCheckbox + "'";

    // Handle Concurrent Employee / Switch Personnel Assignment
    var sApproverPernr = this.getOwnerComponent().getModel("Pernr").getData(),
     sApprPernrFilter = " and " + "AssignmentID" +  " eq '" + sApproverPernr + "'";
    if( sApproverPernr ){
     filter += sApprPernrFilter;
    }

    that.oDataMassModel = this.getOwnerComponent().getModel();
    that.byId("MassApproval").setBusy(true);

    var oMassFilter = {
     "$filter": filter
    };

    var mParametersMass = {
     urlParameters: oMassFilter,
     success: function (oData, oResponse) {
      var oPassActualModel = new sap.ui.model.json.JSONModel();
      if (massActualData.length) {
       massActualData = massActualData.concat(oData.results);
       oPassActualModel.setData(massActualData);
       that.setGlobalModel(oPassActualModel, "MassApprovalActualModel");
      } else {
       oPassActualModel.setData(oData.results);
       that.setGlobalModel(oPassActualModel, "MassApprovalActualModel");
      }
      var oMassModel = new sap.ui.model.json.JSONModel();
      var tempArr = [];
      var tempArrElement = [];
      var assignId, sumAmount = 0, sumMinutes = 0,
       sumTotal = 0;
      var g;
      for (g = 0; g < oData.results.length; g++) {
       if (assignId !== undefined && oData.results[g].AssignmentID !== assignId) {
        tempArrElement.CATSAmount = sumAmount + (sumMinutes / 60);
        tempArrElement.Total = sumTotal;
        var data = $.extend(true, {}, tempArrElement);
        tempArr.push(data);
        sumTotal = 0;
        sumAmount = 0;
        sumMinutes = 0;
       }

       assignId = oData.results[g].AssignmentID;
       tempArrElement.Counter = oData.results[g].Counter;
       tempArrElement.EmployeeID = oData.results[g].EmployeeID;
       tempArrElement.EmployeeName = oData.results[g].EmployeeName;
       tempArrElement.EmployeeRole = oData.results[g].EmployeeRole;
       tempArrElement.Total = oData.results[g].Total;
       tempArrElement.AssignmentID = oData.results[g].AssignmentID;
       tempArrElement.AssignmentText = oData.results[g].AssignmentText;

       if (oData.results[g].CATSHours !== 0) {
        tempArrElement.CATSAmount = 0; //oData.results[g].CATSHours;
        sumMinutes = sumMinutes + Math.round( parseFloat(oData.results[g].CATSHours, 10) * 60 );
       } else if (oData.results[g].CATSQuantity !== 0) {
        tempArrElement.CATSAmount = oData.results[g].CATSQuantity;
       } else {
        tempArrElement.CATSAmount = oData.results[g].CATSAmount;
       }

       sumAmount = sumAmount + parseFloat(tempArrElement.CATSAmount, 10);

       tempArrElement.UnitOfMeasure = oData.results[g].UnitOfMeasure;
       tempArrElement.Currency = oData.results[g].Currency;
       tempArrElement.Unit = oData.results[g].Unit;
       tempArrElement.Status = oData.results[g].Status;
       tempArrElement.Reason = oData.results[g].Reason;
       tempArrElement.DateCreate = oData.results[g].DateCreate;
       tempArrElement.TimeCreate = oData.results[g].TimeCreate;
       sumTotal = sumTotal + 1;
      }
      g--;
      tempArrElement.CATSAmount = sumAmount + (sumMinutes / 60); // Rounding off minutes to hours
      tempArrElement.Counter = oData.results[g].Counter;
      tempArrElement.EmployeeID = oData.results[g].EmployeeID;
      tempArrElement.EmployeeName = oData.results[g].EmployeeName;
      tempArrElement.EmployeeRole = oData.results[g].EmployeeRole;
      tempArrElement.Total = oData.results[g].Total;
      tempArrElement.AssignmentID = oData.results[g].AssignmentID;
      tempArrElement.AssignmentText = oData.results[g].AssignmentText;
      tempArrElement.UnitOfMeasure = oData.results[g].UnitOfMeasure;
      tempArrElement.Currency = oData.results[g].Currency;
      tempArrElement.Unit = oData.results[g].Unit;
      tempArrElement.Status = oData.results[g].Status;
      tempArrElement.Reason = oData.results[g].Reason;
      tempArrElement.DateCreate = oData.results[g].DateCreate;
      tempArrElement.TimeCreate = oData.results[g].TimeCreate;
      tempArrElement.Total = sumTotal;
      var pushData = $.extend(true, {}, tempArrElement);
      tempArr.push(pushData);
      var itemsText;
      if (massData.length) {
       massData = massData.concat(tempArr);
       oMassModel.setData(massData);
       if (massData.length === 1) {
        itemsText = that.oBundle.getText("item");
       } else {
        itemsText = that.oBundle.getText("items", [massData.length]);
       }
      } else {
       oMassModel.setData(tempArr);
       if (tempArr.length === 1) {
        itemsText = that.oBundle.getText("item");
       } else {
        itemsText = that.oBundle.getText("items", [tempArr.length]);
       }
      }
      that.byId("MassTabTextId").setText(itemsText);
      var timeTable = that.byId("PendingEntriesTable");
      timeTable.setVisible(false);
      that.setModel(oMassModel, "MassApprovalModel");
      that.setGlobalModel(oMassModel, "MassApprovalSharedModel");
      var massTable = that.byId("MassApproval");
      massTable.setVisible(true);
      var selectedEmployeesText = that.oBundle.getText("selectedEmployees");
      that.byId("ApprovalDetailPage").setTitle(selectedEmployeesText + " (" + pSelectedIds.length + ")");
      var objHdr = that.byId("ObjectPageLayoutHeaderTitle");
      var empSelectedText;
      if (pSelectedIds.length == 1) {
       empSelectedText = that.oBundle.getText("employeeSelected");
      } else {
       empSelectedText = that.oBundle.getText("employeesSelected");
      }
      objHdr.setObjectTitle(pSelectedIds.length + " " + empSelectedText);
      objHdr.setObjectSubtitle("");
      that.byId("TeleTitleObjAttrId").setTitle("");
      that.byId("MailTitleObjAttrId").setTitle("");
      that.byId("TeleTitleObjAttrId").setText("");
      that.byId("MailTitleObjAttrId").setText("");
      that.applySortingAndGroupingMass();
      that.byId("MassApproval").setBusy(false);
     },
     error: function (oError) {
      that.byId("MassApproval").setBusy(false);
      that.processMessage(oError);
     }
    };
    that.oDataMassModel
     .read(
      "/MassApprovalSet",
      mParametersMass);
   }
  },
  performSingleApproval: function (selectedItems, apprStatus, rejReason, selectAll) {
   var that = this;
   var oErrorModelInit = new JSONModel({
    "EnableError": "true"
   });
   that.setModel(oErrorModelInit, "ErrorModel");
   that.oDataSingleApprModel = this.getOwnerComponent().getModel();
   that.byId("PendingEntriesTable").setBusy(true);
   that.oDataSingleApprModel.resetChanges();
   that.oDataSingleApprModel.setChangeBatchGroups({
    "*": {
     groupId: "SingleApproval",
     changeSetId: "SingleApproval",
     single: false
    }
   });
   that.oDataSingleApprModel.setDeferredGroups(["SingleApproval"]);
   that.oDataSingleApprModel
    .refreshSecurityToken(
     function (oData) {
      if (selectedItems.length > 0) {
       for (var j = 0; j < selectedItems.length; j++) {
        var obj = {
         properties: {
          EmployeeID: selectedItems[j].EmployeeId,
          Counter: selectedItems[j].Counter,
          Status: apprStatus,
          Reason: rejReason,
          DateCreate: selectedItems[j].DateCreate,
          TimeCreate: selectedItems[j].TimeCreate
         },
         success: function (oDataReturn) {
          if (j == selectedItems.length) {
           var filt = "EmployeeID eq '" + selectedItems[j - 1].EmployeeId + "'";
           that.getIndividualApprovalDetails(filt);
           that.getView().getModel("IndividualApprovalModel").refresh();
           var oEventBus = sap.ui.getCore().getEventBus();
           if (selectAll === "true") {
            oEventBus.publish("ApprovalDetail", "refreshAll");
           } else {
            oEventBus.publish("ApprovalDetail", "refreshMasterList");
           }
          }
          that.byId("PendingEntriesTable").setBusy(false);
          if (apprStatus == "30") {
           var toastMsg = that.oBundle.getText("apprSuccess");
          } else if (apprStatus == "40") {
           var toastMsg = that.oBundle.getText("rejSuccess");
          }
          sap.m.MessageToast.show(toastMsg, {
           duration: 3000
          });
         },
         error: function (oError) {
          var enable = that.getView().getModel("ErrorModel").getData().EnableError;
          if (enable === "true") {
           that.byId("PendingEntriesTable").setBusy(false);
           if (j == selectedItems.length) {
            var oErrorModel = new JSONModel({
             "EnableError": "false"
            });
            that.setModel(oErrorModel, "ErrorModel");
            var empFilter = "EmployeeID eq '" + selectedItems[j - 1].EmployeeId + "'";
            that.processMessage(oError, empFilter);
           }
          }
         },
         changeSetId: "SingleApproval",
         groupId: "SingleApproval"
        };
        that.oDataSingleApprModel
         .createEntry(
          "/ApprovalDetailsSet",
          obj);
       }
      }
      that.oDataSingleApprModel.submitChanges({
       groupId: "SingleApproval",
       changeSetId: "SingleApproval"
      });
     }, true);
  },
  performMassApproval: function (selectedEmps, apprStatus, rejReason) {
   var that = this;
   var oErrorModelInit = new JSONModel({
    "EnableError": "true"
   });
   that.setModel(oErrorModelInit, "ErrorModel");
   that.oDataMassApprModel = this.getOwnerComponent().getModel();
   that.byId("MassApproval").setBusy(true);
   that.oDataMassApprModel.resetChanges();
   that.oDataMassApprModel.setChangeBatchGroups({
    "*": {
     groupId: "MassApproval",
     changeSetId: "MassApproval",
     single: false
    }
   });
   that.results = [];
   var MassApprovalActualModel = this.getGlobalModel("MassApprovalActualModel");
   var entries = MassApprovalActualModel.oData;
   that.oDataMassApprModel.setDeferredGroups(["MassApproval"]);
   that.oDataMassApprModel
    .refreshSecurityToken(
     function (oData) {
      for (var j = 0; j < entries.length; j++) {
       var obj = {
        properties: {
         EmployeeID: entries[j].EmployeeID,
         Counter: entries[j].Counter,
         Reason: rejReason,
         Status: apprStatus,
         DateCreate: entries[j].DateCreate,
         TimeCreate: entries[j].TimeCreate
        },
        success: function (oDataReturn) {
         var oEventBus = sap.ui.getCore().getEventBus();
         oEventBus.publish("ApprovalDetail", "refreshAll");
         that.byId("MassApproval").setBusy(false);
         if (apprStatus == "30") {
          var toastMsg = that.oBundle.getText("apprSuccess");
         } else if (apprStatus == "40") {
          var toastMsg = that.oBundle.getText("rejSuccess");
         }
         sap.m.MessageToast.show(toastMsg, {
          duration: 3000
         });
         if (sap.ui.Device.system.phone === true) {
          that.getOwnerComponent().getRouter().navTo("master", {}, true);
         }
        },
        error: function (oError) {
         var enable = that.getView().getModel("ErrorModel").getData().EnableError;
         if (enable === "true") {
          var oErrorModel = new JSONModel({
           "EnableError": "false"
          });
          that.setModel(oErrorModel, "ErrorModel");
          that.byId("MassApproval").setBusy(false);
          that.processMessage(oError);
         }
        },
        changeSetId: "MassApproval",
        groupId: "MassApproval"
       };
       that.oDataMassApprModel
        .createEntry(
         "/MassApprovalSet",
         obj);
      }
      that.oDataMassApprModel.submitChanges({
       groupId: "MassApproval",
       changeSetId: "MassApproval"
      });
     }, true);
  },
  onSelectCheckbox: function (oEvent) {
   var listId = this.byId("PendingEntriesTable");
   var listItems = listId.getItems();
   var selectedNum = 0;
   for (var i = 0; i < listItems.length; i++) {
    if (listItems[i].getProperty("selected")) {
     selectedNum += 1;
    }
   }
   if (selectedNum > 0) {
    this.byId("ApproveButton").setEnabled(true);
    this.byId("RejectButton").setEnabled(true);
   } else {
    this.byId("ApproveButton").setEnabled(false);
    this.byId("RejectButton").setEnabled(false);
   }
  },
  onNavBack: function () {
   var sPreviousHash = History.getInstance().getPreviousHash();
   if (sPreviousHash !== undefined) {
    history.go(-1);
   } else {
    this.getOwnerComponent().getRouter().navTo("master", {}, true);
   }
  },
  onPhoneClick: function (oEvent) {
   sap.m.URLHelper.triggerTel(oEvent.getSource().getText());
  },
  onEmailClick: function (oEvent) {
   sap.m.URLHelper.triggerEmail(oEvent.getSource().getText());
  },
  handleIndividualViewSettingsDialogButtonPressed: function (oEvent) {
   if (!this._oDialogInd) {
    this._oDialogInd = sap.ui.xmlfragment(this.getView().getId(),
     "hcm.fab.approve.timesheet.view.fragments.IndividualApprovalTableDialog",
     this);
    this.getView().addDependent(this._oDialogInd);
   }
   // toggle compact style
   jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialogInd);
   this._oDialogInd.open();
  },
  handleMassViewSettingsDialogButtonPressed: function (oEvent) {
   if (!this._oDialogMass) {
    this._oDialogMass = sap.ui.xmlfragment(this.getView().getId(), "hcm.fab.approve.timesheet.view.fragments.MassApprovalTableDialog",
     this);
    this.getView().addDependent(this._oDialogMass);
   }
   // toggle compact style
   jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialogMass);
   this._oDialogMass.open();
  },
  handleIndividualViewSettingsConfirm: function (oEvent) {
   var oView = this.getView();
   var oTable = oView.byId("PendingEntriesTable");
   var mParams = oEvent.getParameters();
   var oBinding = oTable.getBinding("items");
   this.byId("DateColumn").setMergeDuplicates(false);
   this.byId("AlreadyApprovedColumn").setMergeDuplicates(false);
   this.byId("TotalOnTargetColumn").setMergeDuplicates(false);
   // apply sorter to binding
   // (grouping comes before sorting)
   var sPath;
   var gPath;
   var bDescending;
   var gDescending;
   var vGroup;
   var grouping = "false";
   var aSorters = [];
   if (mParams.groupItem) {
    grouping = "true";
    gPath = mParams.groupItem.getKey();
    gDescending = mParams.groupDescending;
    vGroup = this.mGroupFunctionsInd[gPath];
    aSorters.push(new sap.ui.model.Sorter(gPath, gDescending, vGroup));
   }
   sPath = mParams.sortItem.getKey();
   bDescending = mParams.sortDescending;
   var oIndividualViewSettingsModel = new JSONModel({
    "grouping": grouping,
    "gPath": gPath,
    "gDescending": gDescending,
    "sPath": sPath,
    "bDescending": bDescending
   });
   this.setModel(oIndividualViewSettingsModel, "IndViewSetModel");
   aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
   oBinding.sort(aSorters);
   this.byId("DateColumn").setMergeDuplicates(true);
   this.byId("AlreadyApprovedColumn").setMergeDuplicates(true);
   this.byId("TotalOnTargetColumn").setMergeDuplicates(true);
  },
  handleMassViewSettingsConfirm: function (oEvent) {
   this.byId("MNameColumn").setMergeDuplicates(false);
   this.byId("MRoleColumn").setMergeDuplicates(false);
   this.byId("MTotalColumn").setMergeDuplicates(false);
   var oView = this.getView();
   var oTable = oView.byId("MassApproval");
   var mParams = oEvent.getParameters();
   var oBinding = oTable.getBinding("items");
   // apply sorter to binding
   // (grouping comes before sorting)
   var sPath;
   var gPath;
   var bDescending;
   var gDescending;
   var vGroup;
   var grouping = "false";
   var aSorters = [];
   if (mParams.groupItem) {
    grouping = "true";
    gPath = mParams.groupItem.getKey();
    gDescending = mParams.groupDescending;
    vGroup = this.mGroupFunctionsMass[gPath];
    aSorters.push(new sap.ui.model.Sorter(gPath, gDescending, vGroup));
   }
   sPath = mParams.sortItem.getKey();
   bDescending = mParams.sortDescending;
   var oMassViewSettingsModel = new JSONModel({
    "grouping": grouping,
    "gPath": gPath,
    "gDescending": gDescending,
    "sPath": sPath,
    "bDescending": bDescending
   });
   this.setModel(oMassViewSettingsModel, "MassViewSetModel");
   aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
   oBinding.sort(aSorters);
   this.byId("MNameColumn").setMergeDuplicates(true);
   this.byId("MRoleColumn").setMergeDuplicates(true);
   this.byId("MTotalColumn").setMergeDuplicates(true);
  },
  handleAssignmentLinkPress: function (oEvent) {
   var that = this;
   that.assignmentText = oEvent.getSource().getProperty("text");
   that.source = oEvent.getSource();
   var oView = this.getView();
   var counterValue = oEvent.getSource().getParent().getCustomData()[0].getProperty("value");
   var aFilter = "Counter eq '" + counterValue + "'";
   var passFilter = {
    "$filter": aFilter
   };
   that.oQuickview = oView.byId("quickViewAssignment");
   that.oDataAssignmentModel = that.getOwnerComponent().getModel();
   var mAsParameters = {
    urlParameters: passFilter,
    success: function (oData) {
     oData.results[0].FieldText = that.getOwnerComponent().getModel("i18n").getResourceBundle().getText("name");
     oData.results[0].FieldValue = that.assignmentText;
     var oAsModel = new sap.ui.model.json.JSONModel(oData.results);
     that.setModel(oAsModel, "AssignmentDetailsModel");
     // that.oQuickview.getPages()[0].setTitle(that.assignmentText);
     var oButton = that.source;
     jQuery.sap.delayedCall(0, that, function () {
      that.oQuickview.openBy(oButton);
     });
    },
    error: function (oError) {
     that.processMessage(oError);
    }
   };
   that.oDataAssignmentModel
    .read("/ApprovalFieldsSet", mAsParameters);
   if (that.oQuickview) {
    that.oQuickview.close();
   }
   // create dialog lazily
   if (!that.oQuickview) {
    // create dialog via fragment factory
    that.oQuickview = sap.ui.xmlfragment(that.getView().getId(), "hcm.fab.approve.timesheet.view.fragments.AssignmentDetailsDialog",
     that);
    // connect dialog to view (models, lifecycle)
    that.getView().addDependent(that.oQuickview);
   }
  },
  onReject: function () {
   var that = this;
   var oView = this.getView();
   that.oDialog = oView.byId("RejectReasonDialogId");
   that.selectedItems = [];
   that.selected = [];
   //Fetch the selected time entry counters
   var tabRef = this.byId("PendingEntriesTable");
   var oItems = tabRef.getItems();
   for (var i = 0; i < oItems.length; i++) {
    if (oItems[i].getProperty("selected") === true) {
     that.selected.Counter = oItems[i].getCustomData()[0].getValue();
     that.selected.EmployeeId = oItems[i].getCustomData()[1].getValue();
     that.selected.DateCreate = oItems[i].getCustomData()[2].getValue();
     that.selected.TimeCreate = oItems[i].getCustomData()[3].getValue();
     var data = $.extend(true, {}, that.selected);
     that.selectedItems.push(data);
    }
   }
   that.selectAll = "false";
   if (oItems.length === that.selectedItems.length) {
    that.selectAll = "true";
   }
   if (that.selectedItems.length) {
    that.oDataRejModel = that.getOwnerComponent().getModel();
    var mRejParameters = {
     success: function (oData) {
      var oRejModel = new sap.ui.model.json.JSONModel(oData.results);
      that.getView().setModel(oRejModel, "RejectionReasonModel");
     },
     error: function (oError) {
      that.processMessage(oError);
     }
    };
    that.oDataRejModel
     .read("/RejectionReasonSet", mRejParameters);
    // create dialog lazily
    if (!that.oDialog) {
     var oDialogController = {
      onRejectConfirm: function (evnt) {
       var rejListRef = that.byId("RejectReasonList");
       if (rejListRef.getSelectedItem() !== null) {
        var reasonCode = rejListRef.getSelectedItem().getCustomData()[0].getProperty("value");
       }
       that.performSingleApproval(that.selectedItems, "40", reasonCode, that.selectAll);
       that.oDialog.close();
      },
      onCancel: function (evnt) {
       that.oDialog.close();
      }
     };
     // create dialog via fragment factory
     that.oDialog = sap.ui.xmlfragment(that.getView().getId(), "hcm.fab.approve.timesheet.view.fragments.RejectionReasonDialog",
      oDialogController);
     // connect dialog to view (models, lifecycle)
     that.getView().addDependent(that.oDialog);
    }
    jQuery.sap.syncStyleClass("sapUiSizeCompact", that.getView(), that.oDialog);
    that.oDialog.open();
   } else {
    var toastMsg = that.oBundle.getText("noSelectionMade");
    sap.m.MessageToast.show(toastMsg, {
     duration: 3000
    });
   }
  },
  onRejectAll: function () {
   var that = this;
   that.oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
   var detailPathModel = this.getGlobalModel("exchangeModel");
   that.selectedArr = [];
   for (var i = 1; i < detailPathModel.oData.length - 1; i++) {
    that.selectedArr[i - 1] = detailPathModel.oData[i];
   }
   if (that.selectedArr.length) {
    that.oDataRejModel = that.getOwnerComponent().getModel();
    var mRejParameters = {
     success: function (oData) {
      var oRejModel = new sap.ui.model.json.JSONModel(oData.results);
      that.getView().setModel(oRejModel, "RejectionReasonModel");
     },
     error: function (oError) {
      that.processMessage(oError);
     }
    };
    that.oDataRejModel
     .read("/RejectionReasonSet", mRejParameters);
    // create dialog lazily
    if (!that.oDialog) {
     var oDialogController = {
      onRejectConfirm: function (evnt) {
       var rejListRef = that.byId("RejectReasonList");
       if (rejListRef.getSelectedItem() !== null) {
        var reasonCode = rejListRef.getSelectedItem().getCustomData()[0].getProperty("value");
       }
       that.performMassApproval(that.selectedArr, "40", reasonCode);
       that.oDialog.close();
      },
      onCancel: function (evnt) {
       that.oDialog.close();
      }
     };
     // create dialog via fragment factory
     that.oDialog = sap.ui.xmlfragment(that.getView().getId(), "hcm.fab.approve.timesheet.view.fragments.RejectionReasonDialog",
      oDialogController);
     // connect dialog to view (models, lifecycle)
     that.getView().addDependent(that.oDialog);
    }
    jQuery.sap.syncStyleClass("sapUiSizeCompact", that.getView(), that.oDialog);
    that.oDialog.open();
   } else {
    var toastMsg = that.oBundle.getText("noSelectionMade");
    sap.m.MessageToast.show(toastMsg, {
     duration: 3000
    });
   }
  },
  onApprove: function () {
   var that = this;
   var selectedItems = [];
   var selected = [];
   //Fetch the selected time entry counters
   var tabRef = this.byId("PendingEntriesTable");
   var oItems = tabRef.getItems();
   for (var i = 0; i < oItems.length; i++) {
    if (oItems[i].getProperty("selected") == true) {
     selected.Counter = oItems[i].getCustomData()[0].getValue();
     selected.EmployeeId = oItems[i].getCustomData()[1].getValue();
     selected.DateCreate = oItems[i].getCustomData()[2].getValue();
     selected.TimeCreate = oItems[i].getCustomData()[3].getValue();
     var data = $.extend(true, {}, selected);
     selectedItems.push(data);
    }
   }
   var selectAll = "false";
   if (oItems.length === selectedItems.length) {
    selectAll = "true";
   }
   if (selectedItems.length) {
    that.performSingleApproval(selectedItems, "30", "", selectAll);
   } else {
    var toastMsg = that.oBundle.getText("noSelectionMade");
    sap.m.MessageToast.show(toastMsg, {
     duration: 3000
    });
   }
  },
  onApproveAll: function () {
   var that = this;
   that.oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
   var detailPathModel = this.getGlobalModel("exchangeModel");
   var selectedArr = [];
   if (sap.ui.Device.system.phone === true) {
    for (var i = 1; i <= detailPathModel.oData.length - 1; i++) {
     selectedArr[i - 1] = detailPathModel.oData[i];
    }
   } else {
    for (var i = 1; i < detailPathModel.oData.length - 1; i++) {
     selectedArr[i - 1] = detailPathModel.oData[i];
    }
   }
   if (selectedArr.length) {
    this.performMassApproval(selectedArr, "30", "");
   } else {
    var toastMsg = that.oBundle.getText("noSelectionMade");
    sap.m.MessageToast.show(toastMsg, {
     duration: 3000
    });
   }
  },
  displayLongtext: function (oEvent) {
   // create popover
   var oDialogController = {};
   this._oPopover = sap.ui.xmlfragment(this.getView().getId(), "hcm.fab.approve.timesheet.view.fragments.LongTextDialog",
    oDialogController);
   this.getView().addDependent(this._oPopover);
   this._oPopover.bindElement('IndividualApprovalModel>' + oEvent.getSource().getBindingContext('IndividualApprovalModel').getPath());
   // }
   // delay because addDependent will do a async rerendering and the popover will immediately close without it
   var oButton = oEvent.getSource();
   jQuery.sap.delayedCall(0, this, function () {
    this._oPopover.openBy(oButton);
   });
  },
  processMessage: function (oError, filt) {
   var that = this;
   var errorObj = JSON.parse(oError.responseText).error;
   var errorSet = errorObj.innererror.errordetails;
   var messageHeader = errorSet[0].message;
   var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
   sap.m.MessageBox.information(
    messageHeader, {
     styleClass: bCompact ? "sapUiSizeCompact" : "",
     onClose: function () {
      if (filt !== undefined) {
       that.getIndividualApprovalDetails(filt);
       that.getView().getModel("IndividualApprovalModel").refresh();
      }
      var oEventBus = sap.ui.getCore().getEventBus();
      oEventBus.publish("ApprovalDetail", "refreshAll");
     }
    }
   );
  },
  initPersonalization: function () {
   if (sap.ushell.Container) {
    var oPendingTable = this.byId("PendingEntriesTable");
    var oMassTable = this.byId("MassApproval");
    var oPersonalizationService = sap.ushell.Container.getService("Personalization");
    var oPendingTabPersonalizer = oPersonalizationService.getPersonalizer({
     container: "hcm.fab.approve.timesheet", // This key must be globally unique (use a key to identify the app) -> only 40 characters are allowed
     item: "PendingEntriesTable" // Maximum of 40 characters applies to this key as well
    });
    var oMassTabPersonalizer = oPersonalizationService.getPersonalizer({
     container: "hcm.fab.approve.timesheet", // This key must be globally unique (use a key to identify the app) -> only 40 characters are allowed
     item: "MassApproval" // Maximum of 40 characters applies to this key as well
    });
    this.oTablePendingPersoController = new TablePersoController({
     table: oPendingTable,
     componentName: "ApproveTimesheet",
     persoService: oPendingTabPersonalizer
    }).activate();
    this.oTableMassPersoController = new TablePersoController({
     table: oMassTable,
     componentName: "ApproveTimesheet",
     persoService: oMassTabPersonalizer
    }).activate();
   }
  },
  onPersPendingButtonPressed: function (oEvent) {
   this.oTablePendingPersoController.openDialog();
  },
  onPersMassButtonPressed: function (oEvent) {
   this.oTableMassPersoController.openDialog();
  }

 });

});