/*
 * Copyright (C) 2009-2017 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([
 "hcm/fab/approve/timesheet/controller/BaseController",
 "sap/ui/model/odata/ODataModel",
 "sap/ui/model/json/JSONModel",
 "sap/ui/core/routing/History",
 "hcm/fab/approve/timesheet/model/formatter",
 "sap/ui/model/Filter",
 "sap/ui/model/FilterOperator",
 "sap/ui/Device",
 "sap/m/GroupHeaderListItem",
 "sap/m/TablePersoController"
], function (BaseController, ODataModel, JSONModel, History, formatter, Filter, FilterOperator, Device, GroupHeaderListItem,
 TablePersoController) {
 "use strict";

 return BaseController.extend("hcm.fab.approve.timesheet.controller.ApprovalDetail", {
  formatter: formatter,
  extHookOnPerformSingleApproval: null,
  extHookOnPerformMassApproval: null,
  _oDialogInd: null,
  _oDialogMass: null,
  onInit: function () {
   var that = this;
   that.getOwnerComponent().getRouter().getRoute("detail").attachPatternMatched(this._onRouteMatched, this);
   that.oDataModel = this.getOwnerComponent().getModel();
   that.oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
   var oModel = new JSONModel({});
   this.setModel(oModel, "MassApprovalModel");
   var oErrorModel = new JSONModel({
    "EnableError": "true"
   });
   this.setModel(oErrorModel, "ErrorModel");
   this.mGroupFunctionsInd = {
    Workdate: function (oContext) {
     var date = formatter.dateStringFormat(oContext.getProperty("Workdate"));
     return {
      key: date,
      text: date
     };
    },
    CATSAssignment: function (oContext) {
     var assignment = oContext.getProperty("CATSAssignment");
     return {
      key: assignment,
      text: assignment
     };
    },
    EmployeeName: function (oContext) {
     var employeename = oContext.getProperty("EmployeeName");
     return {
      key: employeename,
      text: employeename
     };
    }
   };
   this.mGroupFunctionsMass = {
    EmployeeName: function (oContext) {
     var name = oContext.getProperty("EmployeeName") + " / " + parseInt(oContext.getProperty("EmployeeID"), 10) + " / " + oContext.getProperty(
      "EmployeeRole");
     return {
      key: name,
      text: name
     };
    },
    AssignmentText: function (oContext) {
     var text = oContext.getProperty("AssignmentText");
     return {
      key: text,
      text: text
     };
    }
   };

   that.initPersonalization();

   // Set Features Model
   this.setModel(new sap.ui.model.json.JSONModel({ 
    IsRejectReasonMandatory: false,
    IsRejectConfirmButtonEnabled: true
   }), "FeatureControlModel");

  },
  onExit: function () {
   if (this._oDialogInd) {
    this._oDialogInd.destroy();
   }
   if (this._oDialogMass) {
    this._oDialogMass.destroy();
   }
   // The personalization table must be destroyed by the app. If not, when the app is restarted another personalization
   // table is created with the same ID and thus the app can't be started.
   if (this.oTablePendingPersoController) {
    this.oTablePendingPersoController.destroy();
    delete this.oTablePendingPersoController;
   }
   if (this.oTableMassPersoController) {
    this.oTableMassPersoController.destroy();
    delete this.oTableMassPersoController;
   }
  },
  _onRouteMatched: function (oEvent) {
   var approveButtonId;
   var rejectButtonId;
   var approveAllButtonId;
   var rejectAllButtonId;
   var detailPathModel = this.getGlobalModel("exchangeModel");
   var oWorkItemModel = this.getGlobalModel("WorkItem");
   if (detailPathModel === undefined) {
    this.getOwnerComponent().getRouter().navTo("master", {}, true);
   }
   if (oWorkItemModel) {
    this.workitemid = oWorkItemModel.getData()[0].workitemid;
    this.empId = detailPathModel.oData[1];
    this.getIndividualWorkItemApprovalDetails(this.workitemid, this.empId);
    this.byId("MailTitleObjAttrId").setVisible(false);
    this.byId("TeleTitleObjAttrId").setVisible(false);
    this.byId("ObjectPageLayoutHeaderTitle").setVisible(false);
   } else {
    if (detailPathModel.oData[0].includes("ALL")) {
     var selectAllAction = true;
     detailPathModel.oData[0] = detailPathModel.oData[0].replace("ALL", "");
    }
    var mode = detailPathModel.oData[0];
    this.mode = detailPathModel.oData[0];
    if (mode !== "MultiSelect") {
     approveButtonId = this.byId("ApproveButton");
     approveButtonId.setVisible(true);
     approveButtonId.setEnabled(false);
     rejectButtonId = this.byId("RejectButton");
     rejectButtonId.setVisible(true);
     rejectButtonId.setEnabled(false);
     approveAllButtonId = this.byId("ApproveAllButton");
     approveAllButtonId.setVisible(false);
     rejectAllButtonId = this.byId("RejectAllButton");
     rejectAllButtonId.setVisible(false);
     var empId = detailPathModel.oData[1];
     var filt = "EmployeeID eq '" + empId + "'";
     var sReadSingle = "/sap/opu/odata/sap/HCMFAB_APR_TIMESHEET_SRV/EmployeePictureSet('" + empId + "')/$value";
     this.byId('ObjectPageLayoutHeaderTitle').setObjectImageURI(sReadSingle);
     var employeeText = this.oBundle.getText("employee");
     this.byId("ApprovalDetailPage").setTitle(employeeText);
     this.getIndividualApprovalDetails(filt);
     this.getEmployeeDetails(filt);
    } else {
     if (Device.system.phone === true || selectAllAction === true) {
      approveButtonId = this.byId("ApproveButton");
      approveButtonId.setVisible(false);
      rejectButtonId = this.byId("RejectButton");
      rejectButtonId.setVisible(false);
      approveAllButtonId = this.byId("ApproveAllButton");
      approveAllButtonId.setVisible(true);
      rejectAllButtonId = this.byId("RejectAllButton");
      rejectAllButtonId.setVisible(true);
      var timeTable = this.byId("PendingEntriesTable");
      timeTable.setVisible(false);
      var massTable = this.byId("MassApproval");
      massTable.setVisible(true);
      var objHdr = this.byId("ObjectPageLayoutHeaderTitle");
      this.oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
      var empSelectedText = this.oBundle.getText("employeesSelected");
      var detailPathModel = this.getGlobalModel("exchangeModel");
      var selectedEmployeesText = this.oBundle.getText("selectedEmployees");
      this.byId("ApprovalDetailPage").setTitle(selectedEmployeesText + " (" + (detailPathModel.oData.length - 1) + ")");
      objHdr.setObjectTitle(detailPathModel.oData.length - 1 + " " + empSelectedText);
      objHdr.setObjectSubtitle("");
      this.byId("TeleTitleObjAttrId").setTitle("");
      this.byId("MailTitleObjAttrId").setTitle("");
      this.byId("TeleTitleObjAttrId").setText("");
      this.byId("MailTitleObjAttrId").setText("");
      var massData = this.getGlobalModel("MassApprovalMobileModel");
      var itemCount = massData.oData.length;
      if (itemCount === undefined) {
       itemCount = 0;
      }
      var itemsText;
      if (itemCount === 1) {
       itemsText = this.oBundle.getText("itemForApproval");
      } else {
       itemsText = this.oBundle.getText("itemsForApproval", [itemCount]);
      }
      this.byId("MassTabTextId").setText(itemsText);
      var oMassModelMobile = new sap.ui.model.json.JSONModel(massData.oData);
      this.setModel(oMassModelMobile, "MassApprovalModel");
      if (selectAllAction === true) {
       this.setGlobalModel(oMassModelMobile, "MassApprovalSharedModel");
      }
      this.applySortingAndGroupingMass();
      var massImage = "sap-icon://group";
      this.byId("ObjectPageLayoutHeaderTitle").setObjectImageURI(massImage);
     } else {
      approveButtonId = this.byId("ApproveButton");
      approveButtonId.setVisible(false);
      rejectButtonId = this.byId("RejectButton");
      rejectButtonId.setVisible(false);
      approveAllButtonId = this.byId("ApproveAllButton");
      approveAllButtonId.setVisible(true);
      rejectAllButtonId = this.byId("RejectAllButton");
      rejectAllButtonId.setVisible(true);
      var selectedArr = [];
      for (var i = 1; i < detailPathModel.oData.length - 1; i++) {
       selectedArr[i - 1] = detailPathModel.oData[i];
      }
      var selectedEmp = detailPathModel.oData[i];
      var massImageComp = "sap-icon://group";
      this.byId('ObjectPageLayoutHeaderTitle').setObjectImageURI(massImageComp);
      this.getMassApprovalDetails(selectedArr, selectedEmp);
     }
    }
   }
  },
  applySortingAndGroupingInd: function (groupPath) {
   var that = this;
   var sPath;
   var bDescending;
   var vGroup;
   var aSorters;
   var oBinding;
   if (that.getView().getModel("IndViewSetModel")) {
    var indViewSet = that.getView().getModel("IndViewSetModel").getData();
    oBinding = that.getView().byId("PendingEntriesTable").getBinding("items");
    that.byId("DateColumn").setMergeDuplicates(false);
    that.byId("AlreadyApprovedColumn").setMergeDuplicates(false);
    that.byId("TotalOnTargetColumn").setMergeDuplicates(false);
    // apply sorter to binding
    // (grouping comes before sorting)
    aSorters = [];
    //Grouping
    if (indViewSet.grouping === "true") {
     var gPath = indViewSet.gPath;
     var gDescending = indViewSet.gDescending;
     vGroup = that.mGroupFunctionsInd[gPath];
     aSorters.push(new sap.ui.model.Sorter(gPath, gDescending, vGroup));
    }
    //Sorting
    sPath = indViewSet.sPath;
    bDescending = indViewSet.bDescending;
    aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
    oBinding.sort(aSorters);
    that.byId("DateColumn").setMergeDuplicates(true);
    that.byId("AlreadyApprovedColumn").setMergeDuplicates(true);
    that.byId("TotalOnTargetColumn").setMergeDuplicates(true);
   } else {
    var oView = that.getView();
    var oTable = oView.byId("PendingEntriesTable");
    oBinding = oTable.getBinding("items");
    that.byId("DateColumn").setMergeDuplicates(false);
    that.byId("AlreadyApprovedColumn").setMergeDuplicates(false);
    that.byId("TotalOnTargetColumn").setMergeDuplicates(false);
    // apply sorter to binding
    // (grouping comes before sorting)
    if (groupPath) {
     sPath = groupPath;
    } else {
     sPath = "Workdate";
    }
    bDescending = false;
    aSorters = [];
    var oIndividualViewSettingsModel = new JSONModel({
     "grouping": "true",
     "gPath": sPath,
     "gDescending": bDescending,
     "sPath": sPath,
     "bDescending": bDescending
    });
    that.setModel(oIndividualViewSettingsModel, "IndViewSetModel");
    //Grouping
    vGroup = that.mGroupFunctionsInd[sPath];
    aSorters.push(new sap.ui.model.Sorter(sPath, bDescending, vGroup));
    //Sorting
    aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
    oBinding.sort(aSorters);
    that.byId("DateColumn").setMergeDuplicates(true);
    that.byId("AlreadyApprovedColumn").setMergeDuplicates(true);
    that.byId("TotalOnTargetColumn").setMergeDuplicates(true);
   }

   jQuery.sap.delayedCall(200, that, function () {
    try {
     that.oView.byId("PendingEntriesTable").getItems()[1].focus();
    } catch (noElement) {

    }
   });
  },
  getIndividualWorkItemApprovalDetails: function (workitem, empId) {
   var that = this;
   that.oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
   that.oDataDetailModel = this.getOwnerComponent().getModel();
   that.byId("PendingEntriesTable").setBusy(true);

   var a = new sap.ui.model.Filter({
    path: "EmployeeID",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: empId
   });
   var b = new sap.ui.model.Filter({
    path: "Workitemid",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: workitem
   });

   // Handle Concurrent Employee / Switch Personnel Assignment
   var sApproverPernr = this.getOwnerComponent().getModel("Pernr").getData();
   var oApproverPernrFilter = new sap.ui.model.Filter({
      path: "CATSAssignment",
      operator: sap.ui.model.FilterOperator.EQ,
      value1: sApproverPernr
     });

   var filter = [];

   filter.push(a);
   filter.push(b);

   // Push filter for Switch Personnel Assignment
   if( sApproverPernr ){
    filter.push(oApproverPernrFilter);
   }

   var mParameters = {
    filters: filter,
    success: function (oData, oResponse) {
     var timeTable = that.byId("PendingEntriesTable");
     timeTable.setVisible(true);
     var massTable = that.byId("MassApproval");
     massTable.setVisible(false);
     var date, date1, date2;
     for (var l = 0; l < oData.results.length; l++) {
      oData.results[l]['Attributes'] = ''; //Adding attributes property
      if (oData.results[l].CATSHours != 0) {
       oData.results[l].CATSAmount = oData.results[l].CATSHours;
      } else if (oData.results[l].CATSquantity != 0) {
       oData.results[l].CATSAmount = oData.results[l].CATSquantity;
      } else if (oData.results[l].CATSAmount != 0) {
       //Do nothing as CATSAmount field's value is shown
      } else {
       //Contains a zero hours record - so delete the entry from the result
       // oData.results.splice(l, 1);
       // Zero hour records are to be considered hence commenting the above code
      }
      try {
       date1 = new Date(oData.results[l].Workdate);
       date2 = new Date(date1.getUTCFullYear(), date1.getUTCMonth(), date1.getUTCDate());
       date = date2;
      } catch (o) {
       date = new Date(oData.results[l].Workdate);
      }
      oData.results[l].Workdate = date;
     }
     var oModel = new sap.ui.model.json.JSONModel(oData.results);
     that.getView().setModel(oModel, "IndividualApprovalModel");
     // that.applySortingAndGroupingInd();
     that.applySortingAndGroupingInd("EmployeeName");
     var timeEntriesText;
     if (oData.results.length === 1) {
      timeEntriesText = that.oBundle.getText("timeEntry");
     } else {
      timeEntriesText = that.oBundle.getText("timeEntries", [oData.results.length]);
     }
     that.byId("PendingTabTextId").setText(timeEntriesText);
     that.byId("PendingEntriesTable").setBusy(false);
    },
    error: function (oError) {
     that.byId("PendingEntriesTable").setBusy(false);
     that.processMessage(oError);
    }
   };
   that.oDataDetailModel
    .read(
     "/ApprovalDetailsSet",
     mParameters);
  },
  getWorkItemDetails: function (workitem, empId) {
   var that = this;

   var a = new sap.ui.model.Filter({
    path: "EmployeeID",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: empId
   });
   var b = new sap.ui.model.Filter({
    path: "Workitemid",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: workitem
   });

   // Handle Concurrent Employee / Switch Personnel Assignment
   var sApproverPernr = this.getOwnerComponent().getModel("Pernr").getData();
   var oApproverPernrFilter = new sap.ui.model.Filter({
      path: "CATSAssignment",
      operator: sap.ui.model.FilterOperator.EQ,
      value1: sApproverPernr
     });

   var filter = [];

   filter.push(a);
   filter.push(b);

   // Push filter for Switch Personnel Assignment
   if( sApproverPernr ){
    filter.push(oApproverPernrFilter);
   }

   that.oDataMassModel = this.getOwnerComponent().getModel();
   that.byId("MassApproval").setBusy(true);
   var mParametersMass = {
    filters: filter,
    success: function (oData, oResponse) {
     var massData = oData.results;
     var oMassModel = new sap.ui.model.json.JSONModel();
     var tempArr = [];
     var tempArrElement = [];
     var assignId, sumAmount = 0, sumMinutes = 0,
      sumTotal = 0;
     var g;
     for (g = 0; g < oData.results.length; g++) {
      if (assignId !== undefined && oData.results[g].AssignmentID !== assignId) {
       tempArrElement.CATSAmount = sumAmount + (sumMinutes / 60);
       tempArrElement.Total = sumTotal;
       var data = $.extend(true, {}, tempArrElement);
       tempArr.push(data);
       sumTotal = 0;
       sumAmount = 0;
       sumMinutes = 0;
      }
      assignId = oData.results[g].AssignmentID;
      tempArrElement.Counter = oData.results[g].Counter;
      tempArrElement.EmployeeID = oData.results[g].EmployeeID;
      tempArrElement.EmployeeName = oData.results[g].EmployeeName;
      tempArrElement.EmployeeRole = oData.results[g].EmployeeRole;
      tempArrElement.Total = oData.results[g].Total;
      tempArrElement.AssignmentID = oData.results[g].AssignmentID;
      tempArrElement.AssignmentText = oData.results[g].AssignmentText;

      if (oData.results[g].CATSHours !== 0) {
       tempArrElement.CATSAmount = 0; //oData.results[g].CATSHours;
       sumMinutes = sumMinutes + Math.round( parseFloat(oData.results[g].CATSHours, 10) * 60 );
      } else if (oData.results[g].CATSQuantity !== 0) {
       tempArrElement.CATSAmount = oData.results[g].CATSQuantity;
      } else {
       tempArrElement.CATSAmount = oData.results[g].CATSAmount;
      }

      sumAmount = sumAmount + parseFloat(tempArrElement.CATSAmount, 10);
      tempArrElement.UnitOfMeasure = oData.results[g].UnitOfMeasure;
      tempArrElement.Currency = oData.results[g].Currency;
      tempArrElement.Unit = oData.results[g].Unit;
      tempArrElement.Status = oData.results[g].Status;
      tempArrElement.Reason = oData.results[g].Reason;
      tempArrElement.DateCreate = oData.results[g].DateCreate;
      tempArrElement.TimeCreate = oData.results[g].TimeCreate;
      sumTotal = sumTotal + 1;
     }
     g--;

     tempArrElement.CATSAmount = sumAmount + (sumMinutes / 60); // Rounding off minutes to hours
     tempArrElement.Counter = oData.results[g].Counter;
     tempArrElement.EmployeeID = oData.results[g].EmployeeID;
     tempArrElement.EmployeeName = oData.results[g].EmployeeName;
     tempArrElement.EmployeeRole = oData.results[g].EmployeeRole;
     tempArrElement.Total = oData.results[g].Total;
     tempArrElement.AssignmentID = oData.results[g].AssignmentID;
     tempArrElement.AssignmentText = oData.results[g].AssignmentText;
     tempArrElement.UnitOfMeasure = oData.results[g].UnitOfMeasure;
     tempArrElement.Currency = oData.results[g].Currency;
     tempArrElement.Unit = oData.results[g].Unit;
     tempArrElement.Status = oData.results[g].Status;
     tempArrElement.Reason = oData.results[g].Reason;
     tempArrElement.DateCreate = oData.results[g].DateCreate;
     tempArrElement.TimeCreate = oData.results[g].TimeCreate;
     tempArrElement.Total = sumTotal;
     var pushData = $.extend(true, {}, tempArrElement);
     tempArr.push(pushData);
     var itemsText;
     if (massData.length) {
      massData = massData.concat(tempArr);
      oMassModel.setData(massData);
      if (massData.length === 1) {
       itemsText = that.oBundle.getText("itemForApproval");
      } else {
       itemsText = that.oBundle.getText("itemsForApproval", [massData.length]);
      }
     } else {
      oMassModel.setData(tempArr);
      if (tempArr.length === 1) {
       itemsText = that.oBundle.getText("itemForApproval");
      } else {
       itemsText = that.oBundle.getText("itemsForApproval", [tempArr.length]);
      }
     }
     that.byId("MassTabTextId").setText(itemsText);
     var timeTable = that.byId("PendingEntriesTable");
     timeTable.setVisible(false);
     that.setModel(oMassModel, "MassApprovalModel");
     that.setGlobalModel(oMassModel, "MassApprovalSharedModel");
     var massTable = that.byId("MassApproval");
     massTable.setVisible(true);
     var selectedEmployeesText = that.oBundle.getText("selectedEmployees");
     // that.byId("ApprovalDetailPage").setTitle(selectedEmployeesText + " (" + pSelectedIds.length + ")");
     var objHdr = that.byId("ObjectPageLayoutHeaderTitle");
     var empSelectedText;
     // if (pSelectedIds.length == 1) {
     //  empSelectedText = that.oBundle.getText("employeeSelected");
     // } else {
     //  empSelectedText = that.oBundle.getText("employeesSelected");
     // }
     // objHdr.setObjectTitle(pSelectedIds.length + " " + empSelectedText);
     objHdr.setObjectSubtitle("");
     that.byId("TeleTitleObjAttrId").setTitle("");
     that.byId("MailTitleObjAttrId").setTitle("");
     that.byId("TeleTitleObjAttrId").setText("");
     that.byId("MailTitleObjAttrId").setText("");
     that.applySortingAndGroupingMass();
     that.byId("MassApproval").setBusy(false);
    },
    error: function (oError) {
     that.byId("MassApproval").setBusy(false);
     that.processMessage(oError);
    }
   };
   that.oDataMassModel
    .read(
     "/MassApprovalSet",
     mParametersMass);
  },
  applySortingAndGroupingMass: function () {
   var that = this;
   if (that.getView().getModel("MassViewSetModel")) {
    var massViewSet = that.getView().getModel("MassViewSetModel").getData();
    var oBinding = that.getView().byId("MassApproval").getBinding("items");
    that.byId("MNameColumn").setMergeDuplicates(false);
    that.byId("MRoleColumn").setMergeDuplicates(false);
    that.byId("MTotalColumn").setMergeDuplicates(false);
    // apply sorter to binding
    // (grouping comes before sorting)
    var vGroup;
    var aSorters = [];
    //Grouping
    if (massViewSet.grouping === "true") {
     var gPath = massViewSet.gPath;
     var gDescending = massViewSet.gDescending;
     vGroup = that.mGroupFunctionsMass[gPath];
     aSorters.push(new sap.ui.model.Sorter(gPath, gDescending, vGroup));
    }
    //Sorting
    var sPath = massViewSet.sPath;
    var bDescending = massViewSet.bDescending;
    aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
    oBinding.sort(aSorters);
    that.byId("MNameColumn").setMergeDuplicates(true);
    that.byId("MRoleColumn").setMergeDuplicates(true);
    that.byId("MTotalColumn").setMergeDuplicates(false);
   } else {
    var oView = that.getView();
    var oTable = oView.byId("MassApproval");
    var oBinding = oTable.getBinding("items");
    that.byId("MNameColumn").setMergeDuplicates(false);
    that.byId("MRoleColumn").setMergeDuplicates(false);
    that.byId("MTotalColumn").setMergeDuplicates(false);
    // apply sorter to binding
    // (grouping comes before sorting)
    var sPath = "EmployeeName";
    var bDescending = false;
    var vGroup;
    var aSorters = [];
    var oMassViewSettingsModel = new JSONModel({
     "grouping": "true",
     "gPath": sPath,
     "gDescending": bDescending,
     "sPath": sPath,
     "bDescending": bDescending
    });
    that.setModel(oMassViewSettingsModel, "MassViewSetModel");
    //Grouping
    vGroup = that.mGroupFunctionsMass[sPath];
    aSorters.push(new sap.ui.model.Sorter(sPath, bDescending, vGroup));
    //Sorting
    aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
    oBinding.sort(aSorters);
    that.byId("MNameColumn").setMergeDuplicates(true);
    that.byId("MRoleColumn").setMergeDuplicates(true);
    that.byId("MTotalColumn").setMergeDuplicates(false);
   }
  },
  getIndividualApprovalDetails: function (pFilter) {
   var that = this;
   that.oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
   that.oDataDetailModel = this.getOwnerComponent().getModel();
   that.byId("PendingEntriesTable").setBusy(true);

   // Handle Concurrent Employee / Switch Personnel Assignment
   var sApproverPernr = this.getOwnerComponent().getModel("Pernr").getData(),
    sApprPernrFilter = "CATSAssignment" +  " eq '" + sApproverPernr + "'",
    sFilter = "";

   if (pFilter && sApproverPernr){
    sFilter = pFilter + " and " + sApprPernrFilter;
   } else if ( pFilter ){
    sFilter = pFilter;
   } else if ( sApproverPernr ){
    sFilter = sApprPernrFilter;
   }

   var oFilter = {
    "$filter": sFilter
   };

   var mParameters = {
    urlParameters: oFilter,
    success: function (oData, oResponse) {
     var timeTable = that.byId("PendingEntriesTable");
     timeTable.setVisible(true);
     var massTable = that.byId("MassApproval");
     massTable.setVisible(false);
     var date, date1, date2;
     for (var l = 0; l < oData.results.length; l++) {
      if (oData.results[l].CATSHours != 0) {
       oData.results[l].CATSAmount = oData.results[l].CATSHours;
      } else if (oData.results[l].CATSquantity != 0) {
       oData.results[l].CATSAmount = oData.results[l].CATSquantity;
      } else if (oData.results[l].CATSAmount != 0) {
       //Do nothing as CATSAmount field's value is shown
      } else {
       //Contains a zero hours record - so delete the entry from the result
       // oData.results.splice(l, 1);
       // Zero hour records are to be considered hence commenting the above code
      }
      try {
       date1 = new Date(oData.results[l].Workdate);
       date2 = new Date(date1.getUTCFullYear(), date1.getUTCMonth(), date1.getUTCDate());
       date = date2;
      } catch (o) {
       date = new Date(oData.results[l].Workdate);
      }
      oData.results[l].Workdate = date;
      oData.results[l].EmployeeID = parseInt(oData.results[0].EmployeeID, 10);
     }
     var oModel = new sap.ui.model.json.JSONModel(oData.results);
     that.getView().setModel(oModel, "IndividualApprovalModel");
     that.applySortingAndGroupingInd();
     var timeEntriesText;
     if (oData.results.length === 1) {
      timeEntriesText = that.oBundle.getText("timeEntry");
     } else {
      timeEntriesText = that.oBundle.getText("timeEntries", [oData.results.length]);
     }
     that.byId("PendingTabTextId").setText(timeEntriesText);
     that.byId("PendingEntriesTable").setBusy(false);
    },
    error: function (oError) {
     that.byId("PendingEntriesTable").setBusy(false);
     that.processMessage(oError);
    }
   };
   that.oDataDetailModel
    .read(
     "/ApprovalDetailsSet",
     mParameters);
  },
  getEmployeeDetails: function (eFilt) {
   var that = this;
   that.oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
   that.oDataEmployeeModel = this.getOwnerComponent().getModel();
   that.byId("ObjectPageLayout").setBusy(true);
   var oEmpFilter = {
    "$filter": eFilt
   };
   var mParametersEmp = {
    urlParameters: oEmpFilter,
    success: function (oData, oResponse) {
     var objHdr = that.byId("ObjectPageLayoutHeaderTitle");
     objHdr.setObjectTitle(oData.results[0].EmployeeName);
     that.byId("TeleTitleObjAttrId").setTitle(that.oBundle.getText("telephone"));
     that.byId("MailTitleObjAttrId").setTitle(that.oBundle.getText("email"));
     that.byId("TeleTitleObjAttrId").setText(oData.results[0].EmployeeTelephone);
     that.byId("MailTitleObjAttrId").setText(oData.results[0].EmployeeMailID);
     that.byId("ObjectPageLayout").setBusy(false);
    },
    error: function (oError) {
     that.byId("ObjectPageLayout").setBusy(false);
     that.processMessage(oError);
    }
   };
   that.oDataEmployeeModel
    .read(
     "/EmployeeDetailsSet",
     mParametersEmp);
  },
  getMassApprovalDetails: function (pSelectedIds, pLastEmployeeCheckbox) {
   var that = this;
   that.oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
   var massData = that.getGlobalModel("MassApprovalSharedModel").getData();
   var removeIndices = [];
   if (massData.length) {
    for (var n = 0; n < massData.length; n++) {
     if (pSelectedIds.indexOf(massData[n].EmployeeID) === -1) {
      removeIndices.push(n);
     }
    }
   }
   if (removeIndices) {
    for (var i = removeIndices.length - 1; i >= 0; i--) {
     massData.splice(removeIndices[i], 1);
    }
   }
   //Remove actual ungrouped values too
   var massActualData = that.getGlobalModel("MassApprovalActualModel").getData();
   var removeActualIndices = [];
   if (massActualData.length) {
    for (var r = 0; r < massActualData.length; r++) {
     if (pSelectedIds.indexOf(massActualData[r].EmployeeID) === -1) {
      removeActualIndices.push(r);
     }
    }
   }
   if (removeActualIndices) {
    for (var s = removeActualIndices.length - 1; s >= 0; s--) {
     massActualData.splice(removeActualIndices[s], 1);
    }
   }
   var oMassSharedModel = new sap.ui.model.json.JSONModel(massActualData);
   that.setGlobalModel(oMassSharedModel, "MassApprovalActualModel");

   if (pSelectedIds.indexOf(pLastEmployeeCheckbox) === -1) {
    pLastEmployeeCheckbox = "Unchecked";
    var oMassModelNew = new sap.ui.model.json.JSONModel(massData);
    that.setModel(oMassModelNew, "MassApprovalModel");
    that.setGlobalModel(oMassModelNew, "MassApprovalSharedModel");
    var timeTable = that.byId("PendingEntriesTable");
    timeTable.setVisible(false);
    var massTable = that.byId("MassApproval");
    massTable.setVisible(true);
    var selectedEmployeesText = that.oBundle.getText("selectedEmployees");
    that.byId("ApprovalDetailPage").setTitle(selectedEmployeesText + " (" + pSelectedIds.length + ")");
    var objHdr = that.byId("ObjectPageLayoutHeaderTitle");
    var empSelectedText = that.oBundle.getText("employeesSelected");
    objHdr.setObjectTitle(pSelectedIds.length + " " + empSelectedText);
    objHdr.setObjectSubtitle("");
    that.byId("TeleTitleObjAttrId").setTitle("");
    that.byId("MailTitleObjAttrId").setTitle("");
    that.byId("TeleTitleObjAttrId").setText("");
    that.byId("MailTitleObjAttrId").setText("");
    var itemCount = massData.length;
    if (!itemCount) {
     itemCount = 0;
    }
    var noItemsText = that.oBundle.getText("itemsForApproval", [itemCount]);
    that.byId("MassTabTextId").setText(noItemsText);
    that.applySortingAndGroupingMass();
   }
   if (pLastEmployeeCheckbox !== "Unchecked") {

    var filter = "EmployeeID eq '" + pLastEmployeeCheckbox + "'";

    // Handle Concurrent Employee / Switch Personnel Assignment
    var sApproverPernr = this.getOwnerComponent().getModel("Pernr").getData(),
     sApprPernrFilter = " and " + "AssignmentID" +  " eq '" + sApproverPernr + "'";
    if( sApproverPernr ){
     filter += sApprPernrFilter;
    }

    that.oDataMassModel = this.getOwnerComponent().getModel();
    that.byId("MassApproval").setBusy(true);
    var oMassFilter = {
     "$filter": filter
    };

    var mParametersMass = {
     urlParameters: oMassFilter,
     success: function (oData, oResponse) {
      var oPassActualModel = new sap.ui.model.json.JSONModel();

      if (massActualData.length) {
       massActualData = massActualData.concat(oData.results);
       oPassActualModel.setData(massActualData);
       that.setGlobalModel(oPassActualModel, "MassApprovalActualModel");
      } else {
       oPassActualModel.setData(oData.results);
       that.setGlobalModel(oPassActualModel, "MassApprovalActualModel");
      }

      var oMassModel = new sap.ui.model.json.JSONModel();
      var tempArr = [];
      var tempArrElement = [];
      var assignId, sumAmount = 0, sumMinutes = 0,
       sumTotal = 0;
      var g;

      for (g = 0; g < oData.results.length; g++) {

       if (assignId !== undefined && oData.results[g].AssignmentID !== assignId) {
        tempArrElement['Attributes'] = ''; //Adding attributes property
        tempArrElement.CATSAmount = sumAmount + (sumMinutes / 60);
        tempArrElement.Total = sumTotal;
        var data = $.extend(true, {}, tempArrElement);
        tempArr.push(data);
        sumTotal = 0;
        sumAmount = 0;
        sumMinutes = 0;
       }

       assignId = oData.results[g].AssignmentID;
       tempArrElement.Counter = oData.results[g].Counter;
       tempArrElement.EmployeeID = oData.results[g].EmployeeID;
       tempArrElement.EmployeeName = oData.results[g].EmployeeName;
       tempArrElement.EmployeeRole = oData.results[g].EmployeeRole;
       tempArrElement.Total = oData.results[g].Total;
       tempArrElement.AssignmentID = oData.results[g].AssignmentID;
       tempArrElement.AssignmentText = oData.results[g].AssignmentText;

       if (oData.results[g].CATSHours > 0) {
        tempArrElement.CATSAmount = 0; // oData.results[g].CATSHours;
        sumMinutes = sumMinutes + Math.round( parseFloat(oData.results[g].CATSHours, 10) * 60 );
       } else if (oData.results[g].CATSQuantity > 0) {
        tempArrElement.CATSAmount = oData.results[g].CATSQuantity;
       } else {
        tempArrElement.CATSAmount = oData.results[g].CATSAmount;
       }

       sumAmount = sumAmount + parseFloat(tempArrElement.CATSAmount, 10);

       tempArrElement.UnitOfMeasure = oData.results[g].UnitOfMeasure;
       tempArrElement.Currency = oData.results[g].Currency;
       tempArrElement.Unit = oData.results[g].Unit;
       tempArrElement.Status = oData.results[g].Status;
       tempArrElement.Reason = oData.results[g].Reason;
       tempArrElement.DateCreate = oData.results[g].DateCreate;
       tempArrElement.TimeCreate = oData.results[g].TimeCreate;
       sumTotal = sumTotal + 1;
      }

      g--;

      tempArrElement.CATSAmount = sumAmount + (sumMinutes / 60); // Rounding off minutes to hours
      tempArrElement.Counter = oData.results[g].Counter;
      tempArrElement.EmployeeID = oData.results[g].EmployeeID;
      tempArrElement.EmployeeName = oData.results[g].EmployeeName;
      tempArrElement.EmployeeRole = oData.results[g].EmployeeRole;
      tempArrElement.Total = oData.results[g].Total;
      tempArrElement.AssignmentID = oData.results[g].AssignmentID;
      tempArrElement.AssignmentText = oData.results[g].AssignmentText;
      tempArrElement.UnitOfMeasure = oData.results[g].UnitOfMeasure;
      tempArrElement.Currency = oData.results[g].Currency;
      tempArrElement.Unit = oData.results[g].Unit;
      tempArrElement.Status = oData.results[g].Status;
      tempArrElement.Reason = oData.results[g].Reason;
      tempArrElement.DateCreate = oData.results[g].DateCreate;
      tempArrElement.TimeCreate = oData.results[g].TimeCreate;
      tempArrElement.Total = sumTotal;
      var pushData = $.extend(true, {}, tempArrElement);
      tempArr.push(pushData);
      var itemsText;

      if (massData.length) {
       massData = massData.concat(tempArr);
       oMassModel.setData(massData);
       if (massData.length === 1) {
        itemsText = that.oBundle.getText("itemForApproval");
       } else {
        itemsText = that.oBundle.getText("itemsForApproval", [massData.length]);
       }
      } else {
       oMassModel.setData(tempArr);
       if (tempArr.length === 1) {
        itemsText = that.oBundle.getText("itemForApproval");
       } else {
        itemsText = that.oBundle.getText("itemsForApproval", [tempArr.length]);
       }
      }

      that.byId("MassTabTextId").setText(itemsText);
      var timeTable = that.byId("PendingEntriesTable");
      timeTable.setVisible(false);
      that.setModel(oMassModel, "MassApprovalModel");
      that.setGlobalModel(oMassModel, "MassApprovalSharedModel");
      var massTable = that.byId("MassApproval");
      massTable.setVisible(true);
      var selectedEmployeesText = that.oBundle.getText("selectedEmployees");
      that.byId("ApprovalDetailPage").setTitle(selectedEmployeesText + " (" + pSelectedIds.length + ")");
      var objHdr = that.byId("ObjectPageLayoutHeaderTitle");
      var empSelectedText;

      if (pSelectedIds.length == 1) {
       empSelectedText = that.oBundle.getText("employeeSelected");
      } else {
       empSelectedText = that.oBundle.getText("employeesSelected");
      }

      objHdr.setObjectTitle(pSelectedIds.length + " " + empSelectedText);
      objHdr.setObjectSubtitle("");
      that.byId("TeleTitleObjAttrId").setTitle("");
      that.byId("MailTitleObjAttrId").setTitle("");
      that.byId("TeleTitleObjAttrId").setText("");
      that.byId("MailTitleObjAttrId").setText("");
      that.applySortingAndGroupingMass();
      that.byId("MassApproval").setBusy(false);
     },
     error: function (oError) {
      that.byId("MassApproval").setBusy(false);
      that.processMessage(oError);
     }
    };
    that.oDataMassModel
     .read(
      "/MassApprovalSet",
      mParametersMass);
   }
  },
  performSingleApproval: function (selectedItems, apprStatus, rejReason, selectAll) {
   var that = this;
   that.oDataReturnCount = 0;
   var oErrorModelInit = new JSONModel({
    "EnableError": "true"
   });
   that.setModel(oErrorModelInit, "ErrorModel");
   that.oDataSingleApprModel = this.getOwnerComponent().getModel();
   that.byId("PendingEntriesTable").setBusy(true);
   that.oDataSingleApprModel.resetChanges();
   that.oDataSingleApprModel.setChangeBatchGroups({
    "*": {
     groupId: "SingleApproval",
     changeSetId: "SingleApproval",
     single: false
    }
   });
   that.oDataSingleApprModel.setDeferredGroups(["SingleApproval"]);
   that.oDataSingleApprModel
    .refreshSecurityToken(
     function (oData) {
      if (selectedItems.length > 0) {
       for (var j = 0; j < selectedItems.length; j++) {
        var obj = {
         properties: {
          EmployeeID: selectedItems[j].EmployeeId,
          Counter: selectedItems[j].Counter,
          Status: apprStatus,
          Reason: rejReason,
          DateCreate: selectedItems[j].DateCreate,
          TimeCreate: selectedItems[j].TimeCreate
         },
         success: function (oDataReturn) {
          that.oDataReturnCount++;
          if (that.oDataReturnCount == selectedItems.length) {
           var filt = "EmployeeID eq '" + selectedItems[j - 1].EmployeeId + "'";
           if (that.workitemid) {
            that.getIndividualWorkItemApprovalDetails(that.workitemid, that.empId);
           } else {
            that.getIndividualApprovalDetails(filt);
            that.getView().getModel("IndividualApprovalModel").refresh();
            var oEventBus = sap.ui.getCore().getEventBus();
            if (selectAll === "true") {
             oEventBus.publish("ApprovalDetail", "refreshAll");
            } else {
             oEventBus.publish("ApprovalDetail", "refreshMasterList");
            }
           }

          }
          that.byId("PendingEntriesTable").setBusy(false);
          if (apprStatus == "30") {
           var toastMsg = that.oBundle.getText("apprSuccess");
          } else if (apprStatus == "40") {
           var toastMsg = that.oBundle.getText("rejSuccess");
          }
          sap.m.MessageToast.show(toastMsg, {
           duration: 3000
          });

          /**
           * @ControllerHook Check the data returned and know that single approval is performed
           * This hook method can be used to modify the object before binding
           * It is called when the decision options for the detail item are fetched successfully
           * @callback hcm.mytimesheet.view.S3~extHookOnPerformSingleApproval
           * @param {object} Post Object
           * @return {object} Final Post Object
           */
          if (that.extHookOnPerformSingleApproval) {
           oDataReturn = that.extHookOnPerformSingleApproval(oDataReturn,apprStatus);
          }
         },
         error: function (oError) {
          var enable = that.getView().getModel("ErrorModel").getData().EnableError;
          if (enable === "true") {
           that.byId("PendingEntriesTable").setBusy(false);
           if (j == selectedItems.length) {
            var oErrorModel = new JSONModel({
             "EnableError": "false"
            });
            that.setModel(oErrorModel, "ErrorModel");
            var empFilter = "EmployeeID eq '" + selectedItems[j - 1].EmployeeId + "'";
            that.processMessage(oError, empFilter);
           }
          }
         },
         changeSetId: "SingleApproval",
         groupId: "SingleApproval"
        };
        that.oDataSingleApprModel
         .createEntry(
          "/ApprovalDetailsSet",
          obj);
       }
      }
      that.oDataSingleApprModel.submitChanges({
       groupId: "SingleApproval",
       changeSetId: "SingleApproval"
      });
     }, true);
  },
  performMassApproval: function (selectedEmps, apprStatus, rejReason) {
   var that = this;
   var oErrorModelInit = new JSONModel({
    "EnableError": "true"
   });
   that.setModel(oErrorModelInit, "ErrorModel");
   that.oDataMassApprModel = this.getOwnerComponent().getModel();
   that.byId("MassApproval").setBusy(true);
   that.oDataMassApprModel.resetChanges();
   that.oDataMassApprModel.setChangeBatchGroups({
    "*": {
     groupId: "MassApproval",
     changeSetId: "MassApproval",
     single: false
    }
   });
   that.results = [];
   var MassApprovalActualModel = this.getGlobalModel("MassApprovalActualModel");
   var entries = MassApprovalActualModel.oData;
   that.oDataMassApprModel.setDeferredGroups(["MassApproval"]);
   that.oDataMassApprModel
    .refreshSecurityToken(
     function (oData) {
      for (var j = 0; j < entries.length; j++) {
       var obj = {
        properties: {
         EmployeeID: entries[j].EmployeeID,
         Counter: entries[j].Counter,
         Reason: rejReason,
         Status: apprStatus,
         DateCreate: entries[j].DateCreate,
         TimeCreate: entries[j].TimeCreate
        },
        success: function (oDataReturn) {
         var oEventBus = sap.ui.getCore().getEventBus();
         oEventBus.publish("ApprovalDetail", "refreshAll");
         that.byId("MassApproval").setBusy(false);
         if (apprStatus == "30") {
          var toastMsg = that.oBundle.getText("apprSuccess");
         } else if (apprStatus == "40") {
          var toastMsg = that.oBundle.getText("rejSuccess");
         }
         sap.m.MessageToast.show(toastMsg, {
          duration: 3000
         });
         if (sap.ui.Device.system.phone === true) {
          that.getOwnerComponent().getRouter().navTo("master", {}, true);
         }

         /**
          * @ControllerHook Check the data returned and know that mass approval is performed
          * This hook method can be used to modify the object before binding
          * It is called when the decision options for the detail item are fetched successfully
          * @callback hcm.mytimesheet.view.S3~extHookOnPerformMassApproval
          * @param {object} Post Object
          * @return {object} Final Post Object
          */
         if (that.extHookOnPerformMassApproval) {
          oDataReturn = that.extHookOnPerformMassApproval(oDataReturn,apprStatus);
         }
        },
        error: function (oError) {
         var enable = that.getView().getModel("ErrorModel").getData().EnableError;
         if (enable === "true") {
          var oErrorModel = new JSONModel({
           "EnableError": "false"
          });
          that.setModel(oErrorModel, "ErrorModel");
          that.byId("MassApproval").setBusy(false);
          that.processMessage(oError);
         }
        },
        changeSetId: "MassApproval",
        groupId: "MassApproval"
       };
       that.oDataMassApprModel
        .createEntry(
         "/MassApprovalSet",
         obj);
      }
      that.oDataMassApprModel.submitChanges({
       groupId: "MassApproval",
       changeSetId: "MassApproval"
      });
     }, true);
  },
  onSelectCheckbox: function (oEvent) {
   var listId = this.byId("PendingEntriesTable");
   var listItems = listId.getItems();
   var selectedNum = 0;
   for (var i = 0; i < listItems.length; i++) {
    if (listItems[i].getProperty("selected")) {
     selectedNum += 1;
    }
   }
   if (selectedNum > 0) {
    this.byId("ApproveButton").setEnabled(true);
    this.byId("RejectButton").setEnabled(true);
   } else {
    this.byId("ApproveButton").setEnabled(false);
    this.byId("RejectButton").setEnabled(false);
   }
  },
  onNavBack: function () {
   var sPreviousHash = History.getInstance().getPreviousHash();
   if (sPreviousHash !== undefined) {
    history.go(-1);
   } else {
    this.getOwnerComponent().getRouter().navTo("master", {}, true);
   }
  },
  onPhoneClick: function (oEvent) {
   sap.m.URLHelper.triggerTel(oEvent.getSource().getText());
  },
  onEmailClick: function (oEvent) {
   sap.m.URLHelper.triggerEmail(oEvent.getSource().getText());
  },
  handleIndividualViewSettingsDialogButtonPressed: function (oEvent) {
   if (!this._oDialogInd) {
    this._oDialogInd = sap.ui.xmlfragment(this.getView().getId(),
     "hcm.fab.approve.timesheet.view.fragments.IndividualApprovalTableDialog",
     this);
    this.getView().addDependent(this._oDialogInd);
   }
   // toggle compact style
   jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialogInd);
   this._oDialogInd.open();
  },
  handleMassViewSettingsDialogButtonPressed: function (oEvent) {
   if (!this._oDialogMass) {
    this._oDialogMass = sap.ui.xmlfragment(this.getView().getId(), "hcm.fab.approve.timesheet.view.fragments.MassApprovalTableDialog",
     this);
    this.getView().addDependent(this._oDialogMass);
   }
   // toggle compact style
   jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialogMass);
   this._oDialogMass.open();
  },
  handleIndividualViewSettingsConfirm: function (oEvent) {
   var oView = this.getView();
   var oTable = oView.byId("PendingEntriesTable");
   var that = this;
   var mParams = oEvent.getParameters();
   var oBinding = oTable.getBinding("items");
   this.byId("DateColumn").setMergeDuplicates(false);
   this.byId("AlreadyApprovedColumn").setMergeDuplicates(false);
   this.byId("TotalOnTargetColumn").setMergeDuplicates(false);
   // apply sorter to binding
   // (grouping comes before sorting)
   var sPath;
   var gPath;
   var bDescending;
   var gDescending;
   var vGroup;
   var grouping = "false";
   var aSorters = [];
   if (mParams.groupItem) {
    grouping = "true";
    gPath = mParams.groupItem.getKey();
    gDescending = mParams.groupDescending;
    vGroup = this.mGroupFunctionsInd[gPath];
    aSorters.push(new sap.ui.model.Sorter(gPath, gDescending, vGroup));
   }
   sPath = mParams.sortItem.getKey();
   bDescending = mParams.sortDescending;
   var oIndividualViewSettingsModel = new JSONModel({
    "grouping": grouping,
    "gPath": gPath,
    "gDescending": gDescending,
    "sPath": sPath,
    "bDescending": bDescending
   });
   this.setModel(oIndividualViewSettingsModel, "IndViewSetModel");
   aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
   oBinding.sort(aSorters);
   this.byId("DateColumn").setMergeDuplicates(true);
   this.byId("AlreadyApprovedColumn").setMergeDuplicates(true);
   this.byId("TotalOnTargetColumn").setMergeDuplicates(true);
   if (gPath !== undefined) {
    var toastMsg = this.oBundle.getText("groupPrecedenceOverSort");
    sap.m.MessageToast.show(toastMsg, {
     duration: 3000
    });
   }
   jQuery.sap.delayedCall(200, that, function () {
    try {
     that.oView.byId("PendingEntriesTable").getItems()[1].focus();
    } catch (noElement) {

    }
   });

  },
  handleMassViewSettingsConfirm: function (oEvent) {
   this.byId("MNameColumn").setMergeDuplicates(false);
   this.byId("MRoleColumn").setMergeDuplicates(false);
   this.byId("MTotalColumn").setMergeDuplicates(false);
   var oView = this.getView();
   var oTable = oView.byId("MassApproval");
   var mParams = oEvent.getParameters();
   var oBinding = oTable.getBinding("items");
   // apply sorter to binding
   // (grouping comes before sorting)
   var sPath;
   var gPath;
   var bDescending;
   var gDescending;
   var vGroup;
   var grouping = "false";
   var aSorters = [];
   if (mParams.groupItem) {
    grouping = "true";
    gPath = mParams.groupItem.getKey();
    gDescending = mParams.groupDescending;
    vGroup = this.mGroupFunctionsMass[gPath];
    aSorters.push(new sap.ui.model.Sorter(gPath, gDescending, vGroup));
   }
   sPath = mParams.sortItem.getKey();
   bDescending = mParams.sortDescending;
   var oMassViewSettingsModel = new JSONModel({
    "grouping": grouping,
    "gPath": gPath,
    "gDescending": gDescending,
    "sPath": sPath,
    "bDescending": bDescending
   });
   this.setModel(oMassViewSettingsModel, "MassViewSetModel");
   aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
   oBinding.sort(aSorters);
   this.byId("MNameColumn").setMergeDuplicates(true);
   this.byId("MRoleColumn").setMergeDuplicates(true);
   this.byId("MTotalColumn").setMergeDuplicates(false);
   if (gPath !== undefined) {
    var toastMsg = this.oBundle.getText("groupPrecedenceOverSort");
    sap.m.MessageToast.show(toastMsg, {
     duration: 3000
    });
   }
  },
  formatTime: function (oTime) {
   if(!oTime){
    return "";
   }

   var timeParser = sap.ui.core.format.DateFormat.getTimeInstance({
    pattern: "HHmm"
   });
   var timeFormatter = sap.ui.core.format.DateFormat.getTimeInstance({
    style: "short"
   });
   // if (oTime === "000000") {
   //  return "00:00";
   // }
   oTime = timeParser.parse(oTime);
   oTime = timeFormatter.format(oTime);
   return oTime;
  },
  handleAlreadyApprovedLinkPress: function (oEvent) {
   var that = this;
   that.AlreadyApprovedSource = oEvent.getSource();
   var counterValue = oEvent.getSource().getParent().getCustomData()[0].getValue();
   var employeeValue = oEvent.getSource().getParent().getCustomData()[1].getValue();
   var workdateValue = oEvent.getSource().getParent().getCustomData()[4].getValue();
   // var oView = this.getView();
   var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
    pattern: "yyyy-MM-dd"
   });
   var oDateParameter = dateFormat.format(new Date(workdateValue));
   oDateParameter = oDateParameter + "T00:00:00";
   var a = new sap.ui.model.Filter({
    path: "Counter",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: counterValue
   });
   var b = new sap.ui.model.Filter({
    path: "EmployeeID",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: employeeValue
   });
   var c = new sap.ui.model.Filter({
    path: "Workdate",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: oDateParameter
   });
   var filter = [];
   filter.push(a);
   filter.push(b);
   filter.push(c);
   // that.oAlreadyApprovedQuickview = oView.byId("quickViewAssignment");
   that.oDataAlreadyApprovedModel = that.getOwnerComponent().getModel();
   var mParameters = {
    filters: filter,
    success: function (oData) {
     for (var l = 0; l < oData.results.length; l++) {
      if (oData.results[l].CATSHours != 0) {
       oData.results[l].CATSAmount = oData.results[l].CATSHours;
      } else if (oData.results[l].CATSquantity != 0) {
       oData.results[l].CATSAmount = oData.results[l].CATSquantity;
      }
     }
     var oAAModel = new sap.ui.model.json.JSONModel(oData.results);
     that.setModel(oAAModel, "AlreadyApprovedModel");
     var oButton = that.AlreadyApprovedSource;
     jQuery.sap.delayedCall(0, that, function () {
      that.oAlreadyApprovedQuickview.openBy(oButton);
     });
    },
    error: function (oError) {
     that.processMessage(oError);
    }
   };
   that.oDataAlreadyApprovedModel
    .read(
     "/ApprovalDetailsSet",
     mParameters);
   if (that.oAlreadyApprovedQuickview) {
    that.oAlreadyApprovedQuickview.close();
   }
   // create dialog lazily
   if (!that.oAlreadyApprovedQuickview) {
    // create dialog via fragment factory
    that.oAlreadyApprovedQuickview = sap.ui.xmlfragment(that.getView().getId(),
     "hcm.fab.approve.timesheet.view.fragments.AlreadyApprovedDialog",
     that);
    // connect dialog to view (models, lifecycle)
    that.getView().addDependent(that.oAlreadyApprovedQuickview);
   }
  },
  handleAssignmentLinkPress: function (oEvent) {
   var that = this;
   var pairObj = {
    customData: null,
    customParent: false,
    constructor: function (customData, customParent) {
     this.customData = customData;
     this.customParent = customParent;
     return this;
    }
   };
   var aCustomDataRef = oEvent.getSource().getCustomData().length == 0 ? new Object(pairObj).constructor(oEvent.getSource().getParent()
    .getCustomData(), true) : new Object(pairObj).constructor(oEvent.getSource()
    .getCustomData(), false);

   var counterValue;
   if (oEvent.getSource().getCustomData()[0] && oEvent.getSource().getCustomData()[0].getKey() === "counter") {
    // Invoked from Already approved popover
    counterValue = oEvent.getSource().getCustomData()[0].getProperty("value");
    that.assignmentText = oEvent.getSource().getCustomData()[1].getProperty("value");
   } else {
    //Invoked by clicking the Assignment hyperlink
    that.assignmentText = oEvent.getSource().getProperty("text");
    counterValue = oEvent.getSource().getParent().getCustomData()[0].getProperty("value");
   }
   try {
    for (var i in aCustomDataRef.customData) {
     if (aCustomDataRef.customData[i].getKey() === "workDate") {
      that.assignmentWorkDate = new Date(aCustomDataRef.customData[i].getValue());
      if (aCustomDataRef.customParent) {
       that.assignmentWorkDate.setDate(that.assignmentWorkDate.getDate() + 1);
      }
      continue;
     }
     if (aCustomDataRef.customData[i].getKey() === "vtken") {
      if (aCustomDataRef.customData[i].getValue() === "X") {
       that.assignmentPrevDay = true;
      } else {
       that.assignmentPrevDay = false;
      }
      continue;
     }

    }
   } catch (e) {
    that.assignmentPrevDay = false;
   }
   that.source = oEvent.getSource();
   var oView = this.getView();
   var aFilter = "Counter eq '" + counterValue + "'";
   var passFilter = {
    "$filter": aFilter
   };
   that.oQuickview = oView.byId("quickViewAssignment");
   that.oDataAssignmentModel = that.getOwnerComponent().getModel();
   var mAsParameters = {
    urlParameters: passFilter,
    success: function (oData) {
     oData.results[0].FieldText = that.getOwnerComponent().getModel("i18n").getResourceBundle().getText("name");
     oData.results[0].FieldValue = that.assignmentText;
     //Format options for Date
     var oDateFormatter = sap.ui.core.format.DateFormat.getDateInstance({
      style: "long"
     });

     //Handling Start Time and End Time display with formatting
     var startTimeIndex, endTimeIndex;
     for (var l = 0; l < oData.results.length; l++) {
      if (oData.results[l].FieldName === "BEGUZ") {
       startTimeIndex = l;
      }
      if (oData.results[l].FieldName === "ENDUZ") {
       endTimeIndex = l;
      }
     }
     if (that.mode === "MultiSelect") {
      //When both start time and end time fields are enabled
      if (startTimeIndex !== undefined && endTimeIndex !== undefined) {
       if (startTimeIndex > endTimeIndex) {
        oData.results.splice(startTimeIndex, 1);
        oData.results.splice(endTimeIndex, 1);
       } else if (endTimeIndex > startTimeIndex) {
        oData.results.splice(endTimeIndex, 1);
        oData.results.splice(startTimeIndex, 1);
       }
       startTimeIndex = endTimeIndex = undefined;
      }
      //When only start time field is enabled
      if (startTimeIndex !== undefined) {
       oData.results.splice(startTimeIndex, 1);
      }
      //When only end time field is enabled
      if (endTimeIndex !== undefined) {
       oData.results.splice(endTimeIndex, 1);
      }
     }
     if (startTimeIndex !== undefined && endTimeIndex !== undefined) {
      if (oData.results[startTimeIndex].FieldValue !== "000000") {
       if (oData.results[endTimeIndex].FieldValue === "000000") {
        oData.results[endTimeIndex].FieldValue = "240000";
       }
      }
      if (oData.results[endTimeIndex].FieldValue !== "000000") {
       if (oData.results[startTimeIndex].FieldValue === "000000") {
        oData.results[startTimeIndex].FieldValue = "240000";
       }
      }
     }
     var iniValBeguz = false;
     var iniValEnduz = false;
     for (var i = 0; i < oData.results.length; ++i) {
      if (oData.results[i].FieldName === "BEGUZ") {
       if (oData.results[i].FieldValue == 0) {
        iniValBeguz = true;
       }
      }
      if (oData.results[i].FieldName === "ENDUZ") {
       if (oData.results[i].FieldValue == 0) {
        iniValEnduz = true;
       }
      }
     }

     for (var i = 0; i < oData.results.length; i++) {
      if (oData.results[i].FieldName === "BEGUZ" || oData.results[i].FieldName === "ENDUZ") {
       if (!(iniValEnduz && iniValEnduz)) {
        oData.results[i].FieldValue = that.formatTime(oData.results[i].FieldValue) + " " + (that.assignmentPrevDay ? "(" +
         oDateFormatter.format(
          new Date(that.assignmentWorkDate)) + ")" : "");

       } else {
        oData.results.splice(i, 1);
        i--;
        continue;
       }
       continue;

      }

      if (oData.results[i].FieldValue == 0) {
       oData.results.splice(i, 1);
       i--;
       continue;
      } else {
       var sFieldName = oData.results[i].FieldName.toLowerCase();
       if ( !(sFieldName === 'vornr' || sFieldName === 'sebelp'  || sFieldName === 'beguz' || sFieldName === 'enduz') ) {
        oData.results[i].FieldValue = oData.results[i].FieldValue.replace(/^0+/, '');
       }

      }

     }
     if (that.mode === "MultiSelect") {
      var withoutPdi = $.grep(oData.results, function (n, i) {
       if (n.FieldName !== "VTKEN") {
        return true;
       }
      });
      oData.results = withoutPdi;
     }
     var oAsModel = new sap.ui.model.json.JSONModel(oData.results);
     var oObjectModel = new JSONModel({
      detailVisible: true,
      FormEntryVisible: false
     });
     that.setModel(oObjectModel, "ObjectProperties");
     if (that.mode === "MultiSelect" && oData.results[0].Noassign == "X") {
      that.getModel("ObjectProperties").setProperty("/detailVisible", false);
      that.getModel("ObjectProperties").setProperty("/FormEntryVisible", true);
     }
     that.setModel(oAsModel, "AssignmentDetailsModel");
     // that.oQuickview.getPages()[0].setTitle(that.assignmentText);
     var oButton = that.source;
     jQuery.sap.delayedCall(0, that, function () {
      that.oQuickview.openBy(oButton);
     });
    },
    error: function (oError) {
     that.processMessage(oError);
    }
   };
   that.oDataAssignmentModel
    .read("/ApprovalFieldsSet", mAsParameters);
   if (that.oQuickview) {
    that.oQuickview.close();
   }
   // create dialog lazily
   if (!that.oQuickview) {
    // create dialog via fragment factory
    that.oQuickview = sap.ui.xmlfragment(that.getView().getId(), "hcm.fab.approve.timesheet.view.fragments.AssignmentDetailsDialog",
     that);
    // connect dialog to view (models, lifecycle)
    that.getView().addDependent(that.oQuickview);
   }
  },
  handleGetAttributes: function (counterValue, sAttributeType) {
   var that = this;
   that.oDataAssignmentModel = that.getOwnerComponent().getModel();
   var oView = this.getView();
   // var aFilter = "Counter eq '" + counterValue + "'";
   // var passFilter = {
   //  "$filter": aFilter
   // };

   var a = new sap.ui.model.Filter({
    path: "Counter",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: counterValue
   });
   var b = new sap.ui.model.Filter({
    path: "Attributes",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: sAttributeType
   });

   var filters = [];
   filters.push(a);
   filters.push(b);
   return new Promise(function (fnResovle, fnReject) {
    var mAsParameters = {
     filters: filters,
     success: function (oData) {
      var oFinalResults = [];
      for (var i = 0; i < oData.results.length; i++) {
       if (oData.results[i].FieldName.toLowerCase() === 'beguz' || oData.results[
         i].FieldName.toLowerCase() === 'enduz') {
        oData.results[i].FieldValue = that.formatTime(oData.results[i].FieldValue);
       }
       oFinalResults.push(oData.results[i]);

      }

      fnResovle(oFinalResults);
     },
     error: function (oError) {
      that.processMessage(oError);
     }
    };
    that.oDataAssignmentModel
     .read("/ApprovalFieldsSet", mAsParameters);

   }.bind(this));

  },
  fireGetDataMassApproval: function (oEvent) {
   var that = this;
   var iNumberEntries = 80;
   var FORM_ENTRY_COUNTER = '00000000';
   var sChangeReason = oEvent.getParameters("reason");
   var actual = 0;
   if (sChangeReason === "Growing") //If growing event is triggered 
   {
    actual = oEvent.getParameter("actual");
   }
   this.actual = actual;

   var aIndices = oEvent.getSource().getBindingInfo('items').binding.aIndices;
   var oData = that.getModel("MassApprovalModel").getData();

   var approveData = $.map(aIndices, function (oVal) {
    //Special Handling for form entry case
    if (oData[oVal].AssignmentID === "111.0000000 ") {
     return {
      Counter: FORM_ENTRY_COUNTER
     };
    }
    return {
     Counter: oData[oVal].Counter
    };
   });
   if (approveData.length === 0) {
    return;
   }
   this.getView().setBusy(true);

   var list = [];
   var arrofPromise = [];

   for (var i = actual; i <= actual + iNumberEntries && i < approveData.length; i++) {
    list.push(i);
   }
   list.forEach(function (val, index) {
    if (Number(approveData[val].Counter) === 0) {
     //Form Entry Scenario
     arrofPromise.push(new Promise(function (resolve, reject) {
      resolve([{
       Counter: '00000000',
       FieldName: "Form_Entry",
       FieldText: "This is a form entry"
      }]);
     }));
    } else {
     arrofPromise.push(that.handleGetAttributes(approveData[val].Counter, "M"));  // 'M' for MassApproval Selection mode
    }

   });

   Promise.all(arrofPromise).then(function (values) {

    var approveData = that.getModel("MassApprovalModel").getData();
    var objOfCounter = {};
    for (var i = 0; i < values.length; i++) {
     objOfCounter[values[i][0].Counter] = values[i];
    }

    for (var i = 0; i < approveData.length; i++) {
     var sCounter = approveData[i].Counter;

     if (objOfCounter[sCounter] || approveData[i].AssignmentID === "111.0000000 ") {
      if (approveData[i].AssignmentID === "111.0000000 ") {
       that.getModel('MassApprovalModel').setProperty("/" + i + "/" + 'Attributes', that.oBundle.getText(
        'detailInfoFormEntryAttributes'));
       continue;
      }
      else if (approveData[i].AssignmentID === "") {
       that.getModel('MassApprovalModel').setProperty("/" + i + "/" + 'Attributes', that.oBundle.getText(
        'detailInfoNoAssignmentAttributes'));
       continue;
      }
      var sAttributes = "";

      for (var j = 0; j < objOfCounter[sCounter].length; j++) {

       var sFieldName = objOfCounter[sCounter][j].FieldName.toLowerCase();

       //Checking for Initial Field
       if (sFieldName === "initial") {
        continue;
       }
       var bTextFieldExist = false;
       var bIsLastfield = false; //Comma is required

       if (j === objOfCounter[sCounter].length - 1) {
        bIsLastfield = true;
       }

       //Using field text if enabled otherwise key is used
       // === === =
       // //Text field exist
       // >>> >>> > refs / heads / master

       var sValue = objOfCounter[sCounter][j].FieldValue;

       if (sValue == 0) {
        continue;
       } else {                              
        if ( !(sFieldName === 'vornr' || sFieldName === 'sebelp'  || sFieldName === 'beguz' || sFieldName === 'enduz') ) {
         sValue = sValue.replace(/^0+/, '');
        }

        sAttributes = sAttributes + sValue + (bIsLastfield === false ? ', ' : ''); //added one extra space after each comma
       }

      }

      var index = sAttributes.length - 2;
      while (index >= 0 && sAttributes.length >= 0 && sAttributes.charAt(index) === ',') {
       sAttributes = sAttributes.slice(0, -2);
       index--;
      }

      that.getModel('MassApprovalModel').setProperty("/" + i + "/" + 'Attributes', sAttributes);

     }
    }

    that.getView().setBusy(false);
   });

  },

  fireGetData: function (oEvent) {
   var that = this;
   var iNumberEntries = 40;
   var sChangeReason = oEvent.getParameter("reason");
   var actual = 0;
   if (sChangeReason === "Growing") //If growing event is triggered 
   {
    actual = oEvent.getParameter("actual");
   }
   this.actual = actual;
   this.getView().setBusy(true);
   var aIndices = oEvent.getSource().getBindingInfo('items').binding.aIndices;
   var oData = that.getModel("IndividualApprovalModel").getData();

   var approveData = $.map(aIndices, function (oVal) {
    return {
     Counter: oData[oVal].Counter
    };
   });

   var list = [];
   var arrofPromise = [];

   for (var i = actual; i <= actual + iNumberEntries && i < approveData.length; i++) {
    list.push(i);
   }
   list.forEach(function (val, index) {

    arrofPromise.push(that.handleGetAttributes(approveData[val].Counter, "I"));   // 'I' for Individual selection mode 
   });

   Promise.all(arrofPromise).then(function (values) {
    var approveData = that.getModel('IndividualApprovalModel').getData();

    var objOfCounter = {};
    for (var i = 0; i < values.length; i++) {
     objOfCounter[values[i][0].Counter] = values[i];
    }

    for (var i = 0; i < approveData.length; i++) {
     var sCounter = approveData[i].Counter;

     if (objOfCounter[sCounter]) {
      var sAttributes = "";
      for (var j = 0; j < objOfCounter[sCounter].length; j++) {

       var sFieldName = objOfCounter[sCounter][j].FieldName.toLowerCase();
       //Checking for Initial Field
       if (sFieldName === "initial") {
        continue;
       }

       var bIsLastfield = false; //Comma is required

       if (j === objOfCounter[sCounter].length - 1) {
        bIsLastfield = true;
       }

       //Using field text if enabled otherwise key is used
       // === === =
       // //Text field exist
       // >>> >>> > refs / heads / master

       var sValue = objOfCounter[sCounter][j].FieldValue;

       if (sValue == 0) {
        continue;
       } else {

        if ( !(sFieldName === 'vornr' || sFieldName === 'sebelp' || sFieldName === 'beguz' || sFieldName === 'enduz') ) {
         sValue = sValue.replace(/^0+/, '');
        }
        sAttributes = sAttributes + sValue + (bIsLastfield === false ? ', ' : '');   // added one extra space after each comma
       }

      }

      var index = sAttributes.length - 2;
      while (index >= 0 && sAttributes.length >= 0 && sAttributes.charAt(index) === ',') {
       sAttributes = sAttributes.slice(0, -2);
       index--;
      }
      that.getModel('IndividualApprovalModel').setProperty("/" + i + "/" + 'Attributes', sAttributes);
     }
    }

    that.getView().setBusy(false);
   });

  },

  onReject: function () {
   var that = this;
   var oView = this.getView();
   that.oDialog = oView.byId("RejectReasonDialogId");
   that.selectedItems = [];
   that.selected = [];
   //Fetch the selected time entry counters
   var tabRef = this.byId("PendingEntriesTable");
   var oItems = tabRef.getItems();
   for (var i = 0; i < oItems.length; i++) {
    if (oItems[i].getProperty("selected") === true) {
     that.selected.Counter = oItems[i].getCustomData()[0].getValue();
     that.selected.EmployeeId = oItems[i].getCustomData()[1].getValue().toString();
     that.selected.DateCreate = oItems[i].getCustomData()[2].getValue();
     that.selected.TimeCreate = oItems[i].getCustomData()[3].getValue();
     var data = $.extend(true, {}, that.selected);
     that.selectedItems.push(data);
    }
   }
   that.selectAll = "false";
   if (oItems.length === that.selectedItems.length) {
    that.selectAll = "true";
   }

   if (that.selectedItems.length) {
    var oEmployeeFeatureMap = that.getGlobalModel("GlobalEmployeeFeatureMap").getData();
    var bMandatoryRejReason = false;
    var sEmpID = that.selectedItems[0].EmployeeId.padStart(8, "0"); // Add padding to get actual pernr

    if( oEmployeeFeatureMap[sEmpID] ){
     bMandatoryRejReason = oEmployeeFeatureMap[sEmpID].IsRejectReasonMandatory;
    }

    that.getModel("FeatureControlModel").setProperty("/IsRejectReasonMandatory", bMandatoryRejReason);
    that.getModel("FeatureControlModel").setProperty("/IsRejectConfirmButtonEnabled", !bMandatoryRejReason); // Set to false initially before getting reasons for selection if reason is mandatory

    that.oDataRejModel = that.getOwnerComponent().getModel();
    var mRejParameters = {
     success: function (oData) {
      var oRejModel = new sap.ui.model.json.JSONModel(oData.results);
      that.getView().setModel(oRejModel, "RejectionReasonModel");
     },
     error: function (oError) {
      that.processMessage(oError);
     }
    };

    that.oDataRejModel
     .read("/RejectionReasonSet", mRejParameters);
    // create dialog lazily
    if (!that.oDialog) {
     var oDialogController = {
      onRejectConfirm: function (evnt) {
       var rejListRef = that.byId("RejectReasonList");
       if (rejListRef.getSelectedItem() !== null) {
        var reasonCode = rejListRef.getSelectedItem().getCustomData()[0].getProperty("value");
       } else {
        // Validation for mandatory reject reason
        if( that.getModel("FeatureControlModel").getProperty("/IsRejectReasonMandatory") === true ){
         sap.m.MessageToast.show( that.oBundle.getText("RejectionReasonsMandatoryMessage"), { duration: 3000 });
         return; 
        }
       }

       that.performSingleApproval(that.selectedItems, "40", reasonCode, that.selectAll);
       // Disable Approve and Reject button after Approval/Rejection
       that.byId("ApproveButton").setEnabled(false); 
       that.byId("RejectButton").setEnabled(false);
       that.oDialog.close();
      },

      onSelectChangeRejectReason: function (oEvent) {
       var oFeature = that.getModel("FeatureControlModel");
       oFeature.setProperty("/IsRejectConfirmButtonEnabled", true);

       if( oEvent.getSource().getSelectedItems().length === 0 && oFeature.getProperty("/IsRejectReasonMandatory") ){
        oFeature.setProperty("/IsRejectConfirmButtonEnabled", false);
       }
      },

      onCancel: function (evnt) {
       that.oDialog.close();
      }
     };
     // create dialog via fragment factory
     that.oDialog = sap.ui.xmlfragment(that.getView().getId(), "hcm.fab.approve.timesheet.view.fragments.RejectionReasonDialog",
      oDialogController);
     // connect dialog to view (models, lifecycle)
     that.getView().addDependent(that.oDialog);
    }
    jQuery.sap.syncStyleClass("sapUiSizeCompact", that.getView(), that.oDialog);
    that.oDialog.open();
   } else {
    var toastMsg = that.oBundle.getText("noSelectionMade");
    sap.m.MessageToast.show(toastMsg, {
     duration: 3000
    });
   }
  },
  onRejectAll: function () {
   var that = this;
   that.oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
   var detailPathModel = this.getGlobalModel("exchangeModel");
   that.selectedArr = [];
   if (sap.ui.Device.system.phone === true) {
    for (var i = 1; i <= detailPathModel.oData.length - 1; i++) {
     that.selectedArr[i - 1] = detailPathModel.oData[i];
    }
   } else {
    for (var i = 1; i <= detailPathModel.oData.length - 1; i++) {
     that.selectedArr[i - 1] = detailPathModel.oData[i];
    }
   }
   if (that.selectedArr.length) {

    var oEmployeeFeatureMap = that.getGlobalModel("GlobalEmployeeFeatureMap").getData();
    var bMandatoryRejReason = false;
    var sEmpID;

    // Check if atleast one selected employee has mandatory reject reason enabled.....
    for( var ind = 0; ind < that.selectedArr.length; ++ind){
     sEmpID = that.selectedArr[ind].padStart(8, "0"); // Add padding to get actual pernr
     if( oEmployeeFeatureMap[sEmpID] ){
      bMandatoryRejReason = oEmployeeFeatureMap[sEmpID].IsRejectReasonMandatory;
     }

     if( bMandatoryRejReason === true ){
      break;
     }
    }

    that.getModel("FeatureControlModel").setProperty("/IsRejectReasonMandatory", bMandatoryRejReason);
    that.getModel("FeatureControlModel").setProperty("/IsRejectConfirmButtonEnabled", !bMandatoryRejReason); // Set to false initially before getting reasons for selection if reason is mandatory

    that.oDataRejModel = that.getOwnerComponent().getModel();
    var mRejParameters = {
     success: function (oData) {
      var oRejModel = new sap.ui.model.json.JSONModel(oData.results);
      that.getView().setModel(oRejModel, "RejectionReasonModel");
     },
     error: function (oError) {
      that.processMessage(oError);
     }
    };
    that.oDataRejModel
     .read("/RejectionReasonSet", mRejParameters);
    // create dialog lazily
    if (!that.oDialog) {
     var oDialogController = {
      onRejectConfirm: function (evnt) {
       var rejListRef = that.byId("RejectReasonList");
       if (rejListRef.getSelectedItem() !== null) {
        var reasonCode = rejListRef.getSelectedItem().getCustomData()[0].getProperty("value");
       } else {
        // Validation for mandatory reject reason
        if( that.getModel("FeatureControlModel").getProperty("/IsRejectReasonMandatory") === true ){
         sap.m.MessageToast.show( that.oBundle.getText("RejectionReasonsMandatoryMessage"), { duration: 3000 });
         return;
        }
       }

       that.performMassApproval(that.selectedArr, "40", reasonCode);
       that.oDialog.close();
      },

      onSelectChangeRejectReason: function (oEvent) {
       var oFeature = that.getModel("FeatureControlModel");
       oFeature.setProperty("/IsRejectConfirmButtonEnabled", true);

       if( oEvent.getSource().getSelectedItems().length === 0 && oFeature.getProperty("/IsRejectReasonMandatory") ){
        oFeature.setProperty("/IsRejectConfirmButtonEnabled", false);
       }
      },

      onCancel: function (evnt) {
       that.oDialog.close();
      }
     };
     // create dialog via fragment factory
     that.oDialog = sap.ui.xmlfragment(that.getView().getId(), "hcm.fab.approve.timesheet.view.fragments.RejectionReasonDialog",
      oDialogController);
     // connect dialog to view (models, lifecycle)
     that.getView().addDependent(that.oDialog);
    }
    jQuery.sap.syncStyleClass("sapUiSizeCompact", that.getView(), that.oDialog);
    that.oDialog.open();
   } else {
    var toastMsg = that.oBundle.getText("noSelectionMade");
    sap.m.MessageToast.show(toastMsg, {
     duration: 3000
    });
   }
  },
  onApprove: function () {
   var that = this;
   var selectedItems = [];
   var selected = [];
   //Fetch the selected time entry counters
   var tabRef = this.byId("PendingEntriesTable");
   var oItems = tabRef.getItems();
   for (var i = 0; i < oItems.length; i++) {
    if (oItems[i].getProperty("selected") == true) {
     selected.Counter = oItems[i].getCustomData()[0].getValue();
     selected.EmployeeId = oItems[i].getCustomData()[1].getValue().toString();
     selected.DateCreate = oItems[i].getCustomData()[2].getValue();
     selected.TimeCreate = oItems[i].getCustomData()[3].getValue();
     var data = $.extend(true, {}, selected);
     selectedItems.push(data);
    }
   }
   var selectAll = "false";
   if (oItems.length === selectedItems.length) {
    selectAll = "true";
   }
   if (selectedItems.length) {
    that.performSingleApproval(selectedItems, "30", "", selectAll);
    // Disable Approve and Reject button after Approval/Rejection
    that.byId("ApproveButton").setEnabled(false);
    that.byId("RejectButton").setEnabled(false);
   } else {
    var toastMsg = that.oBundle.getText("noSelectionMade");
    sap.m.MessageToast.show(toastMsg, {
     duration: 3000
    });
   }
  },
  onApproveAll: function () {
   var that = this;
   that.oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
   var detailPathModel = this.getGlobalModel("exchangeModel");
   var selectedArr = [];
   if (sap.ui.Device.system.phone === true) {
    for (var i = 1; i <= detailPathModel.oData.length - 1; i++) {
     selectedArr[i - 1] = detailPathModel.oData[i];
    }
   } else {
    for (var i = 1; i <= detailPathModel.oData.length - 1; i++) {
     selectedArr[i - 1] = detailPathModel.oData[i];
    }
   }
   if (selectedArr.length) {
    this.performMassApproval(selectedArr, "30", "");
   } else {
    var toastMsg = that.oBundle.getText("noSelectionMade");
    sap.m.MessageToast.show(toastMsg, {
     duration: 3000
    });
   }
  },
  displayLongtext: function (oEvent) {
   // create popover
   var oDialogController = {};
   this._oPopover = sap.ui.xmlfragment(this.getView().getId(), "hcm.fab.approve.timesheet.view.fragments.LongTextDialog",
    oDialogController);
   this.getView().addDependent(this._oPopover);
   this._oPopover.bindElement('IndividualApprovalModel>' + oEvent.getSource().getBindingContext('IndividualApprovalModel').getPath());
   // }
   // delay because addDependent will do a async rerendering and the popover will immediately close without it
   var oButton = oEvent.getSource();
   jQuery.sap.delayedCall(0, this, function () {
    this._oPopover.openBy(oButton);
   });
  },
  displayHistory: function (oEvent) {
   var CapturedSource = oEvent.getSource();
   var that = this;
   var sPath = oEvent.getSource().getBindingContext('IndividualApprovalModel').getPath().split("/")[1];
   var rec = this.getModel('IndividualApprovalModel').getData()[sPath];
   this.oDataDetailModel = this.getOwnerComponent().getModel();
   var c = new sap.ui.model.Filter({
    path: "Counter",
    operator: sap.ui.model.FilterOperator.EQ,
    value1: rec.Refcounter
   });
   var filter = [];
   filter.push(c);
   var mParameters = {
    filters: filter,
    success: function (oData, oResponse) {
     var oDialogController = {
      handleClose: function (evnt) {
       that._oDialogIndHistory.close();
      },
      formatter: that.formatter,
      self: that
     };
     if (!that._oDialogIndHistory) {
      that._oDialogIndHistory = sap.ui.xmlfragment(that.getView().getId(),
       "hcm.fab.approve.timesheet.view.fragments.HistoryDetails",
       oDialogController);
      that.getView().addDependent(that._oDialogIndHistory);
     }
     //Handing Time zone dependent display issue
     var date, date1, date2;
     for (var l = 0; l < oData.results.length; l++) {
      try {
       date1 = new Date(oData.results[l].Workdate);
       date2 = new Date(date1.getUTCFullYear(), date1.getUTCMonth(), date1.getUTCDate());
       date = date2;
      } catch (o) {
       date = new Date(oData.results[l].Workdate);
      }
      oData.results[l].Workdate = date;
      try {
       date1 = new Date(oData.results[l].DateCreate);
       date2 = new Date(date1.getUTCFullYear(), date1.getUTCMonth(), date1.getUTCDate());
       date = date2;
      } catch (o) {
       date = new Date(oData.results[l].DateCreate);
      }
      oData.results[l].DateCreate = date;
      try {
       date1 = new Date(oData.results[l].DateChange);
       date2 = new Date(date1.getUTCFullYear(), date1.getUTCMonth(), date1.getUTCDate());
       date = date2;
      } catch (o) {
       date = new Date(oData.results[l].DateChange);
      }
      oData.results[l].DateChange = date;
      if (oData.results[l].ApprovalDate !== null) {
       try {
        date1 = new Date(oData.results[l].ApprovalDate);
        date2 = new Date(date1.getUTCFullYear(), date1.getUTCMonth(), date1.getUTCDate());
        date = date2;
       } catch (o) {
        date = new Date(oData.results[l].ApprovalDate);
       }
       oData.results[l].ApprovalDate = date;
      }
     }
     var oModel = new sap.ui.model.json.JSONModel(oData.results);
     that.setModel(oModel, "HistoryModel");
     // toggle compact style
     jQuery.sap.syncStyleClass("sapUiSizeCompact", that.getView(), that._oDialogIndHistory);
     that._oDialogIndHistory.open(CapturedSource);
    },
    error: function (oError) {
     that.byId("PendingEntriesTable").setBusy(false);
     that.processMessage(oError);
    }
   };
   this.oDataDetailModel
    .read(
     "/ApprovalDetailsSet",
     mParameters);

  },
  processMessage: function (oError, filt) {
   var that = this;
   var errorObj = JSON.parse(oError.responseText).error;
   var errorSet = errorObj.innererror.errordetails;
   var messageHeader = errorSet[0].message;
   var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
   sap.m.MessageBox.information(
    messageHeader, {
     styleClass: bCompact ? "sapUiSizeCompact" : "",
     onClose: function () {
      if (filt !== undefined) {
       that.getIndividualApprovalDetails(filt);
       that.getView().getModel("IndividualApprovalModel").refresh();
      } else if (sap.ui.Device.system.phone === true) {
       //mass approval mode error in mobile screen
       that.getOwnerComponent().getRouter().navTo("master", {}, true);
      }
      var oEventBus = sap.ui.getCore().getEventBus();
      oEventBus.publish("ApprovalDetail", "refreshAll");
     }
    }
   );
  },
  initPersonalization: function () {
   var that = this;
   if (sap.ushell.Container) {
    var oPendingTable = this.byId("PendingEntriesTable");
    var oMassTable = this.byId("MassApproval");
    this.oPendingTable = oPendingTable;
    this.oMassTable = oMassTable;
    var oPersonalizationService = sap.ushell.Container.getService("Personalization");
    var oPendingTabPersonalizer = oPersonalizationService.getPersonalizer({
     container: "hcm.fab.approve.timesheet", // This key must be globally unique (use a key to identify the app) -> only 40 characters are allowed
     item: "PendingEntriesTable" // Maximum of 40 characters applies to this key as well
    });
    var oMassTabPersonalizer = oPersonalizationService.getPersonalizer({
     container: "hcm.fab.approve.timesheet", // This key must be globally unique (use a key to identify the app) -> only 40 characters are allowed
     item: "MassApproval" // Maximum of 40 characters applies to this key as well
    });
    this.oTablePendingPersoController = new TablePersoController({
     table: oPendingTable,
     componentName: "ApproveTimesheet",
     persoService: oPendingTabPersonalizer
    }).activate();
    this.oTableMassPersoController = new TablePersoController({
     table: oMassTable,
     componentName: "ApproveTimesheet",
     persoService: oMassTabPersonalizer
    }).activate();

    if (sap.ui.Device.system.phone === true) {
     that.oTablePendingPersoController.getPersoService().getPersData().done(function (data) {
      that.setPendingEntriesTableColumns(data);

     });
     that.oTablePendingPersoController.getTablePersoDialog().attachConfirm(function (oEvent) {
      that.oTablePendingPersoController.getPersoService().getPersData().done(function (data) {
       that.setPendingEntriesTableColumns(data);
      });
     });

     that.oTableMassPersoController.getPersoService().getPersData().done(function (data) {
      that.setMassApprovalColumns(data);

     });
     that.oTableMassPersoController.getTablePersoDialog().attachConfirm(function (oEvent) {
      that.oTableMassPersoController.getPersoService().getPersData().done(function (data) {
       that.setMassApprovalColumns(data);
      });
     });
    }

   }
  },

  setPendingEntriesTableColumns: function (data) {
   var that = this;
   if (data) {
    try {
     var minOrder = Number.MAX_SAFE_INTEGER;
     for (var i = 0; i < data.aColumns.length; i++) {
      if (data.aColumns[i].visible) {
       minOrder = Math.min(minOrder, data.aColumns[i].order);
      }
     }
     if (minOrder === Number.MAX_SAFE_INTEGER) {
      minOrder = 0;
     }
     var oOrderedColumn = $.grep(data.aColumns, function (oval) {
      if (oval.order === minOrder) {
       return true;
      }
      return false;

     });
     var sId = oOrderedColumn[0].id.split('-')[oOrderedColumn[0].id.split('-').length - 1];
     var oTable = that.byId("PendingEntriesTable");
     oTable.getColumns().forEach(function (oVal, index) {
      var sIdColumn = oVal.getId().split('--')[oVal.getId().split('--').length - 1];
      if (sIdColumn === sId) {
       oVal.setDemandPopin(false);
       oVal.setMinScreenWidth("Phone");
       oVal.setPopinDisplay("Inline");
      } else {
       oVal.setDemandPopin(true);
       oVal.setMinScreenWidth("Desktop");
       oVal.setPopinDisplay("Inline");
      }

     });
     that.byId("PendingEntriesTable").updateBindings();

    } catch (e) {

    }
   } else {
    var oTable = that.byId("PendingEntriesTable");
    var firstColumn = true;
    var oPendingTableReset = that.oPendingTable;
    oPendingTableReset.getColumns().forEach(function (oVal, index) {
     oVal.setVisible(true);
    });
    this.oTablePendingPersoController.removeAllTables();
    this.oTablePendingPersoController.setTable(oPendingTableReset);
    oTable.getColumns().forEach(function (oVal, index) {
     if (firstColumn) {
      oVal.setDemandPopin(false);
      oVal.setMinScreenWidth("Phone");
      oVal.setPopinDisplay("Inline");
      firstColumn = false;
     } else {
      oVal.setDemandPopin(true);
      oVal.setMinScreenWidth("Desktop");
      oVal.setPopinDisplay("Inline");
     }
    });
    that.byId("PendingEntriesTable").updateBindings();
   }
  },

  setMassApprovalColumns: function (data) {
   var that = this;
   if (data) {
    try {
     var minOrder = Number.MAX_SAFE_INTEGER;
     for (var i = 0; i < data.aColumns.length; i++) {
      if (data.aColumns[i].visible) {
       minOrder = Math.min(minOrder, data.aColumns[i].order);
      }
     }
     if (minOrder === Number.MAX_SAFE_INTEGER) {
      minOrder = 0;
     }
     var oOrderedColumn = $.grep(data.aColumns, function (oval) {
      if (oval.order === minOrder) {
       return true;
      }
      return false;

     });
     var sId = oOrderedColumn[0].id.split('-')[oOrderedColumn[0].id.split('-').length - 1];
     var oTable = that.byId("MassApproval");
     oTable.getColumns().forEach(function (oVal, index) {
      var sIdColumn = oVal.getId().split('--')[oVal.getId().split('--').length - 1];
      if (sIdColumn === sId) {
       oVal.setDemandPopin(false);
       oVal.setMinScreenWidth("Phone");
       oVal.setPopinDisplay("Inline");
      } else {
       oVal.setDemandPopin(true);
       oVal.setMinScreenWidth("Desktop");
       oVal.setPopinDisplay("Inline");
      }

     });
     that.byId("MassApproval").updateBindings();

    } catch (e) {

    }
   } else {
    var oTable = that.byId("MassApproval");
    var firstColumn = true;
    var oMassTableReset = that.oMassTable;
    oMassTableReset.getColumns().forEach(function (oVal, index) {
     oVal.setVisible(true);
    });
    this.oTableMassPersoController.removeAllTables();
    this.oTableMassPersoController.setTable(oMassTableReset);
    oTable.getColumns().forEach(function (oVal, index) {
     if (firstColumn) {
      oVal.setDemandPopin(false);
      oVal.setMinScreenWidth("Phone");
      oVal.setPopinDisplay("Inline");
      firstColumn = false;
     } else {
      oVal.setDemandPopin(true);
      oVal.setMinScreenWidth("Desktop");
      oVal.setPopinDisplay("Inline");
     }

    });
    that.byId("MassApproval").updateBindings();
   }
  },
  onPersPendingButtonPressed: function (oEvent) {
   this.oTablePendingPersoController.openDialog();
  },
  onPersMassButtonPressed: function (oEvent) {
   this.oTableMassPersoController.openDialog();
  }
 });
});
